/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Categoria = 'Cerveja' | 'NAB' | 'Marketplace';
export type CurvaABC = 'A' | 'B' | 'C';

// Relatório 02.05.02 — Estoque Atual
export interface EstoqueAtual {
  sku: string;
  descricao: string;
  custoMedio: number;
  fatorEmbalagem: number; // Quantidade de unidades por caixa
  fatorHectolitro: number; // Volume em hectolitros (HL) por caixa/unidade
  quantidadeAtualCaixas: number; // Estoque sistêmico principal em caixas
}

// Guia "Inventário" — Confronto Físico x Fiscal (De acordo com conciliação)
export interface InventarioItem {
  sku: string;
  estoqueFisicoCaixas: number;
  estoqueSistemaCaixas: number;
  vendaOntemCaixas?: number; // Venda de ontem extraída do documento
}

// Guia "Caixas Pallet"
export interface CaixaPallet {
  sku: string;
  caixasPorPallet: number;
}

// Relatório 03.05.19 — Venda Média Últimos 3 Meses
export interface VendaMedia {
  sku: string;
  vendaMensalMediaCaixas: number;
}

// Relatório Auxiliar de Entradas Fiscais Futuras (Previsões de recebimento)
export interface EntradaFiscalFutura {
  id: string;
  sku: string;
  descricao: string;
  dataPrevisao: string;
  quantidadeCaixas: number;
  chaveNotaFiscal: string;
  fornecedor: string;
  valorTotal: number;
  status: 'Pendente' | 'Recebido' | 'Cancelado';
}

// Controle Futuro: Gestão de Validade / FEFO / Abastecimento
export interface LoteValidade {
  id: string;
  sku: string;
  numeroLote: string;
  dataFabricacao: string;
  dataValidade: string;
  quantidadeCaixas: number;
  diasParaVencer: number;
  alertaStatus: 'Normal' | 'Atenção' | 'Crítico'; // Atenção < 60 dias, Crítico < 30 dias
  rua?: string;
  posicaoRef?: string;
  nivel?: number;
  dataEntrada?: string;
  dataUltimaMovimentacao?: string;
}

export interface PickingMapeamento {
  sku: string;
  capacidadeCaixas: number;
  saldoAtualCaixas: number;
  pontoRessuprimentoCaixas: number; // Alerta de reabastecimento
}

// Registro compilado por SKU consolidando todas as informações
export interface ProdutoConsolidado {
  sku: string;
  descricao: string;
  categoria: Categoria;
  custoMedio: number;
  fatorEmbalagem: number;
  fatorHectolitro: number;
  
  // Novos campos obrigatórios do Cadastro de Produtos
  fornecedor?: string;
  marca?: string;
  peso?: number; // em kg
  volume?: number; // em litros por SKU
  status?: 'Ativo' | 'Inativo';

  // Estoque atual & financeiro (Calculados)
  quantidadeAtualCaixas: number; // Estoque após saldo ajustado
  quantidadeTotalUnitario: number; // quantidadeAtualCaixas * fatorEmbalagem
  valorTotalEstoque: number; // quantidadeAtualCaixas * custoMedio (valor por caixa)
  volumeHectolitro: number; // quantidadeAtualCaixas * fatorHectolitro

  // Inventário e Conciliação
  estoqueFisicoCaixas: number;
  estoqueSistemaCaixas: number;
  saldoAjustadoCaixas: number; // novo saldo físico vira o saldo final ajustado
  diferencaCaixas: number; // estoqueFisicoCaixas - estoqueSistemaCaixas
  divergenciaHectolitro: number;
  divergenciaValor: number;
  temDivergencia: boolean;

  // Palletização
  caixasPorPallet: number;
  quantidadePallets: number; // quantidadeAtualCaixas / caixasPorPallet

  // Vendas / Pareto
  vendaMensalMediaCaixas: number;
  vendaOntemCaixas?: number; // Venda específica do dia anterior (Coluna K)
  porcentagemVolumeAcumulado?: number; // Calculado no Pareto
  curvaABC?: CurvaABC; // A, B, C baseados em Pareto
}

// Posicionamento WMS
export interface WmsPosicao {
  id: string; // ex: CD-A01-01 (Armazém Central Corridor A, Prateleira 1, Nível 1)
  area: 'Central' | 'Picking' | 'Paredão' | 'Marketing e Vendas';
  rua: string; // R1, R2, R3... ou A1..C4
  modulo: number;
  nivel: number;
  skuAlocado: string | null;
  capacidadePallets: number;
  palletsAlocados: number;
  idadePallet?: number;
  stockAgeIndex?: number;
}
