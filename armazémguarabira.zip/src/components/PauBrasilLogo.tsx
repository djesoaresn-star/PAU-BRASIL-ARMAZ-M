import React from 'react';

interface PauBrasilLogoProps {
  width?: number;
  height?: number;
  showText?: boolean;
  isDarkBg?: boolean; // Permite alternar de acordo com a seção do CD (painel escuro ou relatório claro)
  className?: string;
}

export function PauBrasilLogo({ 
  width = 46, 
  height = 46, 
  showText = true, 
  isDarkBg = true, 
  className = "" 
}: PauBrasilLogoProps) {
  // Cor oficial da marca Pau Brasil Ambev: #2D489A
  const brandBlue = "#2D489A";
  
  return (
    <div className={`flex items-center gap-3.5 ${className}`} id="pau-brasil-brand-group">
      {/* Ícone vetorizado de altíssima fidelidade - Balão com Árvore Pau Brasil estilizada idêntica à imagem */}
      <div className="relative shrink-0 select-none" style={{ width, height }} id="pau-brasil-brand-logo-container">
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-md"
        >
          {/* Formato oficial do balão de localização redondo com cauda pontiaguda no canto esquerdo inferior */}
          <path
            d="M50 10 C72.09 10 90 27.91 90 50 C90 71.07 73.7 88.33 53.05 89.85 C51.48 89.97 49 92 46.5 94.5 C43 98 35 91.5 35 91.5 C35 91.5 24 87.5 17.5 81 C11.5 75 10 67 10 50 C10 27.91 27.91 10 50 10 Z"
            fill={brandBlue}
          />
          
          {/* Monte de terra / morro branco curvo no fundo (Crescent hill do logo oficial) */}
          <path
            d="M26 73 C38 67 62 67 74 73 C71 77 62 82 50 82 C38 82 29 77 26 73 Z"
            fill="white"
          />

          {/* Tronco da árvore central com ramificações elegantes */}
          <path
            d="M50 73 L50 51"
            stroke="white"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M50 63 C46 59 44 55 42 52"
            stroke="white"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          <path
            d="M50 60 C54 56 56 52 59 49"
            stroke="white"
            strokeWidth="3.2"
            strokeLinecap="round"
          />

          {/* Copa de linhas onduladas rabiscadas horizontais (Scribbled Look), idêntica à logomarca */}
          {/* Tapering elegante e denso de baixo para cima */}
          <path
            d="M28 58 Q50 49 72 58"
            stroke="white"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          <path
            d="M31 51 Q50 42 69 51"
            stroke="white"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          <path
            d="M34 45 Q50 36 66 45"
            stroke="white"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          <path
            d="M37 39 Q50 31 63 39"
            stroke="white"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M41 33 Q50 26 59 33"
            stroke="white"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          <path
            d="M44 28 Q50 22 56 28"
            stroke="white"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <path
            d="M47 23 Q50 18 53 23"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col leading-none select-none font-sans" id="pau-brasil-brand-logo-text">
          <div className="flex items-baseline antialiased">
            {/* "PAU" é mais fino e "BRASIL" é pesado (Bold/Black) */}
            <span 
              className={`text-base tracking-wider uppercase`}
              style={{ 
                fontWeight: 300, 
                letterSpacing: '0.07em',
                color: isDarkBg ? '#F8FAFC' : brandBlue
              }}
            >
              PAU
            </span>
            <span 
              className={`text-base tracking-tighter uppercase`}
              style={{ 
                fontWeight: 900, 
                letterSpacing: '-0.02em', 
                color: isDarkBg ? '#FFFFFF' : brandBlue,
                marginLeft: '0.12em'
              }}
            >
              BRASIL
            </span>
          </div>
          {/* Subtítulo "distribuidora ambev" fiel à marca */}
          <div 
            className={`text-[9px] tracking-tight antialiased mt-0.5 whitespace-nowrap`}
            style={{ 
              color: isDarkBg ? '#94A3B8' : brandBlue,
              fontFamily: 'Inter, sans-serif'
            }}
          >
            <span style={{ fontWeight: 300 }}>distribuidora </span>
            <span style={{ fontWeight: 800 }}>ambev</span>
          </div>
        </div>
      )}
    </div>
  );
}

