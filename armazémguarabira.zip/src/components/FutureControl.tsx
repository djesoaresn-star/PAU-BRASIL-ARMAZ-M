/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { 
  Building2, 
  Calendar, 
  Clock, 
  RefreshCw, 
  TrendingDown, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Sparkles,
  ArrowRight,
  Gauge,
  Package,
  Layers,
  Archive,
  AlertCircle,
  Truck,
  HeartCrack,
  FolderSync,
  Download,
  UploadCloud,
  FileText,
  Check,
  X,
  Plus
} from 'lucide-react';
import { 
  LoteValidade, 
  PickingMapeamento, 
  ProdutoConsolidado, 
  EntradaFiscalFutura,
  WmsPosicao
} from '../types';

interface FutureControlProps {
  produtos: ProdutoConsolidado[];
  lotes: LoteValidade[];
  picking: PickingMapeamento[];
  entradasFuturas: EntradaFiscalFutura[];
  layout: WmsPosicao[];
  onReplenishPicking: (sku: string, qtd: number) => Promise<void>;
  onQuarantineBatch: (loteId: string) => Promise<void>;
  onReceiveFutureEntry: (entryId: string) => Promise<void>;
  onImportState?: (payload: any) => Promise<void>;
}

export default function FutureControl({
  produtos,
  lotes,
  picking,
  entradasFuturas,
  layout,
  onReplenishPicking,
  onQuarantineBatch,
  onReceiveFutureEntry,
  onImportState
}: FutureControlProps) {
  
  // Estado para filtragem rápida de validades
  const [validadeFiltro, setValidadeFiltro] = useState<'TODOS' | 'CRITICO' | 'ATENÇÃO'>('TODOS');
  const [loadingAction, setLoadingAction] = useState<string | null>(null);

  // Estados do Planejador de Separação / Picking FEFO integrado ao WMS
  const [selectedFefoSku, setSelectedFefoSku] = useState<string>("");
  const [pickQuantity, setPickQuantity] = useState<number>(50);

  // Filtro de nível para a Central de Alertas Operacionais
  const [filtroAlertaOperacional, setFiltroAlertaOperacional] = useState<'ALL' | 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');

  // Estados de Importação do Excel (Arraste o documento)
  const [isDragging, setIsDragging] = useState(false);
  const [previewLotes, setPreviewLotes] = useState<LoteValidade[] | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [isImporting, setIsImporting] = useState(false);

  // Helper date parsing robusto para Excel
  const parseExcelDate = (val: any): string => {
    if (!val) return new Date().toISOString().split('T')[0];
    if (val instanceof Date) {
      return val.toISOString().split('T')[0];
    }
    if (typeof val === 'number') {
      try {
        // Tratar serial Excel (ex: 46377 representa datas de 2026/2027)
        const date = new Date((val - 25569) * 86400 * 1000);
        if (!isNaN(date.getTime())) {
          return date.toISOString().split('T')[0];
        }
      } catch (e) {
        console.warn("Falha ao converter serial date:", val);
      }
    }
    if (typeof val === 'string') {
      const trimmed = val.trim();
      const parts = trimmed.split('/');
      if (parts.length === 3) {
        let [d, m, y] = parts;
        if (y.length === 2) y = "20" + y;
        return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
      }
      const isYmd = /^\d{4}-\d{2}-\d{2}$/.test(trimmed);
      if (isYmd) return trimmed;
    }
    return new Date().toISOString().split('T')[0];
  };

  // Helper para buscar colunas de forma flexível (fuzzy header match)
  const findColumnValue = (row: any, keys: string[]): any => {
    for (const rawKey of Object.keys(row)) {
      const key = rawKey.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
      if (keys.some(k => key === k || key.includes(k))) {
        return row[rawKey];
      }
    }
    return undefined;
  };

  // Função para processar arquivo Excel
  const processDocumentExcel = (file: File) => {
    setFileName(file.name);
    setImportError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonRows = XLSX.utils.sheet_to_json(worksheet);

        if (!jsonRows || jsonRows.length === 0) {
          throw new Error("A planilha Excel carregada está vazia ou ilegível.");
        }

        const parsed: LoteValidade[] = jsonRows.map((row: any, index: number) => {
          const rawSku = findColumnValue(row, ['sku', 'codigo', 'cod', 'produto', 'id']);
          const skuNorm = String(rawSku || '').trim().padStart(8, '0');

          const rawDesc = findColumnValue(row, ['descricao', 'desc', 'produto', 'nome', 'mercadoria', 'nome do produto']) || '';

          const rawVal = findColumnValue(row, ['validade', 'data', 'expiration', 'venc', 'vencimento', 'exp', 'data de validade']);
          const dateVal = parseExcelDate(rawVal);

          const rawQtd = findColumnValue(row, ['quantidade', 'qtd', 'volume', 'caixas', 'peso', 'saldo', 'total', 'caixas no lote', 'cases']);
          const caixas = Math.max(1, Math.round(Number(rawQtd) || 80));

          const loteNum = String(findColumnValue(row, ['lote', 'numero', 'lote no', 'num', 'lote codigo', 'batch']) || `LT-EXCEL-${skuNorm}-${index + 1}`);
          const rua = String(findColumnValue(row, ['rua', 'corredor', 'corredor wms', 'canal', 'localizacao', 'posicao', 'coluna']) || 'A1');
          const nivel = Number(findColumnValue(row, ['nivel', 'altura', 'level'])) || 1;
          const posicaoRef = String(findColumnValue(row, ['posicaoref', 'posicao', 'local', 'endereco', 'loc', 'posis']) || `${rua}-M01-N${nivel}`);

          const currentDays = Math.max(0, Math.round((new Date(dateVal).getTime() - Date.now()) / (1000 * 60 * 60 * 24)));

          return {
            id: `L0IMP_${skuNorm}_${index + 1}_${Date.now()}`,
            sku: skuNorm,
            numeroLote: loteNum,
            dataFabricacao: new Date().toISOString().split('T')[0],
            dataValidade: dateVal,
            quantidadeCaixas: caixas,
            diasParaVencer: currentDays,
            alertaStatus: currentDays <= 30 ? 'Crítico' : currentDays <= 60 ? 'Atenção' : 'Normal',
            rua: rua.toUpperCase(),
            nivel,
            posicaoRef: posicaoRef.toUpperCase()
          };
        });

        setPreviewLotes(parsed);
      } catch (err: any) {
        setImportError(err.message || 'Erro inesperado na leitura do arquivo Excel.');
        setPreviewLotes(null);
      }
    };
    reader.onerror = () => {
      setImportError('Erro técnico ao abrir o arquivo físico do documento.');
      setPreviewLotes(null);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        processDocumentExcel(file);
      } else {
        setImportError('Tipo de arquivo não suportado. Por favor, arraste um documento Excel (.xlsx ou .xls).');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      processDocumentExcel(file);
    }
  };

  // Envia os lotes analisados para salvar na plataforma
  const handleSaveImportedLotes = async () => {
    if (!previewLotes || previewLotes.length === 0 || !onImportState) return;
    setIsImporting(true);
    try {
      // Salva os lotes na base ativa da plataforma
      await onImportState({ lotesValidade: previewLotes });
      setPreviewLotes(null);
      setFileName(null);
    } catch (e: any) {
      setImportError("Erro ao sincronizar os dados processados com o banco de dados.");
    } finally {
      setIsImporting(false);
    }
  };

  // Cancela ou remove a planilha atual importada
  const handleCancelImport = () => {
    setPreviewLotes(null);
    setFileName(null);
    setImportError(null);
  };

  // Exportação inteligente de Validades e Alertas Operacionais para planilha Excel
  const handleExportToExcel = () => {
    // Transforma os dados em colunas limpas, didáticas e profissionais
    const dataToExport = lotes.map((lote) => {
      const prod = mappedProdutos.get(lote.sku);
      return {
        'Lote N°': lote.numeroLote,
        'Código SKU': lote.sku,
        'Descrição SKU': prod?.descricao || 'Produto Cadastrado',
        'Rua Corredor': lote.rua || 'A1',
        'Nível Vertical': lote.nivel || 1,
        'Posição de Endereço': lote.posicaoRef || '',
        'Data de Validade': lote.dataValidade,
        'Restam Dias': lote.diasParaVencer,
        'Quantidade Caixas': lote.quantidadeCaixas,
        'Status Alerta': lote.alertaStatus === 'Normal' ? 'Normal (Vencimento OK)' : lote.alertaStatus === 'Atenção' ? 'Atenção (<60 dias)' : 'Crítico (<30 dias)'
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    
    // Auto-ajusta a largura das colunas
    const maxColsWidth = Object.keys(dataToExport[0] || {}).map((key) => {
      return { wch: Math.max(key.length + 3, 14) };
    });
    worksheet['!cols'] = maxColsWidth;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Validades CD FEFO');

    // Salva o arquivo no formato Excel XLSX
    XLSX.writeFile(workbook, `WMS_CONTROLER_VALIDADES_FEFO_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Baixar modelo limpo para preencher
  const handleDownloadExcelTemplate = () => {
    const templateRows = [
      {
        'Lote N°': 'LOT-EMBALADOS-A1',
        'Código SKU': '00020164',
        'Descrição': 'SUKITA 2L',
        'Rua Corredor': 'A1',
        'Nível Vertical': 2,
        'Posição de Endereço': 'A1-M02-N2',
        'Data de Validade': '2026-12-19',
        'Quantidade Caixas': 240
      },
      {
        'Lote N°': 'LOT-EMBALADOS-B1',
        'Código SKU': '00013061',
        'Descrição': 'H2OH LIMONETO PET 500ML',
        'Rua Corredor': 'B1',
        'Nível Vertical': 1,
        'Posição de Endereço': 'B1-M01-N1',
        'Data de Validade': '2026-08-27',
        'Quantidade Caixas': 640
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Modelo Validades');
    XLSX.writeFile(workbook, `WMS_MODELO_IMPORTACAO_VALIDADES.xlsx`);
  };

  // Cria dicionário rápido para buscar descrição do SKU
  const mappedProdutos = useMemo(() => {
    const map = new Map<string, ProdutoConsolidado>();
    produtos.forEach((p) => map.set(p.sku, p));
    return map;
  }, [produtos]);

  // 1. Central Unificada de Auditoria e Alertas Operacionais WMS
  const monitoramentoAlertas = useMemo(() => {
    const list: Array<{
      id: string;
      level: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
      title: string;
      description: string;
      suggestion: string;
      icon: React.ReactNode;
    }> = [];

    // Nível Crítico: Quebra FEFO Picking x Estoque
    const skusUnicosInAtivo = Array.from(new Set(lotes.map(l => l.sku)));
    
    skusUnicosInAtivo.forEach(sku => {
      const prod = mappedProdutos.get(sku);
      const skuLotes = lotes.filter(l => l.sku === sku && l.quantidadeCaixas > 0);
      if (skuLotes.length === 0) return;

      // Picking lots (Nível 1 ou posição explicitamente Picking)
      const pickingLots = skuLotes.filter(l => l.nivel === 1 || l.posicaoRef?.includes('-N1'));
      // Pulmão/racks verticais (Nível > 1 ou central)
      const pulmaoLots = skuLotes.filter(l => l.nivel && l.nivel > 1);

      if (pickingLots.length > 0 && pulmaoLots.length > 0) {
        const oldestPulmao = [...pulmaoLots].sort((a,b) => a.diasParaVencer - b.diasParaVencer)[0];
        const newestPicking = [...pickingLots].sort((a,b) => b.diasParaVencer - a.diasParaVencer)[0];

        if (oldestPulmao.diasParaVencer < newestPicking.diasParaVencer) {
          list.push({
            id: `crit-fefo-${sku}`,
            level: 'CRITICAL',
            title: `Erro Crítico: Quebra FEFO Picking x Estoque Pulmão`,
            description: `Quebra Operacional de Giro: SKU [${sku.replace(/^0+/, '')}] possui lote mais antigo ${oldestPulmao.numeroLote} (${oldestPulmao.diasParaVencer} dias p/ vencer) parado em rack vertical (${oldestPulmao.posicaoRef}), enquanto o lote posterior mais novo e fresco ${newestPicking.numeroLote} (${newestPicking.diasParaVencer} dias p/ vencer) está exposto na posição de Picking térreo (${newestPicking.posicaoRef}).`,
            suggestion: `Ordem de Remanejamento Urgente: Mover o lote antigo ${oldestPulmao.numeroLote} do rack para o Picking térreo (${newestPicking.posicaoRef}) e recolher o lote novo para o Pulmão.`,
            icon: <ShieldAlert className="w-5 h-5 text-rose-600" />
          });
        }
      }
    });

    // Nível Alto: Validade antiga em rua distante (Quebra FEFO Estoque x Estoque)
    // Cores de prioridade de corredores logísticos para o ranking de proximidade
    const ruasRanking = ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "CB1", "CB2", "CB3", "CB4", "C1", "C2", "C3", "C4"];
    
    skusUnicosInAtivo.forEach(sku => {
      const skuLotes = lotes.filter(l => l.sku === sku && l.quantidadeCaixas > 0 && l.rua);
      if (skuLotes.length < 2) return;

      for (let i = 0; i < skuLotes.length; i++) {
        for (let j = 0; j < skuLotes.length; j++) {
          if (i === j) continue;
          const lot1 = skuLotes[i];
          const lot2 = skuLotes[j];

          const rank1 = ruasRanking.indexOf(lot1.rua || "");
          const rank2 = ruasRanking.indexOf(lot2.rua || "");

          if (rank1 !== -1 && rank2 !== -1) {
            // Se lot1 vence ANTES do lot2, mas está guardado em corredor geograficamente mais longe (ranking maior)
            if (lot1.diasParaVencer < lot2.diasParaVencer && rank1 > rank2) {
              const alreadyAdded = list.some(item => item.id === `high-fefo-${sku}`);
              if (!alreadyAdded) {
                list.push({
                  id: `high-fefo-${sku}`,
                  level: 'HIGH',
                  title: `Erro de Alocação: Validade Antiga em Rua Distante`,
                  description: `Quebra FEFO Estoque x Estoque: O lote prioritário ${lot1.numeroLote} (${lot1.diasParaVencer} dias p/ vencer) do SKU [${sku.replace(/^0+/, '')}] foi estocado na rua distante ${lot1.rua} (ranking d${rank1 + 1}), enquanto o lote mais novo e fresco ${lot2.numeroLote} (${lot2.diasParaVencer} dias) foi posicionado na rua mais próxima ${lot2.rua} (ranking d${rank2 + 1}).`,
                  suggestion: `Ação Preventiva: Programar o próximo faturamento corporativo para descarregar o pallet diretamente no corredor ${lot1.rua} primeiro.`,
                  icon: <AlertTriangle className="w-5 h-5 text-orange-500" />
                });
              }
            }
          }
        }
      }
    });

    // Nível Médio: Próximo do vencimento (<30 ou <60 dias no lote ativo)
    lotes.forEach(l => {
      if (l.quantidadeCaixas <= 0) return;
      if (l.diasParaVencer <= 30) {
        list.push({
          id: `med-cr-${l.id}`,
          level: 'MEDIUM',
          title: `Lote Próximo do Vencimento Crítico (<30 dias)`,
          description: `Risco de Baixa Física: O lote ${l.numeroLote} do SKU [${l.sku.replace(/^0+/, '')}] expira em apenas ${l.diasParaVencer} dias (${l.dataValidade}). Contém ${l.quantidadeCaixas} caixas ativas na posição vertical ${l.posicaoRef || 'central'}.`,
          suggestion: `Forçar Escoamento: Mover o lote imediatamente para a área do 'Paredão' ou gerar saldos de bonificação de vendas com desconto de validade.`,
          icon: <AlertCircle className="w-5 h-5 text-amber-500" />
        });
      } else if (l.diasParaVencer <= 60) {
        list.push({
          id: `med-at-${l.id}`,
          level: 'MEDIUM',
          title: `Aviso de Validade Intermediária (<60 dias)`,
          description: `Giro Requerido: Lote ${l.numeroLote} do SKU [${l.sku.replace(/^0+/, '')}] expira daqui a ${l.diasParaVencer} dias (${l.dataValidade}). Estoque: ${l.quantidadeCaixas} caixas em ${l.posicaoRef || 'geral'}.`,
          suggestion: `Inibir Novo Fornecimento: Reter a recepção de mais lotes deste SKU até escoar esta data de validade.`,
          icon: <Clock className="w-5 h-5 text-amber-400" />
        });
      }
    });

    // Nível Baixo: Corredor / Rua acima de 90% de ocupação
    if (layout && layout.length > 0) {
      const ruaCapMap: Record<string, { totalCap: number; ocup: number }> = {};
      layout.forEach(p => {
        if (!ruaCapMap[p.rua]) {
          ruaCapMap[p.rua] = { totalCap: 0, ocup: 0 };
        }
        ruaCapMap[p.rua].totalCap += p.capacidadePallets;
        ruaCapMap[p.rua].ocup += p.palletsAlocados;
      });

      Object.entries(ruaCapMap).forEach(([ruaNome, m]) => {
        const pct = m.totalCap > 0 ? (m.ocup / m.totalCap) * 100 : 0;
        if (pct > 90) {
          list.push({
            id: `low-sat-${ruaNome}`,
            level: 'LOW',
            title: `Corredor de Alta Saturação (>90% Ocupado)`,
            description: `Gargalo de Ocupação: O corredor ${ruaNome} atingiu ${pct.toFixed(0)}% de sua capacidade física total (${m.ocup.toFixed(1)} / ${m.totalCap} Pallets ocupados). Velocidade das empilhadeiras para picking pode ficar reduzida.`,
            suggestion: `Redirecionamento de Entrada: Bloquear novos armazenamentos preventivos no corredor ${ruaNome} nas próximas ordens de recebimento fiscal.`,
            icon: <Gauge className="w-5 h-5 text-indigo-500" />
          });
        }
      });
    }

    return list;
  }, [lotes, produtos, layout]);

  // Alertas filtrados por Nível
  const alertasOperacionaisFiltrados = useMemo(() => {
    if (filtroAlertaOperacional === 'ALL') return monitoramentoAlertas;
    return monitoramentoAlertas.filter(a => a.level === filtroAlertaOperacional);
  }, [monitoramentoAlertas, filtroAlertaOperacional]);

  // Estatísticas macro de alertas operacionais
  const contagemAlertas = useMemo(() => {
    return {
      critico: monitoramentoAlertas.filter(a => a.level === 'CRITICAL').length,
      alto: monitoramentoAlertas.filter(a => a.level === 'HIGH').length,
      medio: monitoramentoAlertas.filter(a => a.level === 'MEDIUM').length,
      baixo: monitoramentoAlertas.filter(a => a.level === 'LOW').length
    };
  }, [monitoramentoAlertas]);

  // 2. Filtragem de Lotes de Validade do Estoque Geral (FEFO-check list)
  const lotesValidadeFiltrados = useMemo(() => {
    return lotes.filter((lote) => {
      if (validadeFiltro === 'CRITICO') return lote.alertaStatus === 'Crítico';
      if (validadeFiltro === 'ATENÇÃO') return lote.alertaStatus === 'Atenção';
      return lote.quantidadeCaixas > 0;
    }).sort((a, b) => a.diasParaVencer - b.diasParaVencer);
  }, [lotes, validadeFiltro]);

  // Estatísticas Rápidas de Validade
  const metricsValidade = useMemo(() => {
    const totalCaixasAtivas = lotes.reduce((acc, current) => acc + current.quantidadeCaixas, 0);
    const validadeCritica = lotes.filter(l => l.alertaStatus === 'Crítico' && l.quantidadeCaixas > 0);
    const validadeAtencao = lotes.filter(l => l.alertaStatus === 'Atenção' && l.quantidadeCaixas > 0);

    const caixasCriticas = validadeCritica.reduce((acc, current) => acc + current.quantidadeCaixas, 0);
    const caixasAtencao = validadeAtencao.reduce((acc, current) => acc + current.quantidadeCaixas, 0);

    return {
      totalLotes: lotes.length,
      lotesCriticos: validadeCritica.length,
      lotesAtencao: validadeAtencao.length,
      caixasCriticas,
      caixasAtencao,
      porcentagemPerigo: Math.round((caixasCriticas / (totalCaixasAtivas || 1)) * 100)
    };
  }, [lotes]);

  // 3. Simulação Dinâmica FEFO (Otimizador de Lançamento / Separação)
  const sugestoesFefoSimulador = useMemo(() => {
    if (!selectedFefoSku) return [];
    
    // Filtra e ordena lotes ativos deste SKU pelo vencimento mais próximo (FEFO Puro)
    const lotesDoSku = lotes
      .filter(l => l.sku === selectedFefoSku && l.quantidadeCaixas > 0)
      .sort((a,b) => a.diasParaVencer - b.diasParaVencer);

    let quantidadePendente = pickQuantity;
    const sugestao: Array<{
      lote: string;
      validade: string;
      diasRestantes: number;
      localizacao: string;
      caixasNoLote: number;
      caixasAAspirar: number;
    }> = [];

    for (const lot of lotesDoSku) {
      if (quantidadePendente <= 0) break;
      const caixasAAspirar = Math.min(lot.quantidadeCaixas, quantidadePendente);
      sugestao.push({
        lote: lot.numeroLote,
        validade: lot.dataValidade,
        diasRestantes: lot.diasParaVencer,
        localizacao: lot.posicaoRef || "Rack Central",
        caixasNoLote: lot.quantidadeCaixas,
        caixasAAspirar
      });
      quantidadePendente -= caixasAAspirar;
    }

    return sugestao;
  }, [selectedFefoSku, pickQuantity, lotes]);

  // 4. Predição Preventiva de Rupturas
  const produtosSobRiscoRuptura = useMemo(() => {
    const list: Array<{
      sku: string;
      descricao: string;
      estoqueCaixas: number;
      giroMensal: number;
      coberturaDias: number;
    }> = [];

    produtos.forEach((prod) => {
      if (prod.quantidadeAtualCaixas > 0) {
        const giroDiario = prod.vendaMensalMediaCaixas / 30;
        const coberturaDias = Math.round(prod.quantidadeAtualCaixas / giroDiario);

        if (coberturaDias <= 7) {
          list.push({
            sku: prod.sku,
            descricao: prod.descricao,
            estoqueCaixas: prod.quantidadeAtualCaixas,
            giroMensal: prod.vendaMensalMediaCaixas,
            coberturaDias
          });
        }
      }
    });

    return list.sort((a, b) => a.coberturaDias - b.coberturaDias);
  }, [produtos]);

  const handleQuarantine = async (loteId: string) => {
    setLoadingAction(loteId);
    try {
      await onQuarantineBatch(loteId);
    } finally {
      setLoadingAction(null);
    }
  };

  const handleProcessEntry = async (entryId: string) => {
    setLoadingAction(entryId);
    try {
      await onReceiveFutureEntry(entryId);
    } finally {
      setLoadingAction(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="future-control-dashboard">
      
      {/* 1. Header Principal com Indicadores FEFO */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1.5 text-center md:text-left">
          <span className="p-1 px-2.5 rounded-full bg-amber-50 text-amber-700 text-[10px] font-extrabold uppercase font-mono tracking-widest flex items-center w-fit gap-1 mx-auto md:mx-0">
            <Layers className="w-3.5 h-3.5" /> Metodologia FEFO
          </span>
          <h2 className="text-lg font-bold text-slate-800 tracking-tight font-display">Controles Inteligentes de Expirabilidade & Auditorias</h2>
          <p className="text-xs text-slate-500 max-w-xl">
            Acompanhamento em tempo real de quebras FEFO de picking e de estoque vertical (Vistoria Inteligente). Central de simulações logística em tempo real.
          </p>
        </div>

        {/* Painel Speedometer Expirabilidade */}
        <div className="flex gap-4 shrink-0">
          <div className="bg-slate-50 border border-slate-100 p-2.5 px-4 rounded-xl text-center">
            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wide">Risco de Perda Total</span>
            <span className="text-sm font-bold text-rose-600 block font-mono">{metricsValidade.caixasCriticas} cx</span>
            <span className="text-[9px] text-slate-500 block">&lt;30 dias de validade</span>
          </div>
          <div className="bg-slate-50 border border-slate-100 p-2.5 px-4 rounded-xl text-center">
            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wide">Lotes em Alerta</span>
            <span className="text-sm font-bold text-amber-500 block font-mono">{metricsValidade.lotesAtencao} lotes</span>
            <span className="text-[9px] text-slate-500 block">&lt;60 dias de validade</span>
          </div>
        </div>
      </div>

      {/* 2. CENTRAL UNIFICADA DE AUDITORIA E ALERTAS OPERACIONAIS WMS */}
      <div className="bg-white p-5 rounded-2xl border border-slate-150 shadow-lux space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-indigo-600" />
              <h3 className="font-display font-extrabold text-slate-850 text-sm tracking-tight">Central Unificada de Auditoria & Alertas do WMS</h3>
            </div>
            <p className="text-[11px] text-slate-500">
              Detecção automatizada de furos procedimentais, gargalos de empilhamento e fracionamento de FEFO no armazém.
            </p>
          </div>
          
          {/* Seletor de Nível */}
          <div className="flex items-center gap-1 bg-slate-50 p-0.5 rounded-lg border border-slate-100 text-[9.5px] font-bold">
            <button 
              type="button"
              onClick={() => setFiltroAlertaOperacional('ALL')}
              className={`p-1 px-2 rounded-md cursor-pointer transition ${filtroAlertaOperacional === 'ALL' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Todos ({monitoramentoAlertas.length})
            </button>
            <button 
              type="button"
              onClick={() => setFiltroAlertaOperacional('CRITICAL')}
              className={`p-1 px-2 rounded-md cursor-pointer transition flex items-center gap-0.5 ${filtroAlertaOperacional === 'CRITICAL' ? 'bg-rose-500 text-white shadow-sm font-black' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Crítico ({contagemAlertas.critico})
            </button>
            <button 
              type="button"
              onClick={() => setFiltroAlertaOperacional('HIGH')}
              className={`p-1 px-2 rounded-md cursor-pointer transition ${filtroAlertaOperacional === 'HIGH' ? 'bg-orange-500 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Alto ({contagemAlertas.alto})
            </button>
            <button 
              type="button"
              onClick={() => setFiltroAlertaOperacional('MEDIUM')}
              className={`p-1 px-2 rounded-md cursor-pointer transition ${filtroAlertaOperacional === 'MEDIUM' ? 'bg-amber-400 text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Médio ({contagemAlertas.medio})
            </button>
            <button 
              type="button"
              onClick={() => setFiltroAlertaOperacional('LOW')}
              className={`p-1 px-2 rounded-md cursor-pointer transition ${filtroAlertaOperacional === 'LOW' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Baixo ({contagemAlertas.baixo})
            </button>
          </div>
        </div>

        {alertasOperacionaisFiltrados.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in" id="operational-alerts-grid">
            {alertasOperacionaisFiltrados.map((alert) => {
              let headerBar = "border-l-4 border-rose-500 bg-rose-50/40 text-rose-950";
              let badgeStatus = "bg-rose-100 text-rose-800";
              let levelTxt = "CRÍTICO";

              if (alert.level === 'HIGH') {
                headerBar = "border-l-4 border-orange-500 bg-orange-50/40 text-orange-950";
                badgeStatus = "bg-orange-100 text-orange-850";
                levelTxt = "ALTO";
              } else if (alert.level === 'MEDIUM') {
                headerBar = "border-l-4 border-amber-500 bg-amber-50/40 text-amber-950";
                badgeStatus = "bg-amber-100 text-amber-850";
                levelTxt = "MÉDIO";
              } else if (alert.level === 'LOW') {
                headerBar = "border-l-4 border-indigo-500 bg-indigo-50/40 text-indigo-950";
                badgeStatus = "bg-indigo-100 text-indigo-850";
                levelTxt = "BAIXO";
              }

              return (
                <div key={alert.id} className={`p-4 rounded-xl border border-slate-100 flex flex-col justify-between gap-3 text-xs shadow-sm transition-all hover:scale-[1.005] ${headerBar}`}>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className={`text-[8.5px] font-black uppercase px-2 py-0.5 rounded ${badgeStatus}`}>
                        Nível {levelTxt}
                      </span>
                      {alert.icon}
                    </div>
                    <h4 className="font-bold text-slate-800 leading-snug">{alert.title}</h4>
                    <p className="text-slate-650 text-[11px] leading-relaxed">{alert.description}</p>
                  </div>

                  <div className="bg-white/80 border border-slate-200 p-2.5 rounded-lg space-y-1 mt-1 text-[11px]">
                    <span className="text-[9.5px] font-bold text-slate-400 block uppercase font-mono tracking-wider">Diretiva de Correção:</span>
                    <p className="text-slate-800 italic leading-snug">"{alert.suggestion}"</p>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center border border-dashed border-slate-150 rounded-2xl bg-slate-50/50">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <span className="text-xs font-bold text-slate-800 block">Nenhuma inconformidade de auditoria ativa!</span>
            <p className="text-[11px] text-slate-500 mt-1">Todas as regras FEFO de Picking, Racks Verticais, e Ocupação das ruas WMS estão cumpridas.</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* 3. SIMULADOR E PLANEJADOR DE SEPARAÇÃO FEFO (Lado Esquerdo, 7 colunas) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4">
          <div className="space-y-0.5 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
              <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight">Otimizador e Planejador de Separação FEFO</h3>
            </div>
            <p className="text-xs text-slate-500">
              Insira o SKU e a quantidade desejada para faturamento corporativo. O WMS calculará e apontará em quais lotes e posições físicas de racks o picking deve extrair para blindar o FEFO.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1 text-xs">
              <label className="font-bold text-slate-500">Selecione o SKU para Simulação:</label>
              <select
                value={selectedFefoSku}
                onChange={(e) => setSelectedFefoSku(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 text-xs font-mono p-2.5 rounded-xl cursor-pointer"
              >
                <option value="">-- Escolher Produto --</option>
                {produtos.filter(p => p.quantidadeAtualCaixas > 0).map((p) => (
                  <option key={p.sku} value={p.sku}>
                    [{p.sku.replace(/^0+/, '')}] {p.descricao.substring(0, 30)}...
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1 text-xs">
              <label className="font-bold text-slate-500">Quantidade de Caixas Mandatórias:</label>
              <input
                type="number"
                min={1}
                value={pickQuantity}
                onChange={(e) => setPickQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                className="w-full bg-slate-50 border border-slate-200 text-xs font-mono p-2.5 rounded-xl"
              />
            </div>
          </div>

          {selectedFefoSku ? (
            <div className="space-y-3 pt-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block font-mono">Rota de Coleta Sugerida para Operador de Empilhadeira:</span>
              
              {sugestoesFefoSimulador.length > 0 ? (
                <div className="space-y-2">
                  <div className="divide-y divide-slate-100 border border-slate-150 rounded-xl overflow-hidden bg-slate-50/20 shadow-sm leading-snug">
                    {sugestoesFefoSimulador.map((sug, i) => (
                      <div key={sug.lote} className="p-3 bg-white flex items-center justify-between gap-4 text-xs font-sans">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="w-5 h-5 font-black text-[9px] text-[#2563eb] bg-[#eff6ff] rounded-full flex items-center justify-center">
                              {i + 1}
                            </span>
                            <strong className="text-slate-800 font-mono text-[11px]">{sug.lote}</strong>
                            <span className="text-[9px] bg-slate-200 font-extrabold px-1.5 py-0.2 rounded text-slate-700 font-mono">
                              {sug.localizacao}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500">
                            Expira em: <strong className="text-slate-800 font-mono">{sug.validade}</strong> ({sug.diasRestantes} dias restantes)
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="font-extrabold text-indigo-700 text-sm block font-mono">{sug.caixasAAspirar} cx</span>
                          <span className="text-[9.5px] text-slate-400">de {sug.caixasNoLote} cx totais</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-3 bg-indigo-50 border border-indigo-150 text-indigo-950 text-[10px] rounded-xl flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    <p>
                      Simulação Finalizada: {sugestoesFefoSimulador.reduce((sum, item) => sum + item.caixasAAspirar, 0)} caixas separadas blindando quebras de validade física.
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-slate-400 text-center py-4 text-xs font-mono">Nenhum lote com caixas ativas localizado para este SKU.</p>
              )}
            </div>
          ) : (
            <div className="p-10 border border-dashed border-slate-200 rounded-2xl bg-slate-50/50 text-center whitespace-normal select-none">
              <RefreshCw className="w-6 h-6 text-slate-350 mx-auto mb-2 animate-spin-slow" />
              <p className="text-xs text-slate-400">Escolha um produto e simule o fluxo automático de picking inteligente.</p>
            </div>
          )}

        </div>

        {/* 4. RECEBIMENTOS FISCAIS FUTUROS / AGENDADOS (Lado Direito, 5 colunas) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4">
          <div className="space-y-0.5 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-1.5">
              <Truck className="w-5 h-5 text-indigo-600" />
              <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight">Recebimento de Entradas Fiscais Futuras (Portaria)</h3>
            </div>
            <p className="text-xs text-slate-500 text-justify">
              Mapeamento de Notas Fiscais estruturadas no portal Ambev aguardando liberação na portaria física. Clicar em "Dar Entrada" cria as posições fiscais e físicas automáticas.
            </p>
          </div>

          <div className="space-y-3.5 max-h-[300px] overflow-y-auto pr-1">
            {entradasFuturas.length > 0 ? (
              entradasFuturas.map((ent) => (
                <div key={ent.id} className="p-3 bg-slate-50/50 hover:bg-slate-50 rounded-xl border border-slate-150 flex flex-col justify-between gap-3 text-xs leading-snug">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-[9px] font-mono">
                      <span className="font-bold text-slate-400 uppercase tracking-wider">NF: {ent.chaveNotaFiscal.substring(0, 10)}</span>
                      <span className="text-indigo-600 font-bold bg-indigo-50 px-1.5 rounded uppercase">Agendado {ent.dataPrevisao}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-800 pt-0.5">
                      <span>{ent.sku.replace(/^0+/, '')}</span>
                      <span className="text-slate-400 text-[10px] font-normal truncate">| {ent.descricao}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono text-slate-500 pt-1">
                      <div>
                        <span>Quantidade:</span>
                        <span className="text-slate-850 font-bold block">{ent.quantidadeCaixas} cx</span>
                      </div>
                      <div>
                        <span>Validade Lote:</span>
                        <span className="text-slate-850 font-bold block">LOT-{ent.sku}-PV</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleProcessEntry(ent.id)}
                    disabled={loadingAction === ent.id}
                    className="w-full bg-[#0f172a] hover:bg-[#1e293b] text-white p-2 text-[10.5px] rounded-xl font-bold transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    {loadingAction === ent.id ? "Alocando no Grid..." : "Receber Portaria & Guardar"} 
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              ))
            ) : (
              <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                <CheckCircle2 className="w-7 h-7 text-emerald-500 mx-auto mb-2" />
                <p className="text-[11px] text-slate-500">Agendamento limpo. Nenhuma carga fiscal na fila de recepção hoje.</p>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* 5. GESTÃO E INVENTÁRIO DE LOTES DE VALIDADE ATIVOS */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5">
              <Archive className="w-4 h-4 text-indigo-600" />
              <h3 className="font-display font-black text-slate-850 text-sm tracking-tight">Inventário de Lotes Ativos no CD (Validade FEFO)</h3>
            </div>
            <p className="text-xs text-slate-500">
              Análise tática de expirabilidade. Lotes críticos bloqueados ficam em quarentena de movimentação para auditoria de piso.
            </p>
          </div>

          {/* Filtro Rápido */}
          <div className="flex bg-slate-50 p-0.5 rounded-xl border border-slate-200 shrink-0 text-[10.5px] font-bold">
            {(['TODOS', 'CRITICO', 'ATENÇÃO'] as const).map((fil) => (
              <button
                key={fil}
                type="button"
                onClick={() => setValidadeFiltro(fil)}
                className={`p-1.5 px-3 rounded-lg cursor-pointer transition ${validadeFiltro === fil ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
              >
                {fil === 'TODOS' ? 'Ver Todos Lotes' : fil === 'CRITICO' ? 'Críticos (<30 dias)' : 'Atenção (<60 dias)'}
              </button>
            ))}
          </div>
        </div>

        {/* Painel Integrado de Excel (Importação e Exportação de Validades) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50/50 p-4 rounded-xl border border-slate-150 text-xs">
          {/* Lado Esquerdo - Arrastar e soltar para Importar */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-slate-700 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider">
              <UploadCloud className="w-4 h-4 text-indigo-650" /> Sincronizar Validade (Arrastar Planilha)
            </h4>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`p-6 border-2 border-dashed rounded-xl flex flex-col items-center justify-center text-center cursor-pointer transition duration-200 relative ${
                isDragging
                  ? 'border-indigo-600 bg-indigo-50/40'
                  : 'border-slate-300 hover:border-indigo-400 bg-white'
              }`}
            >
              <input
                type="file"
                accept=".xlsx, .xls"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                id="excel-validity-upload-input"
              />
              <FileText className={`w-8 h-8 mb-2 ${isDragging ? 'text-indigo-650 animate-bounce' : 'text-slate-400'}`} />
              <span className="text-slate-850 font-bold block text-[11px]">
                {fileName ? `Documento: ${fileName}` : "Arraste a Planilha de Validades aqui"}
              </span>
              <p className="text-[10px] text-slate-400 mt-1 max-w-xs mx-auto">
                Suporta formato Excel (.xlsx, .xls). As colunas Código SKU, Lote, Saldo e Validade serão indexadas dinamicamente.
              </p>
            </div>

            {importError && (
              <div className="p-3 bg-rose-50 border border-rose-150 rounded-lg text-rose-800 text-[11px] flex items-start gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                <span>{importError}</span>
              </div>
            )}
          </div>

          {/* Lado Direito - Exportar Planilha ou Ver Amostra */}
          <div className="flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-200 pt-4 md:pt-0 md:pl-4 space-y-4">
            <div className="space-y-1.5">
              <h4 className="font-extrabold text-slate-700 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider">
                <Download className="w-4 h-4 text-emerald-600 font-bold" /> Exportar Dados e Modelos
              </h4>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                Baixe o inventário completo de validades ativo no armazém em formato Excel de alta fidelidade FEFO para auditorias fiscais físicas ou use o modelo padrão para preencher.
              </p>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              <button
                type="button"
                onClick={handleExportToExcel}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-xl flex items-center gap-1.5 transition text-[11px] cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> Exportar Lotes Ativos (.XLSX)
              </button>
              <button
                type="button"
                onClick={handleDownloadExcelTemplate}
                className="bg-[#f8fafc] border border-slate-300 hover:bg-slate-100 text-slate-700 font-extrabold py-2 px-4 rounded-xl flex items-center gap-1.5 transition text-[11px] cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-slate-500" /> Planilha Modelo
              </button>
            </div>
          </div>
        </div>

        {/* Tabela de Amostra/Preview dos Lotes Importados antes de salvar */}
        {previewLotes && previewLotes.length > 0 && (
          <div className="p-4 border border-indigo-150 rounded-xl bg-indigo-50/20 space-y-3 animate-fade-in">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-indigo-100 pb-2">
              <div className="space-y-0.5">
                <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-indigo-600 font-extrabold" /> Visualizar Planilha Processada ({previewLotes.length} registros detectados)
                </span>
                <p className="text-[10px] text-slate-500">Confirme as correspondências fiscais antes de atualizar o saldo mestre por FEFO.</p>
              </div>

              <div className="flex gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleCancelImport}
                  className="bg-white hover:bg-slate-150 text-slate-700 border border-slate-250 font-bold py-1.5 px-3 rounded-lg text-[10.5px] transition cursor-pointer"
                >
                  Descartar
                </button>
                <button
                  type="button"
                  onClick={handleSaveImportedLotes}
                  disabled={isImporting}
                  className="bg-indigo-650 hover:bg-indigo-700 text-white font-black py-1.5 px-4 rounded-lg text-[10.5px] shadow-sm transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                >
                  {isImporting ? "Gravando no CD..." : "Confirmar e Sincronizar no WMS"}
                </button>
              </div>
            </div>

            <div className="max-h-[220px] overflow-y-auto border border-indigo-100 rounded-lg bg-white shadow-inner">
              <table className="w-full text-left text-[10.5px]">
                <thead className="bg-[#1e293b] text-slate-200 font-mono font-bold sticky top-0 uppercase">
                  <tr>
                    <th className="p-2 pl-3">Lote</th>
                    <th className="p-2">SKU</th>
                    <th className="p-2 text-center">Posição</th>
                    <th className="p-2 text-center">Rua</th>
                    <th className="p-2 text-center">Validade</th>
                    <th className="p-2 text-right pr-3">Qtd Caixas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 leading-snug">
                  {previewLotes.slice(0, 50).map((p, idx) => {
                    const prodInfo = mappedProdutos.get(p.sku);
                    return (
                      <tr key={idx} className="hover:bg-indigo-50/30 transition duration-100">
                        <td className="p-2 pl-3 font-mono font-bold text-slate-855">{p.numeroLote}</td>
                        <td className="p-2">
                          <span className="font-mono bg-slate-100 text-slate-800 p-0.5 px-1 rounded font-bold text-[10px]">
                            {p.sku.replace(/^0+/, '')}
                          </span>
                          <span className="text-slate-500 pl-1.5 font-semibold truncate max-w-[200px] inline-block align-middle">
                            {prodInfo?.descricao || 'Novo SKU'}
                          </span>
                        </td>
                        <td className="p-2 text-center font-mono bg-indigo-50/20">{p.posicaoRef}</td>
                        <td className="p-2 text-center font-mono">{p.rua}</td>
                        <td className="p-2 text-center font-mono font-bold text-slate-800">{p.dataValidade}</td>
                        <td className="p-2 text-right pr-3 font-mono font-black text-indigo-700">{p.quantidadeCaixas} cx</td>
                      </tr>
                    );
                  })}
                  {previewLotes.length > 50 && (
                    <tr>
                      <td colSpan={6} className="p-2 text-center text-slate-400 font-medium italic bg-slate-50">
                        E mais {previewLotes.length - 50} itens ocultados na pré-visualização rápida...
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Linha de Tabela de Inventário */}
        <div className="overflow-x-auto select-none rounded-xl border border-slate-100">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#0f172a] text-slate-200 text-[10.5px] font-semibold uppercase font-mono">
              <tr>
                <th className="p-3 text-center">Lote</th>
                <th className="p-3">SKU / Descrição Fiscal</th>
                <th className="p-3 text-center">Posição Rack</th>
                <th className="p-3 text-center">Rua</th>
                <th className="p-3 text-center">Vencimento</th>
                <th className="p-3 text-right">Saldo Caixas</th>
                <th className="p-3 text-center">Alertas FEFO</th>
                <th className="p-3 text-center">Ações Operacionais</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 leading-snug">
              {lotesValidadeFiltrados.map((lote) => {
                const prod = mappedProdutos.get(lote.sku);
                
                let chipColor = "bg-emerald-50 text-emerald-800 border-emerald-150";
                let statusLabel = "Normal (Saudável)";
                if (lote.alertaStatus === 'Crítico') {
                  chipColor = "bg-rose-50 text-rose-800 border-rose-150 font-bold animate-pulse";
                  statusLabel = "Crítico (<30 dias)";
                } else if (lote.alertaStatus === 'Atenção') {
                  chipColor = "bg-amber-50 text-amber-800 border-amber-150 font-bold";
                  statusLabel = "Atenção (<60 dias)";
                } else if (lote.alertaStatus === 'Quarentena') {
                  chipColor = "bg-purple-50 text-purple-800 border-purple-150 font-bold";
                  statusLabel = "Quarentena (Retido)";
                }

                return (
                  <tr key={lote.id} className="hover:bg-slate-50/50 transition duration-150">
                    <td className="p-3 text-center font-mono font-bold text-slate-800">{lote.numeroLote}</td>
                    <td className="p-3 min-w-[200px]">
                      <div className="font-bold text-slate-800 select-all font-mono text-[11px]">
                        {lote.sku.replace(/^0+/, '')}
                      </div>
                      <div className="text-[10px] text-slate-450 truncate max-w-sm mt-0.5 font-semibold text-slate-500">
                        {prod?.descricao || "Sku Cadastrado"}
                      </div>
                    </td>
                    <td className="p-3 text-center">
                      <span className="font-mono bg-indigo-50 text-indigo-700 px-1.5 py-0.2 rounded font-extrabold text-[10px]">
                        {lote.posicaoRef || "Central"}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <span className="font-mono font-bold text-slate-600">
                        {lote.rua || "Padrão"}
                      </span>
                    </td>
                    <td className="p-3 text-center font-mono text-[10.5px]">
                      <div className="font-extrabold text-slate-800">{lote.dataValidade}</div>
                      <div className="text-[9px] text-slate-400 mt-0.5">{lote.diasParaVencer} dias restantes</div>
                    </td>
                    <td className="p-3 text-right font-mono font-extrabold text-slate-900">{lote.quantidadeCaixas} cx</td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span className={`p-1.5 px-3 rounded-full border text-[9.5px] uppercase font-bold tracking-wide ${chipColor}`}>
                        {statusLabel}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      {lote.alertaStatus !== 'Quarentena' ? (
                        <button
                          type="button"
                          onClick={() => handleQuarantine(lote.id)}
                          disabled={lote.diasParaVencer <= 0 || loadingAction === lote.id}
                          className="bg-purple-50 hover:bg-purple-600 text-purple-700 hover:text-white p-1 px-2.5 rounded text-[10px] font-extrabold border border-purple-100 transition cursor-pointer"
                        >
                          Quarentena
                        </button>
                      ) : (
                        <span className="text-[10px] text-purple-700 font-extrabold uppercase">Retido em Inspeção</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 6. Predição de Ruptura Master (Risco de Falta na Próxima Semana) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4">
        <div className="space-y-0.5">
          <div className="flex items-center gap-1.5">
            <TrendingDown className="w-4 h-4 text-amber-500" />
            <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight">Ruptura Sistêmica Próxima Semana — Análise Preventiva</h3>
          </div>
          <p className="text-[11px] text-slate-500">
            Produtos cuja velocidade de giro é muito maior do que o estoque master total estocado. Medidas rápidas de suprimento evitariam perda de vendas.
          </p>
        </div>

        {produtosSobRiscoRuptura.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="ruptures-grid">
            {produtosSobRiscoRuptura.map((rup) => (
              <div key={rup.sku} className="p-3.5 bg-rose-50/50 border border-rose-100 rounded-xl space-y-2 text-xs">
                <div className="flex justify-between items-start">
                  <span className="font-mono font-bold text-rose-800 bg-rose-100/60 px-2 py-0.5 rounded text-[10px]">{rup.sku.replace(/^0+/, '') || '0'}</span>
                  <span className="text-[10px] text-rose-600 font-bold font-mono">Cobertura: {rup.coberturaDias} dias</span>
                </div>
                <h5 className="font-bold text-slate-800 line-clamp-1">{rup.descricao}</h5>
                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-500 pt-1 border-t border-rose-100/50">
                  <div>
                    <span>Estoque Master:</span>
                    <span className="text-slate-800 block font-bold">{rup.estoqueCaixas} cx</span>
                  </div>
                  <div>
                    <span>Giro Mês:</span>
                    <span className="text-slate-800 block font-bold">{rup.giroMensal} cx</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/50 select-none">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <p className="text-xs text-slate-600 font-semibold">Nenhum risco de ruptura iminente. Cobertura estocada de todos os SKUs de giro está saudável.</p>
          </div>
        )}
      </div>

    </div>
  );
}
