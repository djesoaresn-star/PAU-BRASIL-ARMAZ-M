import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  User, 
  Clock, 
  CheckCircle, 
  FolderPlus, 
  BarChart2, 
  RotateCcw, 
  Zap, 
  Database,
  ArrowUpRight,
  TrendingUp,
  Cpu
} from 'lucide-react';

interface ProdutividadeItem {
  id: string;
  operador: string;
  tipo: 'Ressuprimento e Reabastecimento' | 'Repack' | 'Despejo' | 'Carregamento' | 'Descarregamento' | 'Montagem';
  quantidadeCaixas: number;
  dataHora: string;
  tempoMinutagem: number;
}

interface ProductivityHubProps {
  produtividade: ProdutividadeItem[];
  onAddProductivity: (item: Omit<ProdutividadeItem, 'id' | 'dataHora'>) => Promise<void>;
  onResetProductivity: () => Promise<void>;
}

export function ProductivityHub({ 
  produtividade, 
  onAddProductivity, 
  onResetProductivity 
}: ProductivityHubProps) {
  
  // State for manual input log
  const [operadorName, setOperadorName] = useState('');
  const [taskType, setTaskType] = useState<ProdutividadeItem['tipo']>('Ressuprimento e Reabastecimento');
  const [caixasQty, setCaixasQty] = useState('');
  const [minutagem, setMinutagem] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  // Calculations for KPI cards
  const summary = useMemo(() => {
    let totCaixas = 0;
    let totMinutos = 0;
    
    // Categorias
    const catsRecord: Record<ProdutividadeItem['tipo'], { caixas: number; tempo: number }> = {
      'Ressuprimento e Reabastecimento': { caixas: 0, tempo: 0 },
      'Repack': { caixas: 0, tempo: 0 },
      'Despejo': { caixas: 0, tempo: 0 },
      'Carregamento': { caixas: 0, tempo: 0 },
      'Descarregamento': { caixas: 0, tempo: 0 },
      'Montagem': { caixas: 0, tempo: 0 },
    };

    // Operadores
    const opsRecord: Record<string, { caixas: number; tempo: number; tasksCount: number }> = {};

    produtividade.forEach(item => {
      totCaixas += item.quantidadeCaixas;
      totMinutos += item.tempoMinutagem;

      if (catsRecord[item.tipo]) {
        catsRecord[item.tipo].caixas += item.quantidadeCaixas;
        catsRecord[item.tipo].tempo += item.tempoMinutagem;
      }

      if (!opsRecord[item.operador]) {
        opsRecord[item.operador] = { caixas: 0, tempo: 0, tasksCount: 0 };
      }
      opsRecord[item.operador].caixas += item.quantidadeCaixas;
      opsRecord[item.operador].tempo += item.tempoMinutagem;
      opsRecord[item.operador].tasksCount += 1;
    });

    const cxPerHourAvg = totMinutos > 0 ? (totCaixas / totMinutos) * 60 : 0;

    return {
      totalCaixas: totCaixas,
      totalMinutos: totMinutos,
      caixasPorHoraMedia: cxPerHourAvg,
      categorias: catsRecord,
      operadores: opsRecord
    };
  }, [produtividade]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!operadorName || !caixasQty || !minutagem) return;
    setLoading(true);
    setSuccessMsg('');

    try {
      await onAddProductivity({
        operador: operadorName,
        tipo: taskType,
        quantidadeCaixas: parseInt(caixasQty) || 0,
        tempoMinutagem: parseInt(minutagem) || 0
      });
      setSuccessMsg('Atividade registrada e sincronizada com sucesso!');
      setOperadorName('');
      setCaixasQty('');
      setMinutagem('');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" id="productivity-hub">
      
      {/* Firebase Status Banner */}
      <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lux">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
            <Database className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h4 className="text-sm font-bold tracking-tight">Banco Integrado Firebase Plataforma</h4>
            <p className="text-xs text-slate-400">Banco de dados de produtividade operacional em tempo real ativo</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full text-emerald-400 text-xs font-semibold">
          <Cpu className="w-3.5 h-3.5" />
          Firebase Sync: Conectado
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Total Caixas Logística */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between">
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Ações Totais</span>
            <h3 className="font-display font-black text-slate-800 text-3xl">
              {summary.totalCaixas.toLocaleString()} cx
            </h3>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Volume Bruto Processado
            </span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-500">
            <Zap className="w-6 h-6" />
          </div>
        </div>

        {/* Produtividade Média */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between">
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Velocidade Média</span>
            <h3 className="font-display font-black text-slate-800 text-3xl">
              {summary.caixasPorHoraMedia.toFixed(1)} cx/h
            </h3>
            <span className="text-[10px] text-slate-500 font-medium">
              Taxa média de movimentação por operador
            </span>
          </div>
          <div className="p-3 bg-indigo-50 rounded-xl text-indigo-500">
            <Activity className="w-6 h-6" />
          </div>
        </div>

        {/* Total Horas */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between">
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Tempo Consumido</span>
            <h3 className="font-display font-black text-slate-800 text-3xl">
              {(summary.totalMinutos / 60).toFixed(1)} h
            </h3>
            <span className="text-[10px] text-slate-500 font-medium">
              Soma total de minutagem em operação
            </span>
          </div>
          <div className="p-3 bg-amber-50 rounded-xl text-amber-500">
            <Clock className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Categories & Input Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Productivity by Category Chart / List */}
        <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-100 shadow-lux space-y-4">
          <div className="flex justify-between items-center border-b border-slate-50 pb-3">
            <div>
              <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Rendimento por Atividade Logística</h4>
              <p className="text-xs text-slate-500">Relatório por base de ressuprimentos, repack, despejo e carregamentos</p>
            </div>
            <BarChart2 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-4 pt-1">
            {(Object.entries(summary.categorias) as Array<[ProdutividadeItem['tipo'], { caixas: number; tempo: number }]>).map(([catName, data]) => {
              const maxVal = Math.max(...(Object.values(summary.categorias) as Array<{ caixas: number; tempo: number }>).map(c => c.caixas), 1);
              const pct = (data.caixas / maxVal) * 100;
              const velocity = data.tempo > 0 ? (data.caixas / data.tempo) * 60 : 0;
              
              return (
                <div key={catName} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-700">{catName}</span>
                    <span className="text-slate-500 font-mono">
                      {data.caixas.toLocaleString()} cx ({velocity.toFixed(0)} cx/h)
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-50 rounded-full overflow-hidden flex">
                    <div 
                      style={{ width: `${pct}%` }} 
                      className={`h-full rounded-full transition-all duration-500 ${
                        catName.startsWith('Ressuprimento') ? 'bg-emerald-500' :
                        catName === 'Repack' ? 'bg-indigo-500' :
                        catName === 'Despejo' ? 'bg-rose-500' :
                        catName === 'Carregamento' ? 'bg-amber-500' :
                        catName === 'Descarregamento' ? 'bg-pink-500' : 'bg-sky-500'
                      }`}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-slate-400">
                    <span>Tempo gasto: {data.tempo} min</span>
                    <span>Peso de volume: {Math.round(pct)}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Manual Tracker log */}
        <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-lux space-y-4">
          <div className="flex items-center gap-2 text-slate-800">
            <FolderPlus className="w-4 h-4 text-slate-600" />
            <span className="font-display font-medium text-sm">Registrar Atividade</span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3 pt-1">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Operador Logístico</label>
              <div className="relative">
                <input 
                  type="text" 
                  required
                  placeholder="Nome do operador"
                  value={operadorName}
                  onChange={(e) => setOperadorName(e.target.value)}
                  className="w-full text-xs p-2.5 pl-8 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-400 font-sans"
                />
                <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Processo Logístico</label>
              <select 
                value={taskType}
                onChange={(e) => setTaskType(e.target.value as any)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-400 font-sans cursor-pointer"
              >
                <option value="Ressuprimento e Reabastecimento">Ressuprimento e Reabastecimento</option>
                <option value="Repack">Repack</option>
                <option value="Despejo">Despejo</option>
                <option value="Carregamento">Carregamento</option>
                <option value="Descarregamento">Descarregamento</option>
                <option value="Montagem">Montagem</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Volume (Caixas)</label>
                <input 
                  type="number" 
                  required
                  min="1"
                  placeholder="Ex: 120"
                  value={caixasQty}
                  onChange={(e) => setCaixasQty(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-400 font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Minutagem</label>
                <input 
                  type="number" 
                  required
                  min="1"
                  placeholder="Minutos"
                  value={minutagem}
                  onChange={(e) => setMinutagem(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-400 font-mono"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full mt-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs p-3 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle className="w-3.5 h-3.5" />
              {loading ? 'Salvando...' : 'Lançar no Firebase'}
            </button>

            {successMsg && (
              <p className="text-[10px] text-emerald-600 font-bold text-center bg-emerald-50 p-2 rounded-lg animate-fade-in border border-emerald-100">
                {successMsg}
              </p>
            )}
          </form>
        </div>

      </div>

      {/* Operator Leaderboard & History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
        
        {/* Operator Leaderboard */}
        <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-lux space-y-4">
          <div className="flex justify-between items-center border-b border-slate-50 pb-3">
            <div>
              <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Rendimento por Colaborador</h4>
              <p className="text-xs text-slate-500">Desempenho individual acumulado</p>
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3.5">
            {Object.entries(summary.operadores).length === 0 ? (
              <p className="text-xs text-slate-400 italic text-center py-5">Nenhum dado lançado.</p>
            ) : (
              (Object.entries(summary.operadores) as Array<[string, { caixas: number; tempo: number; tasksCount: number }]>)
                .sort((a, b) => b[1].caixas - a[1].caixas)
                .slice(0, 5)
                .map(([name, stats], index) => {
                  const itemsRate = stats.tempo > 0 ? (stats.caixas / stats.tempo) * 60 : 0;
                  return (
                    <div key={name} className="flex items-center justify-between p-2 hover:bg-slate-50/50 rounded-xl border border-slate-50 transition">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-xs font-bold text-slate-400 w-4">#{index + 1}</span>
                        <div>
                          <span className="font-bold text-slate-800 text-xs block">{name}</span>
                          <span className="text-[9px] text-slate-400 font-medium">Frequência: {stats.tasksCount} tarefas</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-slate-700 text-xs block">{stats.caixas.toLocaleString()} cx</span>
                        <span className="text-[9px] text-emerald-600 font-semibold">{itemsRate.toFixed(0)} cx/h</span>
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>

        {/* Live log list */}
        <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-100 shadow-lux space-y-4">
          <div className="flex justify-between items-center border-b border-slate-50 pb-3">
            <div>
              <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Memorial de Atividades Logísticas</h4>
              <p className="text-xs text-slate-500">Últimas execuções resgatadas do Firebase</p>
            </div>
            <button 
              onClick={onResetProductivity}
              className="text-xs text-slate-500 hover:text-slate-800 font-semibold flex items-center gap-1.5 p-1 px-2.5 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer transition active:scale-95"
            >
              <RotateCcw className="w-3 h-3" />
              Restaurar Padrão
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  <th className="py-2.5 px-3">Log ID</th>
                  <th className="py-2.5 px-3">Operador</th>
                  <th className="py-2.5 px-3">Atividade</th>
                  <th className="py-2.5 px-3 text-right">Volume</th>
                  <th className="py-2.5 px-3 text-right">Minutos</th>
                  <th className="py-2.5 px-3 text-right">Taxa (cx/h)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-xs font-mono">
                {produtividade.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400 italic">Nenhum log cadastrado. Use o formulário à direita.</td>
                  </tr>
                ) : (
                  [...produtividade].reverse().slice(0, 8).map((item) => {
                    const cxH = item.tempoMinutagem > 0 ? (item.quantidadeCaixas / item.tempoMinutagem) * 60 : 0;
                    return (
                      <tr key={item.id} className="hover:bg-slate-50/50 transition">
                        <td className="py-2.5 px-3 font-semibold text-slate-400">{item.id}</td>
                        <td className="py-2.5 px-3 font-sans font-bold text-slate-800">{item.operador}</td>
                        <td className="py-2.5 px-3 font-sans text-slate-600">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.tipo.startsWith('Ressuprimento') ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                            item.tipo === 'Repack' ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' :
                            item.tipo === 'Despejo' ? 'bg-rose-50 text-rose-600 border border-rose-100' :
                            item.tipo === 'Carregamento' ? 'bg-amber-50 text-amber-600 border border-amber-100' :
                            item.tipo === 'Descarregamento' ? 'bg-pink-50 text-pink-600 border border-pink-100' :
                            'bg-sky-50 text-sky-600 border border-sky-100'
                          }`}>
                            {item.tipo}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-slate-700">{item.quantidadeCaixas} cx</td>
                        <td className="py-2.5 px-3 text-right text-slate-500">{item.tempoMinutagem} min</td>
                        <td className="py-2.5 px-3 text-right text-emerald-600 font-bold">{cxH.toFixed(0)} cx/h</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
}
