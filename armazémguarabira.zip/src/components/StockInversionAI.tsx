import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  TrendingUp, 
  ArrowRight,
  Info,
  Layers,
  Activity,
  UserCheck,
  Download,
  Check,
  Plus,
  Minus,
  Trash2,
  FileSpreadsheet,
  Shuffle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  ReferenceLine
} from 'recharts';
import { ProdutoConsolidado } from '../types';

interface StockInversionAIProps {
  produtos: ProdutoConsolidado[];
  operatorEmail: string;
  onRefresh: () => Promise<void>;
}

interface InversionCandidate {
  sopSku: string;
  sopDesc: string;
  sopSobra: number;
  sobCusto: number;
  falSku: string;
  falDesc: string;
  falFalta: number;
  falCusto: number;
  categoria: string;
  embalagem: 'LATA' | 'PET' | 'GARRAFA' | 'OUTRO';
  caixasSugeridas: number;
  hlSugeridos: number;
  valorBalanciado: number;
  viabilidade: 'ALTA' | 'MÉDIA' | 'BAIXA';
  justificativa: string;
  detalheImpacto: string;
}

interface GroupData {
  categoria: string;
  embalagem: 'LATA' | 'PET' | 'GARRAFA' | 'OUTRO';
  sobras: ProdutoConsolidado[];
  faltas: ProdutoConsolidado[];
  totalSobraBoxes: number;
  totalFaltaBoxes: number;
}

export default function StockInversionAI({ produtos, operatorEmail, onRefresh }: StockInversionAIProps) {
  // Estado para aba ativa global: Grupos (Recomendado) ou Pares 1-para-1 anterior
  const [activeTabMode, setActiveTabMode] = useState<'grupos' | 'pares'>('grupos');
  
  // Estado para Recomendações em Pares (1-para-1)
  const [pairCandidates, setPairCandidates] = useState<InversionCandidate[]>([]);
  const [isLoadingPairs, setIsLoadingPairs] = useState(false);
  const [customQuantities, setCustomQuantities] = useState<Record<string, number>>({});
  
  // Estado para Planejador em Lotes/Grupo (Multi-SKU)
  const [activeGroupKey, setActiveGroupKey] = useState<string>('');
  const [plannedSaidas, setPlannedSaidas] = useState<Record<string, number>>({}); // sku -> qtd (saída de sobras)
  const [plannedEntradas, setPlannedEntradas] = useState<Record<string, number>>({}); // sku -> qtd (entrada de faltas)
  const [isAiCalculating, setIsAiCalculating] = useState(false);
  const [aiJustificativa, setAiJustificativa] = useState<string>('');
  
  // Alertas Globais
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);

  // Normalizador de Embalagem
  const getEmbalagem = (descricao: string): 'LATA' | 'PET' | 'GARRAFA' | 'OUTRO' => {
    const desc = (descricao || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (desc.includes("lata") || desc.includes("lt") || desc.includes("can")) return "LATA";
    if (desc.includes("pet") || desc.includes("garrafa pet")) return "PET";
    if (desc.includes("garrafa") || desc.includes("ln") || desc.includes("lnv") || desc.includes("long neck") || desc.includes("lf") || desc.includes("ow") || desc.includes("ret")) return "GARRAFA";
    return "OUTRO";
  };

  // Divide os produtos por categorias de afinidade (Grupo e Embalagem)
  const getCategorizedGroups = (): Record<string, GroupData> => {
    const groups: Record<string, GroupData> = {};

    produtos.forEach(p => {
      const emb = getEmbalagem(p.descricao);
      const key = `${p.categoria}_${emb}`;

      if (!groups[key]) {
        groups[key] = {
          categoria: p.categoria,
          embalagem: emb,
          sobras: [],
          faltas: [],
          totalSobraBoxes: 0,
          totalFaltaBoxes: 0
        };
      }

      const diff = p.diferencaCaixas;
      if (diff > 0.001) {
        const integerSobra = Math.floor(diff);
        if (integerSobra > 0) {
          groups[key].sobras.push(p);
          groups[key].totalSobraBoxes += integerSobra;
        }
      } else if (diff < -0.001) {
        const integerFalta = Math.abs(Math.ceil(diff));
        if (integerFalta > 0) {
          groups[key].faltas.push(p);
          groups[key].totalFaltaBoxes += integerFalta;
        }
      }
    });

    return groups;
  };

  const groups = getCategorizedGroups();
  const groupKeys = Object.keys(groups).filter(key => groups[key].sobras.length > 0 && groups[key].faltas.length > 0);

  // Inicializa o primeiro grupo ativo automaticamente
  useEffect(() => {
    if (groupKeys.length > 0 && !activeGroupKey) {
      setActiveGroupKey(groupKeys[0]);
    }
  }, [produtos]);

  // Reseta os inputs do planejador ao trocar de grupo
  useEffect(() => {
    setPlannedSaidas({});
    setPlannedEntradas({});
    setAiJustificativa('');
    setErrorMessage('');
    setSuccessMessage('');
  }, [activeGroupKey]);

  // Carrega as recomendações de pares (1-para-1) anteriores
  const fetchPairRecommendations = async () => {
    setIsLoadingPairs(true);
    setErrorMessage('');
    try {
      const response = await fetch('/api/ai/inversion-recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();
      if (data.success) {
        setPairCandidates(data.candidates || []);
        const quantities: Record<string, number> = {};
        (data.candidates || []).forEach((c: InversionCandidate) => {
          quantities[`${c.sopSku}_${c.falSku}`] = c.caixasSugeridas;
        });
        setCustomQuantities(quantities);
      } else {
        setErrorMessage(data.error || 'Erro ao obter recomendações de pares.');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage('Falha ao comunicar com o servidor de Inteligência Artificial.');
    } finally {
      setIsLoadingPairs(false);
    }
  };

  useEffect(() => {
    fetchPairRecommendations();
  }, [produtos]);

  // Executa Inversão Contábil 1-para-1 do par selecionado
  const handleInvertStockPair = async (c: InversionCandidate) => {
    const customKey = `${c.sopSku}_${c.falSku}`;
    const qtyToInvert = customQuantities[customKey] || c.caixasSugeridas;

    if (qtyToInvert <= 0) {
      alert('Selecione uma quantidade válida maior que zero caixas.');
      return;
    }

    setIsExecuting(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const response = await fetch('/api/state/invert-stock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          skuSobra: c.sopSku,
          skuFalta: c.falSku,
          caixasInvertidas: qtyToInvert,
          usuario: operatorEmail
        })
      });

      const resData = await response.json();
      if (resData.success) {
        setSuccessMessage(`Compensação Efetuada: ${qtyToInvert} caixas do SKU ${c.sopSku} aplicadas contra SKU ${c.falSku}.`);
        await onRefresh();
        await fetchPairRecommendations();
      } else {
        setErrorMessage(resData.error || 'Não foi possível autorizar a inversão.');
      }
    } catch (e) {
      setErrorMessage('Ocorreu um erro no pipeline de auditoria física de inversão.');
    } finally {
      setIsExecuting(false);
    }
  };

  // Handlers para o Planejador em Lotes (Multi-SKU)
  const currentGroupData = activeGroupKey ? groups[activeGroupKey] : null;

  const handleSaidaChange = (sku: string, val: number, max: number) => {
    const bound = Math.min(max, Math.max(0, Math.floor(val)));
    setPlannedSaidas(prev => ({ ...prev, [sku]: bound }));
  };

  const handleEntradaChange = (sku: string, val: number, max: number) => {
    const bound = Math.min(max, Math.max(0, Math.floor(val)));
    setPlannedEntradas(prev => ({ ...prev, [sku]: bound }));
  };

  // Heurística de Correspondência Rápida local
  const executeLocalHeuristic = () => {
    if (!currentGroupData) return;
    
    // Zera os planejamentos anteriores
    const saídas: Record<string, number> = {};
    const entradas: Record<string, number> = {};

    const sSorted = [...currentGroupData.sobras].sort((a,b) => b.diferencaCaixas - a.diferencaCaixas);
    const fSorted = [...currentGroupData.faltas].sort((a,b) => Math.abs(b.diferencaCaixas) - Math.abs(a.diferencaCaixas));

    const totalSobra = sSorted.reduce((sum, s) => sum + Math.floor(s.diferencaCaixas), 0);
    const totalFalta = fSorted.reduce((sum, f) => sum + Math.abs(Math.ceil(f.diferencaCaixas)), 0);
    const maxMatchable = Math.min(totalSobra, totalFalta);

    // Distribui saídas
    let allocatedSaida = 0;
    sSorted.forEach(s => {
      const cap = Math.floor(s.diferencaCaixas);
      const toTake = Math.min(cap, maxMatchable - allocatedSaida);
      if (toTake > 0) {
        saídas[s.sku] = toTake;
        allocatedSaida += toTake;
      }
    });

    // Distribui entradas
    let allocatedEntrada = 0;
    fSorted.forEach(f => {
      const cap = Math.abs(Math.ceil(f.diferencaCaixas));
      const toTake = Math.min(cap, maxMatchable - allocatedEntrada);
      if (toTake > 0) {
        entradas[f.sku] = toTake;
        allocatedEntrada += toTake;
      }
    });

    setPlannedSaidas(saídas);
    setPlannedEntradas(entradas);
    setAiJustificativa('Cascata proporcional calculada automaticamente baseada na ordenação de desvios físicos.');
  };

  // Otimizador de Atribuição Avançado usando Gemini 3.5 Flash pelas APIs do CD
  const executeAIOptimizer = async () => {
    if (!currentGroupData) return;
    setIsAiCalculating(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      // Converte sobras e faltas locais para formatos compactos para enviar ao Gemini
      const subSobras = currentGroupData.sobras.map(s => ({
        sku: s.sku,
        descricao: s.descricao,
        sobra: Math.floor(s.diferencaCaixas),
        custoMedio: s.custoMedio
      }));

      const subFaltas = currentGroupData.faltas.map(f => ({
        sku: f.sku,
        descricao: f.descricao,
        falta: Math.abs(Math.ceil(f.diferencaCaixas)),
        custoMedio: f.custoMedio
      }));

      const response = await fetch('/api/ai/inversion-recommendations-multi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sobras: subSobras,
          faltas: subFaltas,
          categoria: currentGroupData.categoria,
          embalagem: currentGroupData.embalagem
        })
      });

      const resData = await response.json();
      if (resData.success) {
        // Popula as quantidades planejadas a partir do plano gerado pelo Gemini
        const saídas: Record<string, number> = {};
        const entradas: Record<string, number> = {};

        (resData.saidas || []).forEach((s: any) => {
          saídas[s.sku] = s.caixas;
        });
        (resData.entradas || []).forEach((e: any) => {
          entradas[e.sku] = e.caixas;
        });

        setPlannedSaidas(saídas);
        setPlannedEntradas(entradas);
        setAiJustificativa(resData.justificativa || 'O balanceamento do lote de SKU fechado foi calculado de forma autônoma pela Rede Neural Ambev.');
        setSuccessMessage('AI central calculou e pré-preencheu o melhor balanço físico-fiscal do lote!');
      } else {
        setErrorMessage(resData.error || 'Erro ao consultar otimização neural.');
      }
    } catch (e) {
      setErrorMessage('Erro de gateway ao consultar modelo generativo de balanceamento.');
    } finally {
      setIsAiCalculating(false);
    }
  };

  // Submete o planejamento de inversão contábil em lote
  const handleApplyGroupInversion = async () => {
    if (!currentGroupData) return;

    // Filtra apenas o que for maior que zero
    const saidasList = Object.entries(plannedSaidas)
      .map(([sku, caixas]) => ({ sku, caixas: Number(caixas) }))
      .filter(item => item.caixas > 0);

    const entradasList = Object.entries(plannedEntradas)
      .map(([sku, caixas]) => ({ sku, caixas: Number(caixas) }))
      .filter(item => item.caixas > 0);

    const sumSaidas: number = saidasList.reduce((sum, s) => sum + s.caixas, 0);
    const sumEntradas: number = entradasList.reduce((sum, e) => sum + e.caixas, 0);

    if (sumSaidas !== sumEntradas) {
      alert(`Erro: O total de caixas de saídas (${sumSaidas} cx) difere do total de caixas de entradas (${sumEntradas} cx). O inventário contábil precisa ficar perfeitamente balanceado.`);
      return;
    }

    if (sumSaidas <= 0) {
      alert('Selecione pelo menos 1 caixa de sobra e 1 caixa de falta correspondente no plano de equivalência.');
      return;
    }

    setIsExecuting(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const response = await fetch('/api/state/invert-stock-multi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          saidas: saidasList,
          entradas: entradasList,
          grupo: `${currentGroupData.categoria} - ${currentGroupData.embalagem}`,
          usuario: operatorEmail
        })
      });

      const data = await response.json();
      if (data.success) {
        setSuccessMessage(`Compensação em lote realizada com sucesso! O físico e o fiscal de ${saidasList.length + entradasList.length} SKUs agora convergem no sistema.`);
        setPlannedSaidas({});
        setPlannedEntradas({});
        setAiJustificativa('');
        await onRefresh();
      } else {
        setErrorMessage(data.error || 'Erro operacional no processamento de e-ajuste.');
      }
    } catch (err) {
      setErrorMessage('Falha ao processar envio de lote equilibrador.');
    } finally {
      setIsExecuting(false);
    }
  };

  // Exportar balanço estruturado no formato nativo exigido pelo Excel brasileiro (semi-cólon e BOM)
  const handleExportCSV = () => {
    if (!currentGroupData) return;

    const saidasList = Object.entries(plannedSaidas)
      .map(([sku, caixas]) => {
        const prod = currentGroupData.sobras.find(s => s.sku === sku);
        return {
          sku,
          descricao: prod ? prod.descricao : 'SKU Sobra',
          caixas: Number(caixas),
          custo: prod ? prod.custoMedio : 30.00,
          fatorHectolitro: prod ? prod.fatorHectolitro : 0.04
        };
      })
      .filter(item => item.caixas > 0);

    const entradasList = Object.entries(plannedEntradas)
      .map(([sku, caixas]) => {
        const prod = currentGroupData.faltas.find(f => f.sku === sku);
        return {
          sku,
          descricao: prod ? prod.descricao : 'SKU Falta',
          caixas: Number(caixas),
          custo: prod ? prod.custoMedio : 30.00,
          fatorHectolitro: prod ? prod.fatorHectolitro : 0.04
        };
      })
      .filter(item => item.caixas > 0);

    if (saidasList.length === 0 && entradasList.length === 0) {
      alert('Impossível exportar: Selecione pelo menos 1 caixa de saída ou entrada com quantidade definida.');
      return;
    }

    const headers = [
      "Categoria de Inversão",
      "Tipo Embalagem",
      "Tipo Operação",
      "Código SKU",
      "Descrição Ambev",
      "Quantidade Invertida (Cx)",
      "Custo Unitário Caixa (R$)",
      "Custo Total (R$)",
      "Hectolitros Compensados (HL)",
      "Auditor Responsável",
      "Data e Hora da Operação"
    ];

    const rows: string[][] = [];
    const timestamp = new Date().toLocaleString('pt-BR');

    saidasList.forEach(s => {
      rows.push([
        currentGroupData.categoria,
        currentGroupData.embalagem,
        "SAÍDA DO ESTOQUE (Abatendo Sobra Física)",
        s.sku,
        s.descricao,
        s.caixas.toString(),
        s.custo.toFixed(2),
        (s.caixas * s.custo).toFixed(2),
        (s.caixas * s.fatorHectolitro).toFixed(4),
        operatorEmail,
        timestamp
      ]);
    });

    entradasList.forEach(e => {
      rows.push([
        currentGroupData.categoria,
        currentGroupData.embalagem,
        "ENTRADA NO ESTOQUE (Compensando Falta Física)",
        e.sku,
        e.descricao,
        e.caixas.toString(),
        e.custo.toFixed(2),
        (e.caixas * e.custo).toFixed(2),
        (e.caixas * e.fatorHectolitro).toFixed(4),
        operatorEmail,
        timestamp
      ]);
    });

    // Formata o CSV com o BOM de conformidade Excel em Português
    const csvContent = "\ufeff" + [
      headers.join(";"),
      ...rows.map(row => row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(";"))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Planejamento_Inversao_${currentGroupData.categoria}_${currentGroupData.embalagem}_${Date.now()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Cálculos de Resumo do Grupo Ativo
  const sumSaidas: number = (Object.values(plannedSaidas) as number[]).reduce((sum, n) => sum + Number(n), 0);
  const sumEntradas: number = (Object.values(plannedEntradas) as number[]).reduce((sum, n) => sum + Number(n), 0);
  const isPerfectBalanced = sumSaidas > 0 && sumSaidas === sumEntradas;
  const valuationSaidas = currentGroupData ? Object.entries(plannedSaidas).reduce((sum, [sku, qty]) => {
    const prod = currentGroupData.sobras.find(s => s.sku === sku);
    return sum + (Number(qty) * (prod ? prod.custoMedio : 0));
  }, 0) : 0;

  const valuationEntradas = currentGroupData ? Object.entries(plannedEntradas).reduce((sum, [sku, qty]) => {
    const prod = currentGroupData.faltas.find(f => f.sku === sku);
    return sum + (Number(qty) * (prod ? prod.custoMedio : 0));
  }, 0) : 0;

  const hlSaindo = currentGroupData ? Object.entries(plannedSaidas).reduce((sum, [sku, qty]) => {
    const prod = currentGroupData.sobras.find(s => s.sku === sku);
    return sum + (Number(qty) * (prod ? prod.fatorHectolitro : 0));
  }, 0) : 0;

  const hlEntrando = currentGroupData ? Object.entries(plannedEntradas).reduce((sum, [sku, qty]) => {
    const prod = currentGroupData.faltas.find(f => f.sku === sku);
    return sum + (Number(qty) * (prod ? prod.fatorHectolitro : 0));
  }, 0) : 0;

  const totalSobraBoxesInit = currentGroupData ? currentGroupData.totalSobraBoxes : 0;
  const totalFaltaBoxesInit = currentGroupData ? currentGroupData.totalFaltaBoxes : 0;
  const divergenciaTotalInicial = totalSobraBoxesInit + totalFaltaBoxesInit;
  const divergenciaCompensadaCaixas = sumSaidas + sumEntradas;
  const divergenciaRestanteCaixas = Math.max(0, divergenciaTotalInicial - divergenciaCompensadaCaixas);
  const pctCompensacao = divergenciaTotalInicial > 0 
    ? Math.min(100, Math.round((divergenciaCompensadaCaixas / divergenciaTotalInicial) * 100))
    : 0;

  return (
    <div className="space-y-6" id="stock-inversion-ai-root">
      
      {/* Banner de Cabeçalho do Módulo */}
      <div className="relative overflow-hidden bg-slate-950 text-white rounded-3xl border border-slate-850 p-6 sm:p-8 shadow-xl shadow-slate-950/20">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/40 via-transparent to-slate-900/10 pointer-events-none" />
        
        <div className="absolute top-0 right-0 p-8 text-indigo-500/10 pointer-events-none select-none">
          <Sparkles className="w-24 h-24 animate-pulse" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 bg-indigo-500/10 border border-indigo-400/20 text-indigo-400 text-[10px] font-black rounded-lg uppercase tracking-wider font-mono">
              <Sparkles className="w-3.5 h-3.5" />
              Equilíbrio Físico vs Fiscal CD Pau Brasil
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Inversões & Compensações de Estoque
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
              Compense divergências de inventários identificando produtos do mesmo grupo de embalagem (lata por lata, pet por pet) que possuem sobressalentes e déficits opostos, regularizando as quantidades de forma flat em caixas fechadas.
            </p>
          </div>

          <div className="flex flex-wrap gap-2 shrink-0">
            <button
              type="button"
              onClick={onRefresh}
              disabled={isExecuting}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-bold transition-all border border-slate-700 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Sincronizar CD
            </button>
          </div>
        </div>
      </div>

      {/* Alertas de Operação */}
      {successMessage && (
        <div className="bg-emerald-900/20 border border-emerald-500/30 p-4 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-3 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="bg-rose-900/20 border border-rose-500/30 p-4 rounded-xl text-rose-300 text-xs font-semibold flex items-center gap-3 animate-fadeIn">
          <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Selector de Modo de Interface (Grupos em Lotes vs Pares Unitários) */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTabMode('grupos')}
          className={`px-5 py-3 text-xs font-black tracking-wide border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
            activeTabMode === 'grupos'
              ? 'border-indigo-600 text-indigo-600 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          📦 Planejador de Inversão por Grupos (Recomendado)
        </button>
        <button
          onClick={() => setActiveTabMode('pares')}
          className={`px-5 py-3 text-xs font-black tracking-wide border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
            activeTabMode === 'pares'
              ? 'border-indigo-600 text-indigo-600 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shuffle className="w-4 h-4" />
          🔗 Pares de Equivalência Direta (1-para-1)
        </button>
      </div>

      {activeTabMode === 'grupos' ? (
        <div className="space-y-6">
          
          {/* Listagem de Grupos em Destaque (Cards com Resumo) */}
          <div className="space-y-2">
            <h3 className="text-xs uppercase font-black text-slate-500 tracking-wider">Grupos com Oportunidades de Compensação</h3>
            {groupKeys.length === 0 ? (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <h4 className="font-bold text-slate-700 text-xs">Físico e Fiscal Próximos de 100%</h4>
                <p className="text-[11px] text-slate-400">Não há no momento grupos de afinidades similares apresentando sobras e faltas contraditórias simultâneas.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {groupKeys.map(key => {
                  const grp = groups[key];
                  const isActive = activeGroupKey === key;
                  return (
                    <button
                      key={key}
                      onClick={() => setActiveGroupKey(key)}
                      className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                        isActive
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-650/15'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span className={`text-[10px] uppercase font-black block tracking-widest ${isActive ? 'text-indigo-200' : 'text-slate-400'}`}>
                        {grp.categoria}
                      </span>
                      <h4 className="text-sm font-black mt-0.5 leading-tight">{grp.embalagem}</h4>
                      
                      <div className="mt-3 flex items-center gap-3 text-[10.5px]">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-indigo-300' : 'bg-blue-500'}`} />
                          <span className={isActive ? 'text-indigo-200' : 'text-slate-500'}>
                            {grp.sobras.length} sobras (<strong className="font-mono">{grp.totalSobraBoxes}</strong> cx)
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-indigo-300' : 'bg-rose-500'}`} />
                          <span className={isActive ? 'text-indigo-200' : 'text-slate-500'}>
                            {grp.faltas.length} faltas (<strong className="font-mono">{grp.totalFaltaBoxes}</strong> cx)
                          </span>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {currentGroupData && (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
              
              {/* Header do Planejador de Lote */}
              <div className="p-5 border-b border-slate-150 bg-slate-50 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1 px-2.5 rounded-full bg-slate-200 text-slate-800 text-[9px] font-black uppercase tracking-wider font-mono">
                      {currentGroupData.categoria}
                    </span>
                    <span className="p-1 px-2.5 rounded-full bg-indigo-50 text-indigo-700 text-[9px] font-black uppercase tracking-wider font-mono">
                      Embalagem: {currentGroupData.embalagem}
                    </span>
                  </div>
                  <h3 className="text-base font-black text-slate-800">
                    Gargalos de Divergência Simétrica no CD Pau Brasil
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Dívidas e sobras idênticas em vasilhame. Realize uma compensação de quantidades de caixa fechada (SKU Fechado) sem casas decimais.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={executeAIOptimizer}
                    disabled={isAiCalculating || isExecuting}
                    className="flex items-center gap-1.5 px-3 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-black shadow-md cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isAiCalculating ? 'animate-spin' : ''}`} />
                    Planejar com IA (Gemini)
                  </button>

                  <button
                    type="button"
                    onClick={executeLocalHeuristic}
                    disabled={isExecuting}
                    className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-650 hover:to-indigo-650 text-white rounded-lg text-xs font-black shadow-md cursor-pointer"
                  >
                    <Shuffle className="w-3.5 h-3.5" />
                    Balanço Rápido
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPlannedSaidas({});
                      setPlannedEntradas({});
                      setAiJustificativa('');
                    }}
                    className="flex items-center gap-1 px-2 py-2 text-slate-500 hover:text-slate-800 text-xs font-bold"
                    title="Zerar Planejamento"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Justificativa de Compensação Ambev */}
              {aiJustificativa && (
                <div className="bg-purple-50/50 p-4 border-b border-indigo-100 flex items-start gap-2.5 text-slate-700 text-xs">
                  <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5 animate-pulse" />
                  <div>
                    <span className="font-extrabold text-purple-800 text-[11px] block uppercase font-mono tracking-wider">Proposta de Inversão da Rede Neural</span>
                    <p className="mt-0.5 leading-relaxed italic">{aiJustificativa}</p>
                  </div>
                </div>
              )}

              {/* Area Lado a Lado (Saídas vs Entradas) */}
              <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
                
                {/* LADO ESQUERDO: SAINDO DO ESTOQUE (PRODUTOS COM SOBRA FÍSICA) */}
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-dashed border-slate-200 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0 animate-pulse" />
                      <h4 className="font-black text-slate-800 text-xs uppercase tracking-wider">SAÍDAS (Reduzindo Sobras)</h4>
                    </div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase font-mono">Físico &gt; Fiscal</span>
                  </div>

                  <div className="space-y-2.5">
                    {currentGroupData.sobras.map(item => {
                      const limit = Math.floor(item.diferencaCaixas);
                      const currentVal = plannedSaidas[item.sku] || 0;
                      
                      return (
                        <div key={item.sku} className="p-3.5 rounded-xl border border-blue-100 bg-blue-50/20 hover:bg-blue-50/40 transition-colors flex items-center justify-between gap-4">
                          <div className="space-y-1 min-w-0">
                            <span className="font-mono text-[11px] font-black text-slate-800 tracking-tight block">SKU {item.sku.replace(/^0+/, '')}</span>
                            <h5 className="text-[11.5px] text-slate-700 font-bold truncate leading-tight block">{item.descricao}</h5>
                            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10px]">
                              <span className="text-slate-400">Sobra: <strong className="text-blue-600 font-mono font-extrabold">+{limit} cx</strong></span>
                              <span className="text-slate-350">|</span>
                              <span className="text-slate-400">Curva {item.curvaABC || 'X'}</span>
                              <span className="text-slate-350">|</span>
                              <span className="text-slate-400 font-mono">R$ {item.custoMedio.toLocaleString('pt-BR')}</span>
                            </div>
                          </div>

                          {/* Seletor SKU Fechado */}
                          <div className="flex items-center gap-1.5 shrink-0 select-none">
                            <button
                              type="button"
                              onClick={() => handleSaidaChange(item.sku, currentVal - 1, limit)}
                              disabled={currentVal <= 0}
                              className="w-7 h-7 bg-white hover:bg-slate-100 disabled:opacity-40 border border-slate-250 rounded-lg text-slate-600 flex items-center justify-center cursor-pointer font-bold text-xs"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <input
                              type="number"
                              min="0"
                              max={limit}
                              step="1"
                              value={currentVal || ''}
                              placeholder="0"
                              onChange={(e) => handleSaidaChange(item.sku, Number(e.target.value), limit)}
                              className="w-12 h-7 rounded-lg border border-slate-350 bg-white text-center text-xs font-black text-slate-850 outline-none focus:border-indigo-650"
                            />
                            <button
                              type="button"
                              onClick={() => handleSaidaChange(item.sku, currentVal + 1, limit)}
                              disabled={currentVal >= limit}
                              className="w-7 h-7 bg-white hover:bg-slate-100 disabled:opacity-40 border border-slate-250 rounded-lg text-slate-600 flex items-center justify-center cursor-pointer font-bold text-xs"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaidaChange(item.sku, limit, limit)}
                              className="p-1 px-2 text-[9px] bg-slate-100 text-slate-500 font-bold rounded-lg border border-slate-200 hover:bg-slate-200 cursor-pointer uppercase transition-colors"
                            >
                              MAX
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* LADO DIREITO: ENTRANDO NO ESTOQUE (PRODUTOS COM FALTA FÍSICA) */}
                <div className="p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-dashed border-slate-200 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0 animate-pulse" />
                      <h4 className="font-black text-slate-800 text-xs uppercase tracking-wider">ENTRADAS (Preenchendo Faltas)</h4>
                    </div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase font-mono">Físico &lt; Fiscal</span>
                  </div>

                  <div className="space-y-2.5">
                    {currentGroupData.faltas.map(item => {
                      const limit = Math.abs(Math.ceil(item.diferencaCaixas));
                      const currentVal = plannedEntradas[item.sku] || 0;
                      
                      return (
                        <div key={item.sku} className="p-3.5 rounded-xl border border-rose-100 bg-rose-50/15 hover:bg-rose-50/30 transition-colors flex items-center justify-between gap-4">
                          <div className="space-y-1 min-w-0">
                            <span className="font-mono text-[11px] font-black text-slate-800 tracking-tight block">SKU {item.sku.replace(/^0+/, '')}</span>
                            <h5 className="text-[11.5px] text-slate-700 font-bold truncate leading-tight block">{item.descricao}</h5>
                            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10px]">
                              <span className="text-slate-400">Falta: <strong className="text-rose-600 font-mono font-extrabold">-{limit} cx</strong></span>
                              <span className="text-slate-350">|</span>
                              <span className="text-slate-400">Curva {item.curvaABC || 'X'}</span>
                              <span className="text-slate-350">|</span>
                              <span className="text-slate-400 font-mono">R$ {item.custoMedio.toLocaleString('pt-BR')}</span>
                            </div>
                          </div>

                          {/* Seletor SKU Fechado */}
                          <div className="flex items-center gap-1.5 shrink-0 select-none">
                            <button
                              type="button"
                              onClick={() => handleEntradaChange(item.sku, currentVal - 1, limit)}
                              disabled={currentVal <= 0}
                              className="w-7 h-7 bg-white hover:bg-slate-100 disabled:opacity-40 border border-slate-250 rounded-lg text-slate-600 flex items-center justify-center cursor-pointer font-bold text-xs"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <input
                              type="number"
                              min="0"
                              max={limit}
                              step="1"
                              value={currentVal || ''}
                              placeholder="0"
                              onChange={(e) => handleEntradaChange(item.sku, Number(e.target.value), limit)}
                              className="w-12 h-7 rounded-lg border border-slate-350 bg-white text-center text-xs font-black text-slate-850 outline-none focus:border-indigo-650"
                            />
                            <button
                              type="button"
                              onClick={() => handleEntradaChange(item.sku, currentVal + 1, limit)}
                              disabled={currentVal >= limit}
                              className="w-7 h-7 bg-white hover:bg-slate-100 disabled:opacity-40 border border-slate-250 rounded-lg text-slate-600 flex items-center justify-center cursor-pointer font-bold text-xs"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleEntradaChange(item.sku, limit, limit)}
                              className="p-1 px-2 text-[9px] bg-slate-100 text-slate-500 font-bold rounded-lg border border-slate-200 hover:bg-slate-200 cursor-pointer uppercase transition-colors"
                            >
                              MAX
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* PAINEL DE SIMULAÇÃO GRÁFICA & IMPACTO EM TEMPO REAL */}
              <div className="p-5 border-t border-slate-200 bg-slate-50/25 space-y-6" id="realtime-interactive-chart-panel">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h4 className="text-xs uppercase font-black text-slate-500 tracking-wider flex items-center gap-2">
                      <Activity className="w-4 h-4 text-indigo-600 animate-pulse" />
                      SIMULAÇÃO GRÁFICA DE IMPACTO (TEMPO REAL)
                    </h4>
                    <p className="text-[11px] text-slate-500 font-sans">
                      Visualize a mitigação financeira, de volume em Hectolitros e a redução da divergência global à medida que preenche a compensação.
                    </p>
                  </div>
                  
                  {/* Excel Simulation Export Button */}
                  <button
                    type="button"
                    onClick={handleExportCSV}
                    disabled={sumSaidas === 0 && sumEntradas === 0}
                    className="flex items-center gap-2 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg text-xs cursor-pointer transition-all shadow-sm shadow-emerald-700/10 disabled:opacity-50 disabled:cursor-not-allowed select-none"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    EXPORTAR EXCEL (.CSV)
                  </button>
                </div>

                {/* Grid do Painel Gráfico */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                  
                  {/* Card 1: Balanço Financeiro */}
                  <div className="bg-white p-4.5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                      <span className="text-[10.5px] font-black text-slate-700 uppercase tracking-widest">Balanço de Custo (R$)</span>
                      <span className="text-[9.5px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-mono font-bold">R$ Custo do Ajuste</span>
                    </div>
                    
                    {/* Recharts BarChart - Balanceamento de Custo */}
                    <div className="h-40 w-full" id="chart-financeiro-container">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Saindo (Sobra)", Valor: valuationSaidas },
                            { name: "Entrando (Falta)", Valor: valuationEntradas }
                          ]}
                          margin={{ top: 10, right: 10, left: 15, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: 700 }} stroke="#94a3b8" />
                          <YAxis tick={{ fontSize: 9, fontWeight: 500 }} stroke="#94a3b8" tickFormatter={(v) => `R$${v}`} />
                          <Tooltip
                            formatter={(value: any) => [`R$ ${Number(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 'Valor']}
                            contentStyle={{ fontSize: 10, fontWeight: 700, borderRadius: 8 }}
                          />
                          <Bar dataKey="Valor" radius={[4, 4, 0, 0]}>
                            <Cell fill="#2563eb" />
                            <Cell fill="#db2777" />
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-center text-[10.5px] border-t border-slate-100 pt-2 font-sans">
                      <div className="bg-blue-50/20 p-1.5 rounded-lg border border-blue-100/60">
                        <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">VALOR SAINDO</span>
                        <strong className="text-blue-700 font-mono font-extrabold">R$ {valuationSaidas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>
                      </div>
                      <div className="bg-pink-50/20 p-1.5 rounded-lg border border-pink-100/50">
                        <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">VALOR ENTRANDO</span>
                        <strong className="text-pink-700 font-mono font-extrabold">R$ {valuationEntradas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Card 2: Balanço de Hectolitros */}
                  <div className="bg-white p-4.5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                      <span className="text-[10.5px] font-black text-slate-700 uppercase tracking-widest">Balanço Líquido (HL)</span>
                      <span className="text-[9.5px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-mono font-bold">HL Hectolitro</span>
                    </div>
                    
                    {/* Recharts BarChart - Balanceamento de Hectolitros */}
                    <div className="h-40 w-full" id="chart-hectolitros-container">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "HL Saída", Volume: Number(hlSaindo.toFixed(4)) },
                            { name: "HL Entrada", Volume: Number(hlEntrando.toFixed(4)) }
                          ]}
                          margin={{ top: 10, right: 10, left: 15, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: 700 }} stroke="#94a3b8" />
                          <YAxis tick={{ fontSize: 9, fontWeight: 500 }} stroke="#94a3b8" tickFormatter={(v) => `${v} HL`} />
                          <Tooltip
                            formatter={(value: any) => [`${Number(value).toFixed(4)} HL`, 'Volume Líquido']}
                            contentStyle={{ fontSize: 10, fontWeight: 700, borderRadius: 8 }}
                          />
                          <Bar dataKey="Volume" radius={[4, 4, 0, 0]}>
                            <Cell fill="#0284c7" />
                            <Cell fill="#d97706" />
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-center text-[10.5px] border-t border-slate-100 pt-2 font-sans">
                      <div className="bg-sky-50/20 p-1.5 rounded-lg border border-sky-100/60">
                        <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">HL SAINDO</span>
                        <strong className="text-sky-700 font-mono font-extrabold">{hlSaindo.toFixed(4)} <span className="text-[9px] text-slate-400">HL</span></strong>
                      </div>
                      <div className="bg-amber-50/20 p-1.5 rounded-lg border border-amber-100/50">
                        <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">HL ENTRANDO</span>
                        <strong className="text-amber-700 font-mono font-extrabold">{hlEntrando.toFixed(4)} <span className="text-[9px] text-slate-400">HL</span></strong>
                      </div>
                    </div>
                  </div>

                  {/* Card 3: Mitigação da Divergência */}
                  <div className="bg-white p-4.5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                      <span className="text-[10.5px] font-black text-slate-700 uppercase tracking-widest">Divergência de Caixas</span>
                      <span className="text-[9.5px] bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded font-mono font-bold">{pctCompensacao}% mitigado</span>
                    </div>

                    {/* Recharts BarChart - Mitigação de Divergência em Caixa Fechada */}
                    <div className="h-40 w-full" id="chart-mitigacao-container">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Inicial", Caixas: divergenciaTotalInicial },
                            { name: "Compensado", Caixas: divergenciaCompensadaCaixas },
                            { name: "Restante", Caixas: divergenciaRestanteCaixas }
                          ]}
                          margin={{ top: 10, right: 10, left: 15, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: 700 }} stroke="#94a3b8" />
                          <YAxis tick={{ fontSize: 9, fontWeight: 500 }} stroke="#94a3b8" />
                          <Tooltip
                            formatter={(value: any) => [`${value} caixas`, 'Divergência Físico-Fiscal']}
                            contentStyle={{ fontSize: 10, fontWeight: 700, borderRadius: 8 }}
                          />
                          <Bar dataKey="Caixas" radius={[4, 4, 0, 0]}>
                            <Cell fill="#64748b" />
                            <Cell fill="#10b981" />
                            <Cell fill={divergenciaRestanteCaixas > 0 ? "#f97316" : "#10b981"} />
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="flex items-center justify-between text-[11px] bg-slate-50 p-2 rounded-lg border border-slate-150 font-sans">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
                        <span className="text-slate-505 font-bold uppercase tracking-wider text-[9px]">COMPENSADO:</span>
                      </div>
                      <strong className="text-emerald-700 font-mono font-black">{divergenciaCompensadaCaixas} / {divergenciaTotalInicial} cx ({pctCompensacao}%)</strong>
                    </div>
                  </div>

                </div>
              </div>

              {/* PAINEL DE CONTROLE DE BALANÇO DE COMPENSAÇÃO */}
              <div className="p-5 border-t border-slate-200 bg-slate-50/50 flex flex-col md:flex-row items-center justify-between gap-6">
                
                {/* Visualizadores de Volume Real-Time */}
                <div className="flex flex-col sm:flex-row flex-wrap items-center gap-6">
                  
                  <div className="space-y-0.5 text-center sm:text-left">
                    <span className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold block">TOTAL SAÍDAS (SOBRAS)</span>
                    <strong className="text-xl font-mono text-blue-600 font-black">{sumSaidas} <span className="text-xs text-slate-400 font-sans font-semibold">cx</span></strong>
                  </div>

                  <div className="self-stretch w-px bg-slate-200 hidden sm:block" />

                  <div className="space-y-0.5 text-center sm:text-left">
                    <span className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold block">TOTAL ENTRADAS (FALTAS)</span>
                    <strong className="text-xl font-mono text-rose-600 font-black">{sumEntradas} <span className="text-xs text-slate-400 font-sans font-semibold">cx</span></strong>
                  </div>

                  <div className="self-stretch w-px bg-slate-200 hidden sm:block" />

                  {/* Detalhe Financeiro do Ajuste */}
                  <div className="space-y-0.5 text-center sm:text-left">
                    <span className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold block">VALOR COMPENSADO</span>
                    <strong className="text-base text-emerald-600 font-sans font-black">
                      R$ {valuationSaidas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </strong>
                  </div>

                </div>

                {/* Status central do Acordo & Ações de Envio/Exportação */}
                <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto shrink-0 select-none">
                  
                  {/* Badge de Balanceamento */}
                  <div className="w-full sm:w-auto shrink-0">
                    {sumSaidas === 0 && sumEntradas === 0 ? (
                      <span className="p-3.5 rounded-xl border border-slate-200 text-slate-550 text-[11px] font-bold block text-center bg-slate-50">
                        Aguardando seleção...
                      </span>
                    ) : isPerfectBalanced ? (
                      <span className="p-3.5 rounded-xl border border-emerald-200 text-emerald-700 text-[11px] font-bold block text-center bg-emerald-50 flex items-center gap-2 justify-center">
                        <Check className="w-4 h-4 text-emerald-600 animate-bounce" />
                        Equilíbrio de Estoque Perfeito!
                      </span>
                    ) : (
                      <span className="p-3.5 rounded-xl border border-amber-250 text-amber-800 text-[11.5px] font-bold block text-center bg-amber-50 leading-tight">
                        Divergência: {Math.abs(sumSaidas - sumEntradas)} caixas
                        <span className="block text-[9.5px] font-medium text-amber-600 mt-0.5 font-sans">Ajuste sobras & faltas para compensar</span>
                      </span>
                    )}
                  </div>

                  {/* Export Excel Button */}
                  <button
                    type="button"
                    onClick={handleExportCSV}
                    disabled={sumSaidas === 0 && sumEntradas === 0}
                    className="w-full sm:w-auto px-4 py-3 border border-emerald-555 hover:bg-emerald-50 text-emerald-750 font-black rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    EXPORTAR EXCEL
                  </button>

                  {/* Apply Button */}
                  <button
                    type="button"
                    onClick={handleApplyGroupInversion}
                    disabled={!isPerfectBalanced || isExecuting}
                    className="w-full sm:w-auto px-5 py-3 bg-indigo-650 text-white border border-indigo-555 hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed font-black rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shrink-0"
                  >
                    {isExecuting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>OPERANDO...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>EFETUAR INVERSÃO</span>
                      </>
                    )}
                  </button>

                </div>

              </div>

            </div>
          )}

        </div>
      ) : (
        // ABA DE PARES DIRETOS (Anterior)
        <div className="bg-white rounded-3xl border border-slate-200 shadow-lg overflow-hidden font-sans">
          
          <div className="p-5 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Oportunidades de Inversão Sugeridas pela IA</h3>
              <p className="text-[11px] text-slate-500">Pares simétricos diretos recomendados pelo algoritmo com base em semelhança do SKU.</p>
            </div>

            <div className="flex items-center gap-2">
              <span className="p-1 px-2.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold border border-slate-200 flex items-center gap-1.5 font-mono">
                <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                Operador: {operatorEmail}
              </span>
            </div>
          </div>

          {isLoadingPairs ? (
            <div className="p-20 text-center space-y-4">
              <div className="w-8 h-8 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin mx-auto"></div>
              <p className="text-xs text-slate-500 font-mono font-bold">Gerando pareamento simétrico do CD Pau Brasil...</p>
            </div>
          ) : pairCandidates.length === 0 ? (
            <div className="p-16 text-center space-y-3">
              <div className="w-12 h-12 bg-slate-150 rounded-full flex items-center justify-center mx-auto text-slate-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-700 text-xs">Nenhum par isolado encontrado.</h4>
              <p className="text-[11px] text-slate-400 max-w-sm mx-auto leading-relaxed">
                Utilize o Planejador por Grupos acima para criar inversões customizadas multilaterais que se compensam mutuamente.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pairCandidates.map((c, idx) => {
                const customKey = `${c.sopSku}_${c.falSku}`;
                const selectedQty = customQuantities[customKey] || c.caixasSugeridas;
                const maxPossibleQty = c.caixasSugeridas;

                let viabClass = "bg-emerald-50 text-emerald-700 border-emerald-200";
                if (c.viabilidade === 'MÉDIA') viabClass = "bg-amber-50 text-amber-700 border-amber-200";
                if (c.viabilidade === 'BAIXA') viabClass = "bg-rose-50 text-rose-700 border-rose-250";

                return (
                  <div key={`${c.sopSku}_${c.falSku}`} className="p-5 hover:bg-slate-50/40 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    
                    {/* Informações */}
                    <div className="flex-1 space-y-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="p-0.5 px-2 rounded-full bg-slate-100 text-slate-600 text-[9px] font-black tracking-wide border border-slate-200 uppercase">
                          {c.categoria}
                        </span>
                        <span className="p-0.5 px-2 rounded-full bg-indigo-50 text-indigo-700 text-[9px] font-black tracking-wide border border-indigo-150 uppercase">
                          📦 Embalagem: {c.embalagem}
                        </span>
                        <span className={`p-0.5 px-2 rounded-full text-[9px] font-black border uppercase tracking-wider ${viabClass}`}>
                          Viabilidade IA: {c.viabilidade}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-11 items-center gap-3">
                        <div className="sm:col-span-5 bg-blue-50/40 p-3 rounded-xl border border-blue-100/70">
                          <div className="flex items-start gap-2.5">
                            <span className="bg-blue-600 text-white rounded px-1.5 py-0.5 text-[9px] font-bold font-mono shrink-0">SOBRA</span>
                            <div>
                              <span className="font-mono text-xs font-black text-slate-800 tracking-tight block">SKU {c.sopSku.replace(/^0+/, '')}</span>
                              <span className="text-[11.5px] text-slate-605 font-semibold block truncate max-w-[240px]">{c.sopDesc}</span>
                              <span className="text-[10px] text-slate-400 block mt-0.5">Disponível: +{c.sopSobra} cx</span>
                            </div>
                          </div>
                        </div>

                        <div className="sm:col-span-1 flex justify-center">
                          <ArrowRight className="w-4 h-4 text-slate-400" />
                        </div>

                        <div className="sm:col-span-5 bg-rose-50/30 p-3 rounded-xl border border-rose-105">
                          <div className="flex items-start gap-2.5">
                            <span className="bg-rose-600 text-white rounded px-1.5 py-0.5 text-[9px] font-bold font-mono shrink-0">FALTA</span>
                            <div>
                              <span className="font-mono text-xs font-black text-slate-800 tracking-tight block">SKU {c.falSku.replace(/^0+/, '')}</span>
                              <span className="text-[11.5px] text-slate-605 font-semibold block truncate max-w-[240px]">{c.falDesc}</span>
                              <span className="text-[10px] text-slate-400 block mt-0.5">Falta: {c.falFalta} cx</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 bg-slate-50 p-3 rounded-xl border border-slate-150 text-[11px] text-slate-600">
                        <Sparkles className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                        <div>
                          <strong>Contextualização Recomendada pelo Modelo: </strong>
                          {c.justificativa}
                        </div>
                      </div>
                    </div>

                    {/* Detalhes de Qtd e Acordo */}
                    <div className="lg:w-72 bg-slate-50/50 p-4 rounded-2xl border border-slate-200 flex flex-col justify-between gap-4 shrink-0 font-sans">
                      
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs text-slate-500">
                          <span>Quantidade (Caixa Fechada):</span>
                          <span className="font-bold text-slate-700 font-mono">Max {maxPossibleQty} cx</span>
                        </div>

                        <div className="grid grid-cols-12 items-center bg-white border border-slate-300 rounded-xl overflow-hidden">
                          <input
                            type="number"
                            value={selectedQty}
                            min="1"
                            max={maxPossibleQty}
                            onChange={(e) => {
                              const v = Math.min(maxPossibleQty, Math.max(1, Math.floor(Number(e.target.value))));
                              setCustomQuantities(prev => ({ ...prev, [customKey]: v }));
                            }}
                            className="col-span-7 px-3 py-2 text-center text-xs font-semibold font-mono text-slate-800 border-none outline-none bg-transparent"
                          />
                          <span className="col-span-5 px-2 py-2 text-[10px] text-slate-450 text-center border-l border-slate-200 font-extrabold bg-slate-50">
                            Caixas
                          </span>
                        </div>
                      </div>

                      <div className="bg-white p-2.5 rounded-lg border border-slate-100 text-[10px] text-slate-500 space-y-1">
                        <div className="flex items-center justify-between">
                          <span>Volume Estimado:</span>
                          <strong className="text-slate-700 font-mono">
                            {(selectedQty * (c.hlSugeridos / c.caixasSugeridas)).toFixed(4)} HL
                          </strong>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Equivalência Financeira:</span>
                          <strong className="text-emerald-600 font-mono">
                            R$ {(selectedQty * c.sobCusto).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </strong>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleInvertStockPair(c)}
                        disabled={isExecuting}
                        className="w-full py-2.5 px-4 bg-indigo-650 text-white hover:bg-indigo-600 rounded-xl text-xs font-black shadow-md border border-indigo-555 transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        Compensar Par
                      </button>

                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

    </div>
  );
}
