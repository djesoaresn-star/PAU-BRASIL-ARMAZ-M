/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { 
  DollarSign, 
  Layers, 
  Percent, 
  TrendingUp, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  Flame,
  ArrowRight,
  Download,
  UploadCloud,
  FileSpreadsheet,
  Trash2,
  Upload,
  RefreshCw
} from 'lucide-react';
import { ProdutoConsolidado, Categoria, CurvaABC } from '../types';
import * as XLSX from 'xlsx';

interface DashboardExecutiveProps {
  produtos: ProdutoConsolidado[];
  logsAuditoria: any[];
  onTabChange: (tab: string) => void;
  onRefresh?: () => Promise<void>;
}

export default function DashboardExecutive({ produtos, logsAuditoria, onTabChange, onRefresh }: DashboardExecutiveProps) {
  // Estados para Importação Integrada de Vendas do Dia Anterior (Coluna J - SKU Fechado)
  const [isDragActive, setIsDragActive] = React.useState(false);
  const [uploading, setUploading] = React.useState(false);
  const [uploadResult, setUploadResult] = React.useState<{ success: boolean; message: string; count: number } | null>(null);
  const [uploadError, setUploadError] = React.useState<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = React.useState<string | null>(null);
  const [viewMode, setViewMode] = React.useState<'financial' | 'volume'>('financial');

  // Manipuladores de Arrasto de Arquivo (Vendas Ontem)
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setUploadedFileName(file.name);
      processFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedFileName(file.name);
      processFile(file);
    }
  };

  const sendSalesToServer = async (vendasOntemList: { sku: string; vendaOntemCaixas: number }[]) => {
    try {
      const res = await fetch("/api/state/import-sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vendasOntem: vendasOntemList })
      });
      const data = await res.json();
      if (data.success) {
        setUploadResult({ success: true, message: data.message, count: vendasOntemList.length });
        if (onRefresh) {
          await onRefresh();
        }
      } else {
        throw new Error(data.error || "Erro ao injetar saídas do CD.");
      }
    } catch (err: any) {
      setUploadError(err.message || "Erro de conexão ao salvar vendas.");
    } finally {
      setUploading(false);
    }
  };

  const processFile = async (file: File) => {
    setUploading(true);
    setUploadResult(null);
    setUploadError(null);

    try {
      const reader = new FileReader();
      const fileExt = file.name.split('.').pop()?.toLowerCase();

      if (fileExt === 'xlsx' || fileExt === 'xls') {
        reader.onload = async (e: any) => {
          try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            if (workbook.SheetNames.length === 0) {
              throw new Error("Esta planilha do Excel não possui planilhas legíveis.");
            }

            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

            if (rows.length < 2) {
              throw new Error("O documento deve possuir pelo menos o cabeçalho e uma linha de vendas.");
            }

            // Normaliza cabeçalhos para localizar a coluna do SKU
            const headers = rows[0].map(h => String(h || "").trim().toUpperCase());
            let skuColIndex = 0; // Padrão: coluna A (0)

            const foundIdx = headers.findIndex(h => h.includes('SKU') || h.includes('PRODUTO') || h.includes('CODIGO') || h.includes('COD'));
            if (foundIdx !== -1) {
              skuColIndex = foundIdx;
            }

            const vendasOntemList: { sku: string; vendaOntemCaixas: number }[] = [];

            for (let i = 1; i < rows.length; i++) {
              const row = rows[i];
              if (!row || row.length === 0) continue;

              const skuRaw = row[skuColIndex];
              if (skuRaw === undefined || skuRaw === null || skuRaw === '') continue;

              let skuStr = String(skuRaw).trim().replace(/['"]/g, "");
              if (!skuStr || isNaN(Number(skuStr))) continue;
              const sku = skuStr.padStart(8, '0');

              // Coluna J = índice 9
              const valJ = row[9];
              let vendaOntemCaixas = 0;
              if (valJ !== undefined && valJ !== null && valJ !== '') {
                const rawVal = String(valJ).trim().replace(/['"]/g, "");
                // SKU FECHADO (física/caixas já prontas)
                vendaOntemCaixas = parseFloat(rawVal.replace(/\./g, "").replace(",", ".")) || 0;
              }

              vendasOntemList.push({
                sku,
                vendaOntemCaixas
              });
            }

            if (vendasOntemList.length === 0) {
              throw new Error("Nenhum código SKU legível foi extraído para vendas.");
            }

            await sendSalesToServer(vendasOntemList);
          } catch (err: any) {
            setUploadError(err.message || "Erro ao processar as células do Excel.");
            setUploading(false);
          }
        };
        reader.readAsArrayBuffer(file);
      } else {
        // Assume CSV
        reader.onload = async (e: any) => {
          try {
            const content = e.target.result;
            const lines = content.split(/\r?\n/);
            if (lines.length < 2) {
              throw new Error("Arquivo CSV sem dados de cabeçalhos detectáveis.");
            }

            const firstLine = lines[0];
            const separator = firstLine.includes(';') ? ';' : ',';
            const headers = firstLine.split(separator).map(h => h.trim().toUpperCase());

            let skuColIndex = 0;
            const foundIdx = headers.findIndex(h => h.includes('SKU') || h.includes('PRODUTO') || h.includes('CODIGO') || h.includes('COD'));
            if (foundIdx !== -1) {
              skuColIndex = foundIdx;
            }

            const vendasOntemList: { sku: string; vendaOntemCaixas: number }[] = [];

            for (let i = 1; i < lines.length; i++) {
              const line = lines[i];
              if (!line.trim()) continue;

              const cols = line.split(separator);
              const skuRaw = cols[skuColIndex];
              if (skuRaw === undefined || skuRaw === null) continue;

              let skuStr = skuRaw.trim().replace(/['"]/g, "");
              if (!skuStr || isNaN(Number(skuStr))) continue;
              const sku = skuStr.padStart(8, '0');

              // Coluna J = índice 9
              const valJ = cols[9];
              let vendaOntemCaixas = 0;
              if (valJ !== undefined && valJ !== null && valJ !== '') {
                const rawVal = valJ.trim().replace(/['"]/g, "");
                vendaOntemCaixas = parseFloat(rawVal.replace(/\./g, "").replace(",", ".")) || 0;
              }

              vendasOntemList.push({
                sku,
                vendaOntemCaixas
              });
            }

            if (vendasOntemList.length === 0) {
              throw new Error("Formato inválido. Nenhum SKU numérico pôde ser extraído.");
            }

            await sendSalesToServer(vendasOntemList);
          } catch (err: any) {
            setUploadError(err.message || "Erro na formatação de colunas do CSV.");
            setUploading(false);
          }
        };
        reader.readAsText(file, 'utf-8');
      }
    } catch (e: any) {
      setUploadError(e.message || "Falha ao processar arquivo de vendas.");
      setUploading(false);
    }
  };

  // 1. Cálculos de Alto Nível
  const metricas = useMemo(() => {
    let valorTotal = 0;
    let volumeHLTotal = 0;
    let caixasTotais = 0;
    let palletsTotais = 0;
    let caixasFisicas = 0;
    let caixasSistema = 0;

    produtos.forEach(p => {
      valorTotal += p.valorTotalEstoque;
      volumeHLTotal += p.volumeHectolitro;
      caixasTotais += p.quantidadeAtualCaixas;
      palletsTotais += p.quantidadePallets;
      caixasFisicas += p.estoqueFisicoCaixas;
      caixasSistema += p.estoqueSistemaCaixas;
    });

    const divergentes = produtos.filter(p => p.temDivergencia);
    const diferencaFisicaSistStr = caixasFisicas - caixasSistema;
    const acuraciaEstoque = caixasSistema > 0 ? (1 - Math.abs(diferencaFisicaSistStr) / caixasSistema) * 100 : 100;

    return {
      valorTotal,
      volumeHLTotal,
      caixasTotais,
      palletsTotais: Math.round(palletsTotais * 10) / 10,
      divergenciasContagem: divergentes.length,
      acuraciaEstoque: Math.max(0, Math.min(100, Math.round(acuraciaEstoque * 100) / 100)),
      diferencaCaixas: diferencaFisicaSistStr,
      valorDivergenciaTotal: divergentes.reduce((sum, p) => sum + p.divergenciaValor, 0)
    };
  }, [produtos]);

  // 2. Agrupamento por Categoria (Para gráficos e breakdown)
  const categoriaBreakdown = useMemo(() => {
    const map: Record<Categoria, { count: number; valor: number; volume: number; caixas: number }> = {
      'Cerveja': { count: 0, valor: 0, volume: 0, caixas: 0 },
      'NAB': { count: 0, valor: 0, volume: 0, caixas: 0 },
      'Marketplace': { count: 0, valor: 0, volume: 0, caixas: 0 },
    };

    produtos.forEach(p => {
      if (map[p.categoria]) {
        map[p.categoria].count += 1;
        map[p.categoria].valor += p.valorTotalEstoque;
        map[p.categoria].volume += p.volumeHectolitro;
        map[p.categoria].caixas += p.quantidadeAtualCaixas;
      }
    });

    return Object.entries(map).map(([key, value]) => ({
      name: key as Categoria,
      ...value,
      percentage: metricas.valorTotal > 0 ? (value.valor / metricas.valorTotal) * 100 : 0
    }));
  }, [produtos, metricas.valorTotal]);

  // 3. Distribuição Curva ABC (Pareto, Ativos em Casa e Faturamento de Ontem)
  const curvaBreakdown = useMemo(() => {
    const counts = { A: 0, B: 0, C: 0, Mkt: 0 };
    const estoqueCaixas = { A: 0, B: 0, C: 0, Mkt: 0 };
    const vendasOntem = { A: 0, B: 0, C: 0, Mkt: 0 };
    const valores = { A: 0, B: 0, C: 0, Mkt: 0 };
    const giros = { A: 0, B: 0, C: 0, Mkt: 0 };

    const valorAtivosCasa = { A: 0, B: 0, C: 0, Mkt: 0 };
    const volumeAtivosCasa = { A: 0, B: 0, C: 0, Mkt: 0 };
    const valorFaturadoOntem = { A: 0, B: 0, C: 0, Mkt: 0 };
    const volumeFaturadoOntem = { A: 0, B: 0, C: 0, Mkt: 0 };

    produtos.forEach(p => {
      const target: 'A' | 'B' | 'C' | 'Mkt' = p.categoria === 'Marketplace' ? 'Mkt' : p.curvaABC || 'C';
      counts[target] += 1;
      estoqueCaixas[target] += p.quantidadeAtualCaixas;
      vendasOntem[target] += p.vendaOntemCaixas || 0;
      valores[target] += p.valorTotalEstoque;
      giros[target] += p.vendaMensalMediaCaixas;

      // Ativos em Casa (Valoração do estoque no local e volume total em HL)
      valorAtivosCasa[target] += p.valorTotalEstoque;
      volumeAtivosCasa[target] += p.volumeHectolitro;

      // Faturamento Ontem (vendas baseadas no custo médio vs caixas faturadas)
      const vOntem = p.vendaOntemCaixas || 0;
      valorFaturadoOntem[target] += vOntem * p.custoMedio;
      volumeFaturadoOntem[target] += vOntem * p.fatorHectolitro;
    });

    const maxValFinanceiro = Math.max(
      Math.max(...Object.values(valorAtivosCasa)),
      Math.max(...Object.values(valorFaturadoOntem)),
      1
    );

    const maxValVolume = Math.max(
      Math.max(...Object.values(volumeAtivosCasa)),
      Math.max(...Object.values(volumeFaturadoOntem)),
      1
    );

    const totalEstoqueCaixas = Object.values(estoqueCaixas).reduce((a, b) => a + b, 0);
    const totalVendaOntem = Object.values(vendasOntem).reduce((a, b) => a + b, 0);
    const totalVal = Object.values(valores).reduce((a, b) => a + b, 0);
    const totalGiro = Object.values(giros).reduce((a, b) => a + b, 0);

    const keys: ('A' | 'B' | 'C' | 'Mkt')[] = ['A', 'B', 'C', 'Mkt'];
    return keys.map((k) => {
      let name = `Curva ${k}`;
      let css = 'bg-emerald-500';
      let color = '#10b981';
      if (k === 'B') {
        css = 'bg-amber-500';
        color = '#f59e0b';
      } else if (k === 'C') {
        css = 'bg-rose-500';
        color = '#f43f5e';
      } else if (k === 'Mkt') {
        name = 'Marketplace';
        css = 'bg-sky-500';
        color = '#0ea5e9';
      }

      return {
        key: k,
        name,
        css,
        color,
        count: counts[k],
        pctCasa: totalEstoqueCaixas > 0 ? (estoqueCaixas[k] / totalEstoqueCaixas) * 100 : 0,
        pctSaidas: totalVendaOntem > 0 ? (vendasOntem[k] / totalVendaOntem) * 100 : 0,
        qtdVenda: vendasOntem[k],
        qtdEstoque: estoqueCaixas[k],
        giro: giros[k],
        pctGiro: totalGiro > 0 ? (giros[k] / totalGiro) * 100 : 0,
        pctValor: totalVal > 0 ? (valores[k] / totalVal) * 100 : 0,

        // Ativos vs Faturamento
        ativoFinanceiro: valorAtivosCasa[k],
        faturamentoFinanceiro: valorFaturadoOntem[k],
        pctAtivoFinanceiro: (valorAtivosCasa[k] / maxValFinanceiro) * 100,
        pctFaturamentoFinanceiro: (valorFaturadoOntem[k] / maxValFinanceiro) * 105, // Pequeno padding estético

        ativoVolume: volumeAtivosCasa[k],
        faturamentoVolume: volumeFaturadoOntem[k],
        pctAtivoVolume: (volumeAtivosCasa[k] / maxValVolume) * 100,
        pctFaturamentoVolume: (volumeFaturadoOntem[k] / maxValVolume) * 105
      };
    });
  }, [produtos]);

  // Função para exportar o RELATÓRIO 02.05.02 (Estoque Atual) em CSV
  const exportarEstoqueCSV = () => {
    const headers = [
      'SKU',                         // A (0)
      'Descricao',                   // B (1)
      'Categoria',                   // C (2)
      'Fator Embalagem',             // D (3)
      'Fator Hectolitro',            // E (4)
      'Diferenca (cx)',              // F (5)
      'Valor Diferenca (R$)',        // G (6)
      'Volume Total (HL)',           // H (7)
      'Pallets Ocupados',            // I (8)
      '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', // J a AA (9 a 26)
      'Saldo Fiscal (cx) [AB]',      // AB (27)
      'Quantidade Fisica (cx) [AC]', // AC (28)
      'Custo Medio ITEM (R$) [AD]'   // AD (29)
    ];

    const csvRows = [
      headers.join(';'), // Excel brasileiro usa ponto e vírgula
      ...produtos.map(p => [
        `"${p.sku}"`,                                        // A (0)
        `"${p.descricao.replace(/"/g, '""')}"`,              // B (1)
        `"${p.categoria}"`,                                  // C (2)
        p.fatorEmbalagem,                                    // D (3)
        p.fatorHectolitro.toFixed(4),                        // E (4)
        p.diferencaCaixas.toFixed(2),                        // F (5)
        p.divergenciaValor.toFixed(2),                       // G (6)
        p.volumeHectolitro.toFixed(4),                       // H (7)
        p.quantidadePallets.toFixed(2),                      // I (8)
        // Colunas Vazias de J a AA (índices 9 a 26)
        '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
        p.estoqueSistemaCaixas.toFixed(2),                   // AB (27)
        p.estoqueFisicoCaixas.toFixed(2),                    // AC (28)
        p.custoMedio.toFixed(2)                              // AD (29)
      ].join(';'))
    ];

    // Adiciona o caractere indicador de BOM (Byte Order Mark) UTF-8 para correta interpretação de acentuação no Excel
    const csvContent = '\uFEFF' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'RELATORIO_02_05_02_ESTOQUE_ATUAL.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="exec-dashboard-root">
      
      {/* Barra de Ações Rápidas de Exportação */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-100 shadow-sm animate-fade-in" id="dashboard-action-banner">
        <div className="space-y-0.5">
          <h2 className="text-sm font-extrabold text-slate-800 tracking-tight">Centro de Integração e Faturamento CD</h2>
          <p className="text-[11px] text-slate-500 font-sans">Atualização consolidada das bases de dados baseada em faturamento e contagem física recente</p>
        </div>
        <button
          type="button"
          onClick={exportarEstoqueCSV}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-lux"
        >
          <Download className="w-4 h-4 text-white" />
          <span>Exportar Relatório 02.05.02 (CSV)</span>
        </button>
      </div>

      {/* 4 Cards de Métricas Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Card 1: Valoração Total */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between" id="metric-valuation">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 font-medium tracking-wide uppercase">Valoração do Estoque (R$)</span>
            <h3 className="text-2xl font-bold font-display text-slate-900 tracking-tight">
              R$ {metricas.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </h3>
            <div className="flex items-center gap-1.5 text-slate-500 text-xs">
              <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded font-semibold text-[10px]">{metricas.caixasTotais.toLocaleString()} cx</span>
              <span>saldo total pós-conciliação</span>
            </div>
          </div>
          <div className="p-3.5 bg-indigo-50 rounded-2xl text-indigo-600">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        {/* Card 2: Hectolitros */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between" id="metric-volume">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 font-medium tracking-wide uppercase">Volume de Armazenagem</span>
            <div className="flex items-baseline gap-1">
              <h3 className="text-2xl font-bold font-display text-slate-900 tracking-tight">
                {metricas.volumeHLTotal.toLocaleString('pt-BR', { maximumFractionDigits: 2 })}
              </h3>
              <span className="text-sm font-semibold text-slate-700">HL</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-500 text-xs">
              <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded font-semibold text-[10px]">{metricas.palletsTotais} PL</span>
              <span>pallets ocupados estimados</span>
            </div>
          </div>
          <div className="p-3.5 bg-emerald-50 rounded-2xl text-emerald-600">
            <Layers className="w-6 h-6" />
          </div>
        </div>

        {/* Card 3: Acurácia Física x Fiscal */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between" id="metric-accuracy">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 font-medium tracking-wide uppercase">Acurácia de Inventário</span>
            <h3 className={`text-2xl font-bold font-display tracking-tight ${metricas.acuraciaEstoque >= 98 ? 'text-emerald-600' : 'text-amber-600'}`}>
              {metricas.acuraciaEstoque}%
            </h3>
            <div className="flex items-center gap-1.5 text-slate-500 text-xs">
              {metricas.diferencaCaixas === 0 ? (
                <div className="flex items-center gap-1 text-emerald-600 font-medium text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Estoque 100% Conciliado
                </div>
              ) : (
                <div className="flex items-center gap-1 text-amber-600 font-medium text-[11px]">
                  <AlertTriangle className="w-3.5 h-3.5" /> Delta: {metricas.diferencaCaixas} cx ({metricas.valorDivergenciaTotal < 0 ? 'Falta' : 'Sobra'})
                </div>
              )}
            </div>
          </div>
          <div className={`p-3.5 rounded-2xl ${metricas.acuraciaEstoque >= 98 ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
            <Percent className="w-6 h-6" />
          </div>
        </div>

        {/* Card 4: Divergências Ativas */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between hover:border-indigo-100 transition-colors cursor-pointer" 
             id="metric-divergences"
             onClick={() => onTabChange('conciliacao')}>
          <div className="space-y-1">
            <span className="text-xs text-slate-500 font-medium tracking-wide uppercase">SKUs com Divergência</span>
            <div className="flex items-center gap-2">
              <h3 className={`text-2xl font-bold font-display tracking-tight ${metricas.divergenciasContagem > 0 ? 'text-rose-600 font-extrabold animate-pulse' : 'text-slate-900'}`}>
                {metricas.divergenciasContagem}
              </h3>
              {metricas.divergenciasContagem > 0 && (
                <span className="bg-rose-100 text-rose-700 text-[10px] px-1.5 py-0.5 rounded-full font-bold">Atenção</span>
              )}
            </div>
            <div className="flex items-center gap-1 text-indigo-600 text-xs font-semibold hover:underline">
              Visualizar divergências <ArrowRight className="w-3 h-3" />
            </div>
          </div>
          <div className={`p-3.5 rounded-2xl ${metricas.divergenciasContagem > 0 ? 'bg-rose-50 text-rose-600' : 'bg-slate-50 text-slate-500'}`}>
            <Flame className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Mini Painel de Produtividade do Plantão */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 shadow-lux animate-fade-in" id="mini-productivity-banner">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>Painel de Produtividade do CD (Firebase)</span>
              <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-extrabold px-1.5 py-0.5 rounded tracking-widest uppercase">Ativo</span>
            </h4>
            <p className="text-xs text-slate-400">Acompanhamento em tempo real de ressuprimentos, reabastecimentos, repack, despejos, carregamentos e fluxo de montagem.</p>
          </div>
        </div>
        <button 
          onClick={() => onTabChange('produtividade')}
          className="flex items-center gap-2 bg-[#2D489A] hover:bg-[#1D327A] active:scale-95 text-white text-xs font-black py-2.5 px-4.5 rounded-xl border border-[#3B5BBF]/30 hover:border-[#3B5BBF]/60 transition-all font-sans cursor-pointer whitespace-nowrap"
        >
          Análise de Produtividade &rarr;
        </button>
      </div>

      {/* Gráficos customizados em Colunas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Gráfico do Pareto (Curva ABC) - 3 Meses */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-100 shadow-lux space-y-6" id="dashboard-chart-pareto">
          <div className="flex justify-between items-start">
            <div className="space-y-0.5">
              <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Ocorrência e Metodologia de Pareto 80/20</h4>
              <p className="text-xs text-slate-500">Distribuição do volume total de giro (vendas) por curva prioritária do WMS</p>
            </div>
            <span className="text-[10px] bg-indigo-50 font-semibold px-2 py-1 rounded text-indigo-700 uppercase tracking-wider font-mono">Giro Analítico</span>
          </div>

          {/* Barra de Distribuição Segmentada Horizontal */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-700">Fatia de Volume Total Acumulada (%):</span>
            <div className="h-6 w-full rounded-lg overflow-hidden flex shadow-inner bg-slate-100">
              {curvaBreakdown.map((c) => (
                c.pctGiro > 0 && (
                  <div 
                    key={c.key} 
                    style={{ width: `${c.pctGiro}%` }} 
                    className={`${c.css} relative transition-all duration-300 hover:brightness-105 group cursor-help`}
                  >
                    {/* Tooltip rápido na barra */}
                    <div className="absolute hidden group-hover:block bottom-full left-1/2 -translate-x-1/2 mb-2 bg-slate-900 text-white text-[10px] p-2 rounded-lg whitespace-nowrap shadow-xl z-30">
                      <strong>{c.name}</strong><br />
                      Giro: {c.giro.toLocaleString()} cx ({Math.round(c.pctGiro)}%)
                    </div>
                  </div>
                )
              ))}
            </div>
            {/* Legenda Customizada */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
              {curvaBreakdown.map((c) => (
                <div key={c.key} className="flex items-start gap-2">
                  <div className={`w-3 h-3 rounded ${c.css} shrink-0 mt-0.5`}></div>
                  <div className="text-[11px] leading-tight text-slate-600">
                    <span className="font-bold text-slate-800 block">{c.key === 'Mkt' ? 'Marketplace' : `Curva ${c.key}`}</span>
                    {Math.round(c.pctGiro)}% Giro ({c.count} SKUs)
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Gráfico de Colunas SVG: Vendas (Saídas Ontem) vs Ativos em Casa */}
          <div className="space-y-3" id="exec-comparison-chart-block">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-800">
                {viewMode === 'financial' 
                  ? 'Ativos em Casa (R$) vs. Venda (R$)' 
                  : 'Volume de Ativos (HL) vs. Volume de Venda (HL)'}
              </span>
              <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200 shrink-0 self-start sm:self-auto shadow-sm">
                <button
                  type="button"
                  onClick={() => setViewMode('financial')}
                  className={`text-[10px] font-extrabold px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    viewMode === 'financial'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  Financeiro (R$)
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('volume')}
                  className={`text-[10px] font-extrabold px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    viewMode === 'volume'
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  Volume (HL)
                </button>
              </div>
            </div>

            <div className="relative h-44 w-full flex items-end justify-around border-b border-l border-slate-200 pb-2 pl-4 pr-2 font-mono overflow-visible">
              {curvaBreakdown.map((c) => {
                const barWidth = 40;
                const heightAtivo = viewMode === 'financial' ? c.pctAtivoFinanceiro : c.pctAtivoVolume;
                const heightFaturamento = viewMode === 'financial' ? c.pctFaturamentoFinanceiro : c.pctFaturamentoVolume;

                return (
                  <div key={c.key} className="flex flex-col items-center gap-1.5 h-full justify-end relative group/col hover:z-50 z-10">
                    <div className="flex h-32 items-end gap-1 px-2">
                      {/* Barra Ativos em Casa */}
                      <div 
                        style={{ height: `${Math.max(4, heightAtivo)}%`, width: `${barWidth / 2}px` }} 
                        className={`${c.css} rounded-t relative group/bar hover:brightness-105 hover:scale-x-105 transition-all cursor-pointer z-20 hover:z-40`}
                      >
                        {/* Tooltip com dados tanto em Real quanto em Hecto para satisfazer ambos requisitos simultaneamente */}
                        <div className="absolute hidden group-hover/bar:block bottom-full left-1/2 -translate-x-1/2 mb-2 bg-slate-950 border border-slate-800 text-white text-[10px] p-2.5 rounded-xl whitespace-nowrap z-50 shadow-2xl pointer-events-none font-sans min-w-[210px] leading-relaxed">
                          <div className="font-bold border-b border-white/10 pb-1 mb-1.5 flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${c.css}`}></span>
                            <span>{c.name} - Ativos em Casa</span>
                          </div>
                          <div className="space-y-0.5">
                            <div>💰 <strong className="text-slate-300">Financeiro:</strong> R$ {c.ativoFinanceiro.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                            <div>📦 <strong className="text-slate-300">Volume:</strong> {c.ativoVolume.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} HL</div>
                            <div className="text-[9px] text-slate-400 font-mono mt-1 pt-1 border-t border-white/5 flex flex-col gap-0.5">
                              <div>Estoque atual: {Math.round(c.qtdEstoque).toLocaleString('pt-BR')} caixas</div>
                              <div className="font-bold text-emerald-400">⚡ Saídas/Estoque: {((c.qtdEstoque > 0 ? (c.qtdVenda / c.qtdEstoque) : 0) * 100).toFixed(2)}%</div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Barra Valor da Venda */}
                      <div 
                        style={{ height: `${Math.max(4, heightFaturamento)}%`, width: `${barWidth / 2}px` }} 
                        className="bg-indigo-600 opacity-95 rounded-t relative group/bar hover:brightness-110 hover:scale-x-105 transition-all cursor-pointer z-20 hover:z-40"
                      >
                        {/* Tooltip com dados tanto em Real quanto em Hecto */}
                        <div className="absolute hidden group-hover/bar:block bottom-full left-1/2 -translate-x-1/2 mb-2 bg-slate-950 border border-slate-800 text-white text-[10px] p-2.5 rounded-xl whitespace-nowrap z-50 shadow-2xl pointer-events-none font-sans min-w-[210px] leading-relaxed">
                          <div className="font-bold border-b border-white/10 pb-1 mb-1.5 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                            <span>{c.name} - Venda (Ontem)</span>
                          </div>
                          <div className="space-y-0.5">
                            <div>💰 <strong className="text-slate-300">Venda:</strong> R$ {c.faturamentoFinanceiro.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                            <div>📦 <strong className="text-slate-300">Volume Venda:</strong> {c.faturamentoVolume.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} HL</div>
                            <div className="text-[9px] text-slate-400 font-mono mt-1 pt-1 border-t border-white/5 flex flex-col gap-0.5">
                              <div>Giro de ontem: {Math.round(c.qtdVenda).toLocaleString('pt-BR')} caixas</div>
                              <div className="font-bold text-indigo-400">⚡ Saídas/Estoque: {((c.qtdEstoque > 0 ? (c.qtdVenda / c.qtdEstoque) : 0) * 100).toFixed(2)}%</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* Label */}
                    <span className="text-[10px] text-slate-500 font-bold leading-none">{c.key === 'Mkt' ? 'MKT' : `Curva ${c.key}`}</span>
                    <span className="text-[9px] font-mono font-bold text-indigo-650 bg-indigo-50 border border-indigo-100 px-1 py-0.5 rounded select-none shadow-sm" title="Percentual de Saída em relação ao Estoque Atual">
                      {((c.qtdEstoque > 0 ? (c.qtdVenda / c.qtdEstoque) : 0) * 100).toFixed(1)}%
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-center gap-5 text-[10px] text-slate-500 pt-1">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-slate-400"></span> 
                Ativos em Casa {viewMode === 'financial' ? '(R$)' : '(HL)'}
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-indigo-600"></span> 
                Venda {viewMode === 'financial' ? '(R$)' : '(HL)'}
              </span>
            </div>
          </div>

          {/* Campo dedicado para arrastar o documento de saídas */}
          <div className="mt-5 pt-4 border-t border-slate-100 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <h5 className="text-[11px] font-bold text-slate-800 flex items-center gap-1.5">
                  <UploadCloud className="w-4 h-4 text-indigo-600" />
                  <span>Lançar Saídas do Dia Anterior</span>
                </h5>
                <p className="text-[10px] text-slate-500">Arraste a planilha: SKU + Coluna J (Saída em caixa fechada)</p>
              </div>
              {uploadResult && (
                <button 
                  type="button"
                  onClick={() => {
                    setUploadResult(null);
                    setUploadedFileName(null);
                    setUploadError(null);
                  }}
                  className="text-[9px] font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-1 rounded transition cursor-pointer"
                >
                  Novo Lançamento
                </button>
              )}
            </div>

            {!uploadResult ? (
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`border border-dashed rounded-xl p-4 text-center transition-all relative flex flex-col items-center justify-center min-h-[90px] cursor-pointer ${
                  isDragActive 
                    ? 'border-indigo-500 bg-indigo-50/70 text-indigo-750 scale-[0.98]' 
                    : 'border-slate-200 hover:border-indigo-400 hover:bg-slate-50 bg-slate-50/50'
                }`}
              >
                <input
                  type="file"
                  accept=".csv, .xlsx, .xls"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  disabled={uploading}
                />
                
                {uploading ? (
                  <div className="space-y-2 flex flex-col items-center">
                    <RefreshCw className="w-5 h-5 text-indigo-600 animate-spin" />
                    <p className="text-[10px] font-bold text-indigo-700 font-mono">Injetando saídas e atualizando gráficos...</p>
                  </div>
                ) : (
                  <>
                    <Upload className="w-5 h-5 text-slate-400 mb-1" />
                    <p className="text-[11px] font-bold text-slate-700">Arraste o documento de vendas ontem aqui</p>
                    <p className="text-[9px] text-slate-400">Suporta .xlsx, .xls ou .csv (Dados na Coluna J)</p>
                  </>
                )}
              </div>
            ) : (
              <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="text-xs font-bold text-emerald-800">Sincronização de Vendas Realizada!</p>
                  <p className="text-[10px] text-emerald-600">{uploadResult.message}</p>
                  {uploadedFileName && (
                    <p className="text-[9px] font-mono text-slate-500 font-bold mt-1">
                      Arquivo processado: <span className="underline">{uploadedFileName}</span>
                    </p>
                  )}
                </div>
              </div>
            )}

            {uploadError && (
              <div className="p-2.5 bg-rose-50 border border-rose-100 text-rose-700 text-[10px] font-semibold rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{uploadError}</span>
              </div>
            )}
          </div>

        </div>

        {/* Categoria Breakdown & Finanças (Donut SVG) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-100 shadow-lux space-y-5" id="dashboard-chart-donut">
          <div className="flex justify-between items-start">
            <div className="space-y-0.5">
              <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Valoração Financeira por Categoria</h4>
              <p className="text-xs text-slate-500">Análise de capital alocado por categoria logística</p>
            </div>
            <span className="text-[10px] bg-indigo-50 font-semibold px-2 py-1 rounded text-indigo-700 uppercase tracking-wider font-mono">ERP Financeiro</span>
          </div>

          {/* Gráfico Donut SVG Simples, Seguro e Decorado */}
          <div className="flex justify-center py-4 relative">
            <svg width="180" height="180" viewBox="0 0 42 42" className="transform -rotate-90">
              <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#f1f5f9" strokeWidth="4.5" />
              {(() => {
                let currentOffset = 0;
                return categoriaBreakdown.map((cat, idx) => {
                  const dashArray = `${cat.percentage} ${100 - cat.percentage}`;
                  const offset = 100 - currentOffset;
                  currentOffset += cat.percentage;
                  
                  // Cores estéticas para cada categoria
                  let cor = '#10b981'; // Cerveja
                  if (cat.name === 'NAB') cor = '#f59e0b'; // Amarelo
                  if (cat.name === 'Marketplace') cor = '#0ea5e9'; // Azul

                  return (
                    <circle 
                      key={cat.name}
                      cx="21" 
                      cy="21" 
                      r="15.915" 
                      fill="transparent" 
                      stroke={cor} 
                      strokeWidth="5" 
                      strokeDasharray={dashArray} 
                      strokeDashoffset={offset} 
                      className="transition-all duration-300 hover:stroke-[6px]"
                    />
                  );
                });
              })()}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Estoque</span>
              <span className="text-lg font-bold font-display text-slate-900 mt-0.5">R$ {(metricas.valorTotal / 1000).toFixed(0)}K</span>
            </div>
          </div>

          {/* Legenda de Categorias com Detalhamento Financeiro */}
          <div className="space-y-2">
            {categoriaBreakdown.map((cat) => {
              let tagCss = 'bg-emerald-500';
              let textHex = 'text-emerald-700';
              if (cat.name === 'NAB') {
                tagCss = 'bg-amber-500';
                textHex = 'text-amber-700';
              }
              if (cat.name === 'Marketplace') {
                tagCss = 'bg-sky-500';
                textHex = 'text-sky-700';
              }

              return (
                <div key={cat.name} className="flex items-center justify-between border-b border-dashed border-slate-100 pb-1.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${tagCss}`}></span>
                    <span className="font-semibold text-slate-700">{cat.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-slate-800">
                      R$ {cat.valor.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
                    </span>
                    <span className="text-slate-400 ml-1 font-mono text-[10px]">({Math.round(cat.percentage)}%)</span>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

      </div>

      {/* Histórico Recente de Conciliação Física x Fiscal (Auditoria) */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-lux p-6 space-y-4" id="dashboard-audit-logs">
        <div className="flex justify-between items-center">
          <div className="space-y-0.5">
            <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Registro de Auditoria de Conciliação</h4>
            <p className="text-xs text-slate-500">Histórico de regularizações e acertos executados no WMS integrado ao ERP</p>
          </div>
          <span className="text-xs font-mono bg-emerald-50 text-emerald-800 px-2 py-1 rounded font-semibold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Segura
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-slate-500 font-semibold bg-slate-50/50">
                <th className="py-2.5 px-3">Código</th>
                <th className="py-2.5 px-3">Data / Hora</th>
                <th className="py-2.5 px-3">Operador Responsável</th>
                <th className="py-2.5 px-3">Ajuste Fiscal (R$)</th>
                <th className="py-2.5 px-3">SKUs Corrigidos</th>
                <th className="py-2.5 px-3">Descrição da Atividade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 font-mono">
              {logsAuditoria.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/50">
                  <td className="py-3 px-3 font-semibold text-slate-900">{log.id}</td>
                  <td className="py-3 px-3 text-slate-600 font-sans">
                    {new Date(log.data).toLocaleString('pt-BR')}
                  </td>
                  <td className="py-3 px-3 text-slate-600 font-sans font-medium">{log.usuario}</td>
                  <td className={`py-3 px-3 font-bold ${log.totalValorAjustado < 0 ? 'text-rose-600' : log.totalValorAjustado > 0 ? 'text-emerald-600' : 'text-slate-600'}`}>
                    {log.totalValorAjustado < 0 ? '-' : log.totalValorAjustado > 0 ? '+' : ''}
                    R$ {Math.abs(log.totalValorAjustado).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-3 text-center font-sans text-slate-700 font-semibold">{log.skusAjustados} item(s)</td>
                  <td className="py-3 px-3 text-slate-500 font-sans">{log.descricao}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
