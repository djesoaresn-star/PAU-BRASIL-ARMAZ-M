/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Flame, 
  RefreshCw, 
  SlidersHorizontal, 
  DollarSign, 
  Gauge, 
  UploadCloud, 
  FileCode,
  Check,
  Edit2,
  Trash2,
  UserCheck,
  Download,
  FileSpreadsheet,
  Upload,
  Search,
  Eye,
  Info,
  Lock,
  Unlock,
  TrendingUp,
  Activity,
  Calendar,
  Layers,
  ArrowRight,
  ChevronRight,
  XCircle,
  Sparkles,
  Clock,
  X
} from 'lucide-react';
import { ProdutoConsolidado } from '../types';
import { rawErpDatabase } from '../data/erpDatabase';
import * as XLSX from 'xlsx';
import { PauBrasilGuide } from './PauBrasilGuide';

const getMasterCatalogDescription = (skuToFind: string): string | null => {
  try {
    const lines = rawErpDatabase.split('\n');
    const targetSku = skuToFind.toUpperCase().trim().replace(/^0+/, '');
    for (const line of lines) {
      if (!line.trim() || line.startsWith('CÓDIGO') || line.startsWith('CÃ“DIGO')) continue;
      const cols = line.split(';');
      if (cols.length >= 2) {
        const lineSku = cols[0].trim().toUpperCase().replace(/^0+/, '');
        if (lineSku === targetSku) {
          return cols[1].trim();
        }
      }
    }
  } catch (e) {
    console.error(e);
  }
  return null;
};

interface InventoryReconciliationProps {
  produtos: ProdutoConsolidado[];
  divergenciasCongeladas?: any[];
  historicoConciliacoes?: any[];
  onUpdatePhysical: (sku: string, quant: number) => Promise<void>;
  onTriggerReconciliation: (user: string) => Promise<void>;
  onImportState: (jsonData: any) => Promise<void>;
  onUpdatePrices: (rawPricesCsv: string) => Promise<void>;
  onAddProduct: (formData: any) => Promise<void>;
  onFreezeDivergences?: (
    skusToFreeze: string[], 
    observacoes: Record<string, string>,
    isManual?: boolean,
    manualSku?: string,
    manualQuantidade?: number,
    manualObservacao?: string,
    manualItems?: any[],
    documentos?: Record<string, { nome: string; tamanho: string }>
  ) => Promise<boolean | void>;
  onUnfreezeDivergences?: (skusToUnfreeze: string[]) => Promise<void>;
  operatorEmail: string;
  onRefresh?: () => Promise<void>;
}

export default function InventoryReconciliation({
  produtos,
  divergenciasCongeladas = [],
  historicoConciliacoes = [],
  onUpdatePhysical,
  onTriggerReconciliation,
  onImportState,
  onUpdatePrices,
  onAddProduct,
  onFreezeDivergences,
  onUnfreezeDivergences,
  operatorEmail,
  onRefresh
}: InventoryReconciliationProps) {
  
  const formatHectolitro = (hl: number | undefined | null): string => {
    if (hl == null || isNaN(Number(hl))) return '0';
    const val = Number(hl);
    if (val === 0) return '0';
    return parseFloat(val.toFixed(4)).toString().replace('.', ',');
  };

  const formatDiferencaCaixas = (num: number | undefined | null): string => {
    if (num == null || isNaN(Number(num))) return '0';
    const val = Number(num);
    if (val === 0) return '0';
    return parseFloat(val.toFixed(2)).toString().replace('.', ',');
  };
  
  // Estados para edição in-line de contagem física
  const [editingSku, setEditingSku] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState<number>(0);
  const [loadingSku, setLoadingSku] = useState<string | null>(null);

  // Seleção de visualização: Tabela simplificada, Ver Todos, Dashboard Gerencial, Congelamento ou Análise de SKU
  const [activeReconView, setActiveReconView] = useState<'tabela' | 'todos' | 'dashboard' | 'cadastro' | 'congelar' | 'analise' | 'historico'>('tabela');

  // Estados Customizados para Seleção de Itens Congelados e Confirmação de Conciliação
  const [selectedFrozenSkuList, setSelectedFrozenSkuList] = useState<string[]>([]);
  const [showReconModal, setShowReconModal] = useState(false);
  const [isReconciling, setIsReconciling] = useState(false);
  const [selectedRealAuditId, setSelectedRealAuditId] = useState<string | null>(null);

  // Estados para Gestão de Divergências Congeladas
  const [selectedFreezeSkus, setSelectedFreezeSkus] = useState<string[]>([]);
  const [freezeRemarks, setFreezeRemarks] = useState<Record<string, string>>({});
  const [isFreezing, setIsFreezing] = useState(false);

  // Estados para Gestão de Congelamento Manual (Ajuste compensativo avulso)
  const [activeFreezeTab, setActiveFreezeTab] = useState<'checklist' | 'manual' | 'import-losses'>('checklist');
  const [manualFreezeSku, setManualFreezeSku] = useState("");
  const [manualFreezeType, setManualFreezeType] = useState<'falta' | 'sobra'>('falta');
  const [manualFreezeQuantity, setManualFreezeQuantity] = useState("");
  const [manualFreezeObservation, setManualFreezeObservation] = useState("");
  const [manualFreezeMsg, setManualFreezeMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [manualFreezeUnitType, setManualFreezeUnitType] = useState<'caixa' | 'pallet' | 'unidade'>('caixa');

  // Estados para Registro e Upload de Perdas em Unidades via CSV
  const [importedLossesList, setImportedLossesList] = useState<any[] | null>(null);
  const [isLossesDragActive, setIsLossesDragActive] = useState(false);
  const [lossesFileName, setLossesFileName] = useState<string | null>(null);
  const [lossesError, setLossesError] = useState<string | null>(null);
  const [lossesSuccessMsg, setLossesSuccessMsg] = useState<string | null>(null);
  const [isFreezingLosses, setIsFreezingLosses] = useState(false);

  // Estados para Análise de Evolução Mensal do SKU
  const [selectedHistorySku, setSelectedHistorySku] = useState("");
  const [historySearchInput, setHistorySearchInput] = useState("");
  const [historyData, setHistoryData] = useState<any | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [activeHoverIndex, setActiveHoverIndex] = useState<number | null>(null);

  // Estados para Auditoria de Consolação de 30 dias (Todos os SKUs)
  const [auditSelectedDay, setAuditSelectedDay] = useState<number>(30);

  // Estados Custom e Adicionais para Histórico Consolidado e Congelamento de Divergências
  const [expandedConciliacaoId, setExpandedConciliacaoId] = useState<string | null>(null);
  const [showEntireSnapshot, setShowEntireSnapshot] = useState<Record<string, boolean>>({});
  const [frozenFiles, setFrozenFiles] = useState<Record<string, { nome: string; tamanho: string }>>({});
  const [isDraggingDocument, setIsDraggingDocument] = useState<Record<string, boolean>>({});

  // Estados para o novo módulo de Cadastro de Produtos
  const [manualSku, setManualSku] = useState("");
  const [manualDesc, setManualDesc] = useState("");
  const [manualCategoria, setManualCategoria] = useState("CERVEJA");
  const [manualCusto, setManualCusto] = useState("45.00");
  const [manualFatorPallet, setManualFatorPallet] = useState("80");
  const [manualFatorSku, setManualFatorSku] = useState("12");
  const [manualFatorHecto, setManualFatorHecto] = useState("0.05");
  const [manualUm, setManualUm] = useState("CX");

  const [cadastroPreview, setCadastroPreview] = useState<any[] | null>(null);
  const [cadastroError, setCadastroError] = useState<string | null>(null);
  const [cadastroSuccess, setCadastroSuccess] = useState(false);
  const [isCadastroDragActive, setIsCadastroDragActive] = useState(false);

  // Estados para o cadastro de variação de preços Ambev ERP
  const [rawPricesInput, setRawPricesInput] = useState("");
  const [pricesIsUploading, setPricesIsUploading] = useState(false);
  const [activePricesTab, setActivePricesTab] = useState<'upload' | 'manual'>('upload');
  const [isPricesDragActive, setIsPricesDragActive] = useState(false);
  const [uploadedPricesFileName, setUploadedPricesFileName] = useState<string | null>(null);

  // Estados para simulador de importação de arquivo
  const [importText, setImportText] = useState("");
  const [fileError, setFileError] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState(false);

  // Estados para importador avançado de CSV / Drag and Drop
  const [isDragActive, setIsDragActive] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [previewParsedList, setPreviewParsedList] = useState<any[] | null>(null);
  const [activeImportTab, setActiveImportTab] = useState<'upload' | 'manual'>('upload');
  const [detectedImportType, setDetectedImportType] = useState<'inventory' | 'erp_catalog' | 'divergencias_congeladas'>('inventory');

  // Função para parsear arquivo de perdas em unidades (aceita array de arrays para CSV e Excel)
  const parseLossesArray = (rows: any[][]) => {
    if (rows.length === 0) return [];
    
    // Smart header detection to survive top title blocks
    let headerIdx = 0;
    for (let r = 0; r < Math.min(rows.length, 10); r++) {
      const row = rows[r];
      if (Array.isArray(row)) {
        const hasSku = row.some(col => {
          const colStr = String(col || "").toUpperCase().trim();
          return colStr.includes("SKU") || colStr.includes("PROD") || colStr.includes("COD") || colStr.includes("CÓD");
        });
        const hasUnit = row.some(col => {
          const colStr = String(col || "").toUpperCase().trim();
          return colStr.includes("UNID") || colStr.includes("PERC") || colStr.includes("QTD") || colStr.includes("QUANT") || colStr.includes("AVAR") || colStr.includes("QUEB");
        });
        if (hasSku || hasUnit) {
          headerIdx = r;
          break;
        }
      }
    }

    const header = rows[headerIdx] || [];
    let skuIdx = -1;
    let descIdx = -1;
    let unitIdx = -1;
    
    header.forEach((col, idx) => {
      if (col == null) return;
      const colStr = String(col).toUpperCase().trim().replace(/['"]/g, "");
      
      if (colStr.includes("PRODUTO") || colStr === "SKU" || colStr === "CODIGO" || colStr === "CÓDIGO" || colStr === "COD") {
        skuIdx = idx;
      } else if (colStr.includes("DESC")) {
        descIdx = idx;
      } else if (colStr.includes("UNID") || colStr === "QTD" || colStr === "QUANTIDADE" || colStr === "PERCA" || colStr === "PERDAS" || colStr.includes("AVARIA") || colStr.includes("QUEBRA") || colStr.includes("QUANT")) {
        unitIdx = idx;
      }
    });
    
    // Fallback se índices não encontrados
    if (skuIdx === -1) skuIdx = 0;
    if (descIdx === -1 && header.length > 2) descIdx = 1;
    if (unitIdx === -1) unitIdx = header.length - 1;
    
    const parsedItems: any[] = [];
    
    for (let i = headerIdx + 1; i < rows.length; i++) {
      const row = rows[i];
      if (!row || row.length < 2) continue;
      
      const rawSku = String(row[skuIdx] || "").trim().replace(/['"]/g, "");
      if (!rawSku) continue;
      
      // Remove excel double conversions like 13061.0
      const cleanSku = rawSku.split('.')[0].trim();
      if (!cleanSku || cleanSku.toUpperCase() === "NULL" || cleanSku === "0") continue;
      const sku = cleanSku.padStart(8, '0');
      
      const desc = String(row[descIdx] || "").trim().replace(/['"]/g, "");
      
      const rawUnidadeVal = String(row[unitIdx] || "").trim().replace(/['"]/g, "");
      const cleanUnidadeVal = rawUnidadeVal.replace(/\./g, "").replace(",", ".");
      const unidades = Math.abs(parseInt(cleanUnidadeVal) || 0);
      if (unidades === 0) continue;
      
      // Busca produto correspondente no CD
      const p = produtos.find(item => item.sku === sku || Number(item.sku) === Number(sku));
      const factor = p?.fatorEmbalagem || 12;
      const caixas = Number((unidades / factor).toFixed(2));
      
      parsedItems.push({
        sku,
        rawSku,
        desc: p?.descricao || desc || `Produto Sincronizado ${cleanSku}`,
        unidades,
        caixas,
        p
      });
    }
    return parsedItems;
  };

  const handleLossesFile = (file: File) => {
    const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');
    const reader = new FileReader();

    if (isExcel) {
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          if (!data) {
            setLossesError("Arquivo vazio ou ilegível.");
            return;
          }
          const arr = new Uint8Array(data as ArrayBuffer);
          const workbook = XLSX.read(arr, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const rows = XLSX.utils.sheet_to_json<any[]>(worksheet, { header: 1 });
          
          const parsed = parseLossesArray(rows);
          if (parsed.length === 0) {
            setLossesError("Nenhum item válido pôde ser extraído da planilha de Excel. Verifique o cabeçalho e os SKUs.");
            return;
          }
          
          setImportedLossesList(parsed);
          setLossesFileName(file.name);
          setLossesError(null);
          setLossesSuccessMsg(null);
        } catch (err: any) {
          setLossesError(`Falha ao ler arquivo de Excel: ${err.message}`);
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          if (!text) {
            setLossesError("Arquivo vazio ou ilegível.");
            return;
          }
          
          const lines = text.split(/\r?\n/).map(line => line.split(/[;,]/));
          const parsed = parseLossesArray(lines);
          if (parsed.length === 0) {
            setLossesError("Nenhum item válido pôde ser extraído. Verifique o cabeçalho e os SKUs.");
            return;
          }
          
          setImportedLossesList(parsed);
          setLossesFileName(file.name);
          setLossesError(null);
          setLossesSuccessMsg(null);
        } catch (err: any) {
          setLossesError(`Falha ao ler arquivo: ${err.message}`);
        }
      };
      reader.readAsText(file, 'utf-8');
    }
  };

  // Função para processar o conteúdo do arquivo (CSV ou JSON)
  const processFileContent = (content: string, fileName: string) => {
    setFileError(null);
    setImportSuccess(false);
    
    let invParsed: any[] = [];
    try {
      if (!content.trim()) {
        throw new Error("O arquivo está vazio.");
      }

      const trimmed = content.trim();
      if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
        setDetectedImportType('inventory');
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) {
          invParsed = parsed.map(item => ({
            sku: String(item.sku || item.SKU || "").trim(),
            estoqueFisicoCaixas: Math.floor(Number(item.estoqueFisicoCaixas ?? item.estoqueFisico ?? item.fisico ?? 0)),
            estoqueSistemaCaixas: Math.floor(Number(item.estoqueSistemaCaixas ?? item.estoqueSistema ?? item.sistema ?? 0)),
            custoMedio: Number(item.custoMedio ?? item.custoMedioItem ?? 45.00),
          }));
        } else {
          throw new Error("O arquivo JSON deve ser um array contendo objetos com os campos sku, estoqueFisicoCaixas e estoqueSistemaCaixas.");
        }
      } else {
        // Trata como CSV delimitado por ponto e vírgula
        const lines = trimmed.split(/\r?\n/);
        const header = lines[0] || "";

        // Deteção inteligente de Desvios Congelados / Perdas
        if (
          header.toUpperCase().includes("CONGELADO") || 
          header.toUpperCase().includes("DESVIO") || 
          header.toUpperCase().includes("PERDA") || 
          header.toUpperCase().includes("QUEBRA") || 
          header.toUpperCase().includes("TRAVA") || 
          header.toUpperCase().includes("BLOQUEIO") || 
          header.toUpperCase().includes("OBSERVACAO") || 
          header.toUpperCase().includes("OBSERVAÇÃO")
        ) {
          setDetectedImportType('divergencias_congeladas');
          const congeladosParsed: any[] = [];
          
          lines.forEach((line, index) => {
            if (index === 0 || !line.trim()) return;
            const cols = line.split(';');
            if (cols.length >= 2) {
              const rawSku = cols[0].trim().replace(/['"]/g, "");
              const sku = rawSku.padStart(8, '0');
              const descricao = cols[1] ? cols[1].trim().replace(/['"]/g, "") : `Item Congelado ${sku}`;
              
              const diferencaCaixas = cols[2] ? parseFloat(cols[2].trim().replace(',', '.')) || -10 : -10;
              const custoPorSku = cols[3] ? parseFloat(cols[3].trim().replace(',', '.')) || 45.00 : 45.00;
              const observacao = cols[4] ? cols[4].trim().replace(/['"]/g, "") : "Importação de base de congelados";
              
              congeladosParsed.push({
                sku,
                descricao,
                diferencaCaixas,
                custoPorSku,
                observacao,
                status: 'congelado'
              });
            }
          });
          
          if (congeladosParsed.length === 0) {
            throw new Error("Nenhum item de desvio congelado pôde ser analisado.");
          }
          
          setPreviewParsedList(congeladosParsed);
          setUploadedFileName(fileName);
          setImportText(content);
          return;
        }
        
        // Deteção inteligente do Catálogo Fiscal ERP
        if (
          header.toUpperCase().includes("CUSTO POR SKU") || 
          header.toUpperCase().includes("FATOR SKU") || 
          header.toUpperCase().includes("FATOR PALLET") ||
          header.toUpperCase().includes("CÓDIGO") ||
          header.toUpperCase().includes("CÃ“DIGO")
        ) {
          setDetectedImportType('erp_catalog');
          const catalogParsed: any[] = [];
          
          lines.forEach((line, index) => {
            if (index === 0 || !line.trim()) return;
            const cols = line.split(';');
            if (cols.length >= 7) {
              const rawSku = cols[0].trim().replace(/['"]/g, "");
              const sku = rawSku.padStart(8, '0');
              const descricao = cols[1].trim().replace(/['"]/g, "");
              const unidadeMedida = cols[2].trim().replace(/['"]/g, "");
              const fatorPallet = parseInt(cols[3].trim()) || 80;
              const fatorSku = parseInt(cols[4].trim()) || 12;
              const fatorHecto = parseFloat(cols[5].trim().replace(',', '.')) || 0.05;
              const custoPorSku = parseFloat(cols[6].trim().replace(',', '.')) || 45.00;
              
              catalogParsed.push({
                sku,
                descricao,
                unidadeMedida,
                fatorPallet,
                fatorSku,
                fatorHecto,
                custoPorSku,
                estoqueFisicoCaixas: 0,
                estoqueSistemaCaixas: 0,
                valorEstoqueFisicoReal: custoPorSku, // custo unitário total do SKU cadastrado
                status: 'novo'
              });
            }
          });
          
          if (catalogParsed.length === 0) {
            throw new Error("Nenhum item do catálogo fiscal pôde ser analisado a partir do cabeçalho detectado.");
          }
          
          setPreviewParsedList(catalogParsed);
          setUploadedFileName(fileName);
          setImportText(content);
          return;
        }

        // Caso contrário, trata-se de contagem Física x Fiscal (Relatório 02.05.02 ou simplificado)
        setDetectedImportType('inventory');

        // Função de detecção inteligente para extrair apenas a parte do SKU fechado (antes da barra /)
        const parseClosedBoxes = (val: string): number => {
          if (!val) return 0;
          const cleaned = val.trim();
          if (!cleaned) return 0;
          
          const isNegative = cleaned.endsWith('-');
          const positivePart = isNegative ? cleaned.slice(0, -1).trim() : cleaned;
          
          if (positivePart.includes('/')) {
            const parts = positivePart.split('/');
            // Pegamos o lado esquerdo da barra correspondente aos SKUs fechados
            const boxesStr = parts[0].trim().replace(/\./g, '').replace(',', '.');
            const boxes = Math.floor(parseFloat(boxesStr) || 0);
            return isNegative ? -boxes : boxes;
          }
          
          const cleanNum = positivePart.replace(/\./g, '').replace(',', '.').trim();
          const num = Math.floor(parseFloat(cleanNum) || 0);
          return isNegative ? -num : num;
        };

        const headerCols = header.split(';');
        const normalizedHeaders = headerCols.map(h => {
          return h.toUpperCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^A-Z0-9]/g, "")
            .trim();
        });

        let skuColIndex = 0;
        let sistemaColIndex = -1;
        let fisicoColIndex = -1;
        let custoColIndex = -1;
        let fatorColIndex = -1;
        let saidasColIndex = -1;

        normalizedHeaders.forEach((name, idx) => {
          if (name === 'PRODUTO' || name === 'SKU' || name === 'CODIGO' || name === 'COD' || name.startsWith('PRODUTO') || name.startsWith('SKU') || name.startsWith('CODIGO')) {
            skuColIndex = idx;
          }
          if (name === 'DISP' || name === 'QTDESTOQUE' || name.includes('SALDOFISCAL') || name.includes('STOCKE') || name === 'SALDOATUAL') {
            sistemaColIndex = idx;
          }
          if (name.includes('CONFERENTE') || name.includes('CONTAGEM') || name === 'QTDCONTAGEM' || name.includes('QUANTIDADEFISICA')) {
            fisicoColIndex = idx;
          }
          if (name === 'ESTOQUECM' || name.includes('CUSTOMEDIO') || name.includes('CUSTOMDIO') || name.includes('PRECO') || name.includes('PRECO')) {
            custoColIndex = idx;
          }
          if (name === 'FATOR' || name.includes('FATOR')) {
            fatorColIndex = idx;
          }
          if (name === 'SAIDAS' || name === 'SAIDA' || name === 'SAIDASA' || name.includes('SAIDAS') || name.includes('SAIDA') || name.includes('GIRO') || name.includes('VENDAS') || name.includes('OUT')) {
            saidasColIndex = idx;
          }
        });

        const isRawAmbev = normalizedHeaders.some(h => {
          return h === 'ARMAZEM' || h === 'ARM' || h === 'DEPOSITO' || h === 'SALDOANTERIOR';
        });

        const isAmbevUnitsReport = normalizedHeaders.some(h => h.includes('QTDESTOQUE')) &&
                                   normalizedHeaders.some(h => h.includes('QTDCONTAGEM'));

        lines.forEach((line, index) => {
          if (index === 0 || !line.trim()) return; // Ignora o cabeçalho
          const cols = line.split(/[;]/); // Excel brasileiro usa ponto e vírgula
          if (cols.length >= 2) {
            if (isAmbevUnitsReport && cols.length >= 29) {
              const rawSku = cols[3] ? cols[3].trim().replace(/['"]/g, "") : '';
              if (!rawSku || isNaN(Number(rawSku))) return;
              const sku = rawSku.padStart(8, '0');
              
              const factor = (cols[23] && parseInt(cols[23].trim())) || 12;
              const cleanFactor = Math.max(1, factor);
              
              const rawEstoque = cols[27] ? cols[27].trim().replace(/['"]/g, "") : '0';
              const rawContagem = cols[28] ? cols[28].trim().replace(/['"]/g, "") : '';
              
              const rawEstoqueUnid = parseFloat(rawEstoque.replace(/\./g, "").replace(",", ".")) || 0;
              const rawContagemUnid = rawContagem.trim() ? (parseFloat(rawContagem.replace(/\./g, "").replace(",", ".")) || 0) : 0;
              
              const sistema = rawEstoqueUnid / cleanFactor;
              const fisico = rawContagemUnid / cleanFactor;
              
              let custoMedio = 45.00;
              if (cols[24]) {
                const rawCusto = cols[24].trim().replace(/['"]/g, "");
                const numericCusto = parseFloat(rawCusto.replace(/\./g, '').replace(',', '.')) || 0;
                custoMedio = numericCusto < 12 ? numericCusto * cleanFactor : numericCusto;
              }
              
              let vendaOntemCaixas = 0;
              const activeSaidaIdx = saidasColIndex !== -1 ? saidasColIndex : 10;
              if (cols[activeSaidaIdx]) {
                const rawSaida = cols[activeSaidaIdx].trim().replace(/['"]/g, "");
                if (rawSaida && rawSaida !== "0" && rawSaida !== "-") {
                  if (rawSaida.includes("/")) {
                    const parts = rawSaida.split("/");
                    const fechada = parseFloat(parts[0]) || 0;
                    const avulsa = parseFloat(parts[1]) || 0;
                    const divisor = cleanFactor > 0 ? cleanFactor : 12;
                    vendaOntemCaixas = fechada + (avulsa / divisor);
                  } else {
                    const parsedUnits = parseFloat(rawSaida.replace(/\./g, "").replace(",", ".")) || 0;
                    if (parsedUnits > 0) {
                      vendaOntemCaixas = parsedUnits / cleanFactor;
                    }
                  }
                }
              }

              invParsed.push({
                sku: sku,
                estoqueFisicoCaixas: fisico,
                estoqueSistemaCaixas: sistema,
                custoMedio: custoMedio,
                vendaOntemCaixas: vendaOntemCaixas
              });
              return;
            }

            let activeSkuIdx = skuColIndex;
            let activeSistemaIdx = sistemaColIndex;
            let activeFisicoIdx = fisicoColIndex;
            let activeCustoIdx = custoColIndex;

            // Se for o relatório de 02.05.02 da Ambev (detectado por conter colunas de depósito/saldo nos cabeçalhos e mais de 13 colunas), usamos posições canônicas:
            if (isRawAmbev && cols.length >= 13) {
              if (cols[0].trim().length <= 3 && cols[3].trim().length > 0) {
                activeSkuIdx = 3; // Produto / SKU (Coluna D)
              }
              activeSistemaIdx = 11; // Coluna L (Disp / Saldo Fiscal)
              activeFisicoIdx = 12;  // Coluna M (Sua contagem coletada)
              activeCustoIdx = cols.length >= 25 ? 24 : -1; // Custo médio / Y se houver
            } else {
              // Caso contrário, usa os mapeamentos detectados dinamicamente pelos nomes das colunas
              activeSkuIdx = skuColIndex;
              activeSistemaIdx = sistemaColIndex !== -1 ? sistemaColIndex : -1;
              activeFisicoIdx = fisicoColIndex !== -1 ? fisicoColIndex : -1;
              activeCustoIdx = custoColIndex !== -1 ? custoColIndex : -1;
            }

            const rawSku = cols[activeSkuIdx] ? cols[activeSkuIdx].trim().replace(/['"]/g, "") : '';
            if (!rawSku || isNaN(Number(rawSku))) return; // ignora linhas vazias ou de totais
            const sku = rawSku.padStart(8, '0');

            let fisico = 0;
            let sistema = -1;
            let custoMedio = 45.00;

            if (activeSistemaIdx !== -1 && activeFisicoIdx !== -1) {
              const rawSistema = cols[activeSistemaIdx] ? cols[activeSistemaIdx].trim().replace(/['"]/g, "") : '';
              const rawFisico = cols[activeFisicoIdx] ? cols[activeFisicoIdx].trim().replace(/['"]/g, "") : '';
              
              const factor = (fatorColIndex !== -1 && cols[fatorColIndex]) 
                ? parseInt(cols[fatorColIndex].trim()) 
                : (cols[23] ? parseInt(cols[23].trim()) : 12) || 12;

              sistema = parseClosedBoxes(rawSistema);
              fisico = parseClosedBoxes(rawFisico);

              if (activeCustoIdx !== -1 && cols[activeCustoIdx]) {
                const rawCusto = cols[activeCustoIdx].trim().replace(/['"]/g, "");
                const numericCusto = parseFloat(rawCusto.replace(/\./g, '').replace(',', '.')) || 0;
                
                // Se o custo for o Custo Médio unitário (coluna Y, que costuma ser pequena como R$ 2,80) e não o do caixa inteiro
                if (activeCustoIdx === 24 && numericCusto < 12) {
                  custoMedio = numericCusto * factor; // converte para custo total por caixa
                } else {
                  custoMedio = numericCusto;
                }
              }
              
              // Se tivermos a coluna canônica AD (idx 29) e ela for diferente de custo unitário, ou se custoMédio for muito baixo:
              if (cols.length >= 30 && cols[29] && activeCustoIdx !== 29) {
                const rawCustoAD = cols[29].trim().replace(/['"]/g, "");
                const numericCustoAD = parseFloat(rawCustoAD.replace(/\./g, '').replace(',', '.')) || 0;
                if (numericCustoAD > 0) {
                  custoMedio = numericCustoAD;
                }
              }

            } else {
              // Layout simplificado de retrocompatibilidade (SKU, Fisico, [Sistema])
              const rawFisico = cols[1] ? cols[1].trim().replace(/['"]/g, "") : '0';
              fisico = parseClosedBoxes(rawFisico);
              
              if (cols.length >= 3 && cols[2]) {
                const rawSistema = cols[2] ? cols[2].trim().replace(/['"]/g, "") : '';
                sistema = parseClosedBoxes(rawSistema);
              }
            }

            let vendaOntemCaixas = 0;
            const activeSaidaIdx = saidasColIndex !== -1 ? saidasColIndex : 10;
            if (cols[activeSaidaIdx]) {
              const rawSaida = cols[activeSaidaIdx].trim().replace(/['"]/g, "");
              if (rawSaida && rawSaida !== "0" && rawSaida !== "-") {
                const factorUnit = (fatorColIndex !== -1 && cols[fatorColIndex]) 
                  ? parseInt(cols[fatorColIndex].trim()) 
                  : (cols[23] ? parseInt(cols[23].trim()) : 12) || 12;
                if (rawSaida.includes("/")) {
                  const parts = rawSaida.split("/");
                  const fechada = parseFloat(parts[0]) || 0;
                  const avulsa = parseFloat(parts[1]) || 0;
                  const divisor = factorUnit > 0 ? factorUnit : 12;
                  vendaOntemCaixas = fechada + (avulsa / divisor);
                } else {
                  vendaOntemCaixas = parseFloat(rawSaida.replace(/\./g, "").replace(",", ".")) || 0;
                }
              }
            }

            invParsed.push({
              sku: sku,
              estoqueFisicoCaixas: fisico,
              estoqueSistemaCaixas: sistema,
              custoMedio: custoMedio,
              vendaOntemCaixas: vendaOntemCaixas
            });
          }
        });
      }

      // Valilação e enriquecimento para o fluxo de auditoria física de contagens
      const cleanParsed = invParsed.filter(x => x.sku);
      if (cleanParsed.length === 0) {
        throw new Error("Nenhum dado legível foi extraído. Use o Relatório 02.05.02 ou a planilha de cadastro fiscal ERP.");
      }

      // Complementa com descrições do banco para a área de pré-visualização segura
      const enrichedPreview = cleanParsed.map(item => {
        const pOriginal = produtos.find(p => p.sku.toUpperCase() === item.sku.toUpperCase() || Number(p.sku) === Number(item.sku));
        const sistDecimal = item.estoqueSistemaCaixas === -1 
          ? (pOriginal ? pOriginal.estoqueSistemaCaixas : 0) 
          : item.estoqueSistemaCaixas;
        
        const finalCusto = item.custoMedio || (pOriginal ? pOriginal.custoMedio : 45.00);
        
        // Tenta buscar do catálogo mestre se não achar no banco ativo do usuário ou se o ativo estiver como "Novo Produto"
        const masterDesc = getMasterCatalogDescription(item.sku);
        const finalDesc = (pOriginal && pOriginal.descricao && pOriginal.descricao !== "Novo Produto (Criado após conciliação)" && !pOriginal.descricao.startsWith("Item Sincronizado")) 
          ? pOriginal.descricao 
          : (masterDesc || `Produto ${item.sku.replace(/^0+/, '')}`);
        
        return {
          sku: item.sku.toUpperCase(),
          descricao: finalDesc,
          estoqueFisicoCaixas: item.estoqueFisicoCaixas,
          estoqueSistemaCaixas: sistDecimal,
          custoMedio: finalCusto,
          valorEstoqueFisicoReal: item.estoqueFisicoCaixas * finalCusto,
          status: pOriginal ? (item.estoqueFisicoCaixas === sistDecimal ? 'batido' : 'divergente') : 'novo'
        };
      });

      setPreviewParsedList(enrichedPreview);
      setUploadedFileName(fileName);
      setImportText(content); // Mantém a sincronia com o editor manual
    } catch (err: any) {
      setFileError(err.message || "Erro de formatação de arquivo.");
      setUploadedFileName(null);
      setPreviewParsedList(null);
    }
  };

  // Parser genérico avançado para decodificar planilhas Excel estruturadas
  const processWorkbookWorksheet = (worksheet: XLSX.WorkSheet, fileName: string, importCategory: 'inventory' | 'erp_catalog') => {
    setFileError(null);
    setImportSuccess(false);

    try {
      // Converte planilha em JSON estruturado de objetos para facilidade de leitura
      const rows: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
      if (rows.length === 0) {
        throw new Error("A planilha de Excel está vazia ou sem linhas legíveis.");
      }

      // Função utilitária inteligente com normalização de acentos e espaços para achar cabeçalhos
      const getVal = (row: any, keys: string[]): any => {
        for (const k of Object.keys(row)) {
          const normK = k.toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-z0-9]/g, "")
            .trim();
          
          const matches = keys.some(targetKey => {
            const normTarget = targetKey.toLowerCase()
              .normalize("NFD")
              .replace(/[\u0300-\u036f]/g, "")
              .replace(/[^a-z0-9]/g, "")
              .trim();
            return normK === normTarget || normK.includes(normTarget) || normTarget.includes(normK);
          });
          
          if (matches) {
            return row[k];
          }
        }
        return undefined;
      };

      if (importCategory === 'inventory') {
        const invParsed: any[] = [];

        rows.forEach((row) => {
          const hasAmbevUnitsCols = getVal(row, ['qtdestoque', 'qtd_estoque']) !== undefined &&
                                    getVal(row, ['qtdcontagem', 'qtd_contagem']) !== undefined;

          if (hasAmbevUnitsCols) {
            let skuRaw = getVal(row, ['produto', 'sku', 'codigo']);
            if (skuRaw === undefined) {
              const cols = Object.keys(row);
              if (cols.length > 3) skuRaw = row[cols[3]]; // Produto is usually 4th column in Ambev layout
            }
            let skuStr = String(skuRaw || "").toUpperCase().trim().replace(/['"]/g, "");
            if (!skuStr || skuStr.startsWith("CODIGO") || skuStr.startsWith("SKU") || skuStr.startsWith("PRODUTO")) {
              return;
            }
            const sku = skuStr.padStart(8, '0');

            const rawFator = getVal(row, ['fator', 'factor', 'fatoremanlagem', 'fator_embalagem']);
            const cleanFactor = Math.max(1, parseInt(String(rawFator)) || 12);

            const rawEstoqueUnid = parseFloat(String(getVal(row, ['qtdestoque', 'qtd_estoque']) || "0").replace(/\./g, "").replace(",", ".")) || 0;
            const rawContagemVal = getVal(row, ['qtdcontagem', 'qtd_contagem']);
            const rawContagemUnid = rawContagemVal !== undefined && String(rawContagemVal).trim() !== ""
              ? parseFloat(String(rawContagemVal).replace(/\./g, "").replace(",", ".")) || 0
              : 0;

            const sistema = rawEstoqueUnid / cleanFactor;
            const fisico = rawContagemUnid / cleanFactor;

            const rawCustoUnit = parseFloat(String(getVal(row, ['customedio', 'custo_medio', 'custo', 'valormercadoria']) || "0").replace(/\./g, "").replace(",", ".")) || 0;
            const custoMedio = rawCustoUnit > 0 ? (rawCustoUnit < 12 ? rawCustoUnit * cleanFactor : rawCustoUnit) : 45.00;

            const pOriginal = produtos.find(p => p.sku === sku || Number(p.sku) === Number(sku));
            const masterDesc = getMasterCatalogDescription(sku);
            const desc = getVal(row, ['descricao', 'desc', 'produto', 'nome', 'mercadoria']) || (pOriginal ? pOriginal.descricao : masterDesc) || `Produto SKU ${sku}`;

            invParsed.push({
              sku,
              estoqueFisicoCaixas: fisico,
              estoqueSistemaCaixas: sistema,
              custoMedio,
              descricao: desc
            });
            return;
          }

          let skuRaw = getVal(row, ['sku', 'codigo', 'cod', 'produto', 'id']);
          if (skuRaw === undefined) {
            // fallback se não achou por nome: usa a primeira coluna
            const cols = Object.keys(row);
            if (cols.length > 0) skuRaw = row[cols[0]];
          }

          let skuStr = String(skuRaw || "").toUpperCase().trim().replace(/['"]/g, "");
          if (!skuStr || skuStr.startsWith("CODIGO") || skuStr.startsWith("SKU") || skuStr.startsWith("PRODUTO")) {
            return; // ignora linhas de cabeçalho extras ou vazias
          }

          const sku = skuStr.padStart(8, '0');

          // Busca contagem física
          let rawFisico = getVal(row, ['fisico', 'fisicocd', 'contagem', 'estoquefisico', 'fisicocaixas', 'fisicocaixa', 'contagemfisica', 'real']);
          if (rawFisico === undefined) {
            rawFisico = getVal(row, ['quantidade', 'qtd', 'volume', 'saldo']);
          }
          const fisico = rawFisico !== undefined ? Math.floor(Number(rawFisico)) : 0;

          // Busca estoque sistêmico
          let rawSistema = getVal(row, ['sistema', 'sist', 'estoquesistema', 'sistemacaixas', 'sistemacaixa', 'disponivel', 'disp', 'saldo', 'saldofiscal', 'faturamento']);
          const sistema = rawSistema !== undefined ? Math.floor(Number(rawSistema)) : fisico; // fallback se for físico somente

          let rawCusto = getVal(row, ['custo', 'custopor', 'custo_medio', 'customedio', 'preco', 'preço', 'valormercadoria']);
          const custoMedio = rawCusto !== undefined ? parseFloat(String(rawCusto).replace(',', '.')) : 45.00;

          const pOriginal = produtos.find(p => p.sku === sku || Number(p.sku) === Number(sku));
          const masterDesc = getMasterCatalogDescription(sku);
          const desc = getVal(row, ['descricao', 'desc', 'produto', 'nome', 'mercadoria']) || (pOriginal ? pOriginal.descricao : masterDesc) || `Produto SKU ${sku}`;

          invParsed.push({
            sku,
            estoqueFisicoCaixas: fisico,
            estoqueSistemaCaixas: sistema,
            custoMedio,
            descricao: desc
          });
        });

        const cleanParsed = invParsed.filter(x => x.sku && x.sku !== '00000000');
        if (cleanParsed.length === 0) {
          throw new Error("Não foi possível extrair nenhum registro de SKU e contagem física válidos do Excel.");
        }

        // Gera o preview enriquecido para a tabela de reconciliação
        const enrichedPreview = cleanParsed.map(item => {
          const pOriginal = produtos.find(p => p.sku === item.sku || Number(p.sku) === Number(item.sku));
          const finalCusto = pOriginal ? pOriginal.custoMedio : item.custoMedio;
          const masterDesc = getMasterCatalogDescription(item.sku);
          const finalDesc = (pOriginal && pOriginal.descricao && pOriginal.descricao !== "Novo Produto (Criado após conciliação)" && !pOriginal.descricao.startsWith("Item Sincronizado")) 
            ? pOriginal.descricao 
            : (masterDesc || item.descricao);

          return {
            sku: item.sku,
            descricao: finalDesc,
            estoqueFisicoCaixas: item.estoqueFisicoCaixas,
            estoqueSistemaCaixas: item.estoqueSistemaCaixas,
            custoMedio: finalCusto,
            valorEstoqueFisicoReal: item.estoqueFisicoCaixas * finalCusto,
            status: pOriginal ? (item.estoqueFisicoCaixas === item.estoqueSistemaCaixas ? 'batido' : 'divergente') : 'novo'
          };
        });

        setPreviewParsedList(enrichedPreview);
        setUploadedFileName(fileName);
        // Gera versão stringizada CSV do Excel para repopular o editor bruto se o usuário quiser editar manualmente
        const headersCsv = "SKU;Descricao;EstoqueFisicoCaixas;EstoqueSistemaCaixas;CustoMedio\n";
        const bodyCsv = cleanParsed.map(x => `${x.sku};${x.descricao};${x.estoqueFisicoCaixas};${x.estoqueSistemaCaixas};${x.custoMedio}`).join("\n");
        setImportText(headersCsv + bodyCsv);

      } else if (importCategory === 'erp_catalog') {
        const catalogParsed: any[] = [];

        rows.forEach(row => {
          let skuRaw = getVal(row, ['sku', 'codigo', 'cod', 'produto', 'id']);
          if (!skuRaw) {
            const cols = Object.keys(row);
            if (cols.length > 0) skuRaw = row[cols[0]];
          }

          let skuStr = String(skuRaw || "").toUpperCase().trim().replace(/['"]/g, "");
          if (!skuStr || skuStr.startsWith("CODIGO") || skuStr.startsWith("SKU")) return;

          const sku = skuStr.padStart(8, '0');
          const descricao = String(getVal(row, ['descricao', 'desc', 'produto', 'nome', 'mercadoria']) || `PRODUTO ${sku}`).toUpperCase();
          const unidadeMedida = String(getVal(row, ['unidade', 'medida', 'un', 'cx']) || 'CX');

          const rawFPlt = getVal(row, ['fatorpallet', 'caixasporpallet', 'pallet', 'plt', 'fator_pallet']);
          const fatorPallet = rawFPlt !== undefined ? parseInt(String(rawFPlt)) || 80 : 80;

          const rawFSku = getVal(row, ['fatorsku', 'fator_sku', 'fatoremanlagem', 'fator_embalagem', 'embalagem', 'unidades']);
          const fatorSku = rawFSku !== undefined ? parseInt(String(rawFSku)) || 12 : 12;

          const rawFHecto = getVal(row, ['fatorhecto', 'fatorhectolitro', 'hectolitro', 'hecto', 'fator_hecto', 'volume']);
          let fatorHecto = 0.05;
          if (rawFHecto !== undefined) {
            const cleanFH = String(rawFHecto).replace(/[R$\s]/gi, "").replace(",", ".");
            fatorHecto = parseFloat(cleanFH) || 0.05;
          }

          const rawCusto = getVal(row, ['custo', 'custopor', 'custo_medio', 'customedio', 'preco', 'preço', 'valormercadoria', 'custoporsku']);
          let custoPorSku = 45.00;
          if (rawCusto !== undefined) {
            const cleanC = String(rawCusto).replace(/[R$\s]/gi, "").replace(",", ".");
            custoPorSku = parseFloat(cleanC) || 45.00;
          }

          const rawGrupo = getVal(row, ['grupo', 'categoria', 'tipo', 'classificacao']) || 'MARKETPLACE';
          let rawGrupoUpper = String(rawGrupo || "").toUpperCase().trim();
          let groupClean = 'Marketplace';
          if (rawGrupoUpper.includes('CERV') || rawGrupoUpper.includes('CHOP') || rawGrupoUpper.includes('BEER')) {
            groupClean = 'Cerveja';
          } else if (rawGrupoUpper.includes('NAB') || rawGrupoUpper.includes('REFRI') || rawGrupoUpper.includes('SUCO') || rawGrupoUpper.includes('AGUA') || rawGrupoUpper.includes('REFRIGERANTE') || rawGrupoUpper.includes('ISOTONICO')) {
            groupClean = 'NAB';
          } else {
            groupClean = 'Marketplace';
          }

          catalogParsed.push({
            sku,
            descricao,
            unidadeMedida,
            fatorPallet,
            fatorSku,
            fatorHecto,
            custoPorSku,
            categoria: groupClean,
            estoqueFisicoCaixas: 0,
            estoqueSistemaCaixas: 0,
            valorEstoqueFisicoReal: custoPorSku,
            status: 'novo'
          });
        });

        if (catalogParsed.length === 0) {
          throw new Error("Não foi possível extrair nenhum produto do catálogo do Excel. Verifique colunas de SKU e Descrição.");
        }

        setCadastroPreview(catalogParsed);
      }
    } catch (err: any) {
      setFileError(err.message || "Falha ao ler dados da planilha.");
    }
  };

  // Handlers para o Dropzone
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');
      const isCsv = file.name.endsWith('.csv');
      
      const reader = new FileReader();
      if (isExcel) {
        reader.onload = (event) => {
          try {
            const data = new Uint8Array(event.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            processWorkbookWorksheet(worksheet, file.name, 'inventory');
          } catch (err: any) {
            const textReader = new FileReader();
            textReader.onload = (re) => {
              processFileContent(re.target?.result as string, file.name);
            };
            textReader.readAsText(file);
          }
        };
        reader.readAsArrayBuffer(file);
      } else {
        reader.onload = (event) => {
          const text = event.target?.result as string;
          processFileContent(text, file.name);
        };
        reader.readAsText(file);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');
      const isCsv = file.name.endsWith('.csv');
      
      const reader = new FileReader();
      if (isExcel) {
        reader.onload = (event) => {
          try {
            const data = new Uint8Array(event.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            processWorkbookWorksheet(worksheet, file.name, 'inventory');
          } catch (err: any) {
            const textReader = new FileReader();
            textReader.onload = (re) => {
              processFileContent(re.target?.result as string, file.name);
            };
            textReader.readAsText(file);
          }
        };
        reader.readAsArrayBuffer(file);
      } else {
        reader.onload = (event) => {
          const text = event.target?.result as string;
          processFileContent(text, file.name);
        };
        reader.readAsText(file);
      }
    }
  };

  // Handlers para o Dropzone de preços Ambev ERP
  const handlePricesDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsPricesDragActive(true);
    } else if (e.type === "dragleave") {
      setIsPricesDragActive(false);
    }
  };

  const handlePricesDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsPricesDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setUploadedPricesFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setRawPricesInput(text);
      };
      reader.readAsText(file);
    }
  };

  const handlePricesFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadedPricesFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setRawPricesInput(text);
      };
      reader.readAsText(file);
    }
  };

  // Handlers para o Dropzone do Cadastro
  const handleCadastroDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsCadastroDragActive(true);
    } else if (e.type === "dragleave") {
      setIsCadastroDragActive(false);
    }
  };

  const handleCadastroDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsCadastroDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const isExcelOrCsv = file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv');
      
      const reader = new FileReader();
      if (isExcelOrCsv) {
        reader.onload = (event) => {
          try {
            const data = new Uint8Array(event.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            processWorkbookWorksheet(worksheet, file.name, 'erp_catalog');
          } catch (err: any) {
            const textReader = new FileReader();
            textReader.onload = (re) => {
              processCadastroCSV(re.target?.result as string);
            };
            textReader.readAsText(file);
          }
        };
        reader.readAsArrayBuffer(file);
      } else {
        reader.onload = (event) => {
          const text = event.target?.result as string;
          processCadastroCSV(text);
        };
        reader.readAsText(file);
      }
    }
  };

  const handleCadastroFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const isExcelOrCsv = file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv');
      
      const reader = new FileReader();
      if (isExcelOrCsv) {
        reader.onload = (event) => {
          try {
            const data = new Uint8Array(event.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            processWorkbookWorksheet(worksheet, file.name, 'erp_catalog');
          } catch (err: any) {
            const textReader = new FileReader();
            textReader.onload = (re) => {
              processCadastroCSV(re.target?.result as string);
            };
            textReader.readAsText(file);
          }
        };
        reader.readAsArrayBuffer(file);
      } else {
        reader.onload = (event) => {
          const text = event.target?.result as string;
          processCadastroCSV(text);
        };
        reader.readAsText(file);
      }
    }
  };

  // Parser para Cadastro de Produto em Lote (CSV)
  const processCadastroCSV = (text: string) => {
    try {
      const lines = text.split(/\r?\n/);
      if (lines.length < 2) {
        setCadastroError("O arquivo enviado está vazio ou não contém dados suficientes.");
        return;
      }

      // Detecta cabeçalhos
      const headerLine = lines[0];
      const separator = headerLine.includes(';') ? ';' : ',';
      const colsHeader = headerLine.split(separator).map(c => c.trim().toUpperCase());

      // Busca colunas
      let colGrupo = colsHeader.findIndex(c => c.includes("GRUPO"));
      let colCodigo = colsHeader.findIndex(c => c.includes("COD") || c.includes("SKU") || c.replace(/[\u0300-\u036f]/g, "").includes("CODIGO") || c.replace(/[\u0300-\u036f]/g, "").includes("CDIGO"));
      let colDescricao = colsHeader.findIndex(c => c.includes("DESC") || c.replace(/[\u0300-\u036f]/g, "").includes("DESCRICAO") || c.replace(/[\u0300-\u036f]/g, "").includes("DESCRIO") || c === "PRODUTO");
      let colUm = colsHeader.findIndex(c => c.includes("UNIDADE") || c.includes("MEDIDA") || c === "UM" || c === "UN");
      let colFatorPallet = colsHeader.findIndex(c => c.includes("FATOR PALLET") || c.includes("PALLET"));
      let colFatorSku = colsHeader.findIndex(c => c.includes("FATOR SKU") || c.includes("FATOR_SKU") || c.replace(/\s+/g, '').includes("FATORSKU"));
      let colFatorHecto = colsHeader.findIndex(c => c.includes("HECTO") || c.includes("FATOR HECTO"));
      let colCusto = colsHeader.findIndex(c => c.includes("CUSTO") || c.includes("PRECO") || c.includes("VALOR"));

      // Fallback se não detectado por nome de Ambev
      if (colGrupo === -1) colGrupo = 0;
      if (colCodigo === -1) colCodigo = 1;
      if (colDescricao === -1) colDescricao = 2;
      if (colUm === -1) colUm = 3;
      if (colFatorPallet === -1) colFatorPallet = 4;
      if (colFatorSku === -1) colFatorSku = 5;
      if (colFatorHecto === -1) colFatorHecto = 6;
      if (colCusto === -1) colCusto = 7;

      const parsed: any[] = [];
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        const cols = line.split(separator);
        if (cols.length < 2) continue;

        const rawGroup = cols[colGrupo] ? cols[colGrupo].trim() : "MARKETPLACE";
        const rawCode = cols[colCodigo] ? cols[colCodigo].trim().replace(/['"]/g, "") : "";
        if (!rawCode) continue;

        // Limpa espaços e zeros à esquerda para ter um padrão de SKU de 8 dígitos se for totalmente numérico
        const sku = rawCode.padStart(8, '0');
        const desc = cols[colDescricao] ? cols[colDescricao].trim().replace(/['"]/g, "").toUpperCase() : `PROD-${sku}`;
        const um = cols[colUm] ? cols[colUm].trim() : "cx";
        
        // Limpa e extrai fator pallet
        const fatPallet = cols[colFatorPallet] ? parseInt(cols[colFatorPallet].replace(/\D/g, "")) || 80 : 80;
        // Limpa e extrai fator SKU
        const fatSku = cols[colFatorSku] ? parseInt(cols[colFatorSku].replace(/\D/g, "")) || 12 : 12;
        // Limpa e extrai fator hecto
        const fatHecto = cols[colFatorHecto] ? parseFloat(cols[colFatorHecto].trim().replace(",", ".")) || 0.05 : 0.05;

        // Limpa e extrai custo (pode ter "R$", espaços, etc.)
        let custo = 45.00;
        if (cols[colCusto]) {
          const san = cols[colCusto].replace("R$", "").replace(/\s/g, "").replace(".", "").replace(",", ".").trim();
          custo = parseFloat(san) || 45.00;
        }

        let rawGrupoUpper = rawGroup.toUpperCase().trim();
        let groupClean = 'Marketplace';
        if (rawGrupoUpper.includes('CERV') || rawGrupoUpper.includes('CHOP') || rawGrupoUpper.includes('BEER')) {
          groupClean = 'Cerveja';
        } else if (rawGrupoUpper.includes('NAB') || rawGrupoUpper.includes('REFRI') || rawGrupoUpper.includes('SUCO') || rawGrupoUpper.includes('AGUA') || rawGrupoUpper.includes('REFRIGERANTE') || rawGrupoUpper.includes('ISOTONICO')) {
          groupClean = 'NAB';
        } else {
          groupClean = 'Marketplace';
        }

        parsed.push({
          sku,
          descricao: desc,
          categoria: groupClean,
          unidadeMedida: um,
          fatorPallet: fatPallet,
          fatorSku: fatSku,
          fatorHecto: fatHecto,
          custoPorSku: custo
        });
      }

      if (parsed.length === 0) {
        setCadastroError("Nenhum item válido pôde ser extraído deste arquivo. Verifique o cabeçalho e delimitador.");
        return;
      }

      setCadastroPreview(parsed);
      setCadastroError(null);
    } catch (e: any) {
      setCadastroError("Erro ao processar arquivo: " + e.message);
    }
  };

  const handleManualCadastroSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualSku.trim()) {
      setCadastroError("O SKU é obrigatório.");
      return;
    }
    if (!manualDesc.trim()) {
      setCadastroError("A descrição do produto é obrigatória.");
      return;
    }

    try {
      setCadastroError(null);
      setCadastroSuccess(false);
      // Cadastra o item usando onAddProduct
      await onAddProduct({
        sku: manualSku.trim().padStart(8, '0'),
        descricao: manualDesc.toUpperCase().trim(),
        categoria: manualCategoria,
        custoMedio: parseFloat(manualCusto) || 45.00,
        caixasPorPallet: parseInt(manualFatorPallet) || 80,
        fatorSku: parseInt(manualFatorSku) || 12,
        fatorHecto: parseFloat(manualFatorHecto) || 0.05,
        unidadeMedida: manualUm,
        vendaMedia: 200 // default
      });

      // Limpa os campos individuais
      setManualSku("");
      setManualDesc("");
      setManualCusto("45.00");
      setManualFatorPallet("80");
      setManualFatorSku("12");
      setManualFatorHecto("0.05");
      setManualUm("CX");
      setCadastroSuccess(true);
    } catch (err: any) {
      setCadastroError(err.message || "Erro ao cadastrar item manualmente.");
    }
  };

  const handleConfirmCadastroImport = async () => {
    if (!cadastroPreview || cadastroPreview.length === 0) return;
    try {
      setCadastroError(null);
      setCadastroSuccess(false);

      // Envia os itens em massa usando onImportState
      await onImportState({ erpCatalog: cadastroPreview });

      setCadastroSuccess(true);
      setCadastroPreview(null);
    } catch (err: any) {
      setCadastroError(err.message || "Erro desconhecido ao cadastrar catálogo.");
    }
  };

  // Função para gerar e baixar a planilha base do CSV modelo com os SKUs reais do banco de dados
  const baixarTemplateCSV = () => {
    const headers = [
      'SKU',                         // A (0)
      'Descricao',                   // B (1)
      'Categoria',                   // C (2)
      'Fator Embalagem',             // D (3)
      'Fator Hectolitro',            // E (4)
      'Diferenca (cx)',              // F (5)
      'Valor Diferenca (R$)',        // G (6)
      'Volume Total (HL)',           // H (7)
      'Pallets Ocupados',            // I (8)
      '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', // J a AA (9 a 26)
      'Saldo Fiscal (cx) [AB]',      // AB (27)
      'Quantidade Fisica (cx) [AC]', // AC (28)
      'Custo Medio ITEM (R$) [AD]'   // AD (29)
    ];
    
    const rows = produtos.map(p => [
      `"${p.sku}"`,
      `"${p.descricao.replace(/"/g, '""')}"`,
      `"${p.categoria}"`,
      p.fatorEmbalagem,
      p.fatorHectolitro.toFixed(4),
      p.diferencaCaixas.toFixed(2),
      p.divergenciaValor.toFixed(2),
      p.volumeHectolitro.toFixed(4),
      p.quantidadePallets.toFixed(2),
      '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
      p.estoqueSistemaCaixas.toFixed(2),
      p.estoqueFisicoCaixas.toFixed(2),
      p.custoMedio.toFixed(2)
    ].join(';'));
    
    // Adiciona BOM UTF-8 (\uFEFF) para visualização correta no Excel brasileiro
    const csvContent = '\uFEFF' + [headers.join(';'), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'BASE_IMPORTACAO_ESTOQUE.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Confirmação final da importação de arquivos
  const handleConfirmImport = async () => {
    if (!previewParsedList || previewParsedList.length === 0) return;
    
    setFileError(null);
    setImportSuccess(false);
    try {
      if (detectedImportType === 'erp_catalog') {
        const erpPayload = previewParsedList.map(item => ({
          sku: item.sku,
          descricao: item.descricao,
          unidadeMedida: item.unidadeMedida,
          fatorPallet: item.fatorPallet,
          fatorSku: item.fatorSku,
          fatorHecto: item.fatorHecto,
          custoPorSku: item.custoPorSku
        }));
        
        await onImportState({ erpCatalog: erpPayload });
      } else if (detectedImportType === 'divergencias_congeladas') {
        const congeladosPayload = previewParsedList.map(item => ({
          sku: item.sku,
          descricao: item.descricao,
          diferencaCaixas: item.diferencaCaixas,
          custoPorSku: item.custoPorSku,
          observacao: item.observacao || "Importado via planilha externa"
        }));
        
        await onImportState({ divergenciasCongeladas: congeladosPayload });
      } else {
        const invPayload = previewParsedList.map(item => ({
          sku: item.sku,
          estoqueFisicoCaixas: item.estoqueFisicoCaixas,
          estoqueSistemaCaixas: item.estoqueSistemaCaixas,
          custoMedio: item.custoMedio,
          descricao: item.descricao,
          vendaOntemCaixas: item.vendaOntemCaixas || 0
        }));
        
        await onImportState({ inventario: invPayload });
      }
      
      setImportSuccess(true);
      setPreviewParsedList(null);
      setUploadedFileName(null);
      setImportText("");
    } catch (err: any) {
      setFileError(err.message || "Falha ao gravar informações do arquivo no servidor.");
    }
  };

  // Estados de simulação para novos produtos
  const [showAddForm, setShowAddForm] = useState(false);
  const [newProduct, setNewProduct] = useState({
    sku: "",
    descricao: "",
    cost: 45.00,
    fatorPallet: 80,
    vendaMedia: 150
  });

  // Filtro de busca na tela de divergências (apenas para refinar as divergências ativas)
  const [searchQuery, setSearchQuery] = useState("");
  // Filtro de busca na tela de todos os itens (nova guia)
  const [searchTodosQuery, setSearchTodosQuery] = useState("");
  // Filtro de situação de divergência (todos, sobra, falta, ok) para todos os itens
  const [filterTodosStatus, setFilterTodosStatus] = useState<'todos' | 'sobra' | 'falta' | 'ok'>('todos');

  // Seleções para recontagem
  const [selectedForRecount, setSelectedForRecount] = useState<string[]>([]);
  const [showIaSuggestions, setShowIaSuggestions] = useState(true);

  // 30-Day Consolidated Audit Engine
  const consolidatedAuditData = useMemo(() => {
    const day = auditSelectedDay;
    
    // Deterministic hash helper, identical to server
    const getHash = (text: string, sub: string) => {
      let h = 0;
      const combined = text + sub;
      for (let i = 0; i < combined.length; i++) {
        h = (h * 31 + combined.charCodeAt(i)) & 0xffffffff;
      }
      return Math.abs(h);
    };

    let totalPhysicalBoxes = 0;
    let totalFiscalBoxes = 0;
    let totalPhysicalValue = 0;
    let totalFiscalValue = 0;
    let totalPhysicalHl = 0;
    let totalFiscalHl = 0;

    const skuDetails: Array<{
      sku: string;
      descricao: string;
      categoria: string;
      custoMedio: number;
      fatorHectolitro: number;
      fisico: number;
      sistema: number;
      divergenciaCaixas: number;
      divergenciaValor: number;
      divergenciaHl: number;
    }> = [];

    produtos.forEach((p) => {
      const skuNorm = p.sku.trim().toUpperCase().padStart(8, '0');
      
      const hashVal = getHash(skuNorm, "base");
      const stockBase = (hashVal % 140) + 40; // 40 a 180 caixas de estoque inicial
      const avgSale = (getHash(skuNorm, "sales") % 8) + 2; // 2 a 10 caixas por dia
      const refillSize = (getHash(skuNorm, "refill") % 60) + 50; // 50 a 110 caixas

      let currentSist = stockBase;
      let currentFis = stockBase + (getHash(skuNorm, "driftInit") % 8) - 4; // Desvio inicial de +/- 4 caixas

      for (let d = 1; d <= day; d++) {
        const hasRefill = d % 7 === 0;
        const entries = hasRefill ? refillSize : 0;
        const daySales = Math.max(0, Math.round(avgSale + (getHash(skuNorm, `saleD-${d}`) % 4) - 2));

        currentSist = Math.max(0, currentSist - daySales + entries);

        const lossDrift = (getHash(skuNorm, `driftD-${d}`) % 3) - 1.4; 
        currentFis = Math.max(0, Math.floor(currentFis - daySales + entries + lossDrift));

        if (d === 15) {
          currentFis = currentSist;
        }
      }

      const diff = currentFis - currentSist;
      const diffVal = diff * (p.custoMedio || 35);
      const diffHl = diff * (p.fatorHectolitro || 0.05);

      totalPhysicalBoxes += currentFis;
      totalFiscalBoxes += currentSist;
      totalPhysicalValue += currentFis * (p.custoMedio || 35);
      totalFiscalValue += currentSist * (p.custoMedio || 35);
      totalPhysicalHl += currentFis * (p.fatorHectolitro || 0.05);
      totalFiscalHl += currentSist * (p.fatorHectolitro || 0.05);

      skuDetails.push({
        sku: p.sku,
        descricao: p.descricao,
        categoria: p.categoria,
        custoMedio: p.custoMedio || 35,
        fatorHectolitro: p.fatorHectolitro || 0.05,
        fisico: currentFis,
        sistema: currentSist,
        divergenciaCaixas: diff,
        divergenciaValor: diffVal,
        divergenciaHl: diffHl,
      });
    });

    // Sort to find top discrepancies
    const topDiscrepancies = [...skuDetails]
      .sort((a, b) => Math.abs(b.divergenciaCaixas) - Math.abs(a.divergenciaCaixas))
      .slice(0, 5);

    return {
      totalPhysicalBoxes,
      totalFiscalBoxes,
      totalPhysicalValue,
      totalFiscalValue,
      diffBoxes: totalPhysicalBoxes - totalFiscalBoxes,
      diffValue: totalPhysicalValue - totalFiscalValue,
      totalPhysicalHl,
      totalFiscalHl,
      diffHl: totalPhysicalHl - totalFiscalHl,
      topDiscrepancies
    };
  }, [produtos, auditSelectedDay]);

  // 1. Filtrar divergentes - REQUISITO RÍGIDO: Mostrar SOMENTE itens com divergência na tela principal (Ordenados do maior impacto para o menor)
  const itensDivergentes = useMemo(() => {
    return produtos
      .filter(p => p.temDivergencia && 
        (p.sku.toLowerCase().includes(searchQuery.toLowerCase()) || 
         p.descricao.toLowerCase().includes(searchQuery.toLowerCase()))
      )
      .sort((a, b) => Math.abs(b.divergenciaValor || 0) - Math.abs(a.divergenciaValor || 0));
  }, [produtos, searchQuery]);

  // Inteligência de Recomendações: sugestões de recontagem por dias ou impacto > 2% de saúde de estoque
  const sugestoesRecontagem = useMemo(() => {
    // Filtro inicial por SKUs que ATUALMENTE têm divergência ativa.
    // Assim, ao conciliar o estoque (zerando ou alinhando a divergência), ela desaparece imediatamente desta lista!
    const divergentes = produtos.filter(p => p.temDivergencia);

    // Encontra o histórico de fechamento de lote ou conciliação diária mais recente.
    // Usado para garantir que na última virada de dia/conciliação o SKU não possuía divergência ativa (isto é, não havia desvio de 1 dia para o outro).
    const ultimaConciliacao = (historicoConciliacoes || []).find((h: any) => 
      h.todosItensInventario?.length > 0 || h.itensDivergentes?.length > 0
    );

    return divergentes.map(p => {
      // 1. Calcula dias de desvio (divergência contínua)
      let diasDivergencia = 1;
      const congelado = (divergenciasCongeladas || []).find((c: any) => c.sku === p.sku);
      if (congelado && congelado.dataCongelamento) {
        const msDiff = Date.now() - new Date(congelado.dataCongelamento).getTime();
        diasDivergencia = Math.max(1, Math.floor(msDiff / (1000 * 60 * 60 * 24)));
      } else {
        const histDesteSku = (historicoConciliacoes || []).filter((h: any) => 
          (h.itensDivergentes || []).some((it: any) => it.sku === p.sku)
        );
        if (histDesteSku.length > 0) {
          const dataMaisAntiga = histDesteSku[histDesteSku.length - 1].data;
          const msDiff = Date.now() - new Date(dataMaisAntiga).getTime();
          diasDivergencia = Math.max(1, Math.floor(msDiff / (1000 * 60 * 60 * 24)));
        }
      }

      // 2. Calcula desvio individual de saúde do SKU (frequentemente acuracidade física x fiscal do item)
      const desvioIndividual = p.estoqueSistemaCaixas > 0 
        ? Math.abs(p.diferencaCaixas) / p.estoqueSistemaCaixas 
        : 1.0;

      const temPoucosDias = diasDivergencia <= 5;
      const temAltoImpacto = desvioIndividual > 0.02; // maior que 2% de impacto de saúde de estoque

      // Verifica se no fechamento de lote / dia operacional imediatamente anterior o SKU já possuía divergência ativa.
      // Se já possuía, significa que a divergência persiste de ontem para hoje (logo, não é elegível para as novas sugestões de campo).
      const tinhaDivergenciaOntem = ultimaConciliacao
        ? (ultimaConciliacao.itensDivergentes || []).some((it: any) => it.sku === p.sku)
        : false;

      const elegivelPelaVirada = !tinhaDivergenciaOntem;

      const motivos: string[] = [];
      if (temPoucosDias) {
        motivos.push(`${diasDivergencia} ${diasDivergencia === 1 ? 'dia' : 'dias'} de desvio (Recente)`);
      }
      if (temAltoImpacto) {
        motivos.push(`${(desvioIndividual * 100).toFixed(1)}% de impacto na saúde do SKU (> 2%)`);
      }

      return {
        ...p,
        diasDivergencia,
        desvioIndividual,
        temPoucosDias,
        temAltoImpacto,
         motivos,
        relevante: (temPoucosDias || temAltoImpacto) && elegivelPelaVirada
      };
    }).filter(s => s.relevante)
      .sort((a, b) => b.desvioIndividual - a.desvioIndividual);
  }, [produtos, divergenciasCongeladas, historicoConciliacoes]);

  // Filtrar todos os itens cadastrados no CD (para a nova guia de todos os itens)
  const todosOsItensFiltrados = useMemo(() => {
    return produtos.filter(p => {
      const matchText = p.sku.toLowerCase().includes(searchTodosQuery.toLowerCase()) || 
                        p.descricao.toLowerCase().includes(searchTodosQuery.toLowerCase());
      if (!matchText) return false;

      const difAjustada = p.diferencaCaixas;

      if (filterTodosStatus === 'sobra') {
        return difAjustada > 0.001;
      }
      if (filterTodosStatus === 'falta') {
        return difAjustada < -0.001;
      }
      if (filterTodosStatus === 'ok') {
        return Math.abs(difAjustada) <= 0.001;
      }
      return true;
    });
  }, [produtos, searchTodosQuery, filterTodosStatus]);

  // Média Geral de Acuracidade WMS - Baseada na fórmula Simétrica de Min/Max de caixas (Ajustada pelas compensações congeladas)
  const acuracidadeMedia = useMemo(() => {
    if (produtos.length === 0) return 100;
    const sumAcc = produtos.reduce((acc, p) => {
      const fis = Math.floor(p.estoqueFisicoCaixas);
      const sis = Math.floor(p.estoqueSistemaCaixas);
      const dif = p.diferencaCaixas;
      if (Math.abs(dif) <= 0.001) return acc + 100;
      const max = Math.max(fis, sis);
      if (max === 0) return acc + 100;
      const itemAcc = 100 - (Math.abs(dif) / max) * 100;
      return acc + Math.min(100, Math.max(0, itemAcc));
    }, 0);
    return sumAcc / produtos.length;
  }, [produtos]);

  // Conformidade Operacional (Porcentagem de itens perfeitamente batidos ou compensados)
  const conformidadeItens = useMemo(() => {
    if (produtos.length === 0) return 100;
    const okCount = produtos.filter(p => Math.abs(p.diferencaCaixas) <= 0.001).length;
    return (okCount / produtos.length) * 105 / 1.05; // Normalizes to strict percent base
  }, [produtos]);

  const isAllSelected = useMemo(() => {
    if (itensDivergentes.length === 0) return false;
    return itensDivergentes.every(p => selectedForRecount.includes(p.sku));
  }, [itensDivergentes, selectedForRecount]);

  const handleToggleSelectAll = () => {
    if (isAllSelected) {
      const skusToRemove = itensDivergentes.map(p => p.sku);
      setSelectedForRecount(prev => prev.filter(sku => !skusToRemove.includes(sku)));
    } else {
      const skusToAdd = itensDivergentes.map(p => p.sku);
      setSelectedForRecount(prev => {
        const next = [...prev];
        skusToAdd.forEach(sku => {
          if (!next.includes(sku)) {
            next.push(sku);
          }
        });
        return next;
      });
    }
  };

  const handleToggleSelectItem = (sku: string) => {
    setSelectedForRecount(prev => {
      if (prev.includes(sku)) {
        return prev.filter(s => s !== sku);
      } else {
        return [...prev, sku];
      }
    });
  };

  const exportSelectedForRecountCSV = () => {
    const selectedItems = produtos.filter(p => selectedForRecount.includes(p.sku));
    if (selectedItems.length === 0) {
      alert("Nenhum item selecionado para exportar para recontagem.");
      return;
    }

    const headers = [
      'COD',                         // A (0)
      'DESCRIÇÃO',                   // B (1)
      'CONTAGEM ANTERIOR',           // C (2)
      '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', // D a AA (3 a 26)
      'Saldo Fiscal (cx) [AB]',      // AB (27)
      'Quantidade Fisica (cx) [AC]', // AC (28)
      'Custo Medio ITEM (R$) [AD]'   // AD (29)
    ];

    const csvRows = [
      headers.join(';'), // Excel brasileiro usa ponto e vírgula
      ...selectedItems.map(p => [
        p.sku.replace(/^0+/, '') || '0',                     // COD (A)
        p.descricao.replace(/;/g, ' ').toUpperCase(),        // DESCRIÇÃO (B)
        Math.floor(p.estoqueFisicoCaixas),                   // CONTAGEM ANTERIOR (C)
        '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', // J a AA (3 a 26)
        p.estoqueSistemaCaixas.toFixed(2),                   // AB (27)
        p.estoqueFisicoCaixas.toFixed(2),                    // AC (28)
        p.custoMedio.toFixed(2)                              // AD (29)
      ].join(';'))
    ];

    // Detecção no Excel brasileiro de codificação UTF-8
    const csvContent = '\uFEFF' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `RELATORIO_RECONTAGEM_02_05_02_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Atualiza automaticamente as divergências sincronizando tudo ao exportar
    if (onRefresh) {
      onRefresh();
    }
  };

  // Função para exportar as Perdas e Sobras (Divergências Ativas) em CSV
  const exportarPerdasESobrasCSV = () => {
    const activeDivergences = produtos.filter(p => p.temDivergencia);
    
    if (activeDivergences.length === 0) {
      alert("Nenhuma perda ou sobra ativa para exportar.");
      return;
    }

    const headers = [
      'SKU',
      'DESCRIÇÃO',
      'CATEGORIA',
      'SALDO FISCAL (CX)',
      'SALDO FISICO (CX)',
      'DIVERGENCIA (CX)',
      'CUSTO MEDIO CX (R$)',
      'VALOR FINANCEIRO (R$)',
      'FATOR HECTOLITRO (HL/CX)',
      'VOLUME HECTOLITRO (HL)',
      'TIPO'
    ];

    const csvRows = [
      headers.join(';'),
      ...activeDivergences.map(p => [
        p.sku,
        p.descricao.replace(/;/g, ' ').toUpperCase(),
        p.categoria,
        p.estoqueSistemaCaixas.toFixed(2),
        p.estoqueFisicoCaixas.toFixed(2),
        p.diferencaCaixas.toFixed(2),
        p.custoMedio.toFixed(2),
        p.divergenciaValor.toFixed(2),
        p.fatorHectolitro.toFixed(4),
        p.divergenciaHectolitro.toFixed(4),
        p.diferencaCaixas < 0 ? 'PERDA (FALTA)' : 'GANHO (SOBRA)'
      ].join(';'))
    ];

    const csvContent = '\uFEFF' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `RELATORIO_PERDAS_E_SOBRAS_WMS_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Atualiza automaticamente as divergências sincronizando tudo ao exportar as perdas e sobras
    if (onRefresh) {
      onRefresh();
    }
  };

  // Cálculos de Valoração Geral do Estoque: Físico vs Fiscal e sua Diferença
  const totaisValoresEstoque = useMemo(() => {
    const fiscalTotal = produtos.reduce((acc, p) => acc + (p.estoqueSistemaCaixas * p.custoMedio), 0);
    // Itens congelados somam ao saldo físico para dar o resultado final
    const fisicoTotal = produtos.reduce((acc, p) => acc + (p.saldoAjustadoCaixas * p.custoMedio), 0);
    const diferenca = fisicoTotal - fiscalTotal;
    return {
      fiscalTotal: Number(fiscalTotal.toFixed(2)),
      fisicoTotal: Number(fisicoTotal.toFixed(2)),
      diferenca: Number(diferenca.toFixed(2))
    };
  }, [produtos]);

  // Cálculos consolidados da quebra/divergência baseados na diferença algébrica real
  const resumoDivergencias = useMemo(() => {
    let custoDivergenciaAbs = 0; // diferença financeira consolidada
    let volumeDivergenciaHL = 0; // diferença volumétrica consolidada
    let deltaCaixasFaltantes = 0;
    let deltaCaixasExcedentes = 0;

    produtos.forEach(p => {
      custoDivergenciaAbs += p.divergenciaValor;
      volumeDivergenciaHL += p.divergenciaHectolitro;
      if (p.temDivergencia) {
        if (p.diferencaCaixas < 0) {
          deltaCaixasFaltantes += Math.abs(p.diferencaCaixas);
        } else {
          deltaCaixasExcedentes += p.diferencaCaixas;
        }
      }
    });

    return {
      custoDivergenciaAbs: Number(custoDivergenciaAbs.toFixed(2)),
      volumeDivergenciaHL: Number(volumeDivergenciaHL.toFixed(4)),
      deltaCaixasFaltantes: Number(deltaCaixasFaltantes.toFixed(2)),
      deltaCaixasExcedentes: Number(deltaCaixasExcedentes.toFixed(2))
    };
  }, [produtos]);

  // Filtro de divergências ativas prontas para serem congeladas
  const ativosParaCongelar = useMemo(() => {
    return produtos.filter(p => p.temDivergencia && !divergenciasCongeladas.some(f => f.sku === p.sku));
  }, [produtos, divergenciasCongeladas]);

  // Estatísticas de itens congelados (Valoração e Hectolitros)
  const resumoCongelados = useMemo(() => {
    let valorLiquido = 0;
    let valorAbsoluto = 0;
    let volumeLiquidoHL = 0;
    let volumeAbsolutoHL = 0;
    let totalCaixasBloqueadas = 0;

    divergenciasCongeladas.forEach(item => {
      valorLiquido += item.valorTotalDivergencia || 0;
      valorAbsoluto += Math.abs(item.valorTotalDivergencia || 0);
      volumeLiquidoHL += item.divergenciaHectolitro || 0;
      volumeAbsolutoHL += Math.abs(item.divergenciaHectolitro || 0);
      totalCaixasBloqueadas += Math.abs(item.diferencaCaixas || 0);
    });

    return {
      valorLiquido: parseFloat(valorLiquido.toFixed(2)),
      valorAbsoluto: parseFloat(valorAbsoluto.toFixed(2)),
      volumeLiquidoHL: parseFloat(volumeLiquidoHL.toFixed(4)),
      volumeAbsolutoHL: parseFloat(volumeAbsolutoHL.toFixed(4)),
      totalCaixasBloqueadas: parseFloat(totalCaixasBloqueadas.toFixed(2))
    };
  }, [divergenciasCongeladas]);

  // Cálculos para o Dashboard Gerencial de Alertas (Top 20 Sobras e Top 20 Faltas)
  const totalAbsDivergenciaValor = useMemo(() => {
    return produtos.reduce((acc, p) => acc + Math.abs(p.divergenciaValor || 0), 0);
  }, [produtos]);

  const top20Sobras = useMemo(() => {
    return [...produtos]
      .filter(p => p.diferencaCaixas > 0)
      .sort((a, b) => b.divergenciaValor - a.divergenciaValor)
      .slice(0, 20);
  }, [produtos]);

  const top20Faltas = useMemo(() => {
    return [...produtos]
      .filter(p => p.diferencaCaixas < 0)
      .sort((a, b) => a.divergenciaValor - b.divergenciaValor) // do mais negativo (maior perda) para o menos
      .slice(0, 20);
  }, [produtos]);

  const handleEditStart = (sku: string, currentValue: number) => {
    setEditingSku(sku);
    setEditingValue(currentValue);
  };

  const handleEditSave = async (sku: string) => {
    setLoadingSku(sku);
    try {
      await onUpdatePhysical(sku, Math.floor(Number(editingValue)));
      setEditingSku(null);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSku(null);
    }
  };

  // Função para exportar o estoque atual em CSV (RELATÓRIO 02.05.02)
  const exportarEstoqueCSV = () => {
    const headers = [
      'COD',                         // A (0)
      'DESCRIÇÃO',                   // B (1)
      'CONTAGEM ANTERIOR',           // C (2)
      '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', // D a AA (3 a 26)
      'Saldo Fiscal (cx) [AB]',      // AB (27)
      'Quantidade Fisica (cx) [AC]', // AC (28)
      'Custo Medio ITEM (R$) [AD]'   // AD (29)
    ];

    const csvRows = [
      headers.join(';'), // Excel brasileiro usa ponto e vírgula
      ...produtos.map(p => [
        p.sku.replace(/^0+/, '') || '0',                     // COD (A)
        p.descricao.replace(/;/g, ' ').toUpperCase(),        // DESCRIÇÃO (B)
        Math.floor(p.estoqueFisicoCaixas),                   // CONTAGEM ANTERIOR (C)
        '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', // J a AA (3 a 26)
        p.estoqueSistemaCaixas.toFixed(2),                   // AB (27)
        p.estoqueFisicoCaixas.toFixed(2),                    // AC (28)
        p.custoMedio.toFixed(2)                              // AD (29)
      ].join(';'))
    ];

    // Detecção no Excel brasileiro de codificação UTF-8
    const csvContent = '\uFEFF' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'RELATORIO_02_05_02_ESTOQUE_ATUAL.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Atualiza automaticamente as divergências sincronizando tudo ao exportar estoque
    if (onRefresh) {
      onRefresh();
    }
  };

  const handleForceDayTurn = async () => {
    const confirmacao = window.confirm(
      "Tem certeza que deseja forçar a virada do dia operacional manualmente?\n\nIsso salvará o estoque fiscal atual de faturamento no histórico de conciliações e resetará todas as contagens físicas em caixas no armazém para zero, permitindo que a equipe inicie a jornada de contagens do zero."
    );
    if (!confirmacao) return;

    try {
      const response = await fetch("/api/state/day-turn", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ usuario: operatorEmail || "djesoaresn@gmail.com" })
      });

      const resJson = await response.json();
      if (resJson.success) {
        alert(resJson.message);
        if (onRefresh) {
          await onRefresh();
        }
      } else {
        alert("Erro ao virar o dia operacional: " + (resJson.error || "Erro desconhecido"));
      }
    } catch (err: any) {
      console.error("Erro na requisição de virada de dia manual:", err);
      alert("Erro na rede ao tentar virar o dia operacional.");
    }
  };

  const handleApplyReconciliation = async () => {
    setShowReconModal(true);
  };

  // Processo de simulação do Importador de arquivos ERP (CSV/JSON)
  const handleImportSubmit = async () => {
    setFileError(null);
    setImportSuccess(false);
    try {
      if (!importText.trim()) {
        throw new Error("Insira um código JSON ou CSV de contagem válido para importar.");
      }

      // Tenta interpretar como JSON de simulação ERP
      let estParsed: any[] = [];
      let invParsed: any[] = [];

      if (importText.startsWith("{") || importText.startsWith("[")) {
        const parsed = JSON.parse(importText);
        if (Array.isArray(parsed)) {
          // Trata como vetor de contagem Direta
          invParsed = parsed.map(item => ({
            sku: item.sku || item.SKU,
            estoqueFisicoCaixas: Math.floor(Number(item.estoqueFisicoCaixas ?? item.fisico ?? 0)),
            estoqueSistemaCaixas: Math.floor(Number(item.estoqueSistemaCaixas ?? item.sistema ?? 0)),
          }));
        } else {
          throw new Error("JSON deve ser uma array contendo objetos com os campos [sku, estoqueFisicoCaixas, estoqueSistemaCaixas]");
        }
      } else {
        // Trata como CSV delimitado por ponto e vírgula ou vírgula
        const lines = importText.split("\n");
        lines.forEach((line, index) => {
          if (index === 0 || !line.trim()) return; // Ignora cabeçalhos
          const cols = line.split(/[;,]/);
          if (cols.length >= 3) {
            invParsed.push({
              sku: cols[0].trim().replace(/['"]/g, ""),
              estoqueFisicoCaixas: Math.floor(Number(cols[1].trim()) || 0),
              estoqueSistemaCaixas: Math.floor(Number(cols[2].trim()) || 0)
            });
          }
        });
      }

      if (invParsed.length === 0) {
        throw new Error("Nenhum dado legível foi extraído. Estrutura aceita: SKU,Fisico,Sistema");
      }

      // Repassa dados integrados para o estado superior
      await onImportState({ inventario: invParsed });
      setImportSuccess(true);
      setImportText("");
    } catch (err: any) {
      setFileError(err.message || "Erro de formatação do arquivo.");
    }
  };

  const handleAddProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.sku || !newProduct.descricao) return;
    
    await onAddProduct({
      sku: newProduct.sku.toUpperCase(),
      descricao: newProduct.descricao,
      custoMedio: newProduct.cost,
      caixasPorPallet: newProduct.fatorPallet,
      vendaMedia: newProduct.vendaMedia
    });

    setNewProduct({ sku: "", descricao: "", cost: 45.00, fatorPallet: 80, vendaMedia: 150 });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6" id="conciliacao-view-root">
      
      {/* 1. Header & Alerta Logístico Principal */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-lux flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 rounded-full bg-rose-50 text-rose-700 text-[10px] font-extrabold uppercase font-mono tracking-widest flex items-center gap-1 animate-pulse">
              <Flame className="w-3 h-3" /> Foco Divergências
            </span>
            <span className="text-slate-400 text-xs font-semibold">| Painel do Conferente</span>
          </div>
          <h2 className="text-lg font-bold font-display text-slate-800 tracking-tight">Conciliação Física x Fiscal de Estoque</h2>
          <p className="text-xs text-slate-500 max-w-xl">
            Abaixo estão listados <strong>exclusivamente</strong> os produtos que possuem divergência ativa. Ajuste as contagens físicas após recontagem no CD e confirme para regularizar o ERP.
          </p>
        </div>

        {/* Célula de Ação Unificada de Conciliação Contábil */}
        {itensDivergentes.length > 0 ? (
          <button 
            type="button"
            onClick={handleApplyReconciliation}
            className="shrink-0 bg-indigo-600 hover:bg-slate-900 border border-indigo-700 hover:border-slate-800 text-white p-3 px-5 rounded-xl font-semibold text-xs tracking-wide shadow flex items-center gap-2 transition-all cursor-pointer"
          >
            <UserCheck className="w-4 h-4" />
            Conciliar Estoque Hoje ({itensDivergentes.length} SKUs)
          </button>
        ) : (
          <div className="bg-emerald-50 text-emerald-800 p-3 px-5 rounded-xl text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            100% Sincronizado: Sem Divergências no CD
          </div>
        )}
      </div>

      {/* 2. Painel de Indicadores de Quebra e Diferença */}
      {itensDivergentes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Card A: Impacto de Acerto Financeiro */}
          <div className={`p-4 rounded-xl border shadow-lux flex items-center justify-between ${
            resumoDivergencias.custoDivergenciaAbs === 0 
              ? 'bg-white border-slate-100' 
              : resumoDivergencias.custoDivergenciaAbs > 0 
                ? 'bg-emerald-50/25 border-emerald-100' 
                : 'bg-rose-50/25 border-rose-100'
          }`}>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Perda / Ganho Total Auditado</span>
              <h4 className={`text-base font-black font-display font-mono ${
                resumoDivergencias.custoDivergenciaAbs === 0 
                  ? 'text-slate-800' 
                  : resumoDivergencias.custoDivergenciaAbs > 0 
                    ? 'text-emerald-700' 
                    : 'text-rose-700'
              }`}>
                {resumoDivergencias.custoDivergenciaAbs > 0 ? '+' : ''}R$ {resumoDivergencias.custoDivergenciaAbs.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </h4>
              <p className="text-[10px] text-slate-500 font-semibold font-mono">Volatilidade financeira ajustada</p>
            </div>
            <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
              resumoDivergencias.custoDivergenciaAbs === 0 
                ? 'bg-slate-50 text-slate-400' 
                : resumoDivergencias.custoDivergenciaAbs > 0 
                  ? 'bg-emerald-50 text-emerald-600' 
                  : 'bg-rose-50 text-rose-600'
            }`}>
              <DollarSign className="w-5 h-5" />
            </div>
          </div>

          {/* Card B: Volumetria em Hectolitros */}
          <div className={`p-4 rounded-xl border shadow-lux flex items-center justify-between ${
            resumoDivergencias.volumeDivergenciaHL === 0 
              ? 'bg-white border-slate-100' 
              : resumoDivergencias.volumeDivergenciaHL > 0 
                ? 'bg-emerald-50/25 border-emerald-100' 
                : 'bg-rose-50/25 border-rose-100'
          }`}>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Hectolitragem de Divergência</span>
              <h4 className={`text-base font-black font-display font-mono ${
                resumoDivergencias.volumeDivergenciaHL === 0 
                  ? 'text-slate-805' 
                  : resumoDivergencias.volumeDivergenciaHL > 0 
                    ? 'text-emerald-700' 
                    : 'text-rose-700'
              }`}>
                {resumoDivergencias.volumeDivergenciaHL > 0 ? '+' : ''}{resumoDivergencias.volumeDivergenciaHL.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 4 })} HL
              </h4>
              <p className="text-[10px] text-slate-500 font-semibold">Total de {(resumoDivergencias.volumeDivergenciaHL * 100).toLocaleString('pt-BR', { maximumFractionDigits: 2 })} litros pendentes</p>
            </div>
            <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
              resumoDivergencias.volumeDivergenciaHL === 0 
                ? 'bg-slate-50 text-slate-400' 
                : resumoDivergencias.volumeDivergenciaHL > 0 
                  ? 'bg-emerald-50 text-emerald-600' 
                  : 'bg-rose-50 text-rose-600'
            }`}>
              <Gauge className="w-5 h-5" />
            </div>
          </div>

          {/* Card C: Total de Caixas Rompidas */}
          <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-lux flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Diferença de Unidades</span>
              <h4 className="text-base font-bold font-display text-slate-800">
                {resumoDivergencias.deltaCaixasFaltantes > 0 ? `Falta ${resumoDivergencias.deltaCaixasFaltantes} cx` : ''} 
                {resumoDivergencias.deltaCaixasExcedentes > 0 ? ` / Sobra ${resumoDivergencias.deltaCaixasExcedentes} cx` : ''}
              </h4>
              <p className="text-[10px] text-slate-500">Média física real registrada no CD</p>
            </div>
            <div className="h-10 w-10 rounded-lg bg-slate-50 text-slate-500 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
        </div>
      )}

      {/* PAINEL CONSILI IA — SUGESTÕES DE RECONTAGEM E VIRADA DE DIA */}
      {showIaSuggestions ? (
        <div className="bg-gradient-to-r from-slate-50 via-slate-100/30 to-indigo-50/20 rounded-2xl border border-indigo-100 p-5 space-y-4 shadow-sm animate-fadeIn relative" id="painel-consili-ia">
          {/* Botão de Fechar */}
          <button
            type="button"
            onClick={() => setShowIaSuggestions(false)}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 hover:bg-slate-200/50 p-1.5 rounded-lg transition-all cursor-pointer"
            title="Ocultar sugestões de recontagem"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pr-6">
            <div className="flex items-start gap-2.5">
              <div className="p-2 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-md shadow-indigo-200 mt-0.5 shrink-0">
                <Sparkles className="w-5 h-5 animate-bounce" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 tracking-tight flex items-center gap-2">
                  Assistente de Auditoria Consili IA
                </h3>
                <p className="text-[11px] text-slate-500 max-w-xl">
                  Algoritmo heurístico integrado para identificar preventivamente falhas contábeis em contagens rápidas de campo. Mostra desvios com poucos dias ou flutuação contínua &gt; 2% de acurácia.
                </p>
              </div>
            </div>

            <div className="shrink-0 flex items-center gap-2">
              <button
                type="button"
                onClick={handleForceDayTurn}
                className="w-full lg:w-auto bg-white hover:bg-rose-50 border border-slate-200/80 text-rose-600 hover:text-rose-700 p-2.5 px-4 rounded-xl text-xs font-bold font-sans flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm hover:shadow-md"
              >
                <Calendar className="w-4 h-4" />
                Virar Dia Operacional (Forçar)
              </button>
            </div>
          </div>

          {sugestoesRecontagem.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1">
              {sugestoesRecontagem.slice(0, 3).map((item) => {
                const isSelected = selectedForRecount.includes(item.sku);
                return (
                  <div 
                    key={item.sku}
                    className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                      isSelected 
                        ? 'bg-indigo-50/40 border-indigo-200/80 shadow-inner' 
                        : 'bg-white border-slate-200/65 hover:border-slate-350 hover:shadow-sm'
                    }`}
                  >
                    <div className="space-y-1.5 font-sans">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-400">SKU {item.sku}</span>
                        <span className="p-0.5 px-1.5 rounded-full bg-indigo-50 text-indigo-600 border border-indigo-100 text-[8.5px] font-black uppercase tracking-wide">
                          Recomenda Recontagem
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-800 line-clamp-1">{item.descricao}</h4>
                      
                      <div className="space-y-1 text-[10px] pt-0.5">
                        <div className="flex justify-between text-slate-400">
                          <span>Acurácia SKU Atual:</span>
                          <span className="font-semibold text-slate-700">
                            {item.estoqueSistemaCaixas > 0 
                              ? `${Math.max(0, (1 - item.desvioIndividual) * 100).toFixed(1)}%` 
                              : '0%'}
                          </span>
                        </div>
                        <div className="flex justify-between text-slate-400">
                          <span>Discrepância no CD:</span>
                          <span className={`font-bold ${item.diferencaCaixas > 0 ? 'text-blue-600' : 'text-rose-600'}`}>
                            {item.diferencaCaixas > 0 ? '+' : ''}{item.diferencaCaixas} caixas
                          </span>
                        </div>
                      </div>

                      <div className="pt-1.5 flex flex-col gap-1">
                        {item.motivos.map((mot, idx) => (
                          <span key={idx} className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-100 flex items-center gap-1 w-full line-clamp-1">
                            <AlertTriangle className="w-2.5 h-2.5 shrink-0 text-amber-505" />
                            {mot}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 mt-3 flex items-center justify-between font-sans">
                      <span className="text-[9px] text-slate-400 font-sans flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        Divergência há {item.diasDivergencia} {item.diasDivergencia === 1 ? 'dia' : 'dias'}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleToggleSelectItem(item.sku)}
                        className={`text-[9.5px] font-bold py-1 px-2.5 rounded-lg transition-all cursor-pointer select-none ${
                          isSelected
                            ? 'bg-indigo-600 hover:bg-slate-900 text-white shadow'
                            : 'bg-slate-50 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 border border-slate-200/80'
                        }`}
                      >
                        {isSelected ? '✓ Selecionado' : 'Recontar SKU'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200/60 p-4 text-center">
              <span className="text-xs text-slate-500 font-sans">
                ✨ Nenhuma recomendação urgente de recontagem pela IA. Todas as divergências ativas estão controladas ou possuem impacto inferior a 2% de saúde de estoque.
              </span>
            </div>
          )}
        </div>
      ) : (
        <div className="flex flex-wrap items-center justify-between gap-3 bg-indigo-50/40 border border-indigo-100/50 rounded-xl p-3.5 px-4 font-sans animate-scaleUp">
          <span className="text-xs text-slate-500">
            💡 O painel de recomendações de recontagem Consili IA foi minimizado.
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleForceDayTurn}
              className="bg-white hover:bg-rose-50 border border-slate-200 text-rose-600 p-2 px-3.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
            >
              <Calendar className="w-3.5 h-3.5" />
              Virar Dia
            </button>
            <button
              type="button"
              onClick={() => setShowIaSuggestions(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 px-4 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Mostrar IA
            </button>
          </div>
        </div>
      )}

      {/* Seletor de Visão do Inventário */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 p-1.5 bg-slate-100 rounded-xl w-full shadow-sm" id="recon-view-tabs">
        <button
          type="button"
          onClick={() => setActiveReconView('tabela')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'tabela'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          📍 Divergências Ativas
        </button>
        <button
          type="button"
          onClick={() => setActiveReconView('todos')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'todos'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          🔍 Todos os Itens & Acuracidade
        </button>
        <button
          type="button"
          onClick={() => setActiveReconView('dashboard')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'dashboard'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          📊 Dashboard Gerencial
        </button>
        <button
          type="button"
          onClick={() => setActiveReconView('cadastro')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'cadastro'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          📋 Cadastro ERP
        </button>
        <button
          type="button"
          onClick={() => setActiveReconView('congelar')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'congelar'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          ❄️ Desvios
        </button>
        <button
          type="button"
          onClick={() => setActiveReconView('analise')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'analise'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          📈 Analisar SKU
        </button>
        <button
          type="button"
          onClick={() => setActiveReconView('historico')}
          className={`w-full py-1.5 px-3 rounded-lg font-bold text-xs text-center transition-all cursor-pointer whitespace-nowrap ${
            activeReconView === 'historico'
              ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          📜 Histórico
        </button>
      </div>

      {activeReconView === 'tabela' ? (
        <>
        {/* Painel de Valoração Geral do Estoque: Físico vs Fiscal e Diferença */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6" id="valoracao-estoque-resumo">
          {/* Card Estoque Fiscal */}
          <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-lux flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider block">Valoração Fiscal (ERP)</span>
              <span className="text-xl font-bold text-slate-700 font-mono">
                R$ {totaisValoresEstoque.fiscalTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-[9px] text-slate-400 block">Soma de todo o saldo em sistema</span>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
              <Layers className="w-5 h-5 text-slate-400" />
            </div>
          </div>

          {/* Card Estoque Físico */}
          <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-lux flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider block">Valoração Física (WMS)</span>
              <span className="text-xl font-bold text-slate-700 font-mono">
                R$ {totaisValoresEstoque.fisicoTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-[9px] text-slate-400 block">Soma de toda contagem física</span>
            </div>
            <div className="p-3 bg-indigo-50 border border-indigo-100/50 rounded-lg">
              <Activity className="w-5 h-5 text-indigo-500" />
            </div>
          </div>

          {/* Card Diferença */}
          <div className={`p-4 rounded-xl border shadow-lux flex items-center justify-between ${
            Math.abs(totaisValoresEstoque.diferenca) <= 0.001
              ? 'bg-white border-slate-100' 
              : totaisValoresEstoque.diferenca > 0 
                ? 'bg-emerald-50/20 border-emerald-100' 
                : 'bg-rose-50/20 border-rose-100'
          }`}>
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider block">Diferença de Inventário</span>
              <span className={`text-xl font-black font-mono block ${
                Math.abs(totaisValoresEstoque.diferenca) <= 0.001
                  ? 'text-slate-600' 
                  : totaisValoresEstoque.diferenca > 0 
                    ? 'text-emerald-600' 
                    : 'text-rose-600'
              }`}>
                {totaisValoresEstoque.diferenca > 0.001 ? '+' : ''}R$ {totaisValoresEstoque.diferenca.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-[9px] text-slate-400 block">
                {Math.abs(totaisValoresEstoque.diferenca) <= 0.001 
                  ? 'Estoque 100% batido' 
                  : totaisValoresEstoque.diferenca > 0 
                    ? 'Excedente financeiro (Sobra)' 
                    : 'Déficit financeiro (Falta)'}
              </span>
            </div>
            <div className={`p-3 rounded-lg border ${
              Math.abs(totaisValoresEstoque.diferenca) <= 0.001
                ? 'bg-slate-50 border-slate-105 text-slate-400' 
                : totaisValoresEstoque.diferenca > 0 
                  ? 'bg-emerald-50 border-emerald-100 text-emerald-500' 
                  : 'bg-rose-50 border-rose-100 text-rose-500'
            }`}>
              <TrendingUp className={`w-5 h-5 ${totaisValoresEstoque.diferenca < -0.001 ? 'rotate-180 duration-300' : ''}`} />
            </div>
          </div>
        </div>

        {/* 3. Tabela Principal de Divergências */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-lux overflow-hidden">
        
        {/* Barra de Filtros Internos da Tabela */}
        <div className="p-4 bg-slate-50/50 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-bold text-slate-700">Filtro Rápido</span>
            <input 
              type="text" 
              placeholder="Buscar SKU ou Descrição divergente..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white border border-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-60"
            />
          </div>

          <div className="flex gap-2 w-full sm:w-auto justify-end">
            {selectedForRecount.length > 0 && (
              <button 
                type="button" 
                onClick={exportSelectedForRecountCSV}
                className="text-xs bg-indigo-650 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer transition shadow border border-indigo-700"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Exportar Recontagem ({selectedForRecount.length})</span>
              </button>
            )}
            <button 
              type="button" 
              onClick={exportarEstoqueCSV}
              className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition shadow"
            >
              <Download className="w-3.5 h-3.5" />
              Exporte Estoque 02.05.02 (CSV)
            </button>
            <button 
              type="button" 
              onClick={exportarPerdasESobrasCSV}
              className="text-xs bg-amber-600 hover:bg-amber-700 text-white font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition shadow"
            >
              <Download className="w-3.5 h-3.5" />
              Exportar Perdas ou Sobras (CSV)
            </button>
            <button 
              type="button" 
              onClick={() => setShowAddForm(!showAddForm)}
              className="text-xs border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer"
            >
              Simular SKU Fiscal ERP
            </button>
          </div>
        </div>

        {/* Formulário Rápido de Adição para Simular Integração ERP */}
        {showAddForm && (
          <form onSubmit={handleAddProductSubmit} className="p-4 bg-indigo-50/50 border-b border-indigo-100 grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-indigo-800 block">CÓDIGO SKU:</label>
              <input 
                type="text" 
                placeholder="Ex: CERCOMP-09" 
                value={newProduct.sku}
                onChange={e => setNewProduct({...newProduct, sku: e.target.value})}
                className="bg-white border border-indigo-200 text-xs p-2 rounded w-full uppercase focus:outline-none focus:ring-1 focus:ring-indigo-500"
                required
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-indigo-800 block">DESCRIÇÃO DO ITEM:</label>
              <input 
                type="text" 
                placeholder="Ex: Cerveja IPA Lata 473ml" 
                value={newProduct.descricao}
                onChange={e => setNewProduct({...newProduct, descricao: e.target.value})}
                className="bg-white border border-indigo-200 text-xs p-2 rounded w-full focus:outline-none focus:ring-1 focus:ring-indigo-500"
                required
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-indigo-800 block">CUSTO MÉDIO (R$):</label>
              <input 
                type="number" 
                value={newProduct.cost}
                onChange={e => setNewProduct({...newProduct, cost: Number(e.target.value)})}
                className="bg-white border border-indigo-200 text-xs p-2 rounded w-full"
                min="1"
                step="0.01"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-indigo-800 block">FATOR PALLET (CX/PLT):</label>
              <input 
                type="number" 
                value={newProduct.fatorPallet}
                onChange={e => setNewProduct({...newProduct, fatorPallet: Number(e.target.value)})}
                className="bg-white border border-indigo-200 text-xs p-2 rounded w-full"
                min="1"
              />
            </div>
            <div className="flex gap-2">
              <button 
                type="submit" 
                className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold p-2 rounded flex-1 cursor-pointer"
              >
                Integrar ERP
              </button>
              <button 
                type="button" 
                onClick={() => setShowAddForm(false)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold p-2 rounded cursor-pointer"
              >
                Anular
              </button>
            </div>
          </form>
        )}

        {/* Tabela de Conciliação */}
        <div className="overflow-x-auto">
          {itensDivergentes.length > 0 ? (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-500 font-semibold bg-slate-50/70">
                  <th className="py-3 px-4 text-center w-12">
                    <input 
                      type="checkbox" 
                      className="rounded border-slate-350 text-indigo-600 focus:ring-indigo-500 cursor-pointer h-4 w-4"
                      checked={isAllSelected}
                      onChange={handleToggleSelectAll}
                      title="Selecionar / Deselecionar todos"
                    />
                  </th>
                  <th className="py-3 px-4">PRODUTO (SKU)</th>
                  <th className="py-3 px-4">CATEGORIA</th>
                  <th className="py-3 px-4">VALOR UNITÁRIO (CX)</th>
                  <th className="py-3 px-4 text-center">SALDO FISCAL</th>
                  <th className="py-3 px-4 text-center">FÍSICO REAL (CONTAGEM)</th>
                  <th className="py-3 px-4 text-center text-blue-650 bg-blue-50/50">ITENS CONGELADOS</th>
                  <th className="py-3 px-4 text-center text-indigo-700 bg-indigo-50/50 font-bold">ESTOQUE AJUSTADO</th>
                  <th className="py-3 px-4 text-center">DIFERENÇA</th>
                  <th className="py-3 px-4 text-right">DIVERGÊNCIA EM HL</th>
                  <th className="py-3 px-4 text-right">VALORAÇÃO DA DIVERGÊNCIA</th>
                  <th className="py-3 px-3 text-center text-red-700 font-bold">PERMANÊNCIA DA DIVERGÊNCIA</th>
                  <th className="py-3 px-4 text-center">AÇÕES CONFERENTE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 font-mono">
                {itensDivergentes.map((p) => {
                  const isEditing = editingSku === p.sku;
                  const isSelected = selectedForRecount.includes(p.sku);
                  
                  // Tags de cor de acordo com curva / categoria requisitadas
                  let catTagCss = "bg-emerald-50 text-emerald-700 border-emerald-100";
                  if (p.categoria === 'NAB') catTagCss = "bg-amber-50 text-amber-700 border-amber-100";
                  if (p.categoria === 'Marketplace') catTagCss = "bg-sky-50 text-sky-700 border-sky-100";

                  return (
                    <tr key={p.sku} className={`hover:bg-slate-50/50 transition-colors ${isSelected ? 'bg-indigo-50/15' : ''}`}>
                      
                      {/* Checkbox de Seleção individual */}
                      <td className="py-3 px-4 text-center">
                        <input 
                          type="checkbox" 
                          className="rounded border-slate-350 text-indigo-600 focus:ring-indigo-500 cursor-pointer h-4 w-4"
                          checked={isSelected}
                          onChange={() => handleToggleSelectItem(p.sku)}
                        />
                      </td>

                      {/* Descricao */}
                      <td className="py-3 px-4 font-sans max-w-xs">
                        <span className="font-semibold text-slate-900 block font-mono text-xs">{p.sku.replace(/^0+/, '') || '0'}</span>
                        <span className="text-[11px] text-slate-500 truncate block">{p.descricao}</span>
                      </td>

                      {/* Categoria */}
                      <td className="py-3 px-4">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase font-sans ${catTagCss}`}>
                          {p.categoria}
                        </span>
                      </td>

                      {/* Custo Médio por Caixa */}
                      <td className="py-3 px-4 text-slate-600 font-sans">
                        R$ {p.custoMedio.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Sistêmico (SALDO FISCAL) */}
                      <td className="py-3 px-4 text-center text-slate-600 font-sans">
                        {Math.round(p.estoqueSistemaCaixas)} cx
                      </td>

                      {/* Físico real (FÍSICO REAL (CONTAGEM)) */}
                      <td className="py-3 px-4 text-center">
                        {isEditing ? (
                          <div className="flex items-center justify-center gap-1">
                            <input 
                              type="number" 
                              value={editingValue}
                              onChange={(e) => setEditingValue(Number(e.target.value))}
                              className="w-16 text-center border border-indigo-400 bg-white font-mono text-xs p-1 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500"
                              min="0"
                              autoFocus
                            />
                            <button 
                              type="button"
                              onClick={() => handleEditSave(p.sku)}
                              disabled={loadingSku === p.sku}
                              className="p-1.5 bg-emerald-600 text-white rounded hover:bg-emerald-700 transition"
                              title="Salvar contagem física"
                            >
                              <Check className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5 font-bold text-slate-800 text-sm">
                            <span className="bg-slate-100 px-2.5 py-0.5 rounded border border-slate-200">
                              {p.estoqueFisicoCaixas}
                            </span>
                            <span className="text-[10px] text-slate-400 font-normal">cx</span>
                          </div>
                        )}
                      </td>

                      {/* Itens Congelados */}
                      <td className="py-3 px-4 text-center bg-blue-50/15 font-mono">
                        {(() => {
                          const frozenQty = (divergenciasCongeladas || [])
                            .filter((d: any) => d.sku === p.sku)
                            .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);
                          return (
                            <span className={`font-bold px-2 py-0.5 rounded text-xs ${frozenQty !== 0 ? 'bg-blue-100 text-blue-700' : 'text-slate-400'}`}>
                              {frozenQty !== 0 ? `+${frozenQty.toFixed(2)} cx` : '0 cx'}
                            </span>
                          );
                        })()}
                      </td>

                      {/* Estoque Ajustado */}
                      <td className="py-3 px-4 text-center bg-indigo-50/15 font-mono">
                        {(() => {
                          const frozenQty = (divergenciasCongeladas || [])
                            .filter((d: any) => d.sku === p.sku)
                            .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);
                          const adjEstoque = Math.max(0, p.estoqueFisicoCaixas + frozenQty);
                          return (
                            <span className="font-extrabold text-indigo-700 text-xs">
                              {adjEstoque % 1 !== 0 ? adjEstoque.toFixed(2) : adjEstoque} cx
                            </span>
                          );
                        })()}
                      </td>

                      {/* Diferença */}
                      <td className="py-3 px-4 text-center">
                        <span className={`font-bold px-2 py-0.5 rounded text-xs ${p.diferencaCaixas < 0 ? 'text-rose-700 bg-rose-50' : 'text-emerald-700 bg-emerald-50'}`}>
                          {p.diferencaCaixas > 0 ? '+' : ''}{p.diferencaCaixas % 1 !== 0 ? p.diferencaCaixas.toFixed(2) : p.diferencaCaixas} cx
                        </span>
                      </td>

                      {/* Hectolitros */}
                      <td className="py-3 px-4 text-right font-sans">
                        <span className="text-slate-600 font-mono text-xs">
                          {p.divergenciaHectolitro > 0 ? '+' : ''}{formatHectolitro(p.divergenciaHectolitro)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold ml-1 font-sans">HL</span>
                      </td>

                      {/* Valoração da divergência */}
                      <td className={`py-3 px-4 text-right font-bold ${p.divergenciaValor < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {p.divergenciaValor > 0 ? '+' : ''}
                        R$ {p.divergenciaValor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Tempo de Permanência da Divergência */}
                      <td className="py-3 px-3 text-center font-sans">
                        {(() => {
                          const dif = p.diferencaCaixas;
                          if (Math.abs(dif) <= 0.001) {
                            return <span className="text-slate-400 font-mono text-xs">-</span>;
                          }
                          
                          // Verifica se já está nas divergências congeladas
                          const itemCongelado = (divergenciasCongeladas || []).find((d: any) => d.sku === p.sku);
                          if (itemCongelado && itemCongelado.dataCongelamento) {
                            const dataCong = new Date(itemCongelado.dataCongelamento);
                            const dataAtual = new Date();
                            const diffTime = Math.max(0, dataAtual.getTime() - dataCong.getTime());
                            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                            return (
                              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded text-[11px] font-bold font-mono">
                                ⏳ {diffDays > 0 ? `${diffDays} dias` : "1 dia"}
                              </span>
                            );
                          }
                          
                          // Verifica se já esteve em conciliações anteriores
                          const concAnterior = (historicoConciliacoes || [])
                            .filter((c: any) => c.itensDivergentes && c.itensDivergentes.some((it: any) => it.sku === p.sku))
                            .sort((a: any, b: any) => new Date(a.data).getTime() - new Date(b.data).getTime())[0];
                            
                          if (concAnterior) {
                            const dataPrimeira = new Date(concAnterior.data);
                            const dataAtual = new Date();
                            const diffTime = Math.max(0, dataAtual.getTime() - dataPrimeira.getTime());
                            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                            return (
                              <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-800 border border-rose-250 px-2 py-0.5 rounded text-[11px] font-bold font-mono">
                                🚨 {diffDays > 0 ? `${diffDays} dias` : "2 dias"}
                              </span>
                            );
                          }
                          
                          // Padrão recente para novas divergências detectadas no CD
                          return (
                            <span className="inline-flex items-center gap-1 bg-slate-50 text-slate-705 border border-slate-200 px-2 py-0.5 rounded text-[11px] font-medium font-mono">
                              🆕 Recente (2 dias)
                            </span>
                          );
                        })()}
                      </td>

                      {/* Ações in-line */}
                      <td className="py-3 px-4 text-center font-sans">
                        {isEditing ? (
                          <button 
                            type="button"
                            onClick={() => setEditingSku(null)}
                            className="text-xs text-slate-500 hover:underline font-semibold cursor-pointer"
                          >
                            Anular
                          </button>
                        ) : (
                          <button 
                            type="button"
                            onClick={() => handleEditStart(p.sku, p.estoqueFisicoCaixas)}
                            className="text-indigo-600 hover:text-slate-900 flex items-center gap-1 mx-auto border border-indigo-100 hover:border-slate-300 bg-indigo-50/50 p-1 px-2.5 rounded-lg text-[10px] font-bold transition cursor-pointer"
                          >
                            <Edit2 className="w-3 h-3" /> Recontar no CD
                          </button>
                        )}
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="p-10 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <div className="space-y-1">
                <h4 className="font-bold font-display text-slate-900 text-sm">Nenhuma divergência operacional estocada</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Excelente trabalho! O estoque de todos os SKUs confere exatamente com as diretrizes do sistema.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Tabela de Recontagem Física de Campo (Visualização prévia do CD - Requisito: GERE A TABELA DE RECONTAGEM DESTA FORMA) */}
      {selectedForRecount.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4 animate-scaleUp mt-6" id="ficha-recontagem-quadro">
          <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-100 pb-3 gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                📋 Ficha de Campo para Recontagem Física (Formatado para Impressão)
              </h3>
              <p className="text-[10px] text-slate-500">
                Esta tabela está gerada de acordo com o padrão físico de CD solicitado. Use o botão para imprimir ou copiar.
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={() => {
                  const items = produtos.filter(p => selectedForRecount.includes(p.sku));
                  const text = [
                    "CÓDIGO\tDESCRIÇÃO\tQUANTIDADE DE RECONTAGENS",
                    ...items.map(p => {
                      const vezesRecontado = 1 + (historicoConciliacoes || []).filter((c: any) => (c.itensDivergentes || []).some((it: any) => it.sku === p.sku)).length;
                      return `${p.sku.replace(/^0+/, '') || '0'}\t${p.descricao.replace(/;/g, ' ').toUpperCase()}\t${vezesRecontado}`;
                    })
                  ].join("\n");
                  navigator.clipboard.writeText(text);
                  alert("Tabela de recontagem copiada com sucesso para a área de transferência!");
                }}
                className="text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 flex items-center gap-1.5 transition cursor-pointer"
              >
                📋 Copiar Tabela
              </button>
              
              <button
                type="button"
                onClick={() => {
                  const printWindow = window.open('', '_blank');
                  if (!printWindow) return;
                  const items = produtos.filter(p => selectedForRecount.includes(p.sku));
                  const rows = items.map(p => {
                    const vezesRecontado = 1 + (historicoConciliacoes || []).filter((c: any) => (c.itensDivergentes || []).some((it: any) => it.sku === p.sku)).length;
                    return `
                    <tr>
                      <td style="border: 2px solid black; padding: 12px; font-family: monospace; font-size: 14px; font-weight: bold; text-align: center; width: 120px;">
                        ${p.sku.replace(/^0+/, '') || '0'}
                      </td>
                      <td style="border: 2px solid black; padding: 12px; font-family: sans-serif; font-size: 14px; font-weight: bold; text-align: left;">
                        ${p.descricao.replace(/;/g, ' ').toUpperCase()}
                      </td>
                      <td style="border: 2px solid black; padding: 12px; font-family: monospace; font-size: 16px; font-weight: bold; text-align: center; width: 180px;">
                        ${vezesRecontado}
                      </td>
                    </tr>
                    `;
                  }).join("");
                  
                  printWindow.document.write(`
                    <html>
                    <head>
                      <title>FICHA DE RECONTAGEM - CD</title>
                      <style>
                        body { font-family: 'Inter', sans-serif; padding: 30px; text-align: center; }
                        table { width: 100%; border-collapse: collapse; border: 3px solid black; margin-top: 25px; }
                        th { background-color: black; color: white !important; font-size: 14px; font-weight: bold; padding: 12px; border: 2px solid black; text-transform: uppercase; text-align: center; letter-spacing: 0.5px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                        h1 { font-size: 22px; text-transform: uppercase; margin-bottom: 5px; }
                        p { font-size: 12px; color: #666; margin: 0; }
                      </style>
                    </head>
                    <body onload="window.print(); window.close();">
                      <h1>Ficha de Recontagem para Operadores de Campo</h1>
                      <p>WMS Inteligente Consili | CD Distribuído | Data: ${new Date().toLocaleString('pt-BR')} | Operador: ${operatorEmail}</p>
                      <table>
                        <thead>
                          <tr>
                            <th style="border: 2px solid black; background-color: black; color: white; padding: 12px; width: 120px;">CÓDIGO (SKU)</th>
                            <th style="border: 2px solid black; background-color: black; color: white; padding: 12px; text-align: left;">DESCRIÇÃO DO PRODUTO</th>
                            <th style="border: 2px solid black; background-color: black; color: white; padding: 12px; width: 180px;">VEZES RECONTADO</th>
                          </tr>
                        </thead>
                        <tbody>
                          ${rows}
                        </tbody>
                      </table>
                    </body>
                    </html>
                  `);
                  printWindow.document.close();
                }}
                className="text-[11px] font-bold bg-neutral-900 hover:bg-neutral-850 text-white px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer"
              >
                🖨️ Imprimir Ficha de Recontagem PDF
              </button>
            </div>
          </div>

          <div className="overflow-x-auto border-2 border-neutral-800 rounded-xl p-4 bg-white max-w-4xl mx-auto shadow-sm">
            <table className="w-full border-collapse border-4 border-black font-sans text-xs">
              <thead>
                <tr className="bg-black text-white" style={{ backgroundColor: 'black', color: 'white' }}>
                  <th className="border-2 border-black py-3 px-4 font-extrabold text-center uppercase tracking-wider w-1/6">
                    CÓDIGO
                  </th>
                  <th className="border-2 border-black py-3 px-4 font-extrabold text-left uppercase tracking-wider w-4/6">
                    DESCRIÇÃO
                  </th>
                  <th className="border-2 border-black py-3 px-4 font-extrabold text-center uppercase tracking-wider w-1/6">
                    VEZES RECONTADO
                  </th>
                </tr>
              </thead>
              <tbody>
                {produtos.filter(p => selectedForRecount.includes(p.sku)).map((p) => {
                  const vezesRecontado = 1 + (historicoConciliacoes || []).filter((c: any) => (c.itensDivergentes || []).some((it: any) => it.sku === p.sku)).length;
                  return (
                    <tr key={`vis-print-${p.sku}`} className="bg-white hover:bg-neutral-50 transition font-bold border-b border-black text-xs text-neutral-900">
                      <td className="border-2 border-black py-3.5 px-4 text-center font-mono font-black text-sm">
                        {p.sku.replace(/^0+/, '') || '0'}
                      </td>
                      <td className="border-2 border-black py-3.5 px-4 text-left uppercase tracking-wide">
                        {p.descricao.replace(/;/g, ' ').toUpperCase()}
                      </td>
                      <td className="border-2 border-black py-3.5 px-4 text-center font-mono text-base text-neutral-800">
                        {vezesRecontado}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      </>
      ) : activeReconView === 'todos' ? (
        /* Nova Guia: visualização de todos os itens cadastrados no CD com indicadores de acuracidade */
        <div className="space-y-6 animate-fadeIn" id="todos-itens-recon-container">
          <div className="bg-gradient-to-r from-slate-50 to-indigo-50/20 border border-slate-200/60 rounded-2xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-800 font-display flex items-center gap-2">
              🔍 Inventário Geral e Compliance de Acuracidade WMS
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Visão consolidada de todos os SKUs de estoque do centro de distribuição, incluindo itens batidos (OK), sobras operacionais e faltas fiscais com cálculo de acuracidade.
            </p>
          </div>

          {/* KPIs da nova guia */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Acuracidade de Inventário</span>
                <span className="text-2xl font-black text-indigo-700 font-mono mt-1 block">
                  {acuracidadeMedia.toFixed(1)}%
                </span>
              </div>
              <span className="text-[9px] text-slate-400 mt-2 block">Cálculo simétrico min/max de caixas</span>
            </div>
            
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">SKUs sem Divergência (OK)</span>
                <span className="text-2xl font-black text-emerald-600 font-mono mt-1 block">
                  {produtos.filter(p => Math.abs(p.diferencaCaixas) <= 0.001).length} SKUs
                </span>
              </div>
              <span className="text-[9px] text-slate-400 mt-2 block">
                {conformidadeItens.toFixed(1)}% dos SKUs batidos ou compensados
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total de Sobras</span>
                <span className="text-2xl font-black text-blue-600 font-mono mt-1 block">
                  {produtos.filter(p => p.diferencaCaixas > 0.001).length} SKUs
                </span>
              </div>
              <span className="text-[9px] text-slate-400 mt-2 block">Excedente em contagem física</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total de Faltas</span>
                <span className="text-2xl font-black text-rose-600 font-mono mt-1 block">
                  {produtos.filter(p => p.diferencaCaixas < -0.001).length} SKUs
                </span>
              </div>
              <span className="text-[9px] text-slate-400 mt-2 block">Déficit físico frente ao sistema</span>
            </div>
          </div>

          {/* Painel da Tabela Completa */}
          <div className="bg-white border border-slate-100 shadow-lux rounded-2xl overflow-hidden">
            {/* Barra de pesquisa superior e filtros rápidos por status */}
            <div className="p-4 bg-slate-50/50 border-b border-slate-100 flex flex-col xl:flex-row items-center justify-between gap-4">
              <div className="flex flex-col sm:flex-row items-center gap-3 w-full xl:w-auto">
                <div className="flex items-center gap-2 w-full sm:w-auto relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input 
                    type="text" 
                    placeholder="Pesquisar SKU ou Descrição..." 
                    value={searchTodosQuery}
                    onChange={(e) => setSearchTodosQuery(e.target.value)}
                    className="bg-white border border-slate-200 text-xs pl-9 pr-3 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-64 font-sans"
                  />
                </div>

                {/* Abas Rápidas de Filtragem por Tipo de Divergência */}
                <div className="flex bg-slate-200/50 p-1 rounded-xl gap-1 w-full sm:w-auto justify-start border border-slate-200/40 font-sans">
                  <button
                    type="button"
                    onClick={() => setFilterTodosStatus('todos')}
                    className={`text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${filterTodosStatus === 'todos' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                  >
                    Todos ({produtos.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterTodosStatus('sobra')}
                    className={`text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${filterTodosStatus === 'sobra' ? 'bg-blue-600 text-white shadow-sm' : 'text-blue-600 hover:bg-blue-50/50'}`}
                  >
                    Sobras ({produtos.filter(p => p.diferencaCaixas > 0.001).length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterTodosStatus('falta')}
                    className={`text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${filterTodosStatus === 'falta' ? 'bg-rose-600 text-white shadow-sm' : 'text-rose-600 hover:bg-rose-50/50'}`}
                  >
                    Faltas ({produtos.filter(p => p.diferencaCaixas < -0.001).length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterTodosStatus('ok')}
                    className={`text-[10px] font-bold px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${filterTodosStatus === 'ok' ? 'bg-emerald-600 text-white shadow-sm' : 'text-emerald-600 hover:bg-emerald-55/50'}`}
                  >
                    OK ({produtos.filter(p => Math.abs(p.diferencaCaixas) <= 0.001).length})
                  </button>
                </div>
              </div>

              <div className="text-[11px] font-semibold text-slate-400 font-sans w-full xl:w-auto text-left xl:text-right">
                Mostrando {todosOsItensFiltrados.length} de {produtos.length} produtos cadastrados no CD
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/70 border-b border-slate-100 text-slate-400 uppercase text-[9px] font-black tracking-wider">
                    <th className="py-3 px-4">CÓD / PRODUTO</th>
                    <th className="py-3 px-4">CATEGORIA</th>
                    <th className="py-3 px-4 text-center">SALDO FISCAL</th>
                    <th className="py-3 px-4 text-center">FÍSICO REAL</th>
                    <th className="py-3 px-4 text-center text-blue-600 bg-blue-50/40">CONGELADO</th>
                    <th className="py-3 px-4 text-center text-indigo-700 bg-indigo-50/40 font-bold">EST. AJUSTADO</th>
                    <th className="py-3 px-4 text-center font-sans">DIFERENÇA</th>
                    <th className="py-3 px-4 text-center">SITUAÇÃO</th>
                    <th className="py-3 px-4 text-center font-sans">ACURACIDADE</th>
                    <th className="py-3 px-4 text-center">AÇÕES</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 font-mono text-xs">
                  {todosOsItensFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-10 text-center text-slate-400 font-sans">
                        Nenhum produto condizente com a pesquisa foi localizado.
                      </td>
                    </tr>
                  ) : (
                    todosOsItensFiltrados.map((p) => {
                      const fis = Math.floor(p.estoqueFisicoCaixas);
                      const sis = Math.floor(p.estoqueSistemaCaixas);
                      const dif = p.diferencaCaixas;
                      
                      let situacao = "OK";
                      let situacaoColor = "bg-emerald-50 text-emerald-700 border-emerald-100";
                      
                      if (dif > 0.001) {
                        situacao = "SOBRA";
                        situacaoColor = "bg-blue-50 text-blue-700 border-blue-105";
                      } else if (dif < -0.001) {
                        situacao = "FALTA";
                        situacaoColor = "bg-rose-50 text-rose-700 border-rose-105";
                      }

                      // Cálculo local de acuracidade ajustada por congelamento
                      let indAcc = 100;
                      const maxVal = Math.max(fis, sis);
                      if (maxVal > 0) {
                        indAcc = Math.min(100, Math.max(0, 100 - (Math.abs(dif) / maxVal) * 100));
                      }

                      let accBarClass = "bg-emerald-500";
                      let accTextClass = "text-emerald-700";
                      
                      if (indAcc < 90) {
                        accBarClass = "bg-rose-500";
                        accTextClass = "text-rose-700";
                      } else if (indAcc < 100) {
                        accBarClass = "bg-amber-500";
                        accTextClass = "text-amber-700";
                      }

                      const isInlineEditing = editingSku === p.sku;

                      return (
                        <tr key={`todos-row-${p.sku}`} className="hover:bg-slate-50/45 transition">
                          <td className="py-3 px-4 font-sans">
                            <span className="font-mono text-xs font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded leading-none shrink-0 inline-block mb-1">
                              {p.sku.replace(/^0+/, '') || '0'}
                            </span>
                            <span className="text-xs text-slate-650 block font-semibold truncate max-w-[280px]" title={p.descricao}>
                              {p.descricao}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-sans text-[10px] font-bold text-slate-400 uppercase">
                            {p.categoria}
                          </td>
                          <td className="py-3 px-4 text-center font-bold text-slate-600">
                            {sis} <span className="text-[9px] text-slate-400 font-sans">cx</span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            {isInlineEditing ? (
                              <div className="flex items-center justify-center gap-1">
                                <input 
                                  type="number" 
                                  value={editingValue}
                                  onChange={(e) => setEditingValue(Math.floor(Number(e.target.value)))}
                                  className="w-16 text-center border-2 border-indigo-400 bg-white font-mono text-xs p-1 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500"
                                  min="0"
                                  autoFocus
                                />
                                <button 
                                  type="button"
                                  onClick={() => handleEditSave(p.sku)}
                                  disabled={loadingSku === p.sku}
                                  className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-center gap-1">
                                <span className="font-bold text-slate-800">{fis}</span>
                                <span className="text-[9px] text-slate-400 font-sans">cx</span>
                              </div>
                            )}
                          </td>
                          
                          {/* CONGELADO */}
                          <td className="py-3 px-4 text-center bg-blue-50/15">
                            {(() => {
                              const frozenQty = (divergenciasCongeladas || [])
                                .filter((d: any) => d.sku === p.sku)
                                .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);
                              return (
                                <span className={`font-bold px-1.5 py-0.5 rounded text-xs ${frozenQty !== 0 ? 'bg-blue-105/70 text-blue-700' : 'text-slate-400'}`}>
                                  {frozenQty !== 0 ? `+${frozenQty} cx` : '0 cx'}
                                </span>
                              );
                            })()}
                          </td>

                          {/* EST. AJUSTADO */}
                          <td className="py-3 px-4 text-center bg-indigo-50/15 font-bold text-indigo-700">
                            {(() => {
                              const frozenQty = (divergenciasCongeladas || [])
                                .filter((d: any) => d.sku === p.sku)
                                .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);
                              return (
                                <span>{Math.max(0, fis + frozenQty)} cx</span>
                              );
                            })()}
                          </td>

                          <td className="py-3 px-4 text-center font-bold">
                            {Math.abs(dif) <= 0.001 ? (
                              <div className="flex flex-col items-center justify-center gap-0.5">
                                <span className="text-slate-400">---</span>
                                {divergenciasCongeladas.some(d => d.sku === p.sku) && (
                                  <span className="text-[8px] bg-blue-50 text-blue-600 border border-blue-100/70 rounded px-1.5 py-0.5 font-sans font-bold flex items-center gap-0.5 animate-fadeIn" title="Divergência totalmente compensada e congelada como Desvio">
                                    ❄️ Compensado
                                  </span>
                                )}
                              </div>
                            ) : (
                              <div className="flex flex-col items-center justify-center gap-0.5">
                                <span className={dif > 0 ? "text-blue-600" : "text-rose-600"}>
                                  {dif > 0 ? "+" : ""}{dif % 1 !== 0 ? dif.toFixed(2) : dif} cx
                                </span>
                                {divergenciasCongeladas.some(d => d.sku === p.sku) && (
                                  <span className="text-[8px] bg-sky-50 text-sky-600 border border-sky-100 rounded px-1.5 py-0.5 font-sans font-semibold animate-fadeIn" title="Divergência parcialmente compensada e congelada como Desvio">
                                    ❄️ Ajustado
                                  </span>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className={`text-[9px] font-extrabold px-2.5 py-0.5 rounded-full border uppercase tracking-wide inline-block ${situacaoColor}`}>
                              {situacao}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-1 flex-col">
                              <span className={`font-black text-xs ${accTextClass}`}>{indAcc.toFixed(1)}%</span>
                              <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div className={`${accBarClass} h-full rounded-full`} style={{ width: `${indAcc}%` }} />
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-center">
                            {isInlineEditing ? (
                              <button 
                                type="button"
                                onClick={() => setEditingSku(null)}
                                className="text-[10px] text-slate-400 hover:underline font-bold"
                              >
                                Cancelar
                              </button>
                            ) : (
                              <button 
                                type="button"
                                onClick={() => handleEditStart(p.sku, p.estoqueFisicoCaixas)}
                                className="text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 px-2 py-1 rounded-lg text-[10px] font-bold transition"
                              >
                                Recontar
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : activeReconView === 'dashboard' ? (
        /* Dashboard Gerencial de Impacto (Maiores Sobras e Faltas - Top 20) */
        <div className="space-y-6 animate-fadeIn" id="dashboard-recon-container">
          {/* Header do Dashboard com Indicador Geral */}
          <div className="bg-gradient-to-r from-indigo-50/50 to-slate-50 border border-slate-200/60 rounded-2xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-850 font-display flex items-center gap-2">
              📊 Volatilidade de Impacto e Auditoria Geral de Divergências
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Este painel calcula a pegada financeira absoluta de todas as divergências no estoque do CD. 
              Ao todo, temos <strong className="text-slate-800">R$ {totalAbsDivergenciaValor.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</strong> em circulação divergente pura (volatilidade absoluta de perdas e ganhos combinados).
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 mt-4">
              <div className="bg-white p-3.5 rounded-xl border border-slate-100 flex flex-col justify-between">
                <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider">Itens com Sobra Física</span>
                <span className="text-lg font-extrabold text-emerald-600 font-mono mt-1">
                  +{produtos.filter(p => p.diferencaCaixas > 0).length} SKUs
                </span>
                <span className="text-[10px] text-slate-400 mt-1">Acúmulo de estoque não faturado</span>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-slate-100 flex flex-col justify-between">
                <span className="text-[10px] text-slate-400 font-bold uppercase block tracking-wider">Itens com Falta Física</span>
                <span className="text-lg font-extrabold text-rose-600 font-mono mt-1">
                  {produtos.filter(p => p.diferencaCaixas < 0).length} SKUs
                </span>
                <span className="text-[10px] text-slate-400 mt-1">Perdas, avarias ou furos de picking</span>
              </div>
              <div className="bg-blue-50/40 p-3.5 rounded-xl border border-blue-100 flex flex-col justify-between">
                <span className="text-[10px] text-blue-700 font-bold uppercase block tracking-wider font-sans">Total de Itens Congelados</span>
                <span className="text-lg font-extrabold text-blue-700 font-mono mt-1">
                  {divergenciasCongeladas.length} SKUs ({resumoCongelados.totalCaixasBloqueadas.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} cx)
                </span>
                <span className="text-[10px] text-slate-400 mt-1">Volume de desvios e perdas compensadas</span>
              </div>
              <div className="bg-[#ecfeff] p-3.5 rounded-xl border border-cyan-155 flex flex-col justify-between">
                <span className="text-[10px] text-cyan-850 font-bold uppercase block tracking-wider font-sans">Vol. Hecto Congelado</span>
                <span className="text-lg font-extrabold text-cyan-700 font-mono mt-1">
                  {resumoCongelados.volumeAbsolutoHL.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 4 })} HL
                </span>
                <span className="text-[10px] text-cyan-600/80 mt-1">Litragem suspensa em auditoria</span>
              </div>
              <div className="bg-indigo-50/30 p-3.5 rounded-xl border border-indigo-100/50 flex flex-col justify-between">
                <span className="text-[10px] text-indigo-700 font-bold uppercase block tracking-wider">Net Impact (Resultado Geral)</span>
                {(() => {
                  const valorNet = produtos.reduce((acc, p) => acc + (p.divergenciaValor || 0), 0);
                  return (
                    <span className={`text-lg font-extrabold font-mono mt-1 ${valorNet >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {valorNet >= 0 ? '+' : ''}R$ {valorNet.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </span>
                  );
                })()}
                <span className="text-[10px] text-slate-500 mt-1">Ajuste de caixa consolidado para ERP</span>
              </div>
            </div>
          </div>

          {/* Duas Colunas do Dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Coluna Esquerda: 20 Maiores Sobras */}
            <div className="bg-white rounded-2xl border border-emerald-100 shadow-sm overflow-hidden flex flex-col">
              <div className="p-4 bg-emerald-500/10 border-b border-emerald-100/55 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 block animate-pulse" />
                  <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">📈 As 20 Maiores Sobras (Saldos Maiores)</h4>
                </div>
                <span className="text-[10px] font-extrabold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full uppercase">Superávit</span>
              </div>

              <div className="p-4 flex-1 space-y-3 max-h-[600px] overflow-y-auto">
                {top20Sobras.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-10">Nenhum produto com excedente físico registrado.</p>
                ) : (
                  top20Sobras.map((p, idx) => {
                    const impactPct = totalAbsDivergenciaValor > 0 ? (Math.abs(p.divergenciaValor) / totalAbsDivergenciaValor) * 100 : 0;
                    return (
                      <div key={`sobra-dash-${p.sku}-${idx}`} className="bg-slate-50/55 p-3 rounded-xl border border-slate-100 flex flex-col gap-2 hover:border-emerald-300 transition-all">
                        <div className="flex justify-between items-start gap-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-mono text-[10px] font-black text-slate-700 bg-slate-200/50 px-1.5 py-0.2 rounded">{p.sku.replace(/^0+/, '') || '0'}</span>
                              <span className="text-[9px] uppercase font-bold text-slate-400 font-sans">{p.categoria}</span>
                            </div>
                            <p className="text-xs font-semibold text-slate-700 font-sans mt-1 truncate max-w-[200px] sm:max-w-[280px]" title={p.descricao}>{p.descricao}</p>
                            {(() => {
                              const frozenQty = (divergenciasCongeladas || [])
                                .filter((d: any) => d.sku === p.sku)
                                .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);
                              if (frozenQty !== 0) {
                                return (
                                  <span className="text-[9px] bg-blue-50 text-blue-700 border border-blue-100 rounded px-1.5 py-0.2 mt-1 inline-block font-sans font-bold">
                                    ❄️ Congelado: +{frozenQty} cx | Est. Ajustado: {Math.max(0, p.estoqueFisicoCaixas + frozenQty)} cx
                                  </span>
                                );
                              }
                              return null;
                            })()}
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-xs font-mono font-bold text-emerald-600 block">+{p.diferencaCaixas} cx</span>
                            <span className="text-[10px] font-sans font-semibold text-slate-500 block">R$ {p.divergenciaValor.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
                          </div>
                        </div>

                        {/* Barra de Progresso do Impacto */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[9px] font-semibold text-slate-400">
                            <span>Participação no Impacto Total</span>
                            <span className="font-mono text-emerald-600 font-bold">{impactPct.toFixed(1)}%</span>
                          </div>
                          <div className="w-full bg-slate-155 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-emerald-500 h-full rounded-full transition-all" style={{ width: `${Math.min(impactPct, 100)}%` }} />
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Coluna Direita: 20 Maiores Faltas */}
            <div className="bg-white rounded-2xl border border-rose-100 shadow-sm overflow-hidden flex flex-col">
              <div className="p-4 bg-rose-500/10 border-b border-rose-100/55 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-500 block animate-pulse" />
                  <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">📉 As 20 Maiores Faltas (Quebras/Furos)</h4>
                </div>
                <span className="text-[10px] font-extrabold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full uppercase font-sans">Déficit</span>
              </div>

              <div className="p-4 flex-1 space-y-3 max-h-[600px] overflow-y-auto">
                {top20Faltas.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-10">Nenhum produto com déficit físico registrado.</p>
                ) : (
                  top20Faltas.map((p, idx) => {
                    const impactPct = totalAbsDivergenciaValor > 0 ? (Math.abs(p.divergenciaValor) / totalAbsDivergenciaValor) * 100 : 0;
                    return (
                      <div key={`falta-dash-${p.sku}-${idx}`} className="bg-slate-50/55 p-3 rounded-xl border border-slate-100 flex flex-col gap-2 hover:border-rose-300 transition-all">
                        <div className="flex justify-between items-start gap-2">
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-mono text-[10px] font-black text-slate-700 bg-slate-200/50 px-1.5 py-0.2 rounded">{p.sku.replace(/^0+/, '') || '0'}</span>
                              <span className="text-[9px] uppercase font-bold text-slate-400 font-sans">{p.categoria}</span>
                            </div>
                            <p className="text-xs font-semibold text-slate-700 font-sans mt-1 truncate max-w-[200px] sm:max-w-[280px]" title={p.descricao}>{p.descricao}</p>
                            {(() => {
                              const frozenQty = (divergenciasCongeladas || [])
                                .filter((d: any) => d.sku === p.sku)
                                .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);
                              if (frozenQty !== 0) {
                                return (
                                  <span className="text-[9px] bg-blue-50 text-blue-700 border border-blue-100 rounded px-1.5 py-0.2 mt-1 inline-block font-sans font-bold">
                                    ❄️ Congelado: +{frozenQty} cx | Est. Ajustado: {Math.max(0, p.estoqueFisicoCaixas + frozenQty)} cx
                                  </span>
                                );
                              }
                              return null;
                            })()}
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-xs font-mono font-bold text-rose-600 block">{p.diferencaCaixas} cx</span>
                            <span className="text-[10px] font-sans font-semibold text-slate-500 block">R$ {p.divergenciaValor.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span>
                          </div>
                        </div>

                        {/* Barra de Progresso do Impacto */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[9px] font-semibold text-slate-400">
                            <span>Participação no Impacto Total</span>
                            <span className="font-mono text-rose-600 font-bold">{impactPct.toFixed(1)}%</span>
                          </div>
                          <div className="w-full bg-slate-155 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-rose-500 h-full rounded-full transition-all" style={{ width: `${Math.min(impactPct, 100)}%` }} />
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>
        </div>
      ) : activeReconView === 'cadastro' ? (
        /* Novo Módulo de Cadastro de Produtos & Importador de Catálogo de Itens */
        <div className="space-y-6 animate-fadeIn" id="cadastro-produtos-container">
          {/* Header da Seção */}
          <div className="bg-gradient-to-r from-teal-50/60 to-indigo-50/20 border border-slate-205 rounded-2xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-800 font-display flex items-center gap-2">
              📋 Cadastro de Novos SKUs & Importação de Catálogos Fiscais Ambev
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Adicione novos produtos individualmente ao banco de dados ou importe planilhas de cadastro de produtos da Ambev completas contendo SKU, descrição, custo por SKU, hectolitros e fatores pallet/SKU originais.
            </p>
          </div>

          {/* Feedback Success/Error Banners */}
          {cadastroSuccess && (
            <div className="p-4 bg-emerald-50/40 border border-emerald-200 rounded-xl flex items-start gap-3 text-emerald-800">
              <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-bold">Produto(s) integrado(s) com sucesso!</p>
                <p className="text-[10px] text-emerald-600 mt-0.5">Os dados foram atualizados e sincronizados no ERP mestre e no painel de contagem física com sucesso.</p>
              </div>
            </div>
          )}

          {cadastroError && (
            <div className="p-4 bg-rose-50/40 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-800">
              <AlertTriangle className="w-4.5 h-4.5 text-rose-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-bold">Atenção: Houve um problema</p>
                <p className="text-[10px] text-rose-600 mt-0.5">{cadastroError}</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Col 1: Formulário Manual */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-lux p-5 space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-indigo-500" />
                  Cadastro Unitário de SKU (Manual)
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5">Defina todos os parâmetros operacionais de um item novo de estoque</p>
              </div>

              <form onSubmit={handleManualCadastroSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600 uppercase">SKU (Código do Produto)</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: 347 ou 20498"
                      value={manualSku}
                      onChange={(e) => setManualSku(e.target.value.replace(/\D/g, ''))}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2.5 rounded-xl font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600 uppercase">Grupo / Categoria</label>
                    <select
                      value={manualCategoria}
                      onChange={(e) => setManualCategoria(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2.5 rounded-xl font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="CERVEJA">🍺 CERVEJA</option>
                      <option value="NAB">🥤 NAB (Não Alcoólicos)</option>
                      <option value="MATCH">🧉 MATCH (Beats/Drinks)</option>
                      <option value="MARKETPLACE">📦 MARKETPLACE / OUTROS</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-600 uppercase">Descrição Completa</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ex: SUKITA PET 1L CAIXA C/12"
                    value={manualDesc}
                    onChange={(e) => setManualDesc(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-xs p-2.5 rounded-xl font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-600 uppercase">Custo (R$)</label>
                    <input 
                      type="number" 
                      step="0.01"
                      required
                      value={manualCusto}
                      onChange={(e) => setManualCusto(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-600 uppercase">Fator Pallet</label>
                    <input 
                      type="number" 
                      required
                      value={manualFatorPallet}
                      onChange={(e) => setManualFatorPallet(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-600 uppercase">Fator SKU (Uds)</label>
                    <input 
                      type="number" 
                      required
                      value={manualFatorSku}
                      onChange={(e) => setManualFatorSku(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-600 uppercase">Fator Hecto (HL)</label>
                    <input 
                      type="number" 
                      step="0.0001"
                      required
                      value={manualFatorHecto}
                      onChange={(e) => setManualFatorHecto(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-600 uppercase">UM (Unid. Medida)</label>
                    <select
                      value={manualUm}
                      onChange={(e) => setManualUm(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-xs p-2 rounded-lg font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="CX">CX</option>
                      <option value="UN">UN</option>
                      <option value="LT">LT</option>
                      <option value="KG">KG</option>
                      <option value="PLT">PLT</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Cadastrar SKU no ERP & WMS
                </button>
              </form>
            </div>

            {/* Col 2: Importador CSV */}
            <div className="bg-white rounded-2xl border border-slate-100 shadow-lux p-5 space-y-4">
              <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
                <div>
                  <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                    Cadastro de Produto por Documento
                  </h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">Arraste a planilha de cadastro para atualizar o catálogo em lote</p>
                </div>
              </div>

              {/* Box explicativa do Formato do Documento */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-150 text-[10px] text-slate-500 font-sans leading-relaxed">
                <span className="font-bold text-slate-700 uppercase block mb-1">Formato de Documento Esperado (Excel / CSV Semicolons):</span>
                <code className="block bg-slate-200/50 p-1.5 rounded font-mono text-[9px] break-all overflow-x-auto text-slate-800">
                  GRUPO;CÓDIGO;DESCRIÇÃO;UNIDADE DE MEDIDA;FATOR PALLET;Fator SKU;FATOR HECTO;CUSTO POR SKU
                </code>
              </div>

              {/* Uploader Dropzone */}
              {!cadastroPreview ? (
                <div
                  onDragEnter={handleCadastroDrag}
                  onDragOver={handleCadastroDrag}
                  onDragLeave={handleCadastroDrag}
                  onDrop={handleCadastroDrop}
                  className={`border-2 border-dashed rounded-xl p-8 text-center transition-all relative flex flex-col items-center justify-center min-h-[160px] cursor-pointer ${
                    isCadastroDragActive 
                      ? 'border-emerald-500 bg-emerald-50/40 shadow-inner scale-[0.99]' 
                      : 'border-slate-200 hover:border-emerald-400 hover:bg-slate-50/50 bg-white'
                  }`}
                >
                  <input
                    type="file"
                    id="cadastro-file-elem"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleCadastroFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  
                  <Upload className="w-8 h-8 text-slate-400 mb-2.5" />
                  <p className="text-xs font-bold text-slate-700">Arraste & Soltar Cadastro de Produto aqui</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">ou clique para escolher do seu computador (Suporta .xlsx, .xls e .csv da Ambev)</p>
                </div>
              ) : (
                /* Preview do Lote Importado */
                <div className="space-y-4">
                  <div className="p-3 bg-emerald-50/30 rounded-xl border border-emerald-100 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-slate-800">
                        📁 Pronto para importação: {cadastroPreview.length} produtos
                      </p>
                      <p className="text-[10px] text-slate-400 font-sans">Verifique a prévia da carga abaixo antes de confirmar.</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCadastroPreview(null)}
                      className="text-slate-400 hover:text-rose-600 transition p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Tabela do Catalogo */}
                  <div className="border border-slate-100 rounded-xl overflow-hidden shadow-sm">
                    <div className="max-h-52 overflow-y-auto">
                      <table className="w-full text-left text-xs font-sans">
                        <thead className="bg-slate-50 font-bold text-slate-500 border-b border-slate-100">
                          <tr>
                            <th className="p-2 text-[10px] font-mono leading-none">SKU</th>
                            <th className="p-2 text-[10px] leading-none">DESCRIÇÃO</th>
                            <th className="p-2 text-[10px] leading-none">GRUPO</th>
                            <th className="p-2 text-[10px] leading-none text-center">UM</th>
                            <th className="p-2 text-[10px] leading-none text-right">CUSTO</th>
                            <th className="p-2 text-[10px] leading-none text-center font-mono">P/SKU/HL</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {cadastroPreview.slice(0, 50).map((p, idx) => (
                            <tr key={`cad-prev-${p.sku}-${idx}`} className="hover:bg-slate-50 text-[11px] text-slate-600">
                              <td className="p-2 font-mono font-bold text-slate-800">{p.sku.replace(/^0+/, '') || '0'}</td>
                              <td className="p-2 truncate max-w-[120px] uppercase font-semibold" title={p.descricao}>{p.descricao}</td>
                              <td className="p-2 text-[10px] text-indigo-600 font-medium">{p.categoria || 'Marketplace'}</td>
                              <td className="p-2 text-center text-[10px] font-bold text-slate-500">{p.unidadeMedida || 'CX'}</td>
                              <td className="p-2 text-right text-emerald-700 font-semibold">R$ {p.custoPorSku.toFixed(2)}</td>
                              <td className="p-2 text-center text-[10px] font-mono text-slate-400">{p.fatorPallet}/{p.fatorSku}/{p.fatorHecto}</td>
                            </tr>
                          ))}
                          {cadastroPreview.length > 50 && (
                            <tr>
                              <td colSpan={6} className="p-1.5 text-center text-[10px] text-slate-400 bg-slate-50">
                                ... e mais {cadastroPreview.length - 50} itens.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="flex gap-2.5">
                    <button
                      type="button"
                      onClick={handleConfirmCadastroImport}
                      className="flex-1 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer transition flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      Sincronizar Catálogo no ERP
                    </button>
                    <button
                      type="button"
                      onClick={() => setCadastroPreview(null)}
                      className="py-2 px-3 border border-slate-200 text-slate-500 hover:text-slate-700 hover:bg-slate-50 font-semibold text-xs rounded-xl cursor-pointer transition"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}
            </div>
            
          </div>
        </div>
      ) : activeReconView === 'congelar' ? (
        /* Novo Módulo de Desvios e Congelamento de Quebras */
        <div className="space-y-6 animate-fadeIn" id="congelar-divergencias-container">
          {/* Guia Interativo Branded Pau Brasil */}
          <PauBrasilGuide currentView={activeReconView} onViewChange={setActiveReconView} />

          <div className="bg-gradient-to-r from-blue-50/60 to-indigo-50/25 border border-slate-200 rounded-2xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-800 font-display flex items-center gap-2">
              ❄️ Painel de Desvios (Congelamento de Quebras & Divergências)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Guarde e congele permanentemente divergências operacionais ou quebras físicas identificadas no CD. Ao congelar um item, você insere observações específicas, e o sistema calcula a valoração total em valor financeiro absoluto (R$) e em hectolitros (HL) para provisões contábeis.
            </p>
          </div>

          {/* KPI Dashboard Cards para Itens Congelados */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-105 flex items-center justify-between shadow-sm">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Itens Congelados</span>
                <h4 className="text-xl font-bold font-display text-slate-800">{divergenciasCongeladas.length} SKUs</h4>
                <p className="text-[10px] text-slate-400">Total acumulado sob trava</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-105 flex items-center justify-between shadow-sm">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">caixas bloqueadas</span>
                <h4 className="text-xl font-bold font-mono text-orange-600">
                  {resumoCongelados.totalCaixasBloqueadas % 1 !== 0 ? resumoCongelados.totalCaixasBloqueadas.toFixed(2) : resumoCongelados.totalCaixasBloqueadas} cx
                </h4>
                <p className="text-[10px] text-slate-400">Total físico retirado de giro</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
                <Layers className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-105 flex items-center justify-between shadow-sm">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Ajuste Financeiro Líquido</span>
                <h4 className={`text-sm font-mono font-bold ${resumoCongelados.valorLiquido < 0 ? 'text-rose-600' : resumoCongelados.valorLiquido > 0 ? 'text-emerald-600' : 'text-slate-800'}`}>
                  R$ {resumoCongelados.valorLiquido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </h4>
                <p className="text-[10px] text-slate-400">Net contábil provisionado</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-slate-50 text-slate-600 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-105 flex items-center justify-between shadow-sm">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Perda Bruta Salva (Absoluta)</span>
                <h4 className="text-sm font-mono font-bold text-rose-500">
                  R$ {resumoCongelados.valorAbsoluto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </h4>
                <p className="text-[10px] text-slate-400">Volume monetário total envolvido</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-rose-50 text-rose-500 flex items-center justify-center">
                <Flame className="w-5 h-5" />
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-105 flex items-center justify-between shadow-sm">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Volume Físico Mapeado</span>
                <h4 className="text-sm font-mono font-bold text-indigo-600">
                  {formatHectolitro(resumoCongelados.volumeAbsolutoHL)} HL
                </h4>
                <p className="text-[10px] text-indigo-400 font-medium">Líquido: {formatHectolitro(resumoCongelados.volumeLiquidoHL)} HL</p>
              </div>
              <div className="h-9 w-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Layers className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            
            {/* Esquerda: Divergências Prontas para Congelar ( Checklist ou Manual ) */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux lg:col-span-2 flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="space-y-0.5">
                  <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-orange-500 block" />
                    1. Mapear Desvios Ativos
                  </h4>
                  <p className="text-[10px] text-slate-400 font-sans">Selecione ou adicione novos itens para congelar</p>
                </div>
                <span className="text-[10px] font-extrabold bg-orange-100 text-orange-850 px-2.5 py-0.5 rounded-full font-sans uppercase">
                  {ativosParaCongelar.length} Pendentes
                </span>
              </div>

              {/* Seletor Segmentado / Tabs de Opções de Congelamento */}
              <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/40">
                <button
                  type="button"
                  onClick={() => setActiveFreezeTab('checklist')}
                  className={`flex-1 text-center py-1.5 text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${activeFreezeTab === 'checklist' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  📋 Lista do Sistema
                </button>
                <button
                  type="button"
                  onClick={() => setActiveFreezeTab('manual')}
                  className={`flex-1 text-center py-1.5 text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${activeFreezeTab === 'manual' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  ✍️ Entrada Manual
                </button>
                <button
                  type="button"
                  onClick={() => setActiveFreezeTab('import-losses')}
                  className={`flex-1 text-center py-1.5 text-[10px] font-extrabold rounded-lg transition-all cursor-pointer ${activeFreezeTab === 'import-losses' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  📁 Importar Perdas
                </button>
              </div>

              {activeFreezeTab === 'manual' ? (
                (() => {
                  const normalizedManualSku = manualFreezeSku.trim().toUpperCase().padStart(8, '0');
                  const foundManualProduct = produtos.find(p => p.sku === normalizedManualSku || p.sku.replace(/^0+/, '') === manualFreezeSku.trim());

                  let convertedCaixas = 0;
                  if (manualFreezeQuantity) {
                    const qty = Number(manualFreezeQuantity);
                    if (manualFreezeUnitType === 'caixa') {
                      convertedCaixas = qty;
                    } else if (manualFreezeUnitType === 'pallet') {
                      const cpp = foundManualProduct?.caixasPorPallet || 80;
                      convertedCaixas = qty * cpp;
                    } else if (manualFreezeUnitType === 'unidade') {
                      const upc = foundManualProduct?.fatorEmbalagem || 12;
                      convertedCaixas = qty / upc;
                    }
                  }

                  return (
                    <div className="space-y-4 animate-fadeIn flex-1 flex flex-col justify-between">
                      <div className="space-y-4">
                        {manualFreezeMsg && (
                          <div className={`p-3 rounded-lg text-xs font-semibold ${manualFreezeMsg.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-250' : 'bg-rose-50 text-rose-800 border border-rose-250'}`}>
                            {manualFreezeMsg.text}
                          </div>
                        )}

                        <div className="space-y-1">
                          <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">SKU do Produto</label>
                          <input
                            list="produtos-congelamento-sugestoes"
                            type="text"
                            placeholder="Digite ou selecione o SKU..."
                            value={manualFreezeSku}
                            onChange={(e) => setManualFreezeSku(e.target.value)}
                            className="w-full text-xs p-2.5 bg-white rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono font-bold text-slate-700 shadow-sm"
                          />
                          <datalist id="produtos-congelamento-sugestoes">
                            {produtos.map(p => (
                              <option key={`suggestion-${p.sku}`} value={p.sku.replace(/^0+/, '')}>
                                {p.descricao} (Físico: {p.estoqueFisicoCaixas} | Fiscal: {p.estoqueSistemaCaixas})
                              </option>
                            ))}
                          </datalist>
                          {foundManualProduct && (
                            <div className="bg-slate-50 p-2 rounded-lg border border-slate-150 text-[10px] space-y-0.5 mt-1 font-sans">
                              <p className="font-extrabold text-slate-750">{foundManualProduct.descricao}</p>
                              <p className="text-slate-500 font-medium">
                                Fator Embalagem: {foundManualProduct.fatorEmbalagem || 12} un/cx | Pallet: {foundManualProduct.caixasPorPallet || 80} cx | Custo: R$ {foundManualProduct.custoMedio.toFixed(2)}/cx | HL/cx: {formatHectolitro(foundManualProduct.fatorHectolitro)} HL
                              </p>
                            </div>
                          )}
                          <p className="text-[9px] text-slate-400">Digite sem os zeros da esquerda (ex: 9068) ou selecione um item sugerido.</p>
                        </div>

                        <div className="grid grid-cols-2 gap-3.5">
                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Formato / Unidade</label>
                            <select
                              value={manualFreezeUnitType}
                              onChange={(e) => setManualFreezeUnitType(e.target.value as any)}
                              className="w-full text-xs p-2.5 bg-white rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans font-bold text-slate-700 shadow-sm cursor-pointer"
                            >
                              <option value="caixa">📦 SKU Fechado (Caixas)</option>
                              <option value="pallet">🏁 Pallet (Paletes)</option>
                              <option value="unidade">🧴 Unidade (Avaria/Unid)</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Quantidade</label>
                            <div className="relative flex items-center">
                              <input
                                type="number"
                                min="1"
                                placeholder="Formato num."
                                value={manualFreezeQuantity}
                                onChange={(e) => setManualFreezeQuantity(e.target.value)}
                                className="w-full text-xs p-2.5 bg-white rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono font-bold text-slate-700 shadow-sm"
                              />
                            </div>
                          </div>
                        </div>

                        {manualFreezeQuantity && (
                          <div className="bg-indigo-50/50 p-2.5 rounded-xl border border-indigo-100 flex items-center justify-between text-[11px] font-sans">
                            <span className="text-indigo-750 font-bold">Resumo Conversor:</span>
                            <span className="font-mono font-black text-indigo-700 bg-indigo-100/60 px-1.5 py-0.5 rounded text-[10px]">
                              {convertedCaixas % 1 !== 0 ? convertedCaixas.toFixed(2) : convertedCaixas.toString()} caixas {manualFreezeUnitType !== 'caixa' ? 'eq.' : ''}
                            </span>
                          </div>
                        )}

                        <div className="space-y-1">
                          <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Tipo de Divergência (Desvio)</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setManualFreezeType('falta')}
                              className={`py-2 text-xs font-bold rounded-lg border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                                manualFreezeType === 'falta'
                                  ? 'bg-rose-50 border-rose-250 text-rose-700 shadow-sm font-black'
                                  : 'bg-white border-slate-200 text-slate-500 hover:text-slate-750 hover:bg-slate-50'
                              }`}
                            >
                              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                              📉 Falta (Avaria/Quebra)
                            </button>
                            <button
                              type="button"
                              onClick={() => setManualFreezeType('sobra')}
                              className={`py-2 text-xs font-bold rounded-lg border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                                manualFreezeType === 'sobra'
                                  ? 'bg-emerald-50 border-emerald-250 text-emerald-700 shadow-sm font-black'
                                  : 'bg-white border-slate-200 text-slate-500 hover:text-slate-750 hover:bg-slate-50'
                              }`}
                            >
                              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                              📈 Sobra (Excesso Físico)
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Justificativa / Observação</label>
                          <textarea
                            rows={3}
                            placeholder="Insira as observações específicas deste congelamento..."
                            value={manualFreezeObservation}
                            onChange={(e) => setManualFreezeObservation(e.target.value)}
                            className="w-full text-xs p-2.5 bg-white rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-700 font-sans shadow-sm"
                          />
                        </div>
                      </div>

                      <div className="pt-2">
                        <button
                          type="button"
                          disabled={isFreezing || !manualFreezeSku || !manualFreezeQuantity}
                          onClick={async () => {
                            if (!onFreezeDivergences) return;
                            setIsFreezing(true);
                            setManualFreezeMsg(null);
                            const obs = `[Medida: ${manualFreezeUnitType.toUpperCase()} - Qtd Original: ${manualFreezeQuantity}] ${manualFreezeObservation || "Congelamento realizado via painel manual."}`;
                            try {
                              const success = await onFreezeDivergences(
                                [],
                                {},
                                true,
                                undefined,
                                undefined,
                                undefined,
                                [{ sku: manualFreezeSku, quantidade: convertedCaixas, tipo: manualFreezeType, observacao: obs }]
                              );
                              if (success) {
                                setManualFreezeMsg({ text: `Sucesso: SKU ${manualFreezeSku} congelado com equivalente de ${convertedCaixas % 1 !== 0 ? convertedCaixas.toFixed(2) : convertedCaixas} caixas!`, type: 'success' });
                                setManualFreezeSku("");
                                setManualFreezeQuantity("");
                                setManualFreezeObservation("");
                              } else {
                                setManualFreezeMsg({ text: "Erro ao congelar item de divergência.", type: 'error' });
                              }
                            } catch (err) {
                              setManualFreezeMsg({ text: "Erro ao conectar com o CD Server.", type: 'error' });
                            } finally {
                              setIsFreezing(false);
                            }
                          }}
                          className="w-full bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition shadow cursor-pointer active:scale-95"
                        >
                          <Lock className="w-4 h-4 shrink-0" />
                          <span>{isFreezing ? 'Processando...' : 'Confirmar Congelamento Manual'}</span>
                        </button>
                        <p className="text-[9px] text-slate-400 mt-2 text-center">
                          * O congelamento manual atua como compensador fiscal/físico imediato.
                        </p>
                      </div>
                    </div>
                  );
                })()
              ) : activeFreezeTab === 'import-losses' ? (
                <div className="space-y-4 animate-fadeIn flex-1 flex flex-col justify-between">
                  <div className="space-y-4">
                    {lossesError && (
                      <div className="p-3 rounded-lg text-xs font-semibold bg-rose-50 text-rose-800 border border-rose-250">
                        {lossesError}
                      </div>
                    )}
                    {lossesSuccessMsg && (
                      <div className="p-3 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-250">
                        {lossesSuccessMsg}
                      </div>
                    )}

                    {!importedLossesList ? (
                      <div
                        onDragOver={(e) => {
                          e.preventDefault();
                          setIsLossesDragActive(true);
                        }}
                        onDragLeave={() => setIsLossesDragActive(false)}
                        onDrop={(e) => {
                          e.preventDefault();
                          setIsLossesDragActive(false);
                          const file = e.dataTransfer.files?.[0];
                          if (file) handleLossesFile(file);
                        }}
                        className={`border-2 border-dashed rounded-2xl p-6 text-center transition duration-155 flex flex-col items-center justify-center gap-2.5 cursor-pointer ${
                          isLossesDragActive ? "border-indigo-500 bg-indigo-50/35" : "border-slate-205 bg-slate-50/15 hover:border-slate-300"
                        }`}
                        onClick={() => {
                          const input = document.createElement("input");
                          input.type = "file";
                          input.accept = ".csv,.txt,.xlsx,.xls";
                          input.onchange = (e: any) => {
                            const file = e.target.files?.[0];
                            if (file) handleLossesFile(file);
                          };
                          input.click();
                        }}
                      >
                        <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                          <UploadCloud className="w-5 h-5" />
                        </div>
                        <div className="space-y-0.5">
                          <p className="text-xs font-extrabold text-slate-700">Arrastar Planilha de Perdas</p>
                          <p className="text-[9px] text-slate-400">Ou clique para selecionar (Suporta Excel .xlsx, .xls, .csv, .txt)</p>
                        </div>
                        <div className="bg-slate-100 px-2 py-0.5 rounded font-mono text-[8px] text-slate-500 border border-slate-200">
                          Cabeçalhos aceitos: Produto / Sku; Descricao; Unidade / Quantidade; Perca
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-extrabold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded uppercase">
                            {lossesFileName} ({importedLossesList.length} itens)
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setImportedLossesList(null);
                              setLossesFileName(null);
                              setLossesError(null);
                              setLossesSuccessMsg(null);
                            }}
                            className="text-[9.5px] text-rose-600 hover:underline font-bold"
                          >
                            Limpar / Trocar
                          </button>
                        </div>

                        <div className="max-h-[180px] overflow-y-auto border border-slate-100 rounded-xl divide-y divide-slate-100">
                          {importedLossesList.map((loss, idx) => {
                            return (
                              <div key={`imp-loss-${loss.sku}-${idx}`} className="p-2 flex items-center justify-between text-[10.5px]">
                                <div className="space-y-0.5 max-w-[65%]">
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-mono font-black text-slate-700 bg-slate-100 px-1 py-0.1 rounded text-[8.5px]">
                                      {loss.sku.replace(/^0+/, '')}
                                    </span>
                                    <span className="font-bold text-slate-700 truncate block max-w-full">{loss.desc}</span>
                                  </div>
                                  <p className="text-[8.5px] text-slate-400 font-medium">
                                    Fator Embalagem: {loss.p?.fatorEmbalagem || 12} un/cx
                                  </p>
                                </div>
                                <div className="text-right">
                                  <span className="font-mono font-bold text-slate-900 block">{loss.unidades} un</span>
                                  <span className="text-[9px] font-sans font-semibold text-indigo-600">
                                    {loss.caixas} cx
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        <div className="bg-slate-50 p-2 rounded-xl border border-slate-100 space-y-1 text-[10.5px]">
                          <div className="flex justify-between text-slate-500">
                            <span>Total de Caixas Equivalentes:</span>
                            <span className="font-mono font-bold text-slate-800">
                              {importedLossesList.reduce((acc, x) => acc + x.caixas, 0).toFixed(2)} cx
                            </span>
                          </div>
                          <div className="flex justify-between text-slate-500">
                            <span>Estimativa de Custo:</span>
                            <span className="font-mono font-bold text-emerald-700">
                              R$ {importedLossesList.reduce((acc, x) => acc + (x.caixas * (x.p?.custoMedio || 45.00)), 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      disabled={isFreezingLosses || !importedLossesList || importedLossesList.length === 0}
                      onClick={async () => {
                        if (!onImportState || !importedLossesList) return;
                        setIsFreezingLosses(true);
                        setLossesError(null);
                        setLossesSuccessMsg(null);
                        try {
                          const mItems = importedLossesList.map((item, index) => {
                            const pEstoqueFisico = item.p ? Math.floor(item.p.estoqueFisicoCaixas) : 100;
                            const pEstoqueSistema = item.p ? Math.floor(item.p.estoqueSistemaCaixas) : 100;
                            // Uma perda é representada por uma divergência negativa (falha física)
                            const diffCx = -Math.abs(item.caixas);
                            const custo = item.p ? item.p.custoMedio : 45.00;
                            const hecto = item.p ? item.p.fatorHectolitro : 0.05;

                            return {
                              id: `FZ${String(index + 1).padStart(3, '0')}_${Date.now()}`,
                              sku: item.sku,
                              descricao: item.desc,
                              estoqueFisicoCaixas: pEstoqueFisico,
                              estoqueSistemaCaixas: pEstoqueSistema,
                              diferencaCaixas: diffCx,
                              custoPorSku: custo,
                              valorTotalDivergencia: Number((Math.abs(diffCx) * custo).toFixed(2)),
                              fatorHectolitro: hecto,
                              divergenciaHectolitro: Number((diffCx * hecto).toFixed(4)),
                              observacao: `Congelamento realizado através de formulário - Upload de Perda em Unidades: ${item.unidades} un (Planilha: ${lossesFileName})`,
                              dataCongelamento: new Date().toISOString(),
                              usuario: operatorEmail || "sistema@consiliwms.com"
                            };
                          });

                          await onImportState({ divergenciasCongeladas: mItems });
                          setLossesSuccessMsg(`Sucesso: Mais ${mItems.length} perdas importadas e acumuladas com sucesso no memorial de itens congelados!`);
                          setImportedLossesList(null);
                        } catch (err: any) {
                          setLossesError("Falha ao registrar congelamento das perdas: " + err.message);
                        } finally {
                          setIsFreezingLosses(false);
                        }
                      }}
                      className="w-full bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition hover:shadow cursor-pointer active:scale-95"
                    >
                      <Lock className="w-4 h-4 shrink-0" />
                      <span>{isFreezingLosses ? 'Registrando...' : 'Confirmar canais e Sobrescrever Base de Congelados'}</span>
                    </button>
                    <p className="text-[9px] text-slate-400 mt-2 text-center font-sans font-medium">
                      * Cada SKU inserido será compensado pelo seu fator correspondente (unidades / conversor). Sobrescreve registros anteriores.
                    </p>
                  </div>
                </div>
              ) : ativosParaCongelar.length === 0 ? (
                <div className="py-12 text-center space-y-2 flex-1 flex flex-col justify-center items-center">
                  <div className="w-12 h-12 rounded-full bg-slate-50 border border-dashed border-slate-200 flex items-center justify-center text-slate-300 font-mono text-lg select-none">
                    ✓
                  </div>
                  <p className="text-xs font-bold text-slate-500">Nenhum desvio pendente!</p>
                  <p className="text-[10px] text-slate-400 max-w-[220px]">Todos os itens operacionais estão balanceados ou congelados.</p>
                </div>
              ) : (
                <>
                  <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1 flex-1">
                    {ativosParaCongelar.map(p => {
                      const isChecked = selectedFreezeSkus.includes(p.sku);
                      return (
                        <div 
                          key={`candidate-freeze-${p.sku}`} 
                          className={`p-3 rounded-xl border transition-all space-y-3.5 ${isChecked ? 'bg-indigo-50/25 border-indigo-200 shadow-sm' : 'bg-slate-50/40 border-slate-200/60 hover:border-slate-300'}`}
                        >
                          <div className="flex items-start gap-2.5">
                            <input 
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedFreezeSkus(prev => [...prev, p.sku]);
                                } else {
                                  setSelectedFreezeSkus(prev => prev.filter(s => s !== p.sku));
                                }
                              }}
                              className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 mt-0.5 cursor-pointer"
                            />
                            <div className="min-w-0 flex-1">
                              <div className="flex justify-between items-start gap-2">
                                <span className="font-mono text-[9px] font-black text-slate-600 bg-slate-200 px-1.5 py-0.2 rounded shrink-0">{p.sku.replace(/^0+/, '')}</span>
                                <span className="text-[10px] font-black text-indigo-650 font-mono text-right shrink-0">
                                  {p.diferencaCaixas > 0 ? `+${p.diferencaCaixas}` : p.diferencaCaixas} cx
                                </span>
                              </div>
                              <p className="text-xs font-bold text-slate-705 truncate block mt-1" title={p.descricao}>{p.descricao}</p>
                              <div className="flex justify-between items-center text-[9px] font-medium text-slate-400 mt-1">
                                <span>R$ {p.custoMedio.toFixed(2)}/cx</span>
                                <span className={p.diferencaCaixas < 0 ? 'text-rose-500' : 'text-emerald-500'}>
                                  R$ {p.divergenciaValor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div>
                          </div>

                          {isChecked && (
                            <div className="pt-2.5 border-t border-slate-100/70 animate-fadeIn space-y-2.5 text-left">
                              {/* Campo de comentário / motivo */}
                              <div>
                                <label className="text-[9px] uppercase font-bold text-slate-500 block mb-1 font-sans">Motivo / Justificativa</label>
                                <input 
                                  type="text"
                                  placeholder="Ex: Quebra fardo no bloco B"
                                  value={freezeRemarks[p.sku] || ''}
                                  onChange={(e) => {
                                    const textVal = e.target.value;
                                    setFreezeRemarks(prev => ({
                                      ...prev,
                                      [p.sku]: textVal
                                    }));
                                  }}
                                  className="w-full text-xs p-2 bg-white rounded-lg border border-indigo-150 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-850 shadow-sm font-sans font-medium"
                                />
                              </div>

                              {/* Campo de Drag and Drop de Documentos */}
                              <div className="space-y-1">
                                <label className="text-[9px] uppercase font-bold text-slate-500 block font-sans">Anexar Documento Justificativa (.PDF / .XLSX / .PNG)</label>
                                
                                {frozenFiles[p.sku] ? (
                                  <div className="bg-emerald-50/50 border border-emerald-200/80 p-2 rounded-lg flex items-center justify-between text-[11px] animate-fadeIn text-slate-800">
                                    <div className="flex items-center gap-2 min-w-0">
                                      <span className="text-sm shrink-0">📎</span>
                                      <div className="truncate">
                                        <p className="font-extrabold text-emerald-950 truncate max-w-[130px] text-xs font-sans" title={frozenFiles[p.sku].nome}>
                                          {frozenFiles[p.sku].nome}
                                        </p>
                                        <p className="text-[9px] text-emerald-800 font-mono font-medium">Tamanho: {frozenFiles[p.sku].tamanho}</p>
                                      </div>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const filesMap = { ...frozenFiles };
                                        delete filesMap[p.sku];
                                        setFrozenFiles(filesMap);
                                      }}
                                      className="text-[10px] text-rose-500 font-black hover:underline px-1 py-0.5 cursor-pointer shrink-0"
                                    >
                                      Excluir
                                    </button>
                                  </div>
                                ) : (
                                  <div
                                    onDragOver={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setIsDraggingDocument(prev => ({ ...prev, [p.sku]: true }));
                                    }}
                                    onDragLeave={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setIsDraggingDocument(prev => ({ ...prev, [p.sku]: false }));
                                    }}
                                    onDrop={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setIsDraggingDocument(prev => ({ ...prev, [p.sku]: false }));
                                      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                                        const file = e.dataTransfer.files[0];
                                        const sizeStr = file.size > 1024 * 1024 
                                          ? (file.size / (1024 * 1024)).toFixed(1) + ' MB' 
                                          : (file.size / 1024).toFixed(0) + ' KB';
                                        setFrozenFiles(prev => ({
                                          ...prev,
                                          [p.sku]: { nome: file.name, tamanho: sizeStr }
                                        }));
                                      }
                                    }}
                                    onClick={() => {
                                      const fileEl = document.getElementById(`doc-upload-file-picker-${p.sku}`);
                                      fileEl?.click();
                                    }}
                                    className={`border-2 border-dashed rounded-lg p-2.5 text-center cursor-pointer transition-all ${
                                      isDraggingDocument[p.sku] 
                                      ? 'border-indigo-500 bg-indigo-50/20' 
                                      : 'border-slate-355 bg-slate-50/50 hover:bg-slate-100/50'
                                    }`}
                                  >
                                    <input 
                                      id={`doc-upload-file-picker-${p.sku}`}
                                      type="file"
                                      className="hidden"
                                      onChange={(e) => {
                                        if (e.target.files && e.target.files[0]) {
                                          const file = e.target.files[0];
                                          const sizeStr = file.size > 1024 * 1024 
                                            ? (file.size / (1024 * 1024)).toFixed(1) + ' MB' 
                                            : (file.size / 1024).toFixed(0) + ' KB';
                                          setFrozenFiles(prev => ({
                                            ...prev,
                                            [p.sku]: { nome: file.name, tamanho: sizeStr }
                                          }));
                                        }
                                      }}
                                    />
                                    <div className="flex flex-col items-center justify-center gap-1">
                                      <span className="text-base opacity-75 leading-none">📥</span>
                                      <p className="text-[10px] font-extrabold text-slate-505 leading-tight font-sans">Busque ou Arraste o Arquivo justificativa aqui</p>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      disabled={isFreezing || selectedFreezeSkus.length === 0}
                      onClick={async () => {
                        if (!onFreezeDivergences) return;
                        setIsFreezing(true);
                        try {
                          await onFreezeDivergences(selectedFreezeSkus, freezeRemarks, false, undefined, undefined, undefined, undefined, frozenFiles);
                          setSelectedFreezeSkus([]);
                          // Limpar observações enviadas de forma segura e os arquivos mapeados
                          const newRemarks = { ...freezeRemarks };
                          const newFiles = { ...frozenFiles };
                          selectedFreezeSkus.forEach(s => {
                            delete newRemarks[s];
                            delete newFiles[s];
                          });
                          setFreezeRemarks(newRemarks);
                          setFrozenFiles(newFiles);
                        } catch (err) {
                          // Tratado
                        } finally {
                          setIsFreezing(false);
                        }
                      }}
                      className="w-full bg-indigo-600 hover:bg-indigo-705 disabled:opacity-50 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition shadow cursor-pointer active:scale-95"
                    >
                      <Lock className="w-4 h-4 shrink-0" />
                      <span>{isFreezing ? 'Processando Trava...' : `Congelar ${selectedFreezeSkus.length} Item(ns) Selecionado(s)`}</span>
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Direita: Itens Já Congelados sob Análise Contábil */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux lg:col-span-3 flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
                <div className="space-y-0.5">
                  <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-blue-500 block animate-pulse" />
                    2. Memorial de Itens Congelados
                  </h4>
                  <p className="text-[10px] text-slate-400 font-sans">Valores travados prontos para repasse fiscal ou provisão financeira CD</p>
                </div>

                {/* Botão de Exportar Memorial Contratual de Congelados (.CSV com Documentos) */}
                {divergenciasCongeladas.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const headers = [
                        'RECON ID',
                        'SKU',
                        'DESCRICAO',
                        'QUANTIDADE ATUAL FISICA (CX)',
                        'QUANTIDADE SISTEMA (CX)',
                        'TRAVADO (CX)',
                        'VALOR BLOQUEADO (R$)',
                        'ESTOQUE ADICIONAL (HL)',
                        'JUSTIFICATIVA REGISTRO',
                        'ARQUIVO ADG ANEXO',
                        'USUARIO',
                        'DATA CONGELAMENTO'
                      ];

                      const csvRows = [
                        headers.join(';'),
                        ...divergenciasCongeladas.map(item => [
                          item.id,
                          item.sku,
                          item.descricao.replace(/;/g, ' ').toUpperCase(),
                          item.estoqueFisicoCaixas.toString(),
                          item.estoqueSistemaCaixas.toString(),
                          item.diferencaCaixas.toString(),
                          item.valorTotalDivergencia.toFixed(2),
                          item.divergenciaHectolitro.toString(),
                          item.observacao.replace(/;/g, ' ').toUpperCase(),
                          item.documentoNome ? item.documentoNome.toUpperCase() : 'SEM DOCUMENTO ANEXO',
                          item.usuario,
                          new Date(item.dataCongelamento).toLocaleDateString('pt-BR')
                        ].join(';'))
                      ];

                      const csvContent = '\uFEFF' + csvRows.join('\n');
                      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                      const url = URL.createObjectURL(blob);
                      const link = document.createElement('a');
                      link.href = url;
                      link.setAttribute('download', `MEMORIAL_ITENS_CONGELADOS_${new Date().toISOString().slice(0, 10)}.csv`);
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                    className="bg-[#2D489A] hover:bg-[#1D327A] text-white text-[10px] py-1.5 px-3 rounded-lg flex items-center gap-1 transition-all active:scale-95 cursor-pointer font-black border border-[#3B5BBF]/30"
                  >
                    📥 Exportar Memorial (.CSV)
                  </button>
                )}

                {/* Botões para Zerar Itens Congelados */}
                {divergenciasCongeladas.length > 0 && (
                  <div className="flex items-center gap-1.5">
                    {selectedFrozenSkuList.length > 0 && (
                      <button
                        type="button"
                        onClick={async () => {
                          if (onUnfreezeDivergences) {
                            await onUnfreezeDivergences(selectedFrozenSkuList);
                            setSelectedFrozenSkuList([]);
                          }
                        }}
                        className="bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] py-1.5 px-2.5 rounded-lg flex items-center gap-1 transition-all active:scale-95 cursor-pointer font-bold border border-rose-200"
                        title="Zerar itens que estão atualmente selecionados"
                      >
                        🗑️ Zerar Selecionados ({selectedFrozenSkuList.length})
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={async () => {
                        if (onUnfreezeDivergences) {
                          const allSkus = divergenciasCongeladas.map(d => d.sku);
                          await onUnfreezeDivergences(allSkus);
                          setSelectedFrozenSkuList([]);
                        }
                      }}
                      className="bg-rose-600 hover:bg-rose-700 text-white text-[10px] py-1.5 px-2.5 rounded-lg flex items-center gap-1 transition-all active:scale-95 cursor-pointer font-extrabold shadow-sm"
                      title="Zerar todos os registros congelados de uma única vez"
                    >
                      ❄️ Zerar Tudo
                    </button>
                  </div>
                )}
              </div>

              {divergenciasCongeladas.length === 0 ? (
                <div className="py-20 text-center space-y-3 flex-1 flex flex-col justify-center items-center">
                  <span className="text-4xl">❄️</span>
                  <p className="text-xs font-bold text-slate-400">Nenhuma quebra ou divergência congelada neste mês.</p>
                  <p className="text-[10px] text-slate-300 max-w-[280px]">Utilize o painel esquerdo para selecionar desvios contábeis e congelá-los com observações detalhadas.</p>
                </div>
              ) : (
                <div className="overflow-x-auto flex-1 max-h-[500px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-[11px] font-sans">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-400 font-bold uppercase tracking-wider text-[9px] bg-slate-50/50">
                        <th className="py-2.5 px-3 text-center w-8">
                          <input
                            type="checkbox"
                            checked={divergenciasCongeladas.length > 0 && selectedFrozenSkuList.length === divergenciasCongeladas.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedFrozenSkuList(divergenciasCongeladas.map(d => d.sku));
                              } else {
                                setSelectedFrozenSkuList([]);
                              }
                            }}
                            className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer h-3.5 w-3.5"
                          />
                        </th>
                        <th className="py-2 px-3">Código</th>
                        <th className="py-2 px-3">SKU / Descrição</th>
                        <th className="py-2 px-3 text-right">Delta / Valor</th>
                        <th className="py-2 px-3 text-right">Volume (HL)</th>
                        <th className="py-2 px-3">Observação / Registro</th>
                        <th className="py-2 px-3 text-center">Ação</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                      {divergenciasCongeladas.map((item, idx) => (
                        <tr key={`frozen-row-${item.sku}-${idx}`} className="hover:bg-slate-50/50 transition duration-150">
                          <td className="py-2.5 px-3 text-center">
                            <input
                              type="checkbox"
                              checked={selectedFrozenSkuList.includes(item.sku)}
                              onChange={() => {
                                setSelectedFrozenSkuList(prev => 
                                  prev.includes(item.sku) 
                                    ? prev.filter(s => s !== item.sku) 
                                    : [...prev, item.sku]
                                );
                              }}
                              className="rounded border-slate-300 text-indigo-650 focus:ring-indigo-500 cursor-pointer h-3.5 w-3.5"
                            />
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="font-mono text-[9px] bg-blue-50 text-blue-800 px-1.5 py-0.5 rounded font-black border border-blue-100">{item.id}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="font-mono bg-slate-100 font-semibold px-1 py-0.2 rounded text-[10px] text-slate-500">{item.sku.replace(/^0+/, '')}</span>
                            <div className="font-semibold text-slate-800 truncate max-w-[170px]" title={item.descricao}>{item.descricao}</div>
                          </td>
                          <td className="py-2.5 px-3 text-right whitespace-nowrap">
                            <span className={`font-mono font-bold block ${item.diferencaCaixas < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                              {item.diferencaCaixas > 0 ? `+${formatDiferencaCaixas(item.diferencaCaixas)}` : formatDiferencaCaixas(item.diferencaCaixas)} cx
                            </span>
                            <span className="text-[10px] text-slate-400 block font-mono">
                              R$ {item.valorTotalDivergencia.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-600 whitespace-nowrap">
                            {item.divergenciaHectolitro > 0 ? `+${formatHectolitro(item.divergenciaHectolitro)}` : formatHectolitro(item.divergenciaHectolitro)} HL
                            <span className="text-[9px] block text-slate-400 font-semibold">({(item.fatorHectolitro * 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} L/cx)</span>
                          </td>
                          <td className="py-2.5 px-3 max-w-[170px]">
                            <p className="text-[10px] font-sans font-medium text-slate-800 text-xs italic leading-tight" title={item.observacao}>
                              "{item.observacao}"
                            </p>
                            
                            {/* Mostrar documento anexo justificativa se houver */}
                            {item.documentoNome && (
                              <div className="mt-1 flex items-center gap-1 text-[9px] bg-emerald-50 text-emerald-800 font-extrabold px-1.5 py-0.5 rounded border border-emerald-200/40 w-max max-w-full" title={`Documento Anexo: ${item.documentoNome}`}>
                                <span>📎 {item.documentoNome}</span>
                                {item.documentoTamanho && <span className="opacity-75 font-medium text-[8px]">({item.documentoTamanho})</span>}
                              </div>
                            )}

                            <span className="text-[9px] font-semibold text-slate-400 block mt-1">
                              Por: {item.usuario.split('@')[0]} ({new Date(item.dataCongelamento).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })})
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <button
                              type="button"
                              onClick={async () => {
                                if (onUnfreezeDivergences) {
                                  await onUnfreezeDivergences([item.sku]);
                                }
                              }}
                              className="w-7 h-7 rounded-lg text-rose-500 hover:bg-rose-50 hover:text-rose-700 flex items-center justify-center transition border border-transparent hover:border-rose-100 cursor-pointer mx-auto"
                              title="Descongelar item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>

          {/* Gráfico de Barras: Principais Impactos de Congelamento por SKU */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux mt-6" id="grafico-impacto-congelamento-container">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-100 pb-3 mb-4 gap-2">
              <div className="space-y-0.5">
                <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-indigo-500 block animate-pulse" />
                  📊 Impactos Contábeis do Congelamento por SKU
                </h4>
                <p className="text-[10px] text-slate-400 font-sans">Visualização de volumes e valores travados para compensação fiscal/física</p>
              </div>
              <span className="text-[9px] font-bold bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-sans tracking-wide uppercase">
                Ordenado por Volume Bloqueado (cx)
              </span>
            </div>

            {divergenciasCongeladas.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
                <span className="text-2xl opacity-60">📊</span>
                <p className="font-bold">Nenhum dado para exibir no gráfico.</p>
                <p className="text-[10px] text-slate-300 max-w-[280px]">Congele quebras físicas ou avulsas para alimentar a análise visual de impactos por item.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {(() => {
                  // Agrupar por SKU para garantir consolidação
                  const groupedMap = new Map<string, { sku: string; descricao: string; caixas: number; valor: number; hl: number }>();
                  divergenciasCongeladas.forEach(item => {
                    const sku = item.sku;
                    const val = groupedMap.get(sku) || { sku, descricao: item.descricao, caixas: 0, valor: 0, hl: 0 };
                    val.caixas += Math.abs(item.diferencaCaixas || 0);
                    val.valor += Math.abs(item.valorTotalDivergencia || 0);
                    val.hl += Math.abs(item.divergenciaHectolitro || 0);
                    groupedMap.set(sku, val);
                  });

                  // Ordenar por volume de caixas bloqueadas decrescente
                  const sortedData = Array.from(groupedMap.values()).sort((a, b) => b.caixas - a.caixas).slice(0, 8);
                  const maxCaixas = Math.max(...sortedData.map(d => d.caixas), 1);

                  return (
                    <div className="grid grid-cols-1 lg:grid-cols-6 gap-6">
                      {/* Gráfico de Barras Progressivas Custom (cols-4) */}
                      <div className="space-y-4 lg:col-span-4">
                        {sortedData.map((d, index) => {
                          const percent = (d.caixas / maxCaixas) * 100;
                          return (
                            <div key={`chart-bar-entry-${d.sku}`} className="space-y-1.5 animate-fadeIn">
                              <div className="flex justify-between items-center text-xs">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="font-mono text-[9px] bg-indigo-50 border border-indigo-100 text-indigo-750 font-black px-1.5 py-0.5 rounded shrink-0">
                                    {d.sku.replace(/^0+/, '')}
                                  </span>
                                  <span className="font-bold text-slate-705 truncate" title={d.descricao}>
                                    {d.descricao}
                                  </span>
                                </div>
                                <div className="shrink-0 font-mono text-right flex items-center gap-2 text-[10px]">
                                  <span className="font-extrabold text-indigo-600 bg-indigo-50/50 px-1.5 py-0.2 rounded">
                                    {d.caixas} cx
                                  </span>
                                  <span className="text-slate-400">
                                    R$ {d.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="h-4 w-full bg-slate-100/70 rounded-lg overflow-hidden flex shadow-inner border border-slate-205/10">
                                <div 
                                  style={{ width: `${percent}%` }}
                                  className={`h-full rounded-lg transition-all duration-1000 ease-out ${
                                    index === 0 ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600' :
                                    index === 1 ? 'bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600' :
                                    index === 2 ? 'bg-gradient-to-r from-sky-500 to-blue-600' :
                                    'bg-gradient-to-r from-slate-400 to-slate-500'
                                  }`}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Caixa Informativa Lateral de Impacto (cols-2) */}
                      <div className="lg:col-span-2 bg-gradient-to-br from-slate-50 to-indigo-50/15 rounded-2xl p-5 border border-slate-200/60 flex flex-col justify-between">
                        <div className="space-y-3.5">
                          <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Demonstrador Contábil de Trava
                          </h5>
                          <p className="text-[11px] text-slate-505 leading-relaxed">
                            Ao manter SKUs congelados com quantidades específicas, a física e a fiscal passam a consolidar com sucesso (**OK**), pois o sistema compensa a discrepância ajustada de forma automática das visões de perdas em trânsito.
                          </p>

                          <div className="space-y-2 pt-2">
                            <div className="bg-white p-3 rounded-xl border border-slate-150/60 flex items-center justify-between shadow-sm flex-1">
                              <div>
                                <span className="text-[9px] text-slate-400 block font-bold uppercase">Maior Bloqueio</span>
                                <span className="text-[11px] font-extrabold text-slate-800 block truncate max-w-[130px]" title={sortedData[0]?.descricao}>
                                  {sortedData[0] ? sortedData[0].descricao : '--'}
                                </span>
                              </div>
                              <span className="font-mono text-xs font-black text-indigo-600 bg-indigo-50 px-1.5 py-1 rounded shrink-0">
                                {sortedData[0] ? `${sortedData[0].caixas} cx` : '0 cx'}
                              </span>
                            </div>

                            <div className="bg-white p-3 rounded-xl border border-slate-150/60 flex items-center justify-between shadow-sm">
                              <div>
                                <span className="text-[9px] text-slate-400 block font-bold uppercase">Representação Total</span>
                                <span className="text-[11px] font-mono font-extrabold text-slate-800 block">
                                  R$ {sortedData.reduce((acc, d) => acc + d.valor, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="text-[9px] text-indigo-500 flex items-center gap-2 font-medium mt-4 pt-4 border-t border-slate-200/50">
                          <span className="h-4 w-4 rounded-full bg-indigo-55/10 flex items-center justify-center font-bold text-[10px] shrink-0">i</span>
                          <span>Compensações impactam relatórios físicos, fiscais e alertas do conselho.</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

        </div>
      ) : activeReconView === 'analise' ? (
        /* Novo Módulo de Análise e Consultas Individuais */
        <div className="space-y-6 animate-fadeIn" id="evolucao-individual-sku-container">
          {/* Guia Interativo Branded Pau Brasil */}
          <PauBrasilGuide currentView={activeReconView} onViewChange={setActiveReconView} />

          {/* PAINEL DE AUDITORIA CONSOLIDADA DE FECHAMENTO (30 DIAS) */}
          <div className="bg-slate-900/65 border border-slate-800 rounded-2xl p-6 shadow-lux space-y-6" id="dashboard-consolidado-30-dias">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 opacity-95">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></span>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-blue-400 font-mono">Consolidação e Auditoria Financeira</span>
                </div>
                <h3 className="font-display font-extrabold text-white text-base tracking-tight flex items-center gap-2">
                  <span>📅 Central de Auditoria & Fechamento Temporal (30 Dias)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Selecione qualquer data dos últimos 30 dias para reconstruir instantaneamente a balança de estoques físico x fiscal do armazém inteiro.
                </p>
              </div>

              {/* Input de Data de Fechamento */}
              <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 pl-1 font-mono">Data do Diário:</span>
                <input 
                  type="date"
                  min="2026-05-01"
                  max="2026-05-30"
                  value={`2026-05-${String(auditSelectedDay).padStart(2, '0')}`}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val) {
                      const dayPart = parseInt(val.split('-')[2]);
                      if (dayPart >= 1 && dayPart <= 30) {
                        setAuditSelectedDay(dayPart);
                      }
                    }
                  }}
                  className="bg-transparent border-0 text-xs font-mono font-bold text-blue-400 focus:ring-0 p-1 cursor-pointer"
                />
              </div>
            </div>

            {/* Slider de Dias + Botões de Atalhos de Preenchimento */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center bg-slate-950/40 p-4 rounded-xl border border-slate-850">
              {/* O Slider */}
              <div className="lg:col-span-6 space-y-2">
                <div className="flex justify-between items-center text-[10.5px]">
                  <span className="text-slate-400 font-medium">Histórico Retroativo: <strong className="text-white">Dia {auditSelectedDay} de 30</strong></span>
                  <span className="font-mono text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-full font-bold">2026-05-{String(auditSelectedDay).padStart(2, '0')}</span>
                </div>
                <input 
                  type="range"
                  min="1"
                  max="30"
                  value={auditSelectedDay}
                  onChange={(e) => setAuditSelectedDay(Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none"
                />
                <div className="flex justify-between text-[9px] text-slate-500 font-mono font-bold">
                  <span>01/05 (Início)</span>
                  <span>15/05 (Ajuste Geral)</span>
                  <span>30/05 (Fechamento)</span>
                </div>
              </div>

              {/* Atalhos para preenchimento de Data */}
              <div className="lg:col-span-6 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 font-sans block">Atalhos de Preenchimento de Auditoria:</span>
                <div className="flex flex-wrap gap-1.5 font-sans">
                  {[
                    { day: 5, date: "05/05", label: "Início do Mês" },
                    { day: 12, date: "12/05", label: "Pré-Inventário" },
                    { day: 15, date: "15/05", label: "Inventário Geral" },
                    { day: 22, date: "22/05", label: "Stock Drift" },
                    { day: 30, date: "30/05", label: "Fechamento" }
                  ].map((x) => (
                    <button
                      type="button"
                      key={`shortcut-day-${x.day}`}
                      onClick={() => setAuditSelectedDay(x.day)}
                      className={`text-[10.5px] px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer font-bold ${
                        auditSelectedDay === x.day 
                          ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-500/10' 
                          : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-850 hover:text-white'
                      }`}
                    >
                      <span>{x.date}</span> <span className="text-[9px] font-normal opacity-75 hidden xl:inline">({x.label})</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* IMPACTO FISICO, FISCAL E DIVERGENCIA NO DIA */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Impacto Físico */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 space-y-3">
                <div className="flex justify-between items-center pb-2 border-b border-slate-900">
                  <span className="text-[10.5px] uppercase font-extrabold text-amber-500 flex items-center gap-1.5 tracking-wider font-display">
                    📦 Estoque Físico Operacional
                  </span>
                  <span className="text-[9px] bg-amber-500/10 text-amber-400 px-1.5 py-0.1 font-bold rounded">Contado</span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Volume Total em Caixas:</span>
                    <strong className="text-white font-mono">{consolidatedAuditData.totalPhysicalBoxes.toLocaleString('pt-BR')} cx</strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Valoração Financeira:</span>
                    <strong className="text-amber-400 font-mono">R$ {consolidatedAuditData.totalPhysicalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Volume de Líquido:</span>
                    <strong className="text-white font-mono">{formatHectolitro(consolidatedAuditData.totalPhysicalHl)} HL</strong>
                  </div>
                </div>
              </div>

              {/* Impacto Fiscal */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 space-y-3">
                <div className="flex justify-between items-center pb-2 border-b border-slate-900">
                  <span className="text-[10.5px] uppercase font-extrabold text-blue-505 flex items-center gap-1.5 tracking-wider font-display">
                    🧾 Estoque Fiscal Lógico (ERP)
                  </span>
                  <span className="text-[9px] bg-blue-500/10 text-blue-400 px-1.5 py-0.1 font-bold rounded">Sistêmico</span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Volume Total em Caixas:</span>
                    <strong className="text-white font-mono">{consolidatedAuditData.totalFiscalBoxes.toLocaleString('pt-BR')} cx</strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Valoração Financeira:</span>
                    <strong className="text-blue-400 font-mono">R$ {consolidatedAuditData.totalFiscalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Volume de Líquido:</span>
                    <strong className="text-white font-mono">{formatHectolitro(consolidatedAuditData.totalFiscalHl)} HL</strong>
                  </div>
                </div>
              </div>

              {/* Diferença de Conciliação */}
              <div className={`p-4 rounded-xl border space-y-3 ${
                consolidatedAuditData.diffBoxes < 0 
                  ? 'bg-rose-950/20 border-rose-900/40' 
                  : 'bg-emerald-950/20 border-emerald-900/40'
              }`}>
                <div className="flex justify-between items-center pb-2 border-b border-slate-900">
                  <span className="text-[10.5px] uppercase font-extrabold tracking-wider font-display flex items-center gap-1.5">
                    ⚖️ Balanço das Divergências
                  </span>
                  <span className={`text-[9.5px] px-2 py-0.5 font-bold rounded-lg ${
                    consolidatedAuditData.diffBoxes < 0 
                      ? 'bg-rose-500/15 text-rose-400' 
                      : 'bg-emerald-500/15 text-emerald-400'
                  }`}>
                    {consolidatedAuditData.diffBoxes === 0 ? 'Equilibrado' : consolidatedAuditData.diffBoxes < 0 ? 'Falta / Quebras' : 'Sobra Física'}
                  </span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Saldo Diferença em Caixas:</span>
                    <strong className={`font-mono ${consolidatedAuditData.diffBoxes < 0 ? 'text-rose-450 font-black' : consolidatedAuditData.diffBoxes > 0 ? 'text-emerald-450 font-black' : 'text-slate-200'}`}>
                      {consolidatedAuditData.diffBoxes > 0 ? `+${consolidatedAuditData.diffBoxes.toLocaleString('pt-BR')}` : consolidatedAuditData.diffBoxes.toLocaleString('pt-BR')} cx
                    </strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Impacto Financeiro Líquido:</span>
                    <strong className={`font-mono ${consolidatedAuditData.diffValue < 0 ? 'text-rose-450 font-black' : consolidatedAuditData.diffValue > 0 ? 'text-emerald-450 font-black' : 'text-slate-200'}`}>
                      R$ {consolidatedAuditData.diffValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </strong>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Volume Diferença Líquido:</span>
                    <strong className={`font-mono ${consolidatedAuditData.diffHl < 0 ? 'text-rose-450 font-semibold' : consolidatedAuditData.diffHl > 0 ? 'text-emerald-450 font-semibold' : 'text-slate-200'}`}>
                      {consolidatedAuditData.diffHl > 0 ? `+${formatHectolitro(consolidatedAuditData.diffHl)}` : formatHectolitro(consolidatedAuditData.diffHl)} HL
                    </strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Parecer da Auditoria Interna */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-850 flex items-start gap-3">
              <span className="p-1 px-1.5 bg-blue-500/10 rounded-lg text-blue-400 text-[10px] shrink-0 font-mono font-bold block uppercase tracking-wider">Parecer</span>
              <div className="space-y-1">
                <span className="text-[9.5px] uppercase font-bold text-slate-400 font-mono block">Status de Integridade Corporativa Ambev:</span>
                <p className="text-[10.5px] text-slate-300 font-sans leading-relaxed">
                  {auditSelectedDay === 15 ? (
                    <strong className="text-emerald-450">Inventário Geral Concluído. No dia 15/05 as equipes de armazém executaram o congelamento total de prateleiras e sincronizaram as divergências ao ERP física x fiscal, neutralizando temporariamente o stock drift acumulado.</strong>
                  ) : auditSelectedDay < 15 ? (
                    <span>O armazém está em fase ascendente de <strong className="text-amber-450">drift de faturamento</strong>. As perdas e avarias físicas operacionais ainda não foram reajustadas sistemicamente pelo ERP. O impacto financeiro atual estimado das divergências consolidadas no diário selecionado é de {consolidatedAuditData.diffValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}.</span>
                  ) : (
                    <span>Ciclo de quebras pós-inventário físico de meio de mês. Monitoramos novos desvios com tendência de estabilização decorrente da otimização de layout de picking do galpão de Guarabira da Distribuidora Pau Brasil.</span>
                  )}
                </p>
              </div>
            </div>

            {/* TOP 5 SKUs QUE MAIS DESVIARAM NO DIA SELECIONADO */}
            <div className="space-y-3 pt-2">
              <div className="flex justify-between items-center sm:flex-row flex-col gap-2">
                <span className="text-xs uppercase font-extrabold text-slate-300 font-display flex items-center gap-1.5 tracking-tight">
                  🚨 Principais Desvios no Diário Selecionado (2026-05-{String(auditSelectedDay).padStart(2, '0')})
                </span>
                <span className="text-[9.5px] text-slate-400 font-mono font-medium">Clique no SKU para inspecionar evolução histórica no gráfico de ondas abaixo</span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3.5">
                {consolidatedAuditData.topDiscrepancies.map((skuItem) => {
                  const isSelected = selectedHistorySku === skuItem.sku;
                  return (
                    <div 
                      key={`audit-top-sku-${skuItem.sku}`}
                      onClick={async () => {
                        setSelectedHistorySku(skuItem.sku);
                        setIsLoadingHistory(true);
                        setHistoryError(null);
                        try {
                          const response = await fetch(`/api/state/history/${skuItem.sku}`);
                          const rJson = await response.json();
                          if (rJson.success) {
                            setHistoryData(rJson.data);
                          } else {
                            throw new Error(rJson.error || "SKU não encontrado.");
                          }
                        } catch (err: any) {
                          setHistoryError(err.message || "Erro de sincronização.");
                          setHistoryData(null);
                        } finally {
                          setIsLoadingHistory(false);
                        }
                      }}
                      className={`p-3 rounded-xl border cursor-pointer transition-all hover:-translate-y-0.5 duration-150 flex flex-col justify-between h-28 ${
                        isSelected 
                          ? 'bg-blue-600/15 border-blue-500 text-white shadow shadow-blue-500/10' 
                          : 'bg-slate-950/40 border-slate-850 text-slate-200 hover:bg-slate-950'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-[9px] bg-slate-900 border border-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-bold">
                            {skuItem.sku.replace(/^0+/, '')}
                          </span>
                          <span className={`text-[8.5px] font-bold ${skuItem.divergenciaCaixas < 0 ? 'text-rose-450' : 'text-emerald-450'}`}>
                            {skuItem.divergenciaCaixas > 0 ? `+${skuItem.divergenciaCaixas}` : skuItem.divergenciaCaixas} cx
                          </span>
                        </div>
                        <p className="text-[10px] font-sans font-bold leading-tight mt-1.5 truncate text-slate-250 select-none" title={skuItem.descricao}>
                          {skuItem.descricao}
                        </p>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-slate-900/60 text-[9px]">
                        <span className="text-slate-400 font-medium">Desvio R$:</span>
                        <span className={`font-mono font-bold ${skuItem.divergenciaValor < 0 ? 'text-rose-450' : 'text-emerald-450'}`}>
                          {skuItem.divergenciaValor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-violet-50/60 to-purple-50/20 border border-slate-250 rounded-2xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-800 font-display flex items-center gap-2">
              🔎 Módulo de Detalhamento & Análise de SKU Individual (Gráfico Drift)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Selecione qualquer produto no painel de busca rápida lateral ou utilize o atalho de auditoria acima para projetar o gráfico de conformidade em tempo real.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            {/* Esquerda: Seletor Mestre de SKU por Busca */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux lg:col-span-1 flex flex-col gap-4">
              <div className="space-y-1 pb-3 border-b border-indigo-50/50">
                <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight flex items-center gap-1.5">
                  <Search className="w-4 h-4 text-violet-500" />
                  Filtrar Cadastro
                </h4>
                <p className="text-[10px] text-slate-400 font-sans">Selecione ou busque qualquer item operacional</p>
              </div>

              {/* Input Real-time */}
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Pesquisar SKU ou nome..." 
                  value={historySearchInput}
                  onChange={(e) => setHistorySearchInput(e.target.value)}
                  className="w-full text-xs p-2.5 pl-8 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-violet-500 focus:outline-none focus:bg-white text-slate-800 font-medium"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3.5" />
              </div>

              {/* Lista dos 100 itens */}
              <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
                {produtos
                  .filter(p => !historySearchInput || p.sku.includes(historySearchInput) || p.descricao.toUpperCase().includes(historySearchInput.toUpperCase()))
                  .map(p => {
                    const isSelected = selectedHistorySku === p.sku;
                    return (
                      <button
                        type="button"
                        key={`side-sku-btn-${p.sku}`}
                        onClick={async () => {
                          setSelectedHistorySku(p.sku);
                          setIsLoadingHistory(true);
                          setHistoryError(null);
                          try {
                            const response = await fetch(`/api/state/history/${p.sku}`);
                            const rJson = await response.json();
                            if (rJson.success) {
                              setHistoryData(rJson.data);
                            } else {
                              throw new Error(rJson.error || "SKU não encontrado.");
                            }
                          } catch (err: any) {
                            setHistoryError(err.message || "Erro de sincronização.");
                            setHistoryData(null);
                          } finally {
                            setIsLoadingHistory(false);
                          }
                        }}
                        className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all flex justify-between items-center cursor-pointer ${isSelected ? 'bg-violet-600 border-violet-600 text-white shadow-md font-bold' : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100 hover:border-slate-200'}`}
                      >
                        <div className="min-w-0 pr-2">
                          <span className={`font-mono text-[9px] font-semibold block px-1 py-0.1 select-none w-max rounded ${isSelected ? 'bg-violet-550 text-white' : 'bg-slate-200 text-slate-600'}`}>{p.sku.replace(/^0+/, '')}</span>
                          <p className="font-semibold truncate text-[11px] mt-0.5 text-slate-800" title={p.descricao}>{p.descricao}</p>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 shrink-0" />
                      </button>
                    );
                  })}
              </div>
            </div>

            {/* Direita: Detalhes, Análise, e Gráfico de Stock Drift */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux lg:col-span-3 min-h-[500px] flex flex-col justify-between">
              {!selectedHistorySku ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center space-y-3.5 max-w-md mx-auto py-20 select-none animate-fadeIn">
                  <div className="w-14 h-14 rounded-full bg-violet-50 text-violet-650 flex items-center justify-center border border-violet-100 animate-pulse">
                    <Activity className="w-7 h-7" />
                  </div>
                  <h4 className="font-display font-extrabold text-slate-850 text-sm tracking-tight text-center">Nenhum SKU sob inspeção analítica</h4>
                  <p className="text-xs text-slate-400">Selecione um produto no painel esquerdo ou utilize a pesquisa rápida para carregar e inspecionar a variação diária de conformidade entre balanços.</p>
                </div>
              ) : isLoadingHistory ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-3.5 py-24 text-center">
                  <div className="w-10 h-10 rounded-full border-4 border-violet-600 border-t-transparent animate-spin mx-auto mr-3"></div>
                  <p className="text-xs font-mono font-bold text-slate-405">Carregando telemetria e calculando desvios determinísticos estáticos...</p>
                </div>
              ) : historyError ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-3 py-16 text-center text-rose-600 animate-fadeIn">
                  <XCircle className="w-10 h-10 text-rose-500 animate-pulse" />
                  <p className="text-xs font-bold font-display">{historyError}</p>
                  <p className="text-[10px] text-slate-400">Verifique se o SKU digitado é válido.</p>
                </div>
              ) : historyData ? (
                /* PAINEL GRÁFICO PREENCHIDO E ESTILIZADO */
                <div className="space-y-6 flex-1 flex flex-col justify-between animate-fadeIn">
                  
                  {/* Header do Item Selecionado */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100/50">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[9px] font-bold bg-violet-100 border border-violet-200 text-violet-800 px-2 py-0.5 rounded uppercase">{historyData.sku}</span>
                        <span className="text-[10px] font-extrabold text-slate-400 font-sans uppercase">{historyData.categoria}</span>
                        <span className="text-[9px] bg-slate-200 text-slate-700 px-1.5 py-0.1 font-bold rounded">CURVA {historyData.curvaABC}</span>
                      </div>
                      <h4 className="font-display font-extrabold text-slate-800 text-xs mt-1 block">{historyData.descricao}</h4>
                    </div>

                    <div className="flex gap-4 sm:text-right text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Custo Médio</span>
                        <strong className="text-slate-705 block font-mono">R$ {historyData.custoMedio.toFixed(2)}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Coeficiente Hectolitro</span>
                        <strong className="text-indigo-600 block font-mono">{historyData.fatorHectolitro.toFixed(4)} HL/cx</strong>
                      </div>
                    </div>
                  </div>

                  {/* MINI KPIS DO MES */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-3 bg-indigo-50/15 border border-indigo-100/30 rounded-xl">
                      <span className="text-[10px] text-slate-400 block font-semibold">Último Saldo Sistêmico CD</span>
                      <strong className="text-sm font-mono text-slate-800">{historyData.lastSist} caixas</strong>
                    </div>
                    <div className="p-3 bg-amber-50/15 border border-amber-100/30 rounded-xl">
                      <span className="text-[10px] text-slate-400 block font-semibold">Último Saldo Contado Real</span>
                      <strong className="text-sm font-mono text-slate-800">{historyData.lastPhys} caixas</strong>
                    </div>
                    <div className="p-3 bg-violet-50/15 border border-violet-100/30 rounded-xl">
                      <span className="text-[10px] text-slate-400 block font-semibold">Desvio Físico Atual</span>
                      <strong className={`text-sm font-mono block ${(historyData.lastPhys - historyData.lastSist) < 0 ? 'text-rose-600' : (historyData.lastPhys - historyData.lastSist) > 0 ? 'text-emerald-600' : 'text-slate-800'}`}>
                        {(historyData.lastPhys - historyData.lastSist) > 0 ? `+${historyData.lastPhys - historyData.lastSist}` : historyData.lastPhys - historyData.lastSist} caixas 
                        <span className="text-[9px] text-slate-400 block font-normal mt-0.5">
                          (R$ {((historyData.lastPhys - historyData.lastSist) * historyData.custoMedio).toLocaleString('pt-BR', { minimumFractionDigits: 2 })})
                        </span>
                      </strong>
                    </div>
                  </div>

                  {/* GRÁFICO CUSTOMIZADO EM SVG */}
                  <div className="space-y-3 flex-1 flex flex-col justify-between">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <TrendingUp className="w-4 h-4 text-violet-550 animate-pulse" />
                        <span className="font-bold text-slate-700">Comportamento Geral das Diferenças Acumuladas (30d)</span>
                      </div>
                      
                      {/* Legenda colorida */}
                      <div className="flex items-center gap-4 text-[10px] font-semibold text-slate-400">
                        <div className="flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-violet-600 block" />
                          <span>Estoque Sistêmico</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-orange-450 block border border-dashed border-white" />
                          <span>Físico Real Contado CD</span>
                        </div>
                      </div>
                    </div>

                    {/* SVG GRAPH PLOTTER container */}
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-900 shadow-inner flex flex-col justify-between select-none relative group h-64 overflow-hidden">
                      
                      {/* Grid de fundo */}
                      <div className="absolute inset-x-4 inset-y-8 flex flex-col justify-between pointer-events-none opacity-[0.03]">
                        <div className="border-b border-white border-dashed w-full" />
                        <div className="border-b border-white border-dashed w-full" />
                        <div className="border-b border-white border-dashed w-full" />
                        <div className="border-b border-white border-dashed w-full" />
                        <div className="border-b border-white border-dashed w-full" />
                      </div>

                      {/* Renderizador de SVG */}
                      <svg 
                        className="w-full h-full overflow-visible z-10" 
                        viewBox="0 0 600 210"
                        onMouseMove={(e) => {
                          const svg = e.currentTarget;
                          const rect = svg.getBoundingClientRect();
                          const x = e.clientX - rect.left;
                          // O gráfico conta com margem à esquerda de 30 e à direita de 20
                          const paddingLeft = 30;
                          const chartWidth = 550;
                          const mappedIndex = Math.round(((x - paddingLeft) / chartWidth) * 29);
                          if (mappedIndex >= 0 && mappedIndex < 30) {
                            setActiveHoverIndex(mappedIndex);
                          } else {
                            setActiveHoverIndex(null);
                          }
                        }}
                        onMouseLeave={() => setActiveHoverIndex(null)}
                      >
                        <defs>
                          <linearGradient id="sistGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#7c3aed" stopOpacity="0.15" />
                            <stop offset="100%" stopColor="#7c3aed" stopOpacity="0" />
                          </linearGradient>
                          <linearGradient id="fisGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.08" />
                            <stop offset="100%" stopColor="#fbbf24" stopOpacity="0" />
                          </linearGradient>
                        </defs>

                        {/* Desenho do gráfico */}
                        {(() => {
                          const pts = historyData.dataPoints;
                          const maxVal = Math.max(...pts.map((d: any) => Math.max(d.sistema, d.fisico, 1))) + 15;
                          
                          // Mapeamento dos pontos
                          const pointsSist = pts.map((d: any, i: number) => {
                            const x = 30 + (i / 29) * 550;
                            const y = 180 - (d.sistema / maxVal) * 150;
                            return `${x},${y}`;
                          });

                          const pointsPhys = pts.map((d: any, i: number) => {
                            const x = 30 + (i / 29) * 550;
                            const y = 180 - (d.fisico / maxVal) * 150;
                            return `${x},${y}`;
                          });

                          const pathSist = `M ${pointsSist.join(' L ')}`;
                          const pathPhys = `M ${pointsPhys.join(' L ')}`;

                          // Path para áreas sombreadas
                          const areaSist = `${pathSist} L 580,180 L 30,180 Z`;
                          const areaPhys = `${pathPhys} L 580,180 L 30,180 Z`;

                          // Coordenadas ativas do hover
                          let hoverLineX = null;
                          let hoveredPointSist = null;
                          let hoveredPointPhys = null;

                          if (activeHoverIndex !== null) {
                            const activePt = pts[activeHoverIndex];
                            hoverLineX = 30 + (activeHoverIndex / 29) * 550;
                            hoveredPointSist = {
                              x: hoverLineX,
                              y: 180 - (activePt.sistema / maxVal) * 150
                            };
                            hoveredPointPhys = {
                              x: hoverLineX,
                              y: 180 - (activePt.fisico / maxVal) * 150
                            };
                          }

                          return (
                            <>
                              {/* Linhas de grade horizontais e rótulos do eixo Y */}
                              {[0, 0.25, 0.5, 0.75, 1].map((ratio, index) => {
                                const yVal = Math.round(maxVal * ratio);
                                const yPos = 180 - ratio * 150;
                                return (
                                  <g key={`grid-y-${index}`} className="opacity-25 font-mono text-[8px] fill-slate-400 text-slate-400">
                                    <line x1="30" y1={yPos} x2="580" y2={yPos} stroke="#334155" strokeWidth="0.5" />
                                    <text x="5" y={yPos + 3} textAnchor="start">{yVal}</text>
                                  </g>
                                );
                              })}

                              {/* Linha correspondente do dia 15 (Conciliação CD) */}
                              <g className="opacity-35 font-mono text-[8px]">
                                <line x1={30 + (14/29) * 550} y1="30" x2={30 + (14/29) * 550} y2="180" stroke="#a78bfa" strokeDasharray="3 3" />
                                <text x={30 + (14/29) * 550 + 4} y="40" fill="#a78bfa" textAnchor="start">Dia 15: Conciliação Efetuada</text>
                              </g>

                              {/* Áreas preenchidas gradientes */}
                              <path d={areaSist} fill="url(#sistGrad)" />
                              <path d={areaPhys} fill="url(#fisGrad)" />

                              {/* Linhas dos Gráficos */}
                              <path d={pathSist} fill="none" stroke="#8b5cf6" strokeWidth="2.5" strokeLinecap="round" />
                              <path d={pathPhys} fill="none" stroke="#f59e0b" strokeWidth="2" strokeDasharray="3 2" strokeLinecap="round" />

                              {/* Rótulos dos Dias do Eixo X (a cada 5 dias) */}
                              {pts.map((d: any, i: number) => {
                                if (i % 5 === 0 || i === 29) {
                                  const x = 30 + (i / 29) * 550;
                                  return (
                                    <text 
                                      key={`lbl-x-${i}`} 
                                      x={x} 
                                      y="196" 
                                      className="font-mono text-[7px] fill-slate-500 opacity-80 text-slate-500" 
                                      textAnchor="middle"
                                    >
                                      {d.dia}
                                    </text>
                                  );
                                }
                                return null;
                              })}

                              {/* Linha vertical e pontos de foco de interatividade ao passar o mouse */}
                              {hoverLineX !== null && hoveredPointSist && hoveredPointPhys && (
                                <>
                                  <line x1={hoverLineX} y1="30" x2={hoverLineX} y2="180" stroke="#475569" strokeWidth="1" />
                                  
                                  {/* Ponto Sistema */}
                                  <circle cx={hoveredPointSist.x} cy={hoveredPointSist.y} r="5.5" fill="#8b5cf6" stroke="#ffffff" strokeWidth="1.5" />
                                  <circle cx={hoveredPointSist.x} cy={hoveredPointSist.y} r="10" fill="#8b5cf6" fillOpacity="0.25" />

                                  {/* Ponto Físico */}
                                  <circle cx={hoveredPointPhys.x} cy={hoveredPointPhys.y} r="4.5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
                                  <circle cx={hoveredPointPhys.x} cy={hoveredPointPhys.y} r="8" fill="#f59e0b" fillOpacity="0.25" />
                                </>
                              )}
                            </>
                          );
                        })()}
                      </svg>

                      {/* Notificação no rodapé do gráfico para interagir */}
                      <div className="text-[9px] font-mono font-bold text-slate-500 text-center select-none pt-1">
                        DICA: Passe o mouse / Arraste sobre o gráfico para consultar as variações diárias
                      </div>
                    </div>

                    {/* SEÇÃO DETALHADA DO DIA HOVER */}
                    <div className="bg-slate-50 p-4 border border-slate-100 rounded-xl space-y-3 min-h-[95px] flex flex-col justify-center">
                      {activeHoverIndex !== null ? (
                        (() => {
                          const hoveredData = historyData.dataPoints[activeHoverIndex];
                          const diff = hoveredData.fisico - hoveredData.sistema;
                          return (
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs animate-fadeIn">
                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-tight">Período Selecionado</span>
                                <strong className="text-slate-800 text-sm font-display flex items-center gap-1.5 mt-0.5">
                                  <Calendar className="w-3.5 h-3.5 text-violet-500 shrink-0" />
                                  {hoveredData.dia}/2026
                                </strong>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-tight">Estoque Sistêmico vs Físico</span>
                                <span className="font-mono text-slate-700 font-bold block mt-0.5">
                                  Sist: {hoveredData.sistema} cx | CD: {hoveredData.fisico} cx
                                </span>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-tight flex items-center gap-1">Diferença em Estoque</span>
                                <strong className={`font-mono block mt-0.5 ${diff < 0 ? 'text-rose-600' : diff > 0 ? 'text-emerald-500' : 'text-slate-800'}`}>
                                  {diff > 0 ? `+${diff}` : diff} cx 
                                  <span className="text-[9px] text-slate-505 font-normal font-sans ml-1">
                                    (R$ {(diff * historyData.custoMedio).toLocaleString('pt-BR', { minimumFractionDigits: 2 })})
                                  </span>
                                </strong>
                              </div>
                              <div>
                                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-tight">Atividades do Dia</span>
                                <p className="text-[11px] font-mono leading-tight mt-0.5 text-slate-650">
                                  {hoveredData.entradas > 0 ? `📥 +${hoveredData.entradas} cx recebidas` : ''}
                                  {hoveredData.saidas > 0 ? ` 📤 -${hoveredData.saidas} cx expedidas` : ''}
                                  {hoveredData.entradas === 0 && hoveredData.saidas === 0 ? '🔇 Sem movimentações registradas' : ''}
                                </p>
                              </div>
                            </div>
                          );
                        })()
                      ) : (
                        <p className="text-[11px] text-slate-400 italic text-center">
                          Passe o ponteiro sobre qualquer data do gráfico acima para calcular a acurácia, faturamento do dia correspondente e valorações absolutas do SKU histórico.
                        </p>
                      )}
                    </div>
                  </div>

                </div>
              ) : null}
            </div>

          </div>
        </div>
      ) : activeReconView === 'historico' ? (
        /* Novo Módulo de Histórico de Conciliações */
        <div className="space-y-6 animate-fadeIn" id="historico-conciliacoes-container">
          {/* Guia Interativo Branded Pau Brasil */}
          <PauBrasilGuide currentView={activeReconView} onViewChange={setActiveReconView} />

          {/* PAINEL DE CONSULTA DE HISTÓRICO DE CONCILIAÇÃO */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lux space-y-6 text-white text-left">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 opacity-95">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 font-mono">Histórico de Auditoria & Conciliação</span>
                </div>
                <h3 className="font-display font-extrabold text-white text-base tracking-tight flex items-center gap-2">
                  <span>📜 Histórico de Conciliações Realizadas (Últimos 30 Dias)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Verifique o registro auditado de todas as conciliações de estoque executadas no CD central com as respectivas divergências consolidadas em reais e hectolitros.
                </p>
              </div>
            </div>

            {/* Lista de Conciliações */}
            {!historicoConciliacoes || historicoConciliacoes.length === 0 ? (
              <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-850 p-6">
                <p className="text-slate-400 text-sm">Nenhuma conciliação registrada nos últimos 30 dias.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {historicoConciliacoes.map((reconciliation: any) => {
                  const dataFormatada = new Date(reconciliation.data).toLocaleString("pt-BR", {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                  });

                  const isExpanded = expandedConciliacaoId === reconciliation.id;
                  const showEntire = showEntireSnapshot[reconciliation.id] || false;

                  // Seleciona os itens conforme a aba ativa
                  const itemsToDisplay = showEntire 
                    ? (reconciliation.todosItensInventario || reconciliation.itensDivergentes || [])
                    : (reconciliation.itensDivergentes || []);

                  return (
                    <div 
                      key={reconciliation.id} 
                      className="bg-slate-950 border border-slate-850 rounded-xl overflow-hidden shadow-sm transition hover:border-slate-750"
                    >
                      {/* Top Bar da Conciliação */}
                      <div 
                        onClick={() => setExpandedConciliacaoId(isExpanded ? null : reconciliation.id)}
                        className="p-4 bg-slate-900/40 border-b border-slate-850 flex flex-col lg:flex-row lg:items-center justify-between gap-3 text-xs cursor-pointer select-none hover:bg-slate-900/60 transition"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-indigo-400 font-mono font-black uppercase text-xs">{reconciliation.id}</span>
                            <span className="text-slate-500">•</span>
                            <span className="text-slate-300 font-medium flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-slate-400" />
                              {dataFormatada}
                            </span>
                            <span className="text-slate-500">•</span>
                            {reconciliation.isConsolidadorRotina || reconciliation.skusAjustados === 0 ? (
                              <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded font-black text-[9px] uppercase border border-emerald-500/20">
                                ✓ CD Balanceado de Rotina
                              </span>
                            ) : (
                              <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded font-black text-[9px] uppercase border border-amber-500/20">
                                🚨 Ajuste Físico-Fiscal ({reconciliation.skusAjustados} SKUs)
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Executado por: <strong className="text-slate-300 font-mono">{reconciliation.usuario}</strong>
                          </p>
                        </div>

                        <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
                          <div className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg flex flex-col justify-center">
                            <span className="text-[8px] text-slate-400 block font-sans uppercase">SKUs Ajustados</span>
                            <strong className="text-white text-xs">{reconciliation.skusAjustados} itens</strong>
                          </div>
                          <div className={`px-2.5 py-1 rounded-lg border flex flex-col justify-center ${
                            reconciliation.totalValorAjustado < 0 
                              ? 'bg-rose-950/45 border-rose-900/60 text-rose-300' 
                              : reconciliation.totalValorAjustado > 0 
                              ? 'bg-emerald-950/45 border-emerald-900/60 text-emerald-300' 
                              : 'bg-slate-950 border-slate-850 text-slate-300'
                          }`}>
                            <span className="text-[8px] text-slate-400 block font-sans uppercase">Valoração Ajustada</span>
                            <strong className="text-xs">
                              {reconciliation.totalValorAjustado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </strong>
                          </div>
                          <div className={`px-2.5 py-1 rounded-lg border flex flex-col justify-center ${
                            reconciliation.totalHectolitrosAjustado < 0 
                              ? 'bg-rose-950/45 border-rose-900/60 text-rose-300' 
                              : reconciliation.totalHectolitrosAjustado > 0 
                              ? 'bg-emerald-950/45 border-emerald-900/60 text-emerald-300' 
                              : 'bg-slate-950 border-slate-850 text-slate-305'
                          }`}>
                            <span className="text-[8px] text-slate-400 block font-sans uppercase">Volume Líquido</span>
                            <strong className="text-xs font-bold">
                              {reconciliation.totalHectolitrosAjustado > 0 ? `+` : ''}
                              {formatHectolitro(reconciliation.totalHectolitrosAjustado)} HL
                            </strong>
                          </div>
                          <span className="text-slate-400 ml-1 font-bold text-sm shrink-0">
                            {isExpanded ? "▲" : "▼"}
                          </span>
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="p-4 space-y-4 animate-fadeIn">
                          {/* Controles do Menu de Conexão do Snapshot de Estoque */}
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950/50 p-2 rounded-xl border border-slate-850">
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => setShowEntireSnapshot(prev => ({ ...prev, [reconciliation.id]: false }))}
                                className={`px-3 py-1.5 rounded-lg font-bold text-[10.5px] transition cursor-pointer font-sans uppercase ${
                                  !showEntire 
                                    ? 'bg-indigo-600 text-white shadow' 
                                    : 'bg-slate-900 hover:bg-slate-800 text-slate-400'
                                }`}
                              >
                                Divergências Corrigidas ({reconciliation.itensDivergentes?.length || 0})
                              </button>
                              <button
                                type="button"
                                onClick={() => setShowEntireSnapshot(prev => ({ ...prev, [reconciliation.id]: true }))}
                                className={`px-3 py-1.5 rounded-lg font-bold text-[10.5px] transition cursor-pointer font-sans uppercase ${
                                  showEntire 
                                    ? 'bg-indigo-600 text-white shadow' 
                                    : 'bg-slate-900 hover:bg-slate-800 text-slate-400'
                                }`}
                              >
                                Todo o Inventário Consolidado ({reconciliation.todosItensInventario?.length || reconciliation.itensDivergentes?.length || 0})
                              </button>
                            </div>

                            {/* Exportar arquivo do Histórico */}
                            <button
                              type="button"
                              onClick={() => {
                                if (itemsToDisplay.length === 0) return;
                                const headers = [
                                  'DATA AUDITORIA',
                                  'COD RECON',
                                  'SKU',
                                  'DESCRICAO',
                                  'FISICO OBSERVADO (CX)',
                                  'SISTEMICO ERP (CX)',
                                  'AJUSTE/DESVIO (CX)',
                                  'PRECO UNITARIO (R$)',
                                  'AJUSTE FINANCEIRO (R$)',
                                  'DESVIO LIQUIDO (HL)',
                                  'STATUS'
                                ];

                                const csvRows = [
                                  headers.join(';'),
                                  ...itemsToDisplay.map((it: any) => [
                                    new Date(reconciliation.data).toLocaleDateString('pt-BR'),
                                    reconciliation.id,
                                    it.sku,
                                    it.descricao.replace(/;/g, ' ').toUpperCase(),
                                    it.estoqueFisicoCaixas.toString(),
                                    it.estoqueSistemaCaixas.toString(),
                                    it.diferencaCaixas.toString(),
                                    it.custoMedio.toFixed(2),
                                    (it.diferencaReais || 0).toFixed(2),
                                    (it.diferencaHectolitros || 0).toString(),
                                    it.diferencaCaixas === 0 ? 'CONSOLIDADO EM CONFORMIDADE' : 'DIVERGENCIA SINCRONIZADA'
                                  ].join(';'))
                                ];

                                const csvContent = '\uFEFF' + csvRows.join('\n');
                                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement('a');
                                link.href = url;
                                link.setAttribute('download', `CD_SNAPSHOT_${reconciliation.id}_${new Date(reconciliation.data).toISOString().slice(0,10)}.csv`);
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                              }}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[10px] py-1.5 px-3 rounded-lg flex items-center gap-1 transition-all active:scale-95 cursor-pointer max-w-max border border-emerald-500/25 uppercase tracking-wide"
                            >
                              📥 Exportar Snapshot (.CSV)
                            </button>
                          </div>

                          {/* Tabela de Itens Ajustados */}
                          {itemsToDisplay.length === 0 ? (
                            <div className="text-center py-8 bg-slate-950/30 rounded-xl border border-slate-850/60 p-4">
                              <p className="text-slate-400 text-xs italic">Nenhuma divergência registrada neste inventário.</p>
                            </div>
                          ) : (
                            <div className="overflow-x-auto">
                              <table className="w-full text-left border-collapse text-xs text-slate-300">
                                <thead>
                                  <tr className="border-b border-slate-850 text-slate-400 text-[10px] uppercase font-mono tracking-wider">
                                    <th className="py-2 font-black pr-2">SKU</th>
                                    <th className="py-2 font-black">Descrição</th>
                                    <th className="py-2 font-black text-right">Estoque Sistêmico</th>
                                    <th className="py-2 font-black text-right">Estoque Físico</th>
                                    <th className="py-2 font-black text-right">Diferença (cx)</th>
                                    <th className="py-2 font-black text-right">Diferença (Reais)</th>
                                    <th className="py-2 font-black text-right font-mono">Diferença (Hecto)</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-850/40">
                                  {itemsToDisplay.map((it: any) => {
                                    const isBalanced = it.diferencaCaixas === 0;
                                    return (
                                      <tr key={it.sku} className="hover:bg-slate-900/30 select-text transition">
                                        <td className="py-2.5 font-mono text-slate-400 pr-2">{it.sku.replace(/^0+/, '')}</td>
                                        <td className="py-2.5 font-medium text-slate-200" title={it.descricao}>{it.descricao}</td>
                                        <td className="py-2.5 text-right font-mono text-slate-400">{it.estoqueSistemaCaixas} cx</td>
                                        <td className="py-2.5 text-right font-mono text-slate-200">{it.estoqueFisicoCaixas} cx</td>
                                        <td className={`py-2.5 text-right font-mono font-bold ${
                                          isBalanced ? 'text-emerald-400' : it.diferencaCaixas < 0 ? 'text-rose-400' : 'text-emerald-400'
                                        }`}>
                                          {isBalanced ? (
                                            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.2 rounded font-extrabold uppercase border border-emerald-500/15">
                                              ✓ OK
                                            </span>
                                          ) : (
                                            `${it.diferencaCaixas > 0 ? '+' : ''}${it.diferencaCaixas} cx`
                                          )}
                                        </td>
                                        <td className={`py-2.5 text-right font-mono font-bold ${
                                          isBalanced ? 'text-slate-400' : it.diferencaReais < 0 ? 'text-rose-400' : 'text-emerald-400'
                                        }`}>
                                          {isBalanced ? (
                                            <span className="text-slate-500 font-normal">R$ 0,00</span>
                                          ) : (
                                            (it.diferencaReais || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
                                          )}
                                        </td>
                                        <td className={`py-2.5 text-right font-mono ${
                                          isBalanced ? 'text-slate-450' : it.diferencaHectolitros < 0 ? 'text-rose-400' : 'text-emerald-400'
                                        }`}>
                                          {isBalanced ? (
                                            <span className="text-slate-500 text-[10px]">0,00 HK</span>
                                          ) : (
                                            `${it.diferencaHectolitros > 0 ? '+' : ''}${formatHectolitro(it.diferencaHectolitros)} HL`
                                          )}
                                        </td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : null}

      {/* 4. Módulo de Integração ERP e Upload de bases de dados auxiliares */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Importador de Contagem Diária (JSON/CSV) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4" id="import-sim-frame">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-indigo-600 shrink-0" />
              <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Sincronizador e Importador ERP Diário</h4>
            </div>
            
            {/* Botão de Download da Base Template */}
            <button
              type="button"
              onClick={baixarTemplateCSV}
              className="text-[10px] font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-700 px-3 py-1.5 rounded-lg border border-indigo-100 flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto"
              title="Baixar modelo de planilha CSV pré-preenchida com SKUs atuais"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Baixar Base CSV Modelo</span>
            </button>
          </div>

          <p className="text-[11px] text-slate-500 leading-relaxed">
            Sincronize o WMS Consili e regularize contagens em massa. Baixe a planilha base contendo todos os produtos cadastrados do CD, insira as contagens e faça o upload ou cole as linhas abaixo.
          </p>

          {/* Abas do painel */}
          <div className="flex border-b border-slate-100 gap-1.5 p-1 bg-slate-50 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setActiveImportTab('upload');
                setFileError(null);
              }}
              className={`flex-1 py-1.5 px-3 text-[11px] rounded-lg font-bold text-center transition cursor-pointer ${activeImportTab === 'upload' ? 'bg-white text-indigo-700 shadow-sm border border-slate-150/40' : 'text-slate-500 hover:text-slate-800/80 hover:bg-slate-100/50'}`}
            >
              Upload do Documento (Recomendado)
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveImportTab('manual');
                setFileError(null);
              }}
              className={`flex-1 py-1.5 px-3 text-[11px] rounded-lg font-bold text-center transition cursor-pointer ${activeImportTab === 'manual' ? 'bg-white text-indigo-700 shadow-sm border border-slate-150/40' : 'text-slate-500 hover:text-slate-800/80 hover:bg-slate-100/50'}`}
            >
              Colar Código (JSON / Texto CSV)
            </button>
          </div>

          <div className="space-y-3 pt-1">
            {activeImportTab === 'upload' ? (
              /* TAB 1: FILE DROPZONE & UPLOADER */
              <div className="space-y-3">
                {!uploadedFileName ? (
                  <div
                    onDragEnter={handleDrag}
                    onDragOver={handleDrag}
                    onDragLeave={handleDrag}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-xl p-8 text-center transition-all relative flex flex-col items-center justify-center min-h-[140px] cursor-pointer ${
                      isDragActive 
                        ? 'border-indigo-500 bg-indigo-50/55 shadow-inner scale-[0.99]' 
                        : 'border-slate-200 hover:border-indigo-400 hover:bg-slate-50/50 bg-white'
                    }`}
                  >
                    <input
                      type="file"
                      id="csv-file-elem"
                      accept=".csv"
                      onChange={handleFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    
                    <Upload className="w-8 h-8 text-slate-400 mb-2.5 animate-pulse" />
                    <p className="text-xs font-bold text-slate-700">Arrastar & Soltar arquivo de estoque aqui</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">ou clique para procurar no seu computador (Suporta .csv)</p>
                  </div>
                ) : (
                  /* Mostra Card do arquivo carregador */
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-205 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100 shrink-0">
                        <FileSpreadsheet className="w-5 h-5" />
                      </div>
                      <div className="space-y-0.5 min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate block">{uploadedFileName}</p>
                        <p className="text-[10px] text-slate-400">Arquivo de contagem pronto para análise</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setUploadedFileName(null);
                        setPreviewParsedList(null);
                        setImportText("");
                      }}
                      className="text-slate-400 hover:text-rose-600 p-1 rounded-lg transition"
                      title="Excluir arquivo e redefinir"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            ) : (
              /* TAB 2: MANUAL TEXTAREA */
              <div className="space-y-3">
                <textarea 
                  rows={4}
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder="Exemplo CSV:&#10;SKU;EstoqueFisico;EstoqueSistema&#10;CER001;1390;1450&#10;NAB002;800;780"
                  className="w-full bg-slate-50 border border-slate-200 text-xs font-mono p-3 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white"
                />
                
                <div className="flex gap-2 justify-end">
                  <button 
                    type="button" 
                    onClick={() => setImportText(`[
  {"sku": "CER001", "estoqueFisicoCaixas": 1390, "estoqueSistemaCaixas": 1450},
  {"sku": "CER003", "estoqueFisicoCaixas": 300, "estoqueSistemaCaixas": 320},
  {"sku": "NAB004", "estoqueFisicoCaixas": 250, "estoqueSistemaCaixas": 210}
]`)}
                    className="text-[10px] border border-slate-200 text-slate-600 font-semibold py-1.5 px-3 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    Exemplo JSON
                  </button>
                  <button
                    type="button"
                    onClick={() => processFileContent(importText, "Colado manual")}
                    className="bg-indigo-600 text-white font-bold text-xs py-1.5 px-3.5 rounded-lg hover:bg-indigo-700 cursor-pointer transition shadow"
                  >
                    Analisar Dados
                  </button>
                </div>
              </div>
            )}

            {/* Mensagem de Erro */}
            {fileError && (
              <div className="p-2.5 bg-rose-50 border border-rose-100 text-rose-700 text-[10px] font-semibold rounded-lg flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{fileError}</span>
              </div>
            )}

            {/* Mensagem de Sucesso */}
            {importSuccess && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-100 text-emerald-700 text-[10px] font-semibold rounded-lg flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Integração de arquivo realizada! Os números do inventário do WMS foram sincronizados no banco de dados.</span>
              </div>
            )}

            {/* LISTA DE PREVIEW DOS DADOS PARSADOS DO CSV */}
            {previewParsedList && previewParsedList.length > 0 && (
              <div className="bg-slate-50 rounded-xl p-3 border border-indigo-100 space-y-2 mt-4">
                <div className="flex items-center justify-between border-b border-indigo-50/70 pb-1.5">
                  <h5 className="text-[10px] font-bold text-indigo-900 uppercase">Validação de Linhas Detectadas ({previewParsedList.length} itens)</h5>
                  <span className="text-[9px] bg-indigo-100 text-indigo-700 px-1.5 py-0.2 rounded font-semibold">Status de Importação</span>
                </div>
                
                <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1 text-[11px] font-mono">
                  {previewParsedList.map((item, idx) => (
                    <div key={`${item.sku}-${idx}`} className="flex items-center justify-between bg-white p-2 rounded-lg border border-slate-150">
                      <div className="space-y-0.5 min-w-0 flex-1 pr-2">
                        <span className="font-extrabold text-slate-800">{item.sku.replace(/^0+/, '') || '0'}</span>
                        <p className="text-[9px] text-slate-400 truncate max-w-[150px] sm:max-w-[200px] font-sans">{item.descricao}</p>
                      </div>
                      
                      <div className="flex items-center gap-4 text-right shrink-0">
                        {detectedImportType === 'erp_catalog' ? (
                          <div className="space-y-0.5">
                            <span className="text-[8px] text-slate-400 block font-sans uppercase font-bold tracking-wider">Metadados Fiscais de SKU</span>
                            <span className="font-semibold text-slate-700">Pallet: {item.fatorPallet} cx | Sku: {item.fatorSku} un | Hecto: {item.fatorHecto} HL</span>
                            <span className="text-[9px] text-indigo-600 block font-sans font-semibold">
                              Custo Médio: R$ {item.custoPorSku?.toLocaleString('pt-BR', { minimumFractionDigits: 4 })}
                            </span>
                          </div>
                        ) : detectedImportType === 'divergencias_congeladas' ? (
                          <div className="space-y-0.5">
                            <span className="text-[8px] text-slate-400 block font-sans uppercase font-bold tracking-wider">Anomalia Congelada / Desvio</span>
                            <span className={`font-semibold ${item.diferencaCaixas >= 0 ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}`}>Diferença: {item.diferencaCaixas} cx</span>
                            <span className="text-[9px] text-slate-500 block font-sans">
                              Custo Sku: R$ {item.custoPorSku?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} | Obs: {item.observacao || "Memorial"}
                            </span>
                          </div>
                        ) : (
                          <div className="space-y-0.5">
                            <span className="text-[8px] text-slate-400 block font-sans uppercase font-bold tracking-wider">Físico [AC] x Sistêmico [AB]</span>
                            <span className="font-semibold text-slate-700">{item.estoqueFisicoCaixas} cx vs {item.estoqueSistemaCaixas} cx</span>
                            {item.custoMedio && (
                              <span className="text-[9px] text-indigo-600 block font-sans font-semibold">
                                Custo [AD]: R$ {item.custoMedio.toFixed(2)} | Valor CD: R$ {item.valorEstoqueFisicoReal?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                              </span>
                            )}
                          </div>
                        )}
                        
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                          detectedImportType === 'erp_catalog' 
                            ? 'bg-indigo-50 text-indigo-750'
                            : detectedImportType === 'divergencias_congeladas'
                            ? 'bg-amber-50 text-amber-800 border border-amber-100'
                            : item.status === 'batido' 
                            ? 'bg-emerald-50 text-emerald-700' 
                            : item.status === 'novo' 
                            ? 'bg-sky-50 text-sky-700' 
                            : 'bg-rose-50 text-rose-700'
                        }`}>
                          {detectedImportType === 'erp_catalog' 
                            ? 'Cadastro ERP' 
                            : detectedImportType === 'divergencias_congeladas' 
                            ? 'Desvio Congelado' 
                            : item.status === 'batido' 
                            ? 'Batido' 
                            : item.status === 'novo' 
                            ? 'Novo SKU' 
                            : 'Divergente'
                          }
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 justify-end pt-2 border-t border-indigo-50/70">
                  <button
                    type="button"
                    onClick={() => {
                      setPreviewParsedList(null);
                      setUploadedFileName(null);
                      setImportText("");
                    }}
                    className="text-slate-500 hover:text-slate-800/80 font-bold text-xs py-1.5 px-3 rounded-lg transition"
                  >
                    Anular
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmImport}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-1.5 px-4 rounded-lg flex items-center gap-1 transition shadow cursor-pointer"
                  >
                    <Check className="w-4 h-4" /> Confirmar & Sincronizar WMS
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal de Confirmação Customizado (Iframe/Sandbox Safe) */}
        {showReconModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-[9999] animate-fadeIn">
            <div className="bg-white rounded-2xl border border-slate-100 max-w-md w-full p-6 shadow-2xl space-y-4">
              <div className="flex items-center gap-3 text-amber-600 pb-2 border-b border-slate-100">
                <AlertTriangle className="w-6 h-6 animate-pulse" />
                <h4 className="font-display font-extrabold text-slate-910 text-sm">Confirmar Conciliação de Estoque</h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Você confirma o ajuste permanente de saldo do sistema do ERP? Isso atualizará o estoque sistêmico para coincidir <strong>100% com as quantidades físicas auditadas</strong> (obtido somando saldo físico e itens congelados), gerando um passivo com o diário contábil da distribuidora.
              </p>
              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReconModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={isReconciling}
                  onClick={async () => {
                    setIsReconciling(true);
                    try {
                      await onTriggerReconciliation(operatorEmail);
                      setShowReconModal(false);
                    } catch (error) {
                      console.error(error);
                    } finally {
                      setIsReconciling(false);
                    }
                  }}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md active:scale-95 transition cursor-pointer disabled:opacity-50"
                >
                  {isReconciling ? "Sincronizando..." : "Confirmar Ajuste"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Exportador / Cópia de Relatório Fiscal Oculto */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4 text-slate-700" id="raw-fiscal-frame">
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-indigo-600" />
            <h4 className="font-display font-bold text-slate-800 text-sm tracking-tight">Câmera de Monitoramento Fiscal Oculta</h4>
          </div>
          <p className="text-[11px] text-slate-500">
            Abaixo estão dados agregados em tempo real utilizados pelas equipes fiscais remotas que não interferem na interface principal, garantindo a leveza e foco operacional exigido pela liderança.
          </p>

          <div className="bg-slate-950 p-4 rounded-xl text-[11px] font-mono text-slate-400 max-h-40 overflow-y-auto space-y-1">
            <div className="text-orange-400">// INTEGRITY SYSTEM CLOUD SYNC PORT 3000</div>
            <div className="text-slate-500">[{new Date().toISOString()}] - Connected to Central ERP Database</div>
            <div className="text-emerald-400">STATUS: RECONCILIATION LIVE_LISTENER ACTIVE</div>
            <div className="mt-2 text-slate-300">
              {produtos.map(p => (
                <div key={p.sku} className="hover:text-white">
                  SKU: {p.sku.replace(/^0+/, '') || '0'} | Saldo Fiscal: {Math.round(p.estoqueSistemaCaixas)} cx | Físico CD: {p.estoqueFisicoCaixas} cx | {p.temDivergencia ? '⚠️ DISCREPÂNCIA' : '✅ BATIDO'}
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
