/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  WmsPosicao, 
  ProdutoConsolidado, 
  Categoria, 
  CurvaABC 
} from '../types';
import { 
  Building2, 
  Layers, 
  Navigation, 
  Sparkles, 
  Map, 
  Info, 
  SlidersHorizontal,
  FolderLock,
  ArrowRight,
  Gauge,
  AlertTriangle,
  XCircle,
  Clock,
  ExternalLink
} from 'lucide-react';

interface WmsLayoutProps {
  layout: WmsPosicao[];
  produtos: ProdutoConsolidado[];
}

export default function WmsLayout({ layout, produtos }: WmsLayoutProps) {
  // Filtro de destaque de SKU
  const [highlightedSku, setHighlightedSku] = useState<string | null>(null);
  
  // Filtro de visualização rápida de Curva ABC
  const [focoCurva, setFocoCurva] = useState<'TODOS' | 'A' | 'B' | 'C' | 'Mkt'>('TODOS');

  // Estado para rua selecionada para o painel de detalhes lateral
  const [selectedRua, setSelectedRua] = useState<string | null>(null);

  // Cria um dicionário de produtos por SKU para consulta direta super veloz
  const prodDict = useMemo(() => {
    const dict: Record<string, ProdutoConsolidado> = {};
    produtos.forEach(p => { dict[p.sku] = p; });
    return dict;
  }, [produtos]);

  // Total de posições e ocupação
  const estatisticasCD = useMemo(() => {
    const totalPosicoes = layout.length;
    const ocupadas = layout.filter(p => p.skuAlocado !== null).length;
    const taxaOcupacao = totalPosicoes > 0 ? (ocupadas / totalPosicoes) * 100 : 0;
    
    let totalPalletsSendoArmazenados = 0;
    layout.forEach(p => totalPalletsSendoArmazenados += p.palletsAlocados);

    return {
      totalPosicoes,
      ocupadas,
      taxaOcupacao: Math.round(taxaOcupacao * 10) / 10,
      totalPallets: Math.round(totalPalletsSendoArmazenados * 10) / 10
    };
  }, [layout]);

  // Agrupa posições por Rua (Corredor) para renderizar como Ruas separadas no CD
  const ruasWms = useMemo(() => {
    const map: Record<string, WmsPosicao[]> = {};
    layout.forEach(pos => {
      if (!map[pos.rua]) {
        map[pos.rua] = [];
      }
      map[pos.rua].push(pos);
    });

    // Ordena as posições de cada rua para renderização ordenada (Modulo crescente, nivel decrescente para o picking ficar abaixo)
    Object.keys(map).forEach(rua => {
      map[rua].sort((a, b) => {
        if (a.modulo !== b.modulo) {
          return a.modulo - b.modulo;
        }
        return b.nivel - a.nivel; // Nível Superior Racks em cima, Nível 1 Picking embaixo!
      });
    });

    return map;
  }, [layout]);

  // Calcula capacidade, ocupação, SKUs e status para cada rua em tempo real
  const ruasCalculadas = useMemo(() => {
    const metrics: Record<string, {
      ruaNome: string;
      capacidadeFisica: number;
      capacidadeOperacional: number; // com empilhamento
      palletsAlocados: number;
      ocupacaoPct: number;
      skusAlocados: string[];
      statusCor: 'Verde' | 'Amarelo' | 'Laranja' | 'Vermelho';
      especialidade: string;
    }> = {};

    Object.keys(ruasWms).forEach((ruaNome) => {
      const posSet = ruasWms[ruaNome];
      let capOperacional = 0;
      let pallets = 0;
      const skus = new Set<string>();

      posSet.forEach(p => {
        capOperacional += p.capacidadePallets;
        pallets += p.palletsAlocados;
        if (p.skuAlocado) skus.add(p.skuAlocado);
      });

      const ocupPct = capOperacional > 0 ? (pallets / capOperacional) * 100 : 0;
      
      let statusCor: 'Verde' | 'Amarelo' | 'Laranja' | 'Vermelho' = 'Verde';
      if (ocupPct > 95) statusCor = 'Vermelho';
      else if (ocupPct > 85) statusCor = 'Laranja';
      else if (ocupPct > 70) statusCor = 'Amarelo';

      let especialidade = "Rack Geral";
      if (["A1", "A2", "A3", "A4"].includes(ruaNome)) {
        especialidade = "Bloco A - Cervejas - Alta Rotatividade";
      } else if (["B1", "B2", "B3", "B4"].includes(ruaNome)) {
        especialidade = "Bloco B - Cervejas / NAB - Picking Integrado";
      } else if (["CB1", "CB2", "CB3"].includes(ruaNome)) {
        especialidade = "Bloco CB Racks - Bebidas Premium & NAB";
      } else if (ruaNome === "CB4") {
        especialidade = "CB4 - Marketing e Vendas - Marketplace (Cross-dock)";
      } else if (["C1", "C2", "C3", "C4"].includes(ruaNome)) {
        especialidade = "Bloco C Paredão - Vertical Blindado (Giro Longo)";
      }

      metrics[ruaNome] = {
        ruaNome,
        capacidadeFisica: posSet.length,
        capacidadeOperacional: capOperacional,
        palletsAlocados: Math.round(pallets * 10) / 10,
        ocupacaoPct: Math.round(ocupPct * 10) / 10,
        skusAlocados: Array.from(skus),
        statusCor,
        especialidade
      };
    });

    return metrics;
  }, [ruasWms]);

  // Lista compacta detalhando todas as ruas de forma macro
  const listRuasOrdenadas = useMemo(() => {
    const list = Object.values(ruasCalculadas) as Array<{
      ruaNome: string;
      capacidadeFisica: number;
      capacidadeOperacional: number;
      palletsAlocados: number;
      ocupacaoPct: number;
      skusAlocados: string[];
      statusCor: 'Verde' | 'Amarelo' | 'Laranja' | 'Vermelho';
      especialidade: string;
    }>;
    return [...list].sort((a,b) => {
      // Ordenação coerente por corredor A1..A4, B1..B4, CB1..CB4, C1..C4
      return a.ruaNome.localeCompare(b.ruaNome, undefined, { numeric: true, sensitivity: 'base' });
    });
  }, [ruasCalculadas]);

  return (
    <div className="space-y-6" id="wms-layout-root">
      
      {/* 1. Header do layout e Indicadores Rápidos */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex flex-col lg:flex-row items-center justify-between gap-5">
        <div className="space-y-1.5 text-center lg:text-left">
          <div className="flex items-center justify-center lg:justify-start gap-2">
            <span className="p-1 px-2.5 rounded-full bg-indigo-50 text-indigo-700 text-[10px] font-extrabold uppercase font-mono tracking-widest flex items-center gap-1">
              <Map className="w-3 h-3" /> Mapa Dinâmico
            </span>
            <span className="text-slate-400 text-xs font-semibold font-mono">| Mapeamento de Layout WMS 3D</span>
          </div>
          <h2 className="text-lg font-bold font-display text-slate-800 tracking-tight">Layout Físico de Racks & Estrutura Física WMS</h2>
          <p className="text-xs text-slate-500 max-w-xl">
            16 corredores divididos por Bloco (A, B, CB, C - Paredão), área especial de Marketing e Vendas (CB4) e separação de Picking integrada. Clique nas ruas para ver vistorias operacionais.
          </p>
        </div>

        {/* Células de Estatísticas de Rack */}
        <div className="flex gap-4 select-none shrink-0" id="wms-core-stats">
          <div className="bg-slate-50 border border-slate-100 p-2.5 px-4 rounded-xl text-center">
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wide">Ocupação de Posições</span>
            <span className="text-sm font-bold text-slate-800 font-mono">{estatisticasCD.taxaOcupacao}%</span>
            <span className="text-[9px] text-slate-500 block">{estatisticasCD.ocupadas} de {estatisticasCD.totalPosicoes} slots</span>
          </div>
          <div className="bg-slate-50 border border-slate-100 p-2.5 px-4 rounded-xl text-center">
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wide">Total de Pallets Estocados</span>
            <span className="text-sm font-bold text-slate-800 font-mono">{estatisticasCD.totalPallets} PL</span>
            <span className="text-[9px] text-slate-500 block">Estoque CD Ativo</span>
          </div>
        </div>
      </div>

      {/* 2. Lista Rápida de Ruas com Cores de Status */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-50 pb-2">
          <SlidersHorizontal className="w-4 h-4 text-slate-500" />
          <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">Monitoramento de Corredores (Status de Ocupação Operacional)</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {listRuasOrdenadas.map((rua) => {
            let statusBadge = "border-slate-200 bg-slate-50/50";
            let indicatorColor = "bg-emerald-500";
            if (rua.statusCor === 'Vermelho') {
              statusBadge = "bg-rose-50 border-rose-200 animate-pulse";
              indicatorColor = "bg-rose-500";
            } else if (rua.statusCor === 'Laranja') {
              statusBadge = "bg-orange-50 border-orange-200";
              indicatorColor = "bg-orange-500";
            } else if (rua.statusCor === 'Amarelo') {
              statusBadge = "bg-amber-50 border-amber-200";
              indicatorColor = "bg-amber-400";
            }

            return (
              <div 
                key={rua.ruaNome}
                onClick={() => setSelectedRua(rua.ruaNome)}
                className={`p-3 rounded-xl border transition-all cursor-pointer select-none text-center ${statusBadge} ${selectedRua === rua.ruaNome ? 'ring-2 ring-indigo-600 border-indigo-600 bg-white shadow-md' : 'hover:shadow-sm'}`}
              >
                <div className="flex items-center justify-center gap-1.5 mb-1">
                  <span className={`w-2.0 h-2.0 rounded-full ${indicatorColor}`}></span>
                  <span className="font-mono font-extrabold text-xs text-slate-900">{rua.ruaNome}</span>
                </div>
                <div className="text-[10px] space-y-0.5">
                  <span className="font-bold text-slate-800">{rua.ocupacaoPct}% Ocup.</span>
                  <span className="text-slate-400 block font-mono">{rua.palletsAlocados}/{rua.capacidadeOperacional} PL</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-6">
        
        {/* 3. ZONA DO MAPA INTERATIVO - CD (Lado Esquerdo, ocupando 8 colunas) */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-indigo-600" />
              <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight">Racks Verticais (Grid do Galpão)</h3>
            </div>
            {/* Filtro Rápido Visual */}
            <div className="flex items-center gap-1.5 bg-slate-50 p-1 rounded-xl shrink-0 text-[10px] font-bold">
              <span className="text-slate-400 px-1">Foco Giro:</span>
              {(['TODOS', 'A', 'B', 'C', 'Mkt'] as const).map((curva) => (
                <button
                  key={curva}
                  type="button"
                  onClick={() => setFocoCurva(curva)}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${focoCurva === curva ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
                >
                  {curva === 'Mkt' ? 'Marketplace' : curva === 'TODOS' ? 'Ver Todos' : `Curva ${curva}`}
                </button>
              ))}
            </div>
          </div>

          {/* Renderizador de Ruas Logísticas */}
          <div className="space-y-8 animate-fade-in" id="warehouse-corridors-map">
            {Object.entries(ruasWms).map(([ruaNome, posicoesRaw]) => {
              const posicoes = posicoesRaw as WmsPosicao[];
              const calc = ruasCalculadas[ruaNome];
              
              return (
                <div key={ruaNome} className="space-y-2.5 border-b border-dashed border-slate-100 pb-4 last:border-0 last:pb-0">
                  
                  {/* Título da Rua */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedRua(ruaNome)}
                        className={`font-mono font-extrabold text-xs px-3 py-0.5 rounded shadow-sm transition-all text-white ${calc?.statusCor === 'Vermelho' ? 'bg-rose-600 animate-pulse' : calc?.statusCor === 'Laranja' ? 'bg-orange-500' : calc?.statusCor === 'Amarelo' ? 'bg-amber-505 text-slate-900 bg-amber-400' : 'bg-slate-900'}`}
                      >
                        {ruaNome}
                      </button>
                      <span className="text-[10px] text-slate-500 font-sans font-semibold flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${calc?.statusCor === 'Vermelho' ? 'bg-rose-500 animate-ping' : calc?.statusCor === 'Laranja' ? 'bg-orange-400' : 'bg-emerald-500'}`}></span>
                        {calc?.especialidade}
                      </span>
                    </div>
                    <button 
                      type="button"
                      onClick={() => setSelectedRua(ruaNome)}
                      className="text-[9px] font-mono text-indigo-600 hover:underline font-bold flex items-center gap-0.5 cursor-pointer"
                    >
                      Ver Ocupação <ExternalLink className="w-2.5 h-2.5" />
                    </button>
                  </div>

                  {/* Blocos de Grid vertical e horizontal. Agrupamos por Módulo */}
                  <div className="overflow-x-auto whitespace-nowrap scrollbar-thin py-2">
                    <div className="inline-flex gap-3 min-w-full">
                      {Array.from({ length: Math.max(...posicoes.map(p => p.modulo)) }).map((_, modIdx) => {
                        const moduloNum = modIdx + 1;
                        // Filtra posições do módulo atual
                        const posicoesModulo = posicoes.filter(p => p.modulo === moduloNum);
                        if (posicoesModulo.length === 0) return null;

                        return (
                          <div key={moduloNum} className="w-24 shrink-0 space-y-1.5 bg-slate-50 p-1.5 rounded-xl border border-slate-150">
                            <span className="text-[9px] font-bold text-slate-400 block text-center font-mono">Módulo {String(moduloNum).padStart(2, '0')}</span>
                            
                            {/* Desenha as posições verticais (Nível racks decrescente para o picking ficar abaixo) */}
                            <div className="space-y-1 animate-fade-in">
                              {posicoesModulo.map((pos) => {
                                const prod = pos.skuAlocado ? prodDict[pos.skuAlocado] : null;

                                // Aplicação de filtros
                                let opacityClass = "opacity-100 scale-100";
                                if (highlightedSku && pos.skuAlocado !== highlightedSku) {
                                  opacityClass = "opacity-20 scale-95 border-slate-100";
                                } else if (focoCurva !== 'TODOS') {
                                  if (focoCurva === 'Mkt' && prod?.categoria !== 'Marketplace') {
                                    opacityClass = "opacity-20 scale-95 border-slate-100";
                                  } else if (focoCurva !== 'Mkt' && prod?.curvaABC !== focoCurva) {
                                    opacityClass = "opacity-20 scale-95 border-slate-100";
                                  }
                                }

                                // Cores por Área de Destinação e Giro do SKU
                                let corRackBlock = "bg-slate-200 border-slate-300 text-slate-500 hover:bg-slate-350";
                                
                                if (pos.skuAlocado && prod) {
                                  if (prod.categoria === 'Marketplace') {
                                    corRackBlock = "bg-sky-500 border-sky-600 text-white hover:bg-sky-600 shadow-sm";
                                  } else if (prod.curvaABC === 'A') {
                                    corRackBlock = "bg-emerald-500 border-emerald-600 text-white hover:bg-emerald-600 shadow-sm";
                                  } else if (prod.curvaABC === 'B') {
                                    corRackBlock = "bg-amber-500 border-amber-600 text-slate-900 hover:bg-amber-650 shadow-sm";
                                  } else {
                                    corRackBlock = "bg-rose-500 border-rose-600 text-white hover:bg-rose-600 shadow-sm";
                                  }
                                }

                                // Isolar clique para destacar SKU
                                const toggleSkuSelect = (e: React.MouseEvent) => {
                                  e.stopPropagation();
                                  if (pos.skuAlocado) {
                                    if (highlightedSku === pos.skuAlocado) setHighlightedSku(null);
                                    else setHighlightedSku(pos.skuAlocado);
                                  }
                                };

                                return (
                                  <div 
                                    key={pos.id} 
                                    onClick={toggleSkuSelect}
                                    className={`h-9 rounded-lg border-b-2 text-[10px] flex flex-col items-center justify-center font-mono font-bold transition-all cursor-pointer relative group select-none ${corRackBlock} ${opacityClass}`}
                                  >
                                    {pos.skuAlocado ? (
                                      <>
                                        <span className="leading-none text-[9px]">{pos.skuAlocado.replace(/^0+/, '') || '0'}</span>
                                        <span className="text-[7.5px] opacity-95 block tracking-tighter leading-none mt-0.5">
                                          N{pos.nivel} • {pos.palletsAlocados}PL
                                        </span>
                                      </>
                                    ) : (
                                      <span className="text-slate-400 font-sans text-[7.5px] font-normal uppercase">LIVRE N{pos.nivel}</span>
                                    )}

                                    {/* Tooltip Popup dinâmico de alta fidelidade */}
                                    {pos.skuAlocado && prod && (
                                      <div className="absolute hidden group-hover:block bottom-full left-1/2 -translate-x-1/2 mb-1.5 bg-slate-950 text-white text-[10px] p-3 rounded-lg z-50 shadow-2xl pointer-events-none min-w-56 font-sans whitespace-normal">
                                        <div className="flex justify-between items-center border-b border-slate-700 pb-1.5 mb-1.5">
                                          <strong className="font-mono text-indigo-400 text-xs">{pos.skuAlocado.replace(/^0+/, '') || '0'}</strong>
                                          <span className={`text-[8px] font-bold uppercase px-1.5 py-0.5 rounded ${prod.categoria === 'Marketplace' ? 'bg-sky-500' : prod.curvaABC === 'A' ? 'bg-emerald-500' : prod.curvaABC === 'B' ? 'bg-amber-500 text-slate-900 font-extrabold pb-0.5 bg-amber-400' : 'bg-rose-500'}`}>
                                            {prod.categoria === 'Marketplace' ? 'Marketplace' : `Curva ${prod.curvaABC}`}
                                          </span>
                                        </div>
                                        <div className="space-y-1 text-slate-300">
                                          <p className="line-clamp-2 leading-snug"><span className="text-slate-500 text-[9px]">Fisc:</span> {prod.descricao}</p>
                                          <div className="grid grid-cols-2 gap-1 pt-1 border-t border-slate-800 text-[8.5px] font-mono">
                                            <div>
                                              <span className="text-slate-500">Posição:</span>
                                              <span className="text-white block font-bold">{pos.id}</span>
                                            </div>
                                            <div>
                                              <span className="text-slate-500">Área CD:</span>
                                              <span className="text-white block font-bold truncate">{pos.area}</span>
                                            </div>
                                            <div>
                                              <span className="text-slate-500">Estoque WMS:</span>
                                              <span className="text-white block font-bold">{prod.quantidadeAtualCaixas} cx</span>
                                            </div>
                                            <div>
                                              <span className="text-slate-500">Pallets:</span>
                                              <span className="text-white block font-bold">{pos.palletsAlocados} PL</span>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 border-t border-slate-100">
            <span className="flex items-center gap-1"><Info className="w-4 h-4 text-slate-400" /> Clique no número SKU para isolar o produto. Use a lista superior para auditorias de rua.</span>
            <span>Portões de Expedição localizados na Doca Frontal</span>
          </div>

        </div>

        {/* 4. SIDEBAR - DETALHES DE RUA SELECIONADA OU DIRETRIZES (Lado Direito, ocupando 4 colunas) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Painel Interativo de vistoria de rua clicada */}
          {selectedRua ? (() => {
            const ruaData = ruasCalculadas[selectedRua];
            const posSet = ruasWms[selectedRua];
            
            // Filtra os SKUs e quantifica
            const listSkusInfo = ruaData.skusAlocados.map(sku => {
              const p = prodDict[sku];
              const palletsRua = posSet.filter(pos => pos.skuAlocado === sku).reduce((acc, current) => acc + current.palletsAlocados, 0);
              return { sku, p, palletsRua };
            }).filter(item => item.p);

            return (
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xl space-y-4 animate-fade-in text-xs">
                <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                  <div className="space-y-0.5">
                    <span className="bg-slate-900 text-white font-mono font-extrabold text-sm px-2.5 py-0.5 rounded shadow">
                      Vistoria: {selectedRua}
                    </span>
                    <h4 className="font-bold text-slate-800 font-sans text-xs mt-1">Status Interno do Corredor</h4>
                  </div>
                  <button 
                    type="button" 
                    onClick={() => setSelectedRua(null)}
                    className="p-1 text-slate-400 hover:text-slate-950 rounded-lg bg-slate-50 cursor-pointer"
                  >
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>

                {/* KPI Saturação Speedometer */}
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-2 text-center">
                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-semibold font-mono border-b border-slate-150 pb-1">
                    <span>Saturação Operacional</span>
                    <span className="font-bold text-slate-900">{ruaData.ocupacaoPct}%</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${ruaData.statusCor === 'Vermelho' ? 'bg-rose-500' : ruaData.statusCor === 'Laranja' ? 'bg-orange-500' : ruaData.statusCor === 'Amarelo' ? 'bg-amber-400' : 'bg-emerald-500'}`}
                      style={{ width: `${Math.min(100, ruaData.ocupacaoPct)}%` }}
                    ></div>
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Ocupação: <strong className="text-slate-800">{ruaData.palletsAlocados} de {ruaData.capacidadeOperacional} Pallets</strong> operacionais. Stacking autorizado.
                  </p>
                </div>

                {/* Especificação e alertas específicos da rua */}
                <div className="space-y-2.5">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider font-mono">Alertas Operacionais Detectados:</span>
                  
                  {ruaData.ocupacaoPct > 90 ? (
                    <div className="bg-orange-50 border border-orange-200 p-2.5 rounded-lg text-orange-950 flex items-start gap-1.5 leading-snug text-[10.5px]">
                      <AlertTriangle className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                      <span><strong>Alerta Saturação:</strong> Corredor acima de 90%. Possível gargalo operacional de trânsito e balanceamento.</span>
                    </div>
                  ) : (
                    <div className="bg-emerald-50 text-emerald-800 p-2.5 rounded-lg text-[10px] font-semibold">
                      ✓ Nível de Ocupação e fluxo operacional saudáveis nesta rua.
                    </div>
                  )}

                  {ruaData.skusAlocados.length === 0 ? (
                    <p className="text-slate-400 text-center py-4">Nenhum produto estocado nesta rua no momento.</p>
                  ) : (
                    <div className="space-y-2 pt-1">
                      <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider font-mono">SKUs Estocados nesta Rua:</span>
                      <div className="divide-y divide-slate-150 border border-slate-100 rounded-xl overflow-hidden bg-slate-50/20 max-h-48 overflow-y-auto">
                        {listSkusInfo.map(({ sku, p, palletsRua }) => (
                          <div key={sku} className="p-2 py-2.5 flex items-center justify-between gap-2 bg-white hover:bg-slate-50 text-[11px]">
                            <div className="truncate pr-2">
                              <span className="font-mono font-extrabold text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded text-[10px]">
                                {sku.replace(/^0+/, '') || '0'}
                              </span>
                              <span className="font-semibold block text-slate-700 mt-0.5 truncate">{p?.descricao}</span>
                            </div>
                            <div className="text-right shrink-0 font-mono text-[10px]">
                              <span className="font-extrabold text-slate-900 block">{palletsRua} PL</span>
                              <span className="text-slate-400">{p?.quantidadeAtualCaixas} cx</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })() : (
            /* Guia explicativa padrão se nenhuma rua estiver clicada */
            <div className="bg-white p-5 rounded-2xl border border-slate-150 shadow-lux space-y-4">
              <div className="flex items-center gap-2">
                <FolderLock className="w-5 h-5 text-indigo-600" />
                <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight">Legenda & Estrutura Física</h3>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start gap-2.5">
                  <span className="w-4 h-4 rounded bg-emerald-500 block mt-0.5 border border-emerald-600"></span>
                  <div className="text-[11px]">
                    <strong className="text-slate-800 block">Curva A (Verde) — Giro de Volume Alto</strong>
                    Alocados prioritariamente no Bloco A (A1..A4) de proximidade à expedição.
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-4 h-4 rounded bg-amber-500 block mt-0.5 border border-amber-600"></span>
                  <div className="text-[11px]">
                    <strong className="text-slate-800 block">Curva B (Amarelo) — Giro Intermediário</strong>
                    Alocados no Bloco B (B1..B4) com picking térreo acoplado para faturamento.
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-4 h-4 rounded bg-rose-500 block mt-0.5 border border-rose-600"></span>
                  <div className="text-[11px]">
                    <strong className="text-slate-800 block">Curva C & Paredão (Vermelho) — Giro Longo</strong>
                    Alocados nos Racks Centrais do Bloco CB ou segregados nos corredores de racks robustos C1..C4 do Paredão.
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-4 h-4 rounded bg-sky-500 block mt-0.5 border border-sky-600"></span>
                  <div className="text-[11px]">
                    <strong className="text-slate-800 block">Marketplace & Marketing (Azul)</strong>
                    Zona segregada com marcação regulatória na rua CB4, sem empilhamento (estocagem rápida de trânsito).
                  </div>
                </div>
              </div>

              <div className="p-3 bg-indigo-50 border border-indigo-150 rounded-xl flex items-center gap-2 text-indigo-950">
                <Info className="w-4 h-4 text-indigo-600 shrink-0" />
                <p className="text-[10px]">
                  Clique em qualquer selo de corredor na seção superior ou no mapa para realizar uma vistoria de ocupação em tempo real.
                </p>
              </div>
            </div>
          )}

          {/* Buscador de Destaque Rápido para Auditor Logístico */}
          <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-4">
            <h4 className="font-display font-bold text-slate-800 text-xs uppercase tracking-wide">Foco e Auditoria de SKU no WMS</h4>
            
            <div className="space-y-2 text-xs">
              <label className="text-[10px] text-slate-400 font-bold block">Selecione um SKU para destacar no mapa:</label>
              <select 
                value={highlightedSku || ""} 
                onChange={(e) => setHighlightedSku(e.target.value || null)}
                className="w-full bg-slate-50 border border-slate-200 text-xs font-mono p-2.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
              >
                <option value="">-- Exibir todos os SKUs do Armazém --</option>
                {produtos.filter(p => p.quantidadeAtualCaixas > 0).map((p) => (
                   <option key={p.sku} value={p.sku}>
                     [{p.sku.replace(/^0+/, '') || '0'}] {p.descricao.substring(0, 30)}...
                   </option>
                ))}
              </select>
              {highlightedSku && (
                <button 
                  type="button"
                  onClick={() => setHighlightedSku(null)}
                  className="text-[10px] text-indigo-600 hover:underline font-bold cursor-pointer"
                >
                  Limpar Foco do Mapa
                </button>
              )}
            </div>

            {/* Informações estendidas do produto selecionado */}
            {highlightedSku && prodDict[highlightedSku] && (() => {
              const pSel = prodDict[highlightedSku];
              return (
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 space-y-2 text-xs animate-fade-in">
                  <span className="text-[9px] bg-slate-200 font-bold px-1.5 py-0.5 rounded text-slate-700 font-mono">Inspecionar de Carga</span>
                  <div className="space-y-1">
                    <h5 className="font-bold text-slate-800 leading-tight">{pSel.descricao}</h5>
                    <p className="text-[10px] text-slate-500 font-mono">Marca: {pSel.marca || "Ambev"} | Custo: R$ {(pSel.custoMedio || 0).toFixed(2)}</p>
                    <p className="text-[10px] text-slate-400">Classificação: {pSel.categoria} (Curva {pSel.curvaABC || "C"})</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200 text-[10px] font-mono">
                    <div>
                      <span className="text-slate-400 block font-sans">Estoque Total:</span>
                      <span className="text-[#0f172a] font-extrabold">{pSel.quantidadeAtualCaixas} cx</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans">Pallets Totais:</span>
                      <span className="text-[#0f172a] font-extrabold">{pSel.quantidadePallets.toFixed(1)} PL</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans font-sans">Estoque Unit:</span>
                      <span className="text-[#0f172a] font-extrabold">{pSel.quantidadeTotalUnitario} un</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans">Vol Líquido:</span>
                      <span className="text-indigo-700 font-extrabold">{pSel.volumeHectolitro.toFixed(1)} HL</span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Otimização Baseada em Regras de Deslocamento do CD */}
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950 p-5 rounded-2xl text-white space-y-4 shadow-xl text-xs">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <h4 className="font-display font-bold text-sm tracking-tight">Ocupação Corredor AI</h4>
            </div>
            <p className="text-[11px] text-slate-300">
              O WMS monitora em tempo real a densidade volumétrica de cada rua para sugerir rebalanceamentos de carga táticos e evitar sobrecarga de piso.
            </p>
            <div className="space-y-2 text-[10px] text-slate-300 border-t border-indigo-950 pt-3">
              <div className="flex justify-between font-mono">
                <span>Velocidade de Expedição CD</span>
                <span className="font-bold text-emerald-400">95% Estável</span>
              </div>
              <div className="flex justify-between font-mono">
                <span>Distância de Deslocamento</span>
                <span className="font-bold text-white">14.6 Metros Médio</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
