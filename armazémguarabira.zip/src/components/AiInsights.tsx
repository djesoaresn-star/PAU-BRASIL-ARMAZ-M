/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Cpu, 
  AlertTriangle, 
  Send, 
  RefreshCw, 
  ShieldAlert, 
  Gauge, 
  Lightbulb, 
  Info,
  Layers,
  ArrowRight
} from 'lucide-react';
import { ProdutoConsolidado } from '../types';

interface AiInsightsProps {
  produtos: ProdutoConsolidado[];
}

interface AlertaAI {
  titulo: string;
  nivel: 'Critico' | 'Atencao' | 'Normal';
  analise: string;
}

interface InsightsAIObj {
  resumoExecutivo: string;
  principaisAlertas: AlertaAI[];
  auditoriaEstoqueSugerida: string;
  otimizacaoLayoutWMS: {
    diagnostico: string;
    sugestoesMapeamento: string;
  };
  conclusoesFefo: string;
}

interface ChatMsg {
  sender: 'user' | 'assistant';
  text: string;
  time: string;
}

export default function AiInsights({ produtos }: AiInsightsProps) {
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<InsightsAIObj | null>(null);
  
  // Estados do Chat Operacional
  const [chatInput, setChatInput] = useState("");
  const [chatLog, setChatLog] = useState<ChatMsg[]>([
    { 
      sender: 'assistant', 
      text: "Olá! Sou o assistente inteligente do Armazém Fácil. Analisei o inventário dinâmico, as margens de tolerância de faturamento e o layout atual. Como posso te auxiliar na otimização de campo ou na resolução de gargalos de faturamento hoje?", 
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) 
    }
  ]);
  const [chatLoading, setChatLoading] = useState(false);
  
  const bottomRef = useRef<HTMLDivElement | null>(null);

  // Carrega insights iniciais ao montar
  useEffect(() => {
    gerarInsights();
  }, []);

  // Rolagem inteligente automática no chat operacional
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatLog]);

  const gerarInsights = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/ai/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const resData = await res.json();
      if (resData.success) {
        setInsights(resData.insights);
      }
    } catch (e) {
      console.error("Erro ao gerar insights do Gemini:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userMsgText = chatInput;
    setChatInput("");
    
    // Adiciona ao chat log
    setChatLog(prev => [...prev, {
      sender: 'user',
      text: userMsgText,
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    }]);

    setChatLoading(true);

    try {
      // Faz uma requisição direta ao modelo via endpoint especial do backend (podemos reaproveitar insights ou criar chat proxy)
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: userMsgText,
          contextoEstoque: produtos.map(p => ({
            sku: p.sku,
            descricao: p.descricao,
            categoria: p.categoria,
            curva: p.curvaABC,
            fisico: p.estoqueFisicoCaixas,
            sistemico: p.estoqueSistemaCaixas,
            diferenca: p.diferencaCaixas,
            valorDivergencia: p.divergenciaValor,
            pallets: p.quantidadePallets
          }))
        })
      });

      const resData = await res.json();
      if (resData.success) {
        setChatLog(prev => [...prev, {
          sender: 'assistant',
          text: resData.answer,
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }]);
      } else {
        throw new Error(resData.error || "Erro de rede");
      }
    } catch (err: any) {
      setChatLog(prev => [...prev, {
        sender: 'assistant',
        text: "Desculpe, encontrei um obstáculo de faturamento ao processar sua pergunta. Por favor, verifique a chave GEMINI_API_KEY ou tente novamente.",
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6" id="ai-insights-view-root">
      
      {/* Lado Esquerdo: Diagnósticos e Recomendações por IA (Donut & Bento - 7 colunas) */}
      <div className="xl:col-span-7 space-y-6">
        
        {/* Bloco de gatilho/estado de processamento */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux flex items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-indigo-600" />
              <span className="text-[10px] text-indigo-700 font-extrabold uppercase font-mono tracking-wider">AI Engine Online</span>
            </div>
            <h3 className="font-display font-bold text-slate-800 text-sm tracking-tight">Análise Executiva e Auditoria de Acurácia</h3>
            <p className="text-[11px] text-slate-500">
              Clique para executar reavaliações baseadas em algoritmos inteligentes e conformidade logística.
            </p>
          </div>

          <button
            type="button"
            onClick={gerarInsights}
            disabled={loading}
            className="shrink-0 bg-indigo-600 hover:bg-slate-900 text-white font-semibold text-xs py-2.5 px-4 rounded-xl shadow-sm flex items-center gap-1.5 transition cursor-pointer"
          >
            {loading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            {loading ? 'Calculando...' : 'Recalcular'}
          </button>
        </div>

        {loading ? (
          /* Esqueleto de Carregamento Inteligente */
          <div className="bg-white p-12 rounded-2xl border border-slate-100 shadow-lux text-center space-y-4">
            <div className="h-10 w-10 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin mx-auto"></div>
            <div className="space-y-1.5">
              <p className="text-xs font-bold text-slate-800 font-mono animate-pulse">Auditando balancetes, cubagem de pallets e lotes FEFO...</p>
              <p className="text-[11px] text-slate-400">Isso pode levar de 5 a 10 segundos para consolidar.</p>
            </div>
          </div>
        ) : insights ? (
          <div className="space-y-6">
            
            {/* 1. Resumo Executivo */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-2.5">
              <span className="text-[9px] bg-indigo-50 font-extrabold text-indigo-700 px-2 py-0.5 rounded uppercase tracking-wider">Resumo Executivo da Rodada</span>
              <p className="text-xs text-slate-700 leading-relaxed font-sans">{insights.resumoExecutivo}</p>
            </div>

            {/* 2. Principais Alertas Encontrados */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-3">
              <h4 className="font-display font-bold text-slate-800 text-xs uppercase tracking-wide">Foco de Atenção Operacional (Alertas)</h4>
              <div className="space-y-3">
                {insights.principaisAlertas && insights.principaisAlertas.map((alerta, idx) => {
                  let alertColor = "bg-rose-50 border-rose-100 text-rose-800";
                  let circleColor = "bg-rose-500";
                  if (alerta.nivel === 'Atencao') {
                    alertColor = "bg-amber-50 border-amber-100 text-amber-800";
                    circleColor = "bg-amber-500";
                  } else if (alerta.nivel === 'Normal') {
                    alertColor = "bg-emerald-50 border-emerald-100 text-emerald-800";
                    circleColor = "bg-emerald-500";
                  }

                  return (
                    <div key={idx} className={`p-3.5 rounded-xl border flex items-start gap-3 ${alertColor}`}>
                      <span className={`w-2 h-2 rounded-full ${circleColor} shrink-0 mt-1.5`}></span>
                      <div className="space-y-0.5 text-xs">
                        <strong className="font-display font-bold">{alerta.titulo}</strong>
                        <p className="text-[11px] opacity-90 leading-snug">{alerta.analise}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 3. Recomendações de Auditoria Física e WMS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Card Auditoria */}
              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-3">
                <div className="flex items-center gap-1.5 text-slate-800">
                  <ShieldAlert className="w-4 h-4 text-indigo-600" />
                  <h5 className="font-display font-bold text-xs uppercase tracking-wider">Passo a Passo de Auditoria</h5>
                </div>
                <div className="text-[11px] text-slate-600 whitespace-pre-line leading-relaxed font-sans">
                  {insights.auditoriaEstoqueSugerida}
                </div>
              </div>

              {/* Card Layout WMS */}
              <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-3">
                <div className="flex items-center gap-1.5 text-slate-800">
                  <Lightbulb className="w-4 h-4 text-indigo-600" />
                  <h5 className="font-display font-bold text-xs uppercase tracking-wider">Diretrizes de Layout WMS</h5>
                </div>
                <div className="space-y-2.5 text-[11px] text-slate-600">
                  <p className="bg-indigo-50/50 p-2 rounded-lg border border-indigo-100/50">
                    <strong className="text-indigo-900 block font-sans">Diagnóstico de Posição:</strong>
                    {insights.otimizacaoLayoutWMS?.diagnostico}
                  </p>
                  <p>
                    <strong className="text-slate-800 block font-sans">Sugestão de Remanejamento:</strong>
                    {insights.otimizacaoLayoutWMS?.sugestoesMapeamento}
                  </p>
                </div>
              </div>

            </div>

            {/* 4. Conclusões FEFO */}
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-lux space-y-3">
              <div className="flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-indigo-600" />
                <h4 className="font-display font-bold text-slate-800 text-xs uppercase tracking-wide">Plano Corretivo de Vencimentos (FEFO)</h4>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">{insights.conclusoesFefo}</p>
            </div>

          </div>
        ) : (
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-lux text-center text-slate-500 text-xs py-10">
            Nenhum balancete pré-processado na memória. Clique em recalcular para acionar a inteligência artificial.
          </div>
        )}

      </div>

      {/* Lado Direito: Assistente de Logística Live Chat (Bento e Console - 5 colunas) */}
      <div className="xl:col-span-5 flex flex-col h-[600px] border border-slate-100 rounded-2xl bg-white shadow-lux overflow-hidden" id="ai-chat-console">
        
        {/* Top Header do Chat */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-display font-bold text-xs tracking-tight">Assistente do CD Armazém Fácil</h4>
              <p className="text-[9px] text-indigo-400 font-mono">Conversação com Gemini 3.5 Flash</p>
            </div>
          </div>
          <span className="text-[9px] font-bold bg-slate-800 px-1.5 py-0.5 rounded text-emerald-400 animate-pulse font-mono">WMS_GPT ON</span>
        </div>

        {/* Zona Dinâmica de Mensagens */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50">
          {chatLog.map((msg, idx) => {
            const isAss = msg.sender === 'assistant';
            return (
              <div 
                key={idx} 
                className={`flex flex-col max-w-[85%] space-y-1 ${isAss ? 'mr-auto items-start' : 'ml-auto items-end'}`}
              >
                {/* Meta data */}
                <span className="text-[8px] text-slate-400 font-bold font-mono">
                  {isAss ? 'LOG_ASSISTANT' : 'CONFERENTE_CD'} &#8226; {msg.time}
                </span>
                {/* Bubble */}
                <div className={`p-3 rounded-2xl text-xs leading-relaxed font-sans ${isAss ? 'bg-white text-slate-800 border border-slate-100 rounded-tl-none shadow-sm' : 'bg-slate-900 text-white rounded-tr-none'}`}>
                  {msg.text}
                </div>
              </div>
            );
          })}
          {chatLoading && (
            <div className="flex flex-col items-start space-y-1 mr-auto max-w-[85%]">
              <span className="text-[8px] text-slate-400 font-bold font-mono">ASSISTENTE DIGITAL</span>
              <div className="bg-white p-3.5 rounded-2xl rounded-tl-none text-slate-500 border border-slate-100 shadow-sm text-xs flex items-center gap-1.5 font-mono">
                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                <span>Analisando o WMS...</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Formulário Inferior de Texto */}
        <form onSubmit={handleChatSubmit} className="p-3 bg-white border-t border-slate-100 flex gap-2 shrink-0">
          <input 
            type="text" 
            placeholder="Pergunte ao WMS: 'Como resolver a quebra do CER001?'"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            disabled={chatLoading}
            className="flex-1 bg-slate-50 border border-slate-200 text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white text-slate-800 font-sans"
          />
          <button 
            type="submit"
            disabled={!chatInput.trim() || chatLoading}
            className="bg-slate-900 hover:bg-slate-800 text-white p-2.5 rounded-xl transition cursor-pointer disabled:opacity-40"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>

    </div>
  );
}
