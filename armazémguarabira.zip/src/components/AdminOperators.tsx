import React, { useState, useEffect } from 'react';
import { UserPlus, ShieldAlert, Sparkles, UserCheck, Trash2, KeyRound, Users, UserX, ShieldCheck } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, onSnapshot, doc, setDoc, deleteDoc } from 'firebase/firestore';

interface UserCredentials {
  username: string;
  name: string;
  passwordHash: string;
}

export default function AdminOperators() {
  // Carregar e persistir a lista de operadores via Firebase para todos os computadores
  const [operators, setOperators] = useState<UserCredentials[]>([]);

  useEffect(() => {
    const qOperators = collection(db, "operators");
    const unsubOperators = onSnapshot(qOperators, (snapshot) => {
      const items: UserCredentials[] = [];
      snapshot.forEach((snap) => {
        items.push(snap.data() as UserCredentials);
      });
      setOperators(items);
    }, (error) => {
      console.warn("Firestore operators sync waiting or restricted:", error);
    });

    return () => {
      unsubOperators();
    };
  }, []);

  // Novos campos de registro
  const [newUsername, setNewUsername] = useState("");
  const [newName, setNewName] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordConfirm, setNewPasswordConfirm] = useState("");

  const [registerSuccess, setRegisterSuccess] = useState<string | null>(null);
  const [registerError, setRegisterError] = useState<string | null>(null);

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError(null);
    setRegisterSuccess(null);

    const regUser = newUsername.trim();
    const regName = newName.trim();
    const regPass = newPassword;
    const regPassConf = newPasswordConfirm;

    if (!regUser || !regName || !regPass || !regPassConf) {
      setRegisterError("Por favor, preencha todos os campos.");
      return;
    }

    if (regUser.toLowerCase() === "g1002") {
      setRegisterError("A matrícula administrativa 'G1002' é reservada e protegida por padrão.");
      return;
    }

    if (operators.some(op => op.username.toLowerCase() === regUser.toLowerCase())) {
      setRegisterError("Esta matrícula de operador já encontra-se cadastrada no sistema do CD.");
      return;
    }

    if (regPass.length < 4) {
      setRegisterError("A senha do operador deve possuir pelo menos 4 caracteres.");
      return;
    }

    if (regPass !== regPassConf) {
      setRegisterError("As senhas informadas não coincidem. Tente digitar novamente.");
      return;
    }

    const newOp: UserCredentials = {
      username: regUser,
      name: regName,
      passwordHash: regPass
    };

    try {
      await setDoc(doc(db, "operators", regUser.toLowerCase()), newOp);
      setRegisterSuccess(`Operador ${regUser} (${regName}) cadastrado com absoluto sucesso e sincronizado via Firebase!`);
      
      // Resetar campos
      setNewUsername("");
      setNewName("");
      setNewPassword("");
      setNewPasswordConfirm("");
    } catch (fsErr: any) {
      console.error("Erro ao registrar operador no Firestore:", fsErr);
      setRegisterError("Erro de gravação no Firebase Firestore: " + (fsErr.message || String(fsErr)));
    }
  };

  const handleDeleteOperator = async (usernameToDelete: string) => {
    if (window.confirm(`Deseja realmente revogar o acesso do operador ${usernameToDelete}?`)) {
      try {
        await deleteDoc(doc(db, "operators", usernameToDelete.toLowerCase()));
        setRegisterSuccess(`Acesso do operador ${usernameToDelete} revogado com sucesso no Firebase.`);
      } catch (fsErr: any) {
        console.error("Erro ao remover operador do Firestore:", fsErr);
        setRegisterError("Erro de remoção no Firebase Firestore: " + (fsErr.message || String(fsErr)));
      }
    }
  };

  return (
    <div className="space-y-6" id="admin-operators-module">
      
      {/* Banner de Cabeçalho Branded */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-lux relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-violet-600/5 pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 font-mono">Controle de Privilégios CD Guarabira</span>
            </div>
            <h1 className="text-xl font-extrabold tracking-tight font-display">
              Gestão de Acessos & Novos Logins
            </h1>
            <p className="text-xs text-slate-400">
              Crie, gerencie e audite os operadores credenciados a realizar movimentações e reconciliações físicas.
            </p>
          </div>
          <div className="bg-slate-950 px-4 py-2 rounded-xl border border-slate-800 text-right">
            <span className="text-[9px] uppercase font-bold text-slate-500 font-mono block">Nível de Permissão</span>
            <span className="text-xs font-black text-rose-400 font-mono flex items-center justify-end gap-1.5 mt-0.5">
              👑 G1002 (Administrador)
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Lado Esquerdo: Formulário de Criação (5/12 colunas) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4" id="operators-create-form-container">
          <div className="space-y-1">
            <h3 className="font-display font-extrabold text-slate-900 text-sm flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-blue-600" />
              <span>Cadastrar Novo Conferente / Operador</span>
            </h3>
            <p className="text-xs text-slate-500">
              Preencha os dados abaixo para cadastrar credenciais ativas para novos operadores de pátio ou galpão.
            </p>
          </div>

          {registerError && (
            <div className="bg-rose-50 border border-rose-200 p-3 rounded-xl flex items-start gap-2.5 text-xs text-rose-800" id="op-reg-err">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span className="leading-tight font-medium">{registerError}</span>
            </div>
          )}

          {registerSuccess && (
            <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-start gap-2.5 text-xs text-emerald-850" id="op-reg-suc">
              <UserCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="leading-tight font-medium">{registerSuccess}</span>
            </div>
          )}

          <form onSubmit={handleRegisterSubmit} className="space-y-4 font-sans">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase text-slate-500 font-mono tracking-wide block">Matrícula Operacional (Ex: G1024, C4590)</label>
              <input 
                type="text" 
                placeholder="Exemplo: G2003"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-sans outline-none font-bold"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase text-slate-500 font-mono tracking-wide block">Nome Completo</label>
              <input 
                type="text" 
                placeholder="Exemplo: João Silva Conferente"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-sans outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase text-slate-500 font-mono tracking-wide block">Senha Inicial</label>
                <input 
                  type="password" 
                  placeholder="Mín. 4 dígitos"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-sans outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase text-slate-500 font-mono tracking-wide block">Confirmar Senha</label>
                <input 
                  type="password" 
                  placeholder="Redigite"
                  value={newPasswordConfirm}
                  onChange={(e) => setNewPasswordConfirm(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-sans outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-md hover:-translate-y-0.5 duration-150 transition-all flex items-center justify-center gap-2 cursor-pointer pt-3 mt-4"
            >
              <UserPlus className="w-4 h-4" />
              <span>Salvar Operador no Banco Local</span>
            </button>
          </form>

          <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl text-[11px] text-amber-800 leading-relaxed font-sans">
            <strong>Regra de Negócio Ambev:</strong> Novos operadores cadastrados receberão permissões padrões de pátio, permitindo visualizações completas e conciliação pontual com login individual de auditoria.
          </div>
        </div>

        {/* Lado Direito: Lista de Operadores Cadastrados (7/12 colunas) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col" id="operators-list-container">
          <div className="space-y-1">
            <h3 className="font-display font-extrabold text-slate-900 text-sm flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-700" />
              <span>Operadores Cadastrados no CD</span>
            </h3>
            <p className="text-xs text-slate-500">
              Lista de logins com autorização para controle de estoque física x fiscal Ambev.
            </p>
          </div>

          <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 divide-y divide-slate-200/60 overflow-y-auto max-h-[350px] flex-1">
            
            {/* Administrador Padrão Fixo */}
            <div className="py-3 flex items-center justify-between gap-2 border-b border-dashed border-slate-200">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center font-bold text-xs text-rose-700 shrink-0 select-none">
                  AD
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-xs font-extrabold text-slate-900">G1002</span>
                    <span className="bg-rose-500/10 text-rose-700 font-bold px-1.5 py-0.1 rounded text-[8px] tracking-wide uppercase font-mono">Admin CD</span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-sans truncate">Gerente Geral da Unidade</p>
                </div>
              </div>
              <div className="text-right text-[10px] font-mono text-slate-400 pr-1 select-none">
                Acesso Vitalício
              </div>
            </div>

            {operators.length === 0 ? (
              <div className="py-12 text-center text-slate-450 text-xs flex flex-col items-center justify-center gap-2" id="empty-operators-state">
                <UserX className="w-8 h-8 text-slate-300" />
                <span>Nenhum operador adicional cadastrado na unidade ainda. Use o formulário à esquerda.</span>
              </div>
            ) : (
              operators.map((op) => (
                <div key={`list-operator-${op.username}`} className="py-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center font-bold text-xs text-blue-700 shrink-0 select-none uppercase">
                      {op.name.slice(0, 2)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-slate-900">{op.username}</span>
                        <span className="bg-blue-500/10 text-blue-700 font-bold px-1.5 py-0.1 rounded text-[8px] tracking-wide uppercase font-mono">Operador</span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-sans truncate">{op.name}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-right font-mono text-[9.5px] text-slate-500 bg-slate-200/50 px-2 py-0.5 rounded border border-slate-200">
                      Senha: <span className="font-bold select-all">{op.passwordHash}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteOperator(op.username)}
                      title="Revogar Acesso"
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer border border-transparent hover:border-rose-100 transition-all duration-150"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}

          </div>

        </div>

      </div>

    </div>
  );
}
