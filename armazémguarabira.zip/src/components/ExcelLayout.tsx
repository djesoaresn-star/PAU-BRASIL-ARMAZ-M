import React from 'react';
import { WmsPosicao, ProdutoConsolidado } from '../types';
import { Grid3X3, Info } from 'lucide-react';

interface ExcelLayoutProps {
  layout: WmsPosicao[];
  produtos: ProdutoConsolidado[];
  prodDict: Record<string, ProdutoConsolidado>;
  displayMode: 'sku' | 'idade' | 'sai' | 'curva';
  excelActiveStreet: string;
  setExcelActiveStreet: (street: string) => void;
  onCellClick: (pos: WmsPosicao) => void;
  onMouseMove: (e: React.MouseEvent, pos: WmsPosicao) => void;
  onMouseLeave: () => void;
  editingCellId?: string;
  hoveredCellId?: string;
}

export default function ExcelLayout({
  layout,
  produtos,
  prodDict,
  displayMode,
  excelActiveStreet,
  setExcelActiveStreet,
  onCellClick,
  onMouseMove,
  onMouseLeave,
  editingCellId,
  hoveredCellId
}: ExcelLayoutProps) {

  // For each module under the selected street
  const listRuas = ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "CB1", "CB2", "CB3", "CB4", "C1", "C2", "C3", "C4"];

  return (
    <div className="xl:col-span-9 bg-white p-6 rounded-3xl border border-slate-300 shadow-2xl space-y-6 relative overflow-x-auto text-slate-800 transition-all duration-300">
      
      {/* Header / Ribbon do Excel */}
      <div className="bg-[#107c41] text-white p-4 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-900/30 rounded-xl border border-emerald-500/30">
            <Grid3X3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm font-sans uppercase tracking-wider">Planilha WMS Interativa</h3>
            <p className="text-[10px] text-emerald-100 font-medium">Modo Linhas e Colunas do CD. Passe o mouse para inspecionar e clique na célula para editar.</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 font-mono text-xs font-black bg-[#0b5c30] p-2 rounded-xl border border-emerald-800">
            <span>RUA ATIVA:</span>
            <select
              value={excelActiveStreet}
              onChange={(e) => setExcelActiveStreet(e.target.value)}
              className="bg-[#107c41] border border-emerald-400 text-white font-extrabold rounded p-1 text-xs focus:outline-none focus:ring-1 focus:ring-white cursor-pointer"
            >
              {listRuas.map(s => (
                <option key={s} value={s} className="bg-slate-900 text-white font-bold">{s}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Barra de Fórmula Excel (fx) */}
      <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 p-2.5 text-slate-700 rounded-xl font-mono text-xs shadow-inner">
        <div className="text-[#107c41] font-black italic px-3 border-r border-slate-300 select-none text-sm">fx</div>
        <div className="font-bold text-[#107c41] bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded select-none w-16 text-center text-[10.5px]">
          {editingCellId || hoveredCellId || "-"}
        </div>
        <div className="text-slate-600 overflow-hidden text-ellipsis whitespace-nowrap px-1 font-semibold flex-1">
          {editingCellId 
            ? `EDITANDO ENDEREÇO SELECIONADO: ${editingCellId}`
            : hoveredCellId
              ? `INSPECIONANDO ENDEREÇO: ${hoveredCellId}`
              : "Passe o cursor sobre os slots ou clique em qualquer célula para alterar saldos e lotes."
          }
        </div>
      </div>

      {/* Planilha Excel Grid real */}
      <div className="border border-slate-300 rounded-2xl overflow-x-auto bg-slate-50 shadow-inner">
        <table className="w-full text-xs border-collapse font-sans min-w-[1200px]">
          <thead>
            <tr className="bg-slate-100 text-slate-600 font-mono text-center select-none border-b border-slate-300">
              <th className="p-3 border-r border-slate-300 bg-slate-200/90 w-24 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">
                Nível
              </th>
              {Array.from({ length: 16 }).map((_, mIdx) => {
                const colLabel = String.fromCharCode(65 + (mIdx % 26));
                return (
                  <th key={mIdx} className="p-3 border-r border-slate-300 bg-slate-150 text-[10.5px] font-extrabold text-slate-700 min-w-[70px] text-center">
                    <span className="text-[11px] text-[#107c41] block font-black">{colLabel}</span>
                    <span className="block text-[8px] font-mono text-slate-500 uppercase">Mód {String(mIdx + 1).padStart(2, '0')}</span>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 4 }).map((_, nIdx) => {
              const nivelNum = 4 - nIdx; // N4, N3, N2, N1
              const labelNivel = nivelNum === 1 
                ? "N1 (Picking)" 
                : `N${nivelNum} (Aéreo)`;
              
              return (
                <tr key={nivelNum} className="border-b border-slate-300 last:border-b-0">
                  <td className="p-3 border-r border-slate-300 bg-slate-100 font-extrabold text-[10px] text-slate-700 text-center uppercase font-mono h-18 select-none">
                    {labelNivel}
                  </td>

                  {Array.from({ length: 16 }).map((_, mIdx) => {
                    const moduloNum = mIdx + 1;
                    const posId = `${excelActiveStreet}-M${String(moduloNum).padStart(2, '0')}-N${nivelNum}`;
                    const posRealVal = layout.find(p => p.rua === excelActiveStreet && p.modulo === moduloNum && p.nivel === nivelNum);

                    const skuAlloc = posRealVal?.skuAlocado || null;
                    const prod = skuAlloc ? prodDict[skuAlloc] : null;

                    let cellBgClass = "bg-white text-slate-400 hover:bg-slate-100 hover:text-slate-600";
                    let cellText = "VAZIO \u2022";

                    if (posRealVal && skuAlloc) {
                      cellText = skuAlloc.replace(/^0+/, '');
                      if (displayMode === 'idade') {
                        const dias = posRealVal.idadePallet || 0;
                        cellText = `${dias} dias`;
                        if (dias > 60) cellBgClass = "bg-rose-100 text-rose-800 font-extrabold border-rose-200 hover:bg-rose-200";
                        else if (dias > 30) cellBgClass = "bg-amber-100 text-amber-800 font-extrabold border-amber-200 hover:bg-amber-200";
                        else cellBgClass = "bg-emerald-100 text-emerald-800 font-extrabold border-emerald-200 hover:bg-emerald-200";
                      } else if (displayMode === 'sai') {
                        const saiVal = posRealVal.stockAgeIndex || 0;
                        cellText = `SAI ${saiVal}%`;
                        if (saiVal > 80) cellBgClass = "bg-rose-100 text-rose-900 font-extrabold border-rose-250 hover:bg-rose-200";
                        else if (saiVal > 50) cellBgClass = "bg-amber-100 text-amber-900 border-amber-200 hover:bg-amber-200";
                        else cellBgClass = "bg-emerald-100 text-emerald-900 border-emerald-200 hover:bg-emerald-200";
                      } else if (displayMode === 'curva') {
                        const curva = prod?.curvaABC || 'C';
                        cellText = `GIRO ${curva}`;
                        if (curva === 'A') cellBgClass = "bg-emerald-600 text-white font-black hover:bg-emerald-700";
                        else if (curva === 'B') cellBgClass = "bg-amber-400 text-slate-950 font-black hover:bg-amber-500";
                        else cellBgClass = "bg-rose-500 text-white font-black hover:bg-rose-600";
                      } else {
                        cellText = skuAlloc.replace(/^0+/, '');
                        if (prod?.curvaABC === 'A') cellBgClass = "bg-emerald-50 text-emerald-800 border-emerald-200 font-bold hover:bg-emerald-100";
                        else if (prod?.curvaABC === 'B') cellBgClass = "bg-amber-50 text-amber-900 border-amber-200 font-bold hover:bg-amber-100";
                        else cellBgClass = "bg-rose-50 text-rose-800 border-rose-200 font-bold hover:bg-rose-100";
                      }
                    }

                    const posToHover: WmsPosicao = posRealVal || {
                      id: posId,
                      area: nivelNum === 1 ? 'Picking' : 'Central',
                      rua: excelActiveStreet,
                      modulo: moduloNum,
                      nivel: nivelNum,
                      skuAlocado: skuAlloc,
                      capacidadePallets: posRealVal?.capacidadePallets || (nivelNum === 1 ? 1 : 2),
                      palletsAlocados: posRealVal?.palletsAlocados || 0,
                      idadePallet: posRealVal?.idadePallet || 0,
                      stockAgeIndex: posRealVal?.stockAgeIndex || 0
                    };

                    const handleCellClick = () => {
                      onCellClick(posToHover);
                    };

                    return (
                      <td
                        key={moduloNum}
                        onClick={handleCellClick}
                        onMouseMove={(e) => onMouseMove(e, posToHover)}
                        onMouseLeave={onMouseLeave}
                        className={`p-2 border-r border-slate-300 text-center font-mono cursor-pointer transition-all h-18 relative select-none ${cellBgClass} ${editingCellId === posId ? 'ring-4 ring-emerald-500 ring-inset outline-none z-10' : ''}`}
                      >
                        <div className="flex flex-col justify-between h-full py-1">
                          <span className="text-[11px] font-black tracking-tight block truncate max-w-[85px] text-center mx-auto">
                            {cellText}
                          </span>
                          <span className="text-[8.5px] font-bold opacity-75 block text-center mt-0.5 leading-none">
                            {posRealVal?.palletsAlocados || 0}/{posRealVal?.capacidadePallets || (nivelNum === 1 ? 1 : 2)} PL
                          </span>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Abas inferiores iguais planilhas do Excel */}
      <div className="bg-slate-100 border border-slate-300 p-2.5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-sm select-none">
        <div className="flex items-center gap-1 overflow-x-auto max-w-full pb-1.5 md:pb-0 scrollbar-none">
          <span className="text-[10px] text-slate-500 font-extrabold uppercase font-mono pr-2.5 shrink-0">
            ABAS PLANILHAS (RUAS DO CD):
          </span>
          {listRuas.map(s => {
            const isActive = excelActiveStreet === s;
            return (
              <button
                key={s}
                type="button"
                onClick={() => setExcelActiveStreet(s)}
                className={`p-1.5 px-3.5 rounded text-xs font-mono font-bold transition-all relative shrink-0 cursor-pointer ${isActive ? 'bg-white text-[#107c41] shadow-md border-b-2 border-t border-x border-[#107c41]' : 'text-slate-600 hover:bg-slate-200'}`}
              >
                {s}
              </button>
            );
          })}
        </div>
        <div className="text-[10px] text-slate-500 font-mono font-bold shrink-0">
          Grade de Endereçamento Ambev CD • Excel View
        </div>
      </div>

      {/* Dica de Utilização */}
      <div className="flex justify-between items-center text-[10.5px] text-slate-500 pt-2 border-t border-slate-200 bg-slate-50 p-4 rounded-xl">
        <span className="flex items-center gap-2"><Info className="w-4 h-4 text-[#107c41]" /> Clique em qualquer célula acima para alterar ou reabastecer pallets. O balão superior flutuante será exibido ao planar o cursor pelas células.</span>
        <span className="text-[#107c41] font-sans font-extrabold select-none">● CONEXÃO WMS ONLINE</span>
      </div>

    </div>
  );
}
