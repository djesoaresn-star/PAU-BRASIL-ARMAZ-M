import React, { useState, useEffect } from 'react';
import { PauBrasilLogo } from './PauBrasilLogo';
import { FolderLock, UserPlus, KeyRound, ShieldAlert, Sparkles, LogIn, ArrowRight, UserCheck } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { collection, onSnapshot } from 'firebase/firestore';

interface LoginScreenProps {
  onSuccess: (username: string) => void;
}

interface UserCredentials {
  username: string;
  name: string;
  passwordHash: string; // no cenário de mockup armazenaremos simples para compatibilidade local
}

export function LoginScreen({ onSuccess }: LoginScreenProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);

  // Carregar lista de operadores registrados no Firebase para sincronização multi-computadores
  const [operators, setOperators] = useState<UserCredentials[]>([]);

  useEffect(() => {
    // Escuta em tempo real para permitir que logins criados em qualquer computador funcionem instantaneamente
    const qOperators = collection(db, "operators");
    const unsubOperators = onSnapshot(qOperators, (snapshot) => {
      const items: UserCredentials[] = [];
      snapshot.forEach((snap) => {
        items.push(snap.data() as UserCredentials);
      });
      setOperators(items);
    }, (error) => {
      console.warn("Firestore operators sync waiting or restricted:", error);
    });

    return () => {
      unsubOperators();
    };
  }, []);

  const handleGoogleLogin = async () => {
    setLoginError(null);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        onSuccess(result.user.email || result.user.displayName || "Usuario Google");
      }
    } catch (e: any) {
      console.error(e);
      setLoginError("Erro ao fazer login com o Google/Firebase: " + (e.message || String(e)));
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const normUsername = username.trim();
    const normPassword = password;

    if (!normUsername || !normPassword) {
      setLoginError("Por favor, preencha todos os campos.");
      return;
    }

    // Administrador Padrão
    if (normUsername === "G1002" && normPassword === "!Liz1105") {
      onSuccess("G1002 (Administrador)");
      return;
    }

    // Buscar entre operadores criados
    const matched = operators.find(
      op => op.username.toLowerCase() === normUsername.toLowerCase() && op.passwordHash === normPassword
    );

    if (matched) {
      onSuccess(`${matched.username} (${matched.name})`);
    } else {
      setLoginError("Credenciais inválidas. Verifique sua matrícula de conferente e sua senha.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans" id="login-layout-wrapper">
      {/* Detalhes de Background para estética moderna e limpa */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,#111e36_0%,#020617_70%)] pointer-events-none z-0"></div>
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch relative z-10 bg-slate-900/40 border border-slate-800/80 backdrop-blur-md rounded-3xl p-6 md:p-8 shadow-2xl" id="login-bento-grid">
        
        {/* Bloco Esquerdo: Branding e Informações do Armazém */}
        <div className="md:col-span-5 flex flex-col justify-between p-6 bg-slate-950/70 border border-slate-800/50 rounded-2xl space-y-8" id="login-branding-card">
          <div className="space-y-4">
            <PauBrasilLogo showText={true} width={45} height={45} />
            <div className="h-[2px] bg-slate-800 w-24"></div>
          </div>

          <div className="space-y-4 flex-1 flex flex-col justify-center">
            <div className="bg-blue-500/10 p-2.5 rounded-lg border border-blue-500/20 max-w-max">
              <FolderLock className="w-5 h-5 text-blue-400 animate-pulse" />
            </div>
            <h1 className="font-display font-black text-white text-xl uppercase tracking-tight leading-snug">
              Portal do Operador <br/>CD Guarabira
            </h1>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans font-medium">
              Autenticação obrigatória e rastreamento de conciliações para mitigação de quebras e controle contábil.
            </p>
          </div>

          <div className="space-y-2 pt-4 border-t border-slate-800/60 text-[10px] text-slate-500 font-mono">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-500/80"></div>
              <span>CD Guarabira - PB</span>
            </div>
          </div>
        </div>

        {/* Bloco Direito: Formulários Interativos */}
        <div className="md:col-span-7 flex flex-col justify-center p-6" id="login-form-card">
          
          {/* Form 1: LOGIN */}
          <form onSubmit={handleLoginSubmit} className="space-y-5 animate-fadeIn" id="applet-login-form">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">Credenciais de Acesso</span>
              <h2 className="font-display font-extrabold text-white text-lg">Área Segura Distribuidora Pau Brasil</h2>
            </div>

            {loginError && (
              <div className="bg-rose-500/10 border border-rose-500/30 p-3 rounded-xl flex items-start gap-2.5 text-xs text-rose-350" id="login-error-toast">
                <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <span className="leading-tight font-medium">{loginError}</span>
              </div>
            )}

            <div className="space-y-3.5">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase text-slate-405 font-mono">Matrícula ou Código Operacional</label>
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Digite sua matrícula"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full px-3.5 py-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-sans outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase text-slate-405 font-mono">Senha de Acesso</label>
                <div className="relative">
                  <input 
                    type="password" 
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3.5 py-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-sans outline-none"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-lux shadow-blue-500/20 hover:-translate-y-0.5 duration-150 transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <span>Autenticar no Sistema</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center my-4">
              <div className="flex-grow border-t border-slate-800"></div>
              <span className="px-3 text-[10px] uppercase font-bold text-slate-500 font-mono">Ou entre com</span>
              <div className="flex-grow border-t border-slate-800"></div>
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              className="w-full py-3.5 bg-slate-950/80 hover:bg-slate-900 border border-slate-800 text-white font-extrabold text-xs rounded-xl shadow-lux duration-150 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>Conectar via Google (Firebase)</span>
            </button>
          </form>

        </div>

      </div>

      {/* Footer Branded */}
      <div className="mt-8 flex items-center gap-1.5 text-slate-500 text-[10px] font-mono tracking-wide z-10 select-none">
        <Sparkles className="w-3.5 h-3.5 text-blue-500" />
        <span>Pau Brasil Guarabira</span>
        <span>•</span>
        <span>Tecnologia Ambev</span>
      </div>
    </div>
  );
}
