import React, { useState, useEffect } from 'react';
import { PauBrasilLogo } from './PauBrasilLogo';
import { 
  BookOpen, 
  CheckCircle2, 
  HelpCircle, 
  TrendingUp, 
  Lock, 
  ListTodo, 
  ChevronRight, 
  ArrowRight,
  Sparkles,
  Info
} from 'lucide-react';

interface PauBrasilGuideProps {
  currentView: 'tabela' | 'todos' | 'dashboard' | 'cadastro' | 'congelar' | 'analise';
  onViewChange: (view: 'tabela' | 'todos' | 'dashboard' | 'cadastro' | 'congelar' | 'analise') => void;
  className?: string;
}

export function PauBrasilGuide({ currentView, onViewChange, className = "" }: PauBrasilGuideProps) {
  const [tasks, setTasks] = useState<{ id: string; text: string; completed: boolean }[]>(() => {
    const saved = localStorage.getItem('paubrasil_guide_tasks');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // use default
      }
    }
    return [
      { id: '1', text: 'Localizar desvio físico ou quebra de produto nas tabelas de divergências ativas.', completed: false },
      { id: '2', text: 'Acessar a aba "Desvios" para salvar observações e congelar o SKU permanentemente.', completed: false },
      { id: '3', text: 'Visualizar a compensação imediata de valor (R$) e volume em hectolitros (HL) calculada no CD.', completed: false },
      { id: '4', text: 'Navegar até "Analisar SKU" para checar o comportamento de Stock Drift do item nos últimos 30 dias.', completed: false },
      { id: '5', text: 'Inspecionar as variações diárias no painel gráfico interativo (movendo o mouse para ver estoque por dia).', completed: false },
    ];
  });

  const [activeStep, setActiveStep] = useState<number>(1);

  useEffect(() => {
    localStorage.setItem('paubrasil_guide_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const steps = [
    {
      number: 1,
      title: "Mapeamento & Alinhamento",
      icon: <HelpCircle className="w-4 h-4 text-blue-500" />,
      desc: "Identifique as quebras físicas no armazém ou as divergências em tempo real geradas pelo faturamento e pelo recebimento físico.",
      tips: [
        "Consulte a aba 'Divergências Ativas' para ver a discrepância instantânea.",
        "Selecione SKUs na lista ou digite manualmente se for perda em unidades fracionadas (avarias)."
      ],
      action: {
        text: "Ver Divergências Ativas",
        view: "tabela" as const
      }
    },
    {
      number: 2,
      title: "Congelamento Compensativo",
      icon: <Lock className="w-4 h-4 text-amber-500" />,
      desc: "O congelamento fixa o desvio fiscal e físico sob uma trava com justificativa, calculando a valoração financeira em reais e perdas em hectolitros.",
      tips: [
        "Acesse a aba 'Desvios' (ou congele diretamente do checklist).",
        "Insira uma justificativa específica (ex: 'Quebra fardo no bloco B durante movimentação de empilhadeira').",
        "Confirme o congelamento para provisionar os valores de compensação contábil."
      ],
      action: {
        text: "Acessar Painel de Desvios & Congelar",
        view: "congelar" as const
      }
    },
    {
      number: 3,
      title: "Auditoria Histórica (30 Dias)",
      icon: <TrendingUp className="w-4 h-4 text-violet-500" />,
      desc: "Analise a evolução diária do estoque e o desvio acumulado nos últimos 30 dias para identificar reincidência e conformidade de giro.",
      tips: [
        "Acesse a aba 'Analisar SKU' para carregar o histórico de telemetria.",
        "Verifique no gráfico linear SVG 'Stock Drift' o descompasso entre estoque sistêmico e físico.",
        "Arraste ou posicione o mouse sobre o gráfico para ver entradas, saídas e divergências dia a dia."
      ],
      action: {
        text: "Checar Gráficos de Estoque (30d)",
        view: "analise" as const
      }
    }
  ];

  return (
    <div 
      className={`bg-slate-900/85 border border-slate-800 rounded-2xl p-5 shadow-lux space-y-6 ${className}`} 
      id="pau-brasil-interactive-guide-panel"
    >
      {/* Header com branding e logo da Pau Brasil */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/65" id="guide-header-branded">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-blue-500 animate-pulse" />
          <div>
            <h3 className="font-display font-extrabold text-white text-sm tracking-tight">
              Guia de Congelamento e Conciliação Operacional
            </h3>
            <p className="text-[10px] text-slate-400 font-sans font-medium">
              Procedimento oficial para controle de perdas e quebras da Distribuidora Ambev
            </p>
          </div>
        </div>
        
        {/* Logo integrado com elegância */}
        <div className="bg-slate-800/40 p-2 px-3 rounded-xl border border-slate-700/30">
          <PauBrasilLogo showText={true} width={32} height={32} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Lado Esquerdo: Checklist de Tarefas Operacionais (5 cols) */}
        <div className="lg:col-span-5 space-y-3.5 bg-slate-950/40 p-4 rounded-xl border border-slate-800/40" id="guide-checklist-column">
          <div className="flex items-center justify-between pb-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 font-sans flex items-center gap-1.5">
              <ListTodo className="w-4 h-4 text-emerald-500" />
              Checklist de Rotina do CD
            </span>
            <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
              {tasks.filter(t => t.completed).length} de {tasks.length} concluídos
            </span>
          </div>

          <div className="space-y-2.5">
            {tasks.map(task => (
              <label 
                key={`task-guide-${task.id}`}
                onClick={() => toggleTask(task.id)}
                className={`flex items-start gap-2.5 p-2 rounded-lg border transition-all cursor-pointer ${
                  task.completed 
                    ? 'bg-slate-900/30 border-emerald-500/30 text-slate-400' 
                    : 'bg-slate-900/60 border-slate-850 hover:bg-slate-900 hover:border-slate-800 text-slate-100'
                }`}
              >
                <input 
                  type="checkbox"
                  checked={task.completed}
                  readOnly
                  className="w-3.5 h-3.5 rounded border-slate-750 text-emerald-500 focus:ring-emerald-500 mt-0.5"
                />
                <span className="text-[10.5px] font-sans leading-relaxed font-medium select-none">
                  {task.text}
                </span>
              </label>
            ))}
          </div>

          <div className="pt-2 flex items-center justify-between text-[9px] text-slate-400 font-medium">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-yellow-500" />
              Sincronizado localmente
            </span>
            <button 
              type="button"
              onClick={() => setTasks(prev => prev.map(t => ({ ...t, completed: false })))}
              className="text-blue-400 hover:underline cursor-pointer"
            >
              Resetar checklist
            </button>
          </div>
        </div>

        {/* Lado Direito: Passos do Fluxo e Switche de Visualização (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-4" id="guide-workflow-column">
          
          {/* Abas Segmentadas dos Passos */}
          <div className="flex bg-slate-950/60 p-1 rounded-xl border border-slate-800" id="guide-step-tabs">
            {steps.map(step => (
              <button
                type="button"
                key={`step-tab-${step.number}`}
                onClick={() => setActiveStep(step.number)}
                className={`flex-1 py-2 text-center rounded-lg transition-all cursor-pointer font-sans font-bold text-[11px] flex items-center justify-center gap-2 ${
                  activeStep === step.number 
                    ? 'bg-blue-600 text-white shadow-lux font-black shadow-blue-500/10' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <span>{step.number}º</span>
                <span className="hidden sm:inline">{step.title.split(' ')[0]}</span>
              </button>
            ))}
          </div>

          {/* Conteúdo do Passo Ativo */}
          {(() => {
            const step = steps.find(s => s.number === activeStep)!;
            return (
              <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-850 space-y-3.5 animate-fadeIn flex-1 flex flex-col justify-between">
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-slate-800 text-white font-extrabold text-[11px] font-mono flex items-center justify-center border border-slate-700/60">
                      {step.number}
                    </span>
                    <h4 className="font-display font-extrabold text-white text-xs tracking-tight flex items-center gap-2">
                      {step.title}
                      {step.icon}
                    </h4>
                  </div>

                  <p className="text-[11px] text-slate-350 leading-relaxed font-sans font-medium">
                    {step.desc}
                  </p>

                  <div className="space-y-1.5 pt-1">
                    <span className="text-[9px] uppercase font-bold text-slate-500 flex items-center gap-1 font-mono">
                      <ChevronRight className="w-3.5 h-3.5 text-blue-400" /> Diretrizes de Valoração Ambev
                    </span>
                    <ul className="space-y-1 pl-2">
                      {step.tips.map((tip, i) => (
                        <li key={`tip-${step.number}-${i}`} className="text-[10px] text-slate-400 font-sans list-disc pl-1 ml-2 font-medium">
                          {tip}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-850 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-[9px] text-slate-400">
                    <Info className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Visualização ativa: <strong className="text-white capitalize">{currentView === 'congelar' ? 'Desvios' : currentView === 'analise' ? 'Analisar SKU' : currentView}</strong></span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onViewChange(step.action.view)}
                    className="py-1.5 px-3 bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white font-extrabold text-[10px] rounded-lg border border-blue-500/20 transition-all flex items-center gap-1.5 cursor-pointer hover:-translate-y-0.5 duration-150 shadow"
                  >
                    <span>{step.action.text}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })()}

        </div>
      </div>
    </div>
  );
}
