/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  EstoqueAtual, 
  InventarioItem, 
  CaixaPallet, 
  VendaMedia, 
  EntradaFiscalFutura, 
  LoteValidade, 
  PickingMapeamento, 
  ProdutoConsolidado,
  Categoria,
  CurvaABC,
  WmsPosicao
} from '../types';

import { rawReportEstoque, rawReportVendas } from './rawReports';
import { rawErpDatabase } from './erpDatabase';

// Interface do cadastro fiscal carregado do ERP
export interface ErpCatalogItem {
  sku: string;
  descricao: string;
  unidadeMedida: string;
  fatorPallet: number;
  fatorSku: number; // embalagem
  fatorHecto: number;
  custoPorSku: number; // custo do SKU
  categoria?: string;
}

// Analisa a base fiscal Master importada do ERP
export const parseErpCatalog = (): Map<string, ErpCatalogItem> => {
  const map = new Map<string, ErpCatalogItem>();
  const lines = rawErpDatabase.split('\n');
  lines.forEach((line) => {
    if (!line.trim() || line.startsWith('CÓDIGO') || line.startsWith('CÃ“DIGO')) return;
    const cols = line.split(';');
    if (cols.length >= 7) {
      const codigoRaw = cols[0].trim();
      if (!codigoRaw) return;
      const sku = codigoRaw.padStart(8, '0');
      const descricao = cols[1].trim();
      const unidadeMedida = cols[2].trim();
      const fatorPallet = parseInt(cols[3].trim()) || 80;
      const fatorSku = parseInt(cols[4].trim()) || 12;
      const fatorHecto = parseFloat(cols[5].trim().replace(',', '.')) || 0.05;
      
      const rawCusto = cols[6].trim().replace(',', '.');
      const custoPorSku = parseFloat(rawCusto) || 45.00;
      
      map.set(sku, {
        sku,
        descricao,
        unidadeMedida,
        fatorPallet,
        fatorSku,
        fatorHecto,
        custoPorSku
      });
    }
  });
  return map;
};

export const erpCatalogMap = parseErpCatalog();


// Helper: deterministica baseada em string hash para dados auxiliares consistentes
function getDeterministicHash(sku: string, key: string, max: number): number {
  let sum = 0;
  const str = sku + key;
  for (let i = 0; i < str.length; i++) {
    sum += str.charCodeAt(i);
  }
  return sum % max;
}

// Helper: Converte a fração clássica Ambev "Caixas/Unidades" (ex: 105/10 ou 1.420/10)
function parseFrac(val: string | undefined, factor: number): number {
  if (!val) return 0;
  const cleaned = val.trim();
  if (!cleaned) return 0;
  
  const isNegative = cleaned.endsWith('-');
  const positivePart = isNegative ? cleaned.slice(0, -1) : cleaned;
  
  if (positivePart.includes('/')) {
    const parts = positivePart.split('/');
    const boxesStr = parts[0].trim().replace(/\./g, '').replace(',', '.');
    const unitsStr = parts[1].trim().replace(/\./g, '').replace(',', '.');
    
    const boxes = parseFloat(boxesStr) || 0;
    const units = parseFloat(unitsStr) || 0;
    
    const total = boxes + (units / (factor || 1));
    return isNegative ? -total : total;
  }
  
  const cleanNum = positivePart.replace(/\./g, '').replace(',', '.').trim();
  const num = parseFloat(cleanNum) || 0;
  return isNegative ? -num : num;
}

// Helper: Deduz inteligentemente o fator de Hectolitro por caixa
function calcularFatorHectolitro(descricao: string, factor: number): number {
  const d = descricao.toUpperCase();
  let volumeLitrosUnit = 0.350; // Padrão 350ml
  
  if (d.includes('BARRIL') || d.includes('KEG')) {
    if (d.includes('50L')) volumeLitrosUnit = 50.0;
    else if (d.includes('30L')) volumeLitrosUnit = 30.0;
    else volumeLitrosUnit = 50.0;
  } else if (d.includes('PET 2,5L') || d.includes('PET 2.5L') || d.includes('2,5L')) {
    volumeLitrosUnit = 2.5;
  } else if (d.includes('PET 2L') || d.includes('PET 2 L') || d.includes('2L CAIXA')) {
    volumeLitrosUnit = 2.0;
  } else if (d.includes('PET 1,5L') || d.includes('PET 1.5L') || d.includes('1,5L CAIXA') || d.includes('1,5 SHRINK') || d.includes('1,5L SHRINK')) {
    volumeLitrosUnit = 1.5;
  } else if (d.includes('PET 1L') || d.includes('PET 1 L') || d.includes('1L CAIXA') || d.includes('GFA VD 1L') || d.includes('1L')) {
    volumeLitrosUnit = 1.0;
  } else if (d.includes('VD 300ML') || d.includes('300ML')) {
    volumeLitrosUnit = 0.300;
  } else if (d.includes('355ML') || d.includes('355 ML') || d.includes('LN 355ML')) {
    volumeLitrosUnit = 0.355;
  } else if (d.includes('473ML') || d.includes('473 ML') || d.includes('LT 473ML')) {
    volumeLitrosUnit = 0.473;
  } else if (d.includes('350ML') || d.includes('LATA 350ML') || d.includes('LT 350ML')) {
    volumeLitrosUnit = 0.350;
  } else if (d.includes('275ML') || d.includes('275 ML')) {
    volumeLitrosUnit = 0.275;
  } else if (d.includes('269ML') || d.includes('LT 269ML')) {
    volumeLitrosUnit = 0.269;
  } else if (d.includes('250ML') || d.includes('LATA 250ML')) {
    volumeLitrosUnit = 0.250;
  } else if (d.includes('200ML') || d.includes('PET 200ML')) {
    volumeLitrosUnit = 0.200;
  } else if (d.includes('500ML') || d.includes('PET 500ML') || d.includes('GFA PET 500ML') || d.includes('GFA PET 510ML') || d.includes('510ML')) {
    volumeLitrosUnit = 0.500;
  } else if (d.includes('998ML') || d.includes('900ML') || d.includes('965ML')) {
    volumeLitrosUnit = 0.950;
  } else if (d.includes('750ML') || d.includes('GFA VD 750') || d.includes('750 ML')) {
    volumeLitrosUnit = 0.750;
  } else if (d.includes('28G') || d.includes('PCT 27G') || d.includes('8G') || d.includes('800G')) {
    return 0.001; // placeholder não-líquido
  }

  // Hectolitro (HL) = Litros / 100. Multiplica pelas unidades por caixa (factor)
  return (volumeLitrosUnit * factor) / 100;
}

// ==========================================
// PARSE EM TEMPO DE EXECUÇÃO DO RELATÓRIO 02.05.02 (Estoque e Inventário)
// ==========================================

const parseEstoqueEInventario = (): { estoque: EstoqueAtual[]; inventario: InventarioItem[] } => {
  const lines = rawReportEstoque.split('\n');
  const estoque: EstoqueAtual[] = [];
  const inventario: InventarioItem[] = [];

  lines.forEach((line) => {
    if (!line.includes(';')) return;
    const cols = line.split(';');
    if (cols.length < 25) return;
    
    const rawSku = cols[3].trim();
    if (rawSku === 'Produto' || !rawSku || isNaN(Number(rawSku))) return;

    const sku = rawSku.padStart(8, '0');
    
    // Procura na tabela de base fiscal ERP importada
    const erpItem = erpCatalogMap.get(sku);
    
    const descricao = erpItem ? erpItem.descricao : cols[4].trim();
    const fatorEmbalagem = erpItem ? erpItem.fatorSku : (parseInt(cols[23].trim()) || 12);
    
    let custoMedio = 45.00;
    if (erpItem) {
      custoMedio = erpItem.custoPorSku;
    } else {
      const rawCusto = cols[24].trim().replace(',', '.');
      const custoUnitario = parseFloat(rawCusto) || 1.50;
      custoMedio = custoUnitario * fatorEmbalagem; // valor por caixa
    }
    
    const fatorHectolitro = erpItem ? erpItem.fatorHecto : calcularFatorHectolitro(descricao, fatorEmbalagem);

    const saldoAtualCaixas = Math.floor(parseFrac(cols[9], fatorEmbalagem));
    const inventarioFisicoCaixas = Math.floor(parseFrac(cols[12], fatorEmbalagem));

    estoque.push({
      sku,
      descricao,
      custoMedio,
      fatorEmbalagem,
      fatorHectolitro,
      quantidadeAtualCaixas: saldoAtualCaixas
    });

    inventario.push({
      sku,
      estoqueSistemaCaixas: saldoAtualCaixas,
      estoqueFisicoCaixas: inventarioFisicoCaixas !== 0 ? inventarioFisicoCaixas : saldoAtualCaixas
    });
  });

  return { estoque, inventario };
};

const parsedEstoqueEInv = parseEstoqueEInventario();

export const relatorioEstoqueInicial: EstoqueAtual[] = parsedEstoqueEInv.estoque;
export const relatorioInventarioInicial: InventarioItem[] = parsedEstoqueEInv.inventario;

// ==========================================
// PARSE EM TEMPO DE EXECUÇÃO DO RELATÓRIO 03.05.19 (Venda Média)
// ==========================================

const parseVendasMedias = (): VendaMedia[] => {
  const lines = rawReportVendas.split('\n');
  const vendas: VendaMedia[] = [];

  lines.forEach((line) => {
    if (!line.includes(';')) return;
    const cols = line.split(';');
    if (cols.length < 15) return;

    const rawSku = cols[6].trim();
    if (rawSku === 'Produto' || !rawSku || isNaN(Number(rawSku))) return;

    const sku = rawSku.padStart(8, '0');
    const vendaTotalRaw = cols[19] || cols[9];
    const vendaMensalMediaCaixas = parseFloat(vendaTotalRaw.trim().replace(',', '.')) || 0;

    vendas.push({
      sku,
      vendaMensalMediaCaixas
    });
  });

  // Se algum SKU do estoque não tiver vendas associadas, adiciona um giro simbólico pequeno para evitar divisão por zero ou falta de curva
  relatorioEstoqueInicial.forEach(est => {
    if (!vendas.some(v => v.sku === est.sku)) {
      vendas.push({
        sku: est.sku,
        vendaMensalMediaCaixas: getDeterministicHash(est.sku, "vendas", 350) + 10
      });
    }
  });

  return vendas;
};

export const relatorioVendasMedias: VendaMedia[] = parseVendasMedias();

// ==========================================
// GERAÇÃO DINÂMICA DE CAIXAS POR PALLET
// ==========================================

const gerarCaixasPallet = (): CaixaPallet[] => {
  return relatorioEstoqueInicial.map((est) => {
    const erpItem = erpCatalogMap.get(est.sku);
    if (erpItem) {
      return {
        sku: est.sku,
        caixasPorPallet: erpItem.fatorPallet
      };
    }

    const d = est.descricao.toUpperCase();
    let caixasPorPallet = 80;

    if (d.includes('LATA') || d.includes('LT') || d.includes('SLEEK')) {
      caixasPorPallet = 100;
    } else if (d.includes('PET 2L') || d.includes('PET 2.5L') || d.includes('2,5L')) {
      caixasPorPallet = 60;
    } else if (d.includes('PET 1L') || d.includes('PET 1.5L')) {
      caixasPorPallet = 80;
    } else if (d.includes('600ML') || d.includes('600 ML') || d.includes('1L')) {
      caixasPorPallet = 64;
    } else if (d.includes('BARRIL') || d.includes('KEG')) {
      caixasPorPallet = 10;
    } else if (d.includes('TRIDENT') || d.includes('HALLS') || d.includes('BUBBALOO') || d.includes('PCT')) {
      caixasPorPallet = 120;
    }

    return {
      sku: est.sku,
      caixasPorPallet
    };
  });
};

export const relatorioCaixasPallet: CaixaPallet[] = gerarCaixasPallet();

// ==========================================
// RECEBIMENTO DE NOTAS FISCAIS FUTURAS (PREVISÕES NO ERP)
// ==========================================

export const relatorioEntradasFuturasInicial: EntradaFiscalFutura[] = [
  { id: 'EF-347', sku: '00000347', descricao: 'SUKITA PET 1L CAIXA C/12', dataPrevisao: '2026-06-01', quantidadeCaixas: 400, chaveNotaFiscal: '352605489001328900456128001002345347', fornecedor: 'AMBEV S/A DISTRIBUIDORA REGIONAL', valorTotal: 13450.00, status: 'Pendente' },
  { id: 'EF-503', sku: '00000503', descricao: 'SUKITA PET 2L CAIXA C/6', dataPrevisao: '2026-06-03', quantidadeCaixas: 800, chaveNotaFiscal: '352605489001328900456128001002345503', fornecedor: 'AMBEV INDUSTRIAL BRASIL', valorTotal: 19570.00, status: 'Pendente' },
  { id: 'EF-982', sku: '00000982', descricao: 'SKOL 600ML', dataPrevisao: '2026-06-04', quantidadeCaixas: 600, chaveNotaFiscal: '352605489001328900456128001002345982', fornecedor: 'AMBEV S/A REFRIGERANTES', valorTotal: 30400.00, status: 'Pendente' },
  { id: 'EF-2515', sku: '00025151', descricao: 'OLD PARR WHISKY GFA VDR 1L', dataPrevisao: '2026-06-06', quantidadeCaixas: 150, chaveNotaFiscal: '352605489001328900456128001002325151', fornecedor: 'DIAGEO IMPORTADORA BRASIL', valorTotal: 78500.00, status: 'Pendente' }
];

// ==========================================
// GERAÇÃO DINÂMICA DE LOTES DE VALIDADE (FEFO) DETERMINÍSTICA
// ==========================================

const pdfLotesSemente: LoteValidade[] = [
  {
    id: "LPDF01",
    sku: "00020164",
    numeroLote: "LOT-VAL-A1-1",
    dataFabricacao: "2026-04-19",
    dataValidade: "2026-12-19",
    quantidadeCaixas: 240,
    diasParaVencer: 201,
    alertaStatus: "Normal",
    rua: "A1",
    nivel: 1,
    posicaoRef: "A1-M01-N1"
  },
  {
    id: "LPDF02",
    sku: "00033820",
    numeroLote: "LOT-VAL-A1-2",
    dataFabricacao: "2026-05-11",
    dataValidade: "2027-01-11",
    quantidadeCaixas: 720,
    diasParaVencer: 224,
    alertaStatus: "Normal",
    rua: "A1",
    nivel: 2,
    posicaoRef: "A1-M02-N2"
  },
  {
    id: "LPDF03",
    sku: "00021020",
    numeroLote: "LOT-VAL-A1-3",
    dataFabricacao: "2026-05-06",
    dataValidade: "2027-01-06",
    quantidadeCaixas: 720,
    diasParaVencer: 219,
    alertaStatus: "Normal",
    rua: "A1",
    nivel: 3,
    posicaoRef: "A1-M03-N3"
  },
  {
    id: "LPDF04",
    sku: "00033820",
    numeroLote: "LOT-VAL-A1-4",
    dataFabricacao: "2026-05-10",
    dataValidade: "2027-01-10",
    quantidadeCaixas: 480,
    diasParaVencer: 223,
    alertaStatus: "Normal",
    rua: "A1",
    nivel: 4,
    posicaoRef: "A1-M04-N4"
  },
  {
    id: "LPDF05",
    sku: "00035331",
    numeroLote: "LOT-VAL-A2-1",
    dataFabricacao: "2026-05-18",
    dataValidade: "2027-01-18",
    quantidadeCaixas: 480,
    diasParaVencer: 231,
    alertaStatus: "Normal",
    rua: "A2",
    nivel: 1,
    posicaoRef: "A2-M01-N1"
  },
  {
    id: "LPDF06",
    sku: "00009427",
    numeroLote: "LOT-VAL-A2-2",
    dataFabricacao: "2026-03-19",
    dataValidade: "2026-11-19",
    quantidadeCaixas: 320,
    diasParaVencer: 171,
    alertaStatus: "Normal",
    rua: "A2",
    nivel: 2,
    posicaoRef: "A2-M02-N2"
  },
  {
    id: "LPDF07",
    sku: "00001388",
    numeroLote: "LOT-VAL-A2-3",
    dataFabricacao: "2026-05-04",
    dataValidade: "2027-01-04",
    quantidadeCaixas: 480,
    diasParaVencer: 217,
    alertaStatus: "Normal",
    rua: "A2",
    nivel: 3,
    posicaoRef: "A2-M03-N3"
  },
  {
    id: "LPDF08",
    sku: "00001388",
    numeroLote: "LOT-VAL-A2-4",
    dataFabricacao: "2026-04-30",
    dataValidade: "2026-12-30",
    quantidadeCaixas: 50,
    diasParaVencer: 212,
    alertaStatus: "Normal",
    rua: "A2",
    nivel: 4,
    posicaoRef: "A2-M04-N4"
  },
  {
    id: "LPDF09",
    sku: "00002538",
    numeroLote: "LOT-VAL-A3-1",
    dataFabricacao: "2026-04-13",
    dataValidade: "2026-12-13",
    quantidadeCaixas: 480,
    diasParaVencer: 195,
    alertaStatus: "Normal",
    rua: "A3",
    nivel: 1,
    posicaoRef: "A3-M01-N1"
  },
  {
    id: "LPDF10",
    sku: "00002546",
    numeroLote: "LOT-VAL-A3-2",
    dataFabricacao: "2026-05-20",
    dataValidade: "2027-01-20",
    quantidadeCaixas: 80,
    diasParaVencer: 233,
    alertaStatus: "Normal",
    rua: "A3",
    nivel: 2,
    posicaoRef: "A3-M02-N2"
  },
  {
    id: "LPDF11",
    sku: "00001743",
    numeroLote: "LOT-VAL-A3-3",
    dataFabricacao: "2026-05-18",
    dataValidade: "2027-01-18",
    quantidadeCaixas: 1440,
    diasParaVencer: 231,
    alertaStatus: "Normal",
    rua: "A3",
    nivel: 3,
    posicaoRef: "A3-M03-N3"
  },
  {
    id: "LPDF12",
    sku: "00001695",
    numeroLote: "LOT-VAL-A3-4",
    dataFabricacao: "2026-05-06",
    dataValidade: "2027-01-06",
    quantidadeCaixas: 80,
    diasParaVencer: 219,
    alertaStatus: "Normal",
    rua: "A3",
    nivel: 4,
    posicaoRef: "A3-M04-N4"
  },
  {
    id: "LPDF13",
    sku: "00007325",
    numeroLote: "LOT-VAL-A4-1",
    dataFabricacao: "2026-02-28",
    dataValidade: "2026-08-31",
    quantidadeCaixas: 160,
    diasParaVencer: 91,
    alertaStatus: "Normal",
    rua: "A4",
    nivel: 1,
    posicaoRef: "A4-M01-N1"
  },
  {
    id: "LPDF14",
    sku: "00002350",
    numeroLote: "LOT-VAL-A4-2",
    dataFabricacao: "2026-02-22",
    dataValidade: "2026-10-22",
    quantidadeCaixas: 160,
    diasParaVencer: 143,
    alertaStatus: "Normal",
    rua: "A4",
    nivel: 2,
    posicaoRef: "A4-M02-N2"
  },
  {
    id: "LPDF15",
    sku: "00013065",
    numeroLote: "LOT-VAL-A4-3",
    dataFabricacao: "2026-01-06",
    dataValidade: "2026-08-06",
    quantidadeCaixas: 560,
    diasParaVencer: 66,
    alertaStatus: "Atenção",
    rua: "A4",
    nivel: 3,
    posicaoRef: "A4-M03-N3"
  },
  {
    id: "LPDF16",
    sku: "00000503",
    numeroLote: "LOT-VAL-B1-1",
    dataFabricacao: "2026-02-25",
    dataValidade: "2026-10-25",
    quantidadeCaixas: 480,
    diasParaVencer: 146,
    alertaStatus: "Normal",
    rua: "B1",
    nivel: 1,
    posicaoRef: "B1-M01-N1"
  },
  {
    id: "LPDF17",
    sku: "00013061",
    numeroLote: "LOT-VAL-B1-2",
    dataFabricacao: "2025-12-27",
    dataValidade: "2026-08-27",
    quantidadeCaixas: 640,
    diasParaVencer: 87,
    alertaStatus: "Normal",
    rua: "B1",
    nivel: 2,
    posicaoRef: "B1-M02-N2"
  },
  {
    id: "LPDF18",
    sku: "00029845",
    numeroLote: "LOT-VAL-B2-1",
    dataFabricacao: "2026-01-02",
    dataValidade: "2026-09-02",
    quantidadeCaixas: 160,
    diasParaVencer: 93,
    alertaStatus: "Normal",
    rua: "B2",
    nivel: 1,
    posicaoRef: "B2-M01-N1"
  },
  {
    id: "LPDF19",
    sku: "00018836",
    numeroLote: "LOT-VAL-B3-1",
    dataFabricacao: "2026-05-16",
    dataValidade: "2027-05-16",
    quantidadeCaixas: 480,
    diasParaVencer: 349,
    alertaStatus: "Normal",
    rua: "B3",
    nivel: 1,
    posicaoRef: "B3-M01-N1"
  },
  {
    id: "LPDF20",
    sku: "00021020",
    numeroLote: "LOT-VAL-PICK-1",
    dataFabricacao: "2026-02-03",
    dataValidade: "2026-11-03",
    quantidadeCaixas: 3,
    diasParaVencer: 155,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF21",
    sku: "00001695",
    numeroLote: "LOT-VAL-PICK-2",
    dataFabricacao: "2026-05-06",
    dataValidade: "2027-01-06",
    quantidadeCaixas: 5,
    diasParaVencer: 219,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF22",
    sku: "00001743",
    numeroLote: "LOT-VAL-PICK-3",
    dataFabricacao: "2026-05-05",
    dataValidade: "2027-01-05",
    quantidadeCaixas: 12,
    diasParaVencer: 218,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF23",
    sku: "00035331",
    numeroLote: "LOT-VAL-PICK-4",
    dataFabricacao: "2026-05-18",
    dataValidade: "2027-01-18",
    quantidadeCaixas: 8,
    diasParaVencer: 231,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF24",
    sku: "00001388",
    numeroLote: "LOT-VAL-PICK-5",
    dataFabricacao: "2026-04-30",
    dataValidade: "2026-12-30",
    quantidadeCaixas: 7,
    diasParaVencer: 212,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF25",
    sku: "00029253",
    numeroLote: "LOT-VAL-PICK-6",
    dataFabricacao: "2026-05-16",
    dataValidade: "2027-01-16",
    quantidadeCaixas: 7,
    diasParaVencer: 229,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF26",
    sku: "00020217",
    numeroLote: "LOT-VAL-PICK-7",
    dataFabricacao: "2026-04-25",
    dataValidade: "2026-12-25",
    quantidadeCaixas: 8,
    diasParaVencer: 207,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF27",
    sku: "00013205",
    numeroLote: "LOT-VAL-PICK-8",
    dataFabricacao: "2026-05-14",
    dataValidade: "2027-01-14",
    quantidadeCaixas: 3,
    diasParaVencer: 227,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF28",
    sku: "00013201",
    numeroLote: "LOT-VAL-PICK-9",
    dataFabricacao: "2026-05-12",
    dataValidade: "2027-01-12",
    quantidadeCaixas: 6,
    diasParaVencer: 225,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF29",
    sku: "00000982",
    numeroLote: "LOT-VAL-PICK-10",
    dataFabricacao: "2026-05-22",
    dataValidade: "2027-01-22",
    quantidadeCaixas: 5,
    diasParaVencer: 235,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF30",
    sku: "00000988",
    numeroLote: "LOT-VAL-PICK-11",
    dataFabricacao: "2026-05-20",
    dataValidade: "2027-01-20",
    quantidadeCaixas: 4,
    diasParaVencer: 233,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF31",
    sku: "00002548",
    numeroLote: "LOT-VAL-PICK-12",
    dataFabricacao: "2026-04-30",
    dataValidade: "2026-12-30",
    quantidadeCaixas: 6,
    diasParaVencer: 212,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF32",
    sku: "00020530",
    numeroLote: "LOT-VAL-PICK-13",
    dataFabricacao: "2026-05-07",
    dataValidade: "2027-01-07",
    quantidadeCaixas: 5,
    diasParaVencer: 220,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF33",
    sku: "00023186",
    numeroLote: "LOT-VAL-PICK-14",
    dataFabricacao: "2026-05-10",
    dataValidade: "2027-02-10",
    quantidadeCaixas: 1,
    diasParaVencer: 254,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF34",
    sku: "00002546",
    numeroLote: "LOT-VAL-PICK-15",
    dataFabricacao: "2026-05-20",
    dataValidade: "2027-01-20",
    quantidadeCaixas: 5,
    diasParaVencer: 233,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF35",
    sku: "00019164",
    numeroLote: "LOT-VAL-PICK-16",
    dataFabricacao: "2026-03-08",
    dataValidade: "2026-11-08",
    quantidadeCaixas: 55,
    diasParaVencer: 160,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  },
  {
    id: "LPDF36",
    sku: "00002349",
    numeroLote: "LOT-VAL-PICK-17",
    dataFabricacao: "2026-03-06",
    dataValidade: "2026-11-06",
    quantidadeCaixas: 8,
    diasParaVencer: 158,
    alertaStatus: "Normal",
    rua: "picking",
    nivel: 1,
    posicaoRef: "picking"
  }
];

const gerarLotesDeterministas = (): LoteValidade[] => {
  const lotes: LoteValidade[] = [];
  let idCounter = 1;

  // Atualiza diasParaVencer e alertaStatus dinamicamente de acordo com a data atual para os dados semente do PDF
  pdfLotesSemente.forEach(l => {
    const currentDays = Math.max(0, Math.round((new Date(l.dataValidade).getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
    l.diasParaVencer = currentDays;
    l.alertaStatus = currentDays <= 30 ? 'Crítico' : currentDays <= 60 ? 'Atenção' : 'Normal';
  });

  // Insere os lotes semente reais extraídos das páginas do PDF Ambev
  lotes.push(...pdfLotesSemente);

  relatorioEstoqueInicial.forEach((est) => {
    if (est.quantidadeAtualCaixas <= 0) return;
    
    // Evita duplicar demasiadamente para SKUs que já têm do PDF semente
    const hasSeed = pdfLotesSemente.some(s => s.sku === est.sku);
    if (hasSeed) return;

    const fatorPallet = relatorioCaixasPallet.find(p => p.sku === est.sku)?.caixasPorPallet || 80;
    const cat = obterCategoriaPorSku(est.sku, est.descricao);
    
    // Hash determinístico baseado em SKU para consistência
    const hashVal = getDeterministicHash(est.sku, "fefovalidade", 150);
    const diasValidadeLoteA = 10 + (hashVal % 45); // Lotes críticos (entre 10 e 55 dias)
    const diasValidadeLoteB = 100 + (hashVal % 120); // Lotes normais (entre 100 e 220 dias)

    const qtdA = Math.round(est.quantidadeAtualCaixas * 0.25);
    const qtdB = est.quantidadeAtualCaixas - qtdA;

    const dataFabricacaoA = new Date();
    dataFabricacaoA.setDate(dataFabricacaoA.getDate() - (90 - diasValidadeLoteA / 2));
    const dataValidadeA = new Date();
    dataValidadeA.setDate(dataValidadeA.getDate() + diasValidadeLoteA);

    const dataFabricacaoB = new Date();
    dataFabricacaoB.setDate(dataFabricacaoB.getDate() - 30);
    const dataValidadeB = new Date();
    dataValidadeB.setDate(dataValidadeB.getDate() + diasValidadeLoteB);

    let alertaA: 'Normal' | 'Atenção' | 'Crítico' = 'Normal';
    if (diasValidadeLoteA <= 30) alertaA = 'Crítico';
    else if (diasValidadeLoteA <= 60) alertaA = 'Atenção';

    // Determina rua e nível com base na Categoria e no Giro do SKU
    let ruaA = "A4";
    let ruaB = "A1";
    if (cat === 'Cerveja') {
      ruaA = "A3";
      ruaB = "A1";
    } else if (cat === 'NAB') {
      ruaA = "B3";
      ruaB = "B1";
    } else {
      ruaA = "CB4";
      ruaB = "CB4";
    }

    // Anomalias FEFO deliberadas para Auditoria do WMS
    if (est.sku === '0013061' || est.sku === '00013061') { // H2OH NAB
      ruaA = "B2"; // Vence em 25 dias (A) está em B2 (ranking 6)
      ruaB = "B1"; // Vence em 90 dias (B) está em B1 (ranking 5)
    } else if (est.sku === '00000371') { // SKOL LATA
      ruaA = "A3"; // Vence em 15 dias (A) está em A3 (ranking 3)
      ruaB = "A1"; // Vence em 80 dias (B) está em A1 (ranking 1)
    }

    const tEntradaA = new Date();
    tEntradaA.setDate(tEntradaA.getDate() - 15);
    const tEntradaB = new Date();
    tEntradaB.setDate(tEntradaB.getDate() - 5);

    if (qtdA > 0) {
      lotes.push({
        id: `L0EXT_${idCounter++}`,
        sku: est.sku,
        numeroLote: `LOT-${est.sku}-T${hashVal}`,
        dataFabricacao: dataFabricacaoA.toISOString().split('T')[0],
        dataValidade: dataValidadeA.toISOString().split('T')[0],
        quantidadeCaixas: qtdA,
        diasParaVencer: diasValidadeLoteA,
        alertaStatus: alertaA,
        rua: ruaA,
        nivel: 2,
        posicaoRef: `${ruaA}-M04-N2`,
        dataEntrada: tEntradaA.toISOString().split('T')[0],
        dataUltimaMovimentacao: tEntradaA.toISOString().split('T')[0]
      });
    }

    if (qtdB > 0) {
      lotes.push({
        id: `L0EXT_${idCounter++}`,
        sku: est.sku,
        numeroLote: `LOT-${est.sku}-R${hashVal + 1}`,
        dataFabricacao: dataFabricacaoB.toISOString().split('T')[0],
        dataValidade: dataValidadeB.toISOString().split('T')[0],
        quantidadeCaixas: qtdB,
        diasParaVencer: diasValidadeLoteB,
        alertaStatus: 'Normal',
        rua: ruaB,
        nivel: 3,
        posicaoRef: `${ruaB}-M03-N3`,
        dataEntrada: tEntradaB.toISOString().split('T')[0],
        dataUltimaMovimentacao: tEntradaB.toISOString().split('T')[0]
      });
    }
  });

  return lotes;
};

export const lotesValidadeInicial: LoteValidade[] = gerarLotesDeterministas();

// ==========================================
// GERAÇÃO DE MAPEAMENTO DE PICKING TÉRREO
// ==========================================

const gerarPickingMapeamento = (): PickingMapeamento[] => {
  return relatorioEstoqueInicial.slice(0, 15).map((est) => {
    const hashVal = getDeterministicHash(est.sku, "picking", 60);
    const capacidadeCaixas = 150;
    const saldoAtualCaixas = Math.floor(est.quantidadeAtualCaixas * 0.12) || 20;

    return {
      sku: est.sku,
      capacidadeCaixas,
      saldoAtualCaixas: Math.min(capacidadeCaixas, saldoAtualCaixas),
      pontoRessuprimentoCaixas: 45
    };
  });
};

export const pickingMapeamentoInicial: PickingMapeamento[] = gerarPickingMapeamento();

// ==========================================
// CORE LOGIC: CATEGORIA E PARETO
// ==========================================

export function obterCategoriaPorSku(sku: string, descricao: string): Categoria {
  const d = descricao.toUpperCase();
  if (d.includes('CERVEJA') || d.includes('CHOPP') || d.includes('PILSEN') || d.includes('SKOL') || d.includes('BRAHMA') || d.includes('BUDWEISER') || d.includes('ORIGINAL') || d.includes('SPATEN') || d.includes('CORONA') || d.includes('MALZBIER') || d.includes('BOHEMIA')) {
    return 'Cerveja';
  }
  if (d.includes('SUKITA') || d.includes('PEPSI') || d.includes('COLA') || d.includes('GUARANA') || d.includes('SODA') || d.includes('TONICA') || d.includes('H2OH') || d.includes('AGUA') || d.includes('INDAIA') || d.includes('ELEVE') || d.includes('DIAS DAVILA') || d.includes('PET_2L') || d.includes('PET_1L') || d.includes('GATORADE') || d.includes('RED BULL') || d.includes('ELEV')) {
    return 'NAB';
  }
  return 'Marketplace';
}

export function processarBasesDados(
  estoque: EstoqueAtual[],
  inventario: InventarioItem[],
  pallet: CaixaPallet[],
  vendas: VendaMedia[],
  divergenciasCongeladas: any[] = []
): ProdutoConsolidado[] {
  // Ordenamento Pareto: vendas decrescentes
  const totalVendas = vendas.reduce((acc, current) => acc + current.vendaMensalMediaCaixas, 0);

  const vMap = new Map<string, number>();
  vendas.forEach(v => vMap.set(v.sku, v.vendaMensalMediaCaixas));

  const pMap = new Map<string, number>();
  pallet.forEach(p => pMap.set(p.sku, p.caixasPorPallet));

  const invMap = new Map<string, InventarioItem>();
  inventario.forEach(i => invMap.set(i.sku, i));

  const skusOrdenadosGiro = [...vendas].sort((a, b) => b.vendaMensalMediaCaixas - a.vendaMensalMediaCaixas);

  let volumeAcumulado = 0;
  const limitsPareto = new Map<string, { cumulativePct: number; curva: CurvaABC }>();

  skusOrdenadosGiro.forEach((v) => {
    volumeAcumulado += v.vendaMensalMediaCaixas;
    const cumulativePct = totalVendas > 0 ? (volumeAcumulado / totalVendas) * 100 : 100;
    
    let curva: CurvaABC = 'C';
    if (cumulativePct <= 80.01) {
      curva = 'A';
    } else if (cumulativePct <= 95.01) {
      curva = 'B';
    } else {
      curva = 'C';
    }

    limitsPareto.set(v.sku, { cumulativePct, curva });
  });

  return estoque.map((item) => {
    const sku = item.sku;
    
    const erpItem = erpCatalogMap.get(sku);
    let realDesc = erpItem ? erpItem.descricao : item.descricao;
    let resolvedCusto = erpItem ? erpItem.custoPorSku : item.custoMedio;
    let resolvedHectolitro = erpItem ? erpItem.fatorHecto : item.fatorHectolitro;
    let resolvedFatorEmbalagem = erpItem ? erpItem.fatorSku : item.fatorEmbalagem;

    // Sincroniza e corrige também a referência original do estoque em memória
    if (erpItem) {
      item.descricao = erpItem.descricao;
      item.custoMedio = erpItem.custoPorSku;
      item.fatorHectolitro = erpItem.fatorHecto;
      item.fatorEmbalagem = erpItem.fatorSku;
    }

    let cat = obterCategoriaPorSku(sku, realDesc);
    if (erpItem && erpItem.categoria) {
      const upperCat = String(erpItem.categoria).toUpperCase().trim();
      if (upperCat.includes("CERV") || upperCat.includes("CHOP")) {
        cat = "Cerveja";
      } else if (upperCat === "NAB" || upperCat.includes("REFR") || upperCat.includes("AGU")) {
        cat = "NAB";
      } else {
        cat = "Marketplace";
      }
    }
    
    const inv = invMap.get(sku) || { sku, estoqueFisicoCaixas: item.quantidadeAtualCaixas, estoqueSistemaCaixas: item.quantidadeAtualCaixas };
    const vendaOntem = inv.vendaOntemCaixas || 0;
    const caixasPorPlt = pMap.get(sku) || 80;
    const vendasMensais = vMap.get(sku) || 0;
    const pareto = limitsPareto.get(sku) || { cumulativePct: 100, curva: 'C' as CurvaABC };

    const estoqueFisico = Math.floor(inv.estoqueFisicoCaixas);
    const estoqueSistema = Math.floor(inv.estoqueSistemaCaixas);
    
    // Soma de divergências congeladas para este SKU (tratados sempre de forma aditiva ao estoque físico)
    const totalCongelado = (divergenciasCongeladas || [])
      .filter((d: any) => d.sku === sku)
      .reduce((acc: number, d: any) => acc + Math.abs(d.diferencaCaixas || 0), 0);

    const saldoAjustado = Math.max(0, estoqueFisico + totalCongelado);
    const diferencaFisicaOriginal = estoqueFisico - estoqueSistema;
    
    // Cálculo da divergência final como o estoque ajustado (Físico + Congelados) menos o saldo fiscal (sistêmico)
    const diferencaAjustada = saldoAjustado - estoqueSistema;
    
    const volumeDivergenciaHL = diferencaAjustada * resolvedHectolitro;
    const valorDivergencia = diferencaAjustada * resolvedCusto;
    const temDivergencia = Math.abs(diferencaAjustada) > 0.001;

    const volumeTotalHL = saldoAjustado * resolvedHectolitro;
    const valorTotalFinanceiro = saldoAjustado * resolvedCusto;
    const totalUnitario = saldoAjustado * resolvedFatorEmbalagem;
    const palletsCalculados = saldoAjustado / caixasPorPlt;

    return {
      sku,
      descricao: realDesc,
      categoria: cat,
      custoMedio: resolvedCusto,
      fatorEmbalagem: resolvedFatorEmbalagem,
      fatorHectolitro: resolvedHectolitro,
      quantidadeAtualCaixas: saldoAjustado,
      quantidadeTotalUnitario: totalUnitario,
      valorTotalEstoque: valorTotalFinanceiro,
      volumeHectolitro: volumeTotalHL,

      estoqueFisicoCaixas: estoqueFisico,
      estoqueSistemaCaixas: estoqueSistema,
      saldoAjustadoCaixas: saldoAjustado,
      diferencaCaixas: diferencaAjustada,
      divergenciaHectolitro: volumeDivergenciaHL,
      divergenciaValor: valorDivergencia,
      temDivergencia,

      caixasPorPallet: caixasPorPlt,
      quantidadePallets: palletsCalculados,

      vendaMensalMediaCaixas: vendasMensais,
      vendaOntemCaixas: vendaOntem,
      porcentagemVolumeAcumulado: Math.round(pareto.cumulativePct * 10) / 10,
      curvaABC: pareto.curva
    };
  });
}

// ==========================================
// GERAÇÃO DE DETALHE DE POSIÇÃO WMS
// ==========================================

export function gerarLayoutWms(produtosConsolidados: ProdutoConsolidado[]): WmsPosicao[] {
  const posicoes: WmsPosicao[] = [];
  
  // Nomes das ruas para cada bloco físico do CD
  const blocoA = ["A1", "A2", "A3", "A4"];
  const blocoB = ["B1", "B2", "B3", "B4"];
  const blocoCB = ["CB1", "CB2", "CB3", "CB4"];
  const blocoC = ["C1", "C2", "C3", "C4"]; // Paredão

  // 1. Gerar todas as posições físicas do CD determinando a área correta de cada slot
  
  // Bloco A (4 ruas * 18 módulos * 4 níveis = 288 posições)
  blocoA.forEach(rua => {
    for (let m = 1; m <= 18; m++) {
      for (let n = 1; n <= 4; n++) {
        const id = `${rua}-M${String(m).padStart(2, '0')}-N${n}`;
        const area = (n === 1) ? 'Picking' : 'Central';
        const cap = (area === 'Picking') ? 1 : 2;
        posicoes.push({ id, area, rua, modulo: m, nivel: n, skuAlocado: null, capacidadePallets: cap, palletsAlocados: 0 });
      }
    }
  });

  // Bloco B (4 ruas * 18 módulos * 4 níveis = 288 posições)
  blocoB.forEach(rua => {
    for (let m = 1; m <= 18; m++) {
      for (let n = 1; n <= 4; n++) {
        const id = `${rua}-M${String(m).padStart(2, '0')}-N${n}`;
        // Para Picking, alocamos apenas B1, B2 no N1 inteiro (2 * 18 = 36 slots)
        // e B3 do módulo 1 ao 14 no N1 (14 slots)
        // Total Picking em B = 50 slots.
        let area: 'Central' | 'Picking' = 'Central';
        if (n === 1) {
          if (["B1", "B2"].includes(rua) || (rua === "B3" && m <= 14)) {
            area = 'Picking';
          }
        }
        const cap = (area === 'Picking') ? 1 : 2;
        posicoes.push({ id, area, rua, modulo: m, nivel: n, skuAlocado: null, capacidadePallets: cap, palletsAlocados: 0 });
      }
    }
  });

  // Bloco CB: CB1 a CB3 têm 16 módulos, CB4 tem 15 módulos
  // CB1, CB2, CB3 (3 ruas * 16 módulos * 4 níveis = 192 posições) -> Todas Central, exceto se decidíssemos Picking
  blocoCB.slice(0, 3).forEach(rua => {
    for (let m = 1; m <= 16; m++) {
      for (let n = 1; n <= 4; n++) {
        const id = `${rua}-M${String(m).padStart(2, '0')}-N${n}`;
        posicoes.push({ id, area: 'Central', rua, modulo: m, nivel: n, skuAlocado: null, capacidadePallets: 2, palletsAlocados: 0 });
      }
    }
  });

  // CB4 representa a área de Marketing e Vendas (1 rua * 15 módulos * 4 níveis = 60 posições)
  const ruaMV = "CB4";
  for (let m = 1; m <= 15; m++) {
    for (let n = 1; n <= 4; n++) {
      const id = `${ruaMV}-M${String(m).padStart(2, '0')}-N${n}`;
      posicoes.push({ id, area: 'Marketing e Vendas', rua: ruaMV, modulo: m, nivel: n, skuAlocado: null, capacidadePallets: 1, palletsAlocados: 0 });
    }
  }

  // Bloco C (Paredão): 4 ruas * 12 módulos * 2 níveis = 96 posições
  blocoC.forEach(rua => {
    for (let m = 1; m <= 12; m++) {
      for (let n = 1; n <= 2; n++) {
        const id = `${rua}-M${String(m).padStart(2, '0')}-N${n}`;
        posicoes.push({ id, area: 'Paredão', rua, modulo: m, nivel: n, skuAlocado: null, capacidadePallets: 2, palletsAlocados: 0 });
      }
    }
  });

  // 2. Alocação Inteligente dos Produtos baseando-se em suas regras e Giro
  const produtosOrdenadosGiro = [...produtosConsolidados].sort((a, b) => b.vendaMensalMediaCaixas - a.vendaMensalMediaCaixas);

  produtosOrdenadosGiro.forEach((prod) => {
    let palletsMarcador = Math.ceil(prod.quantidadePallets);
    if (palletsMarcador <= 0) return;

    // Regra de Segregação por Classificação e Categoria
    let ruasAlvo: string[] = [];
    let areaAlvo: 'Central' | 'Picking' | 'Paredão' | 'Marketing e Vendas' = 'Central';

    if (prod.categoria === 'Marketplace') {
      ruasAlvo = ["CB4"];
      areaAlvo = 'Marketing e Vendas';
    } else if (prod.categoria === 'NAB') {
      ruasAlvo = ["B2", "B3", "B4", "CB1", "CB2"];
      areaAlvo = 'Central';
    } else { // Cervejas / Alta Rotatividade
      ruasAlvo = ["A1", "A2", "A3", "A4", "B1", "C1", "C2", "C3", "C4"];
      areaAlvo = (prod.curvaABC === 'A') ? 'Central' : 'Paredão';
    }

    // Aloca Picking para SKU com giro de curva A ou B
    if (prod.curvaABC === 'A' || prod.curvaABC === 'B') {
      const posPickingLivre = posicoes.filter(p => 
        p.area === 'Picking' && 
        p.skuAlocado === null && 
        ruasAlvo.includes(p.rua)
      );

      if (posPickingLivre.length > 0) {
        const pPick = posPickingLivre[0];
        pPick.skuAlocado = prod.sku;
        const alocado = Math.min(palletsMarcador, pPick.capacidadePallets);
        pPick.palletsAlocados = alocado;
        palletsMarcador -= alocado;
      }
    }

    // Aloca Pulmão restante (Central ou Paredão dependendo das características)
    while (palletsMarcador > 0) {
      const posLivres = posicoes.filter(p => 
        p.area === areaAlvo && 
        p.skuAlocado === null && 
        ruasAlvo.includes(p.rua)
      );

      // Se não houver vagas exatas na rua alvo, use qualquer vaga livre que corresponda à Área específica do produto
      const vagas = posLivres.length > 0 ? posLivres : posicoes.filter(p => p.area === areaAlvo && p.skuAlocado === null);

      if (vagas.length > 0) {
        // Ordena por nível para preencher embaixo primeiro (N2 antes de N4)
        vagas.sort((a, b) => a.nivel - b.nivel || a.modulo - b.modulo);
        const pCentral = vagas[0];
        pCentral.skuAlocado = prod.sku;
        const alocado = Math.min(palletsMarcador, pCentral.capacidadePallets);
        pCentral.palletsAlocados = alocado;
        palletsMarcador -= alocado;
      } else {
        // Fallback de contingência caso todo o armazém especializado esteja cheio
        const fallbackLivre = posicoes.find(p => p.skuAlocado === null);
        if (fallbackLivre) {
          fallbackLivre.skuAlocado = prod.sku;
          const alocado = Math.min(palletsMarcador, fallbackLivre.capacidadePallets);
          fallbackLivre.palletsAlocados = alocado;
          palletsMarcador -= alocado;
        } else {
          break; // Sem vagas no galpão
        }
      }
    }
  });

  // 3. Atribuir Idade do Pallet e Stock Age Index para posições ocupadas
  posicoes.forEach((pos, idx) => {
    if (pos.skuAlocado) {
      const prod = produtosConsolidados.find(p => p.sku === pos.skuAlocado);
      const cleanSku = pos.skuAlocado.replace(/^0+/, '') || '1';
      const parsedSku = parseInt(cleanSku, 10) || 123;
      const hash = (parsedSku + idx) % 100;
      let idade = 10 + (hash % 120); // de 10 a 130 dias
      if (prod?.curvaABC === 'A') {
        idade = 2 + (hash % 18); // de 2 a 20 dias
      } else if (prod?.curvaABC === 'B') {
        idade = 15 + (hash % 40); // de 15 a 55 dias
      }
      pos.idadePallet = idade;
      
      let benchmark = 45;
      if (prod?.curvaABC === 'A') benchmark = 15;
      else if (prod?.curvaABC === 'B') benchmark = 45;
      else benchmark = 90;
      
      const sai = Math.round((idade / benchmark) * 100);
      pos.stockAgeIndex = Math.min(100, Math.max(5, sai));
    } else {
      pos.idadePallet = 0;
      pos.stockAgeIndex = 0;
    }
  });

  return posicoes;
}
