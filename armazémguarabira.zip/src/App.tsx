/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Sparkles, 
  Cpu, 
  Map, 
  Users, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp, 
  RefreshCw,
  FolderLock,
  Layers,
  Sliders,
  LogOut,
  X,
  Send,
  MessageSquare,
  Bot,
  HelpCircle,
  ExternalLink,
  UploadCloud,
  Check,
  FileText,
  Loader2
} from 'lucide-react';

import JSZip from 'jszip';

import DashboardExecutive from './components/DashboardExecutive';
import InventoryReconciliation from './components/InventoryReconciliation';
import WmsLayout from './components/WmsLayout';
import FutureControl from './components/FutureControl';
import AiInsights from './components/AiInsights';
import AdminOperators from './components/AdminOperators';
import InteractiveLayout from './components/InteractiveLayout';
import { ProductivityHub } from './components/ProductivityHub';
import { PauBrasilLogo } from './components/PauBrasilLogo';
import { LoginScreen } from './components/LoginScreen';
import StockInversionAI from './components/StockInversionAI';

import { db, auth, handleFirestoreError, OperationType } from './lib/firebase';
import { collection, onSnapshot, query, doc, setDoc } from 'firebase/firestore';

import { ProdutoConsolidado, LoteValidade, PickingMapeamento, EntradaFiscalFutura } from './types';

export default function App() {
  const [operatorUser, setOperatorUser] = useState<string | null>(() => {
    return localStorage.getItem('paubrasil_current_logged_user');
  });

  const isAdmin = operatorUser ? (operatorUser.toLowerCase().includes("g1002") || operatorUser.toLowerCase().includes("administrador")) : false;

  const userEmail = operatorUser || "djesoaresn@gmail.com";
  
  // Tab ativa principal
  const [activeTab, setActiveTab ] = useState("executivo");

  // Estado unificado baixado do Servidor
  const [produtos, setProdutos] = useState<ProdutoConsolidado[]>([]);
  const [lotesValidade, setLotesValidade] = useState<LoteValidade[]>([]);
  const [pickingMapeamento, setPickingMapeamento] = useState<PickingMapeamento[]>([]);
  const [entradasFuturas, setEntradasFuturas] = useState<EntradaFiscalFutura[]>([]);
  const [layoutWms, setLayoutWms] = useState<any[]>([]);
  const [logsAuditoria, setLogsAuditoria] = useState<any[]>([]);
  const [divergenciasCongeladas, setDivergenciasCongeladas] = useState<any[]>([]);
  const [historicoConciliacoes, setHistoricoConciliacoes] = useState<any[]>([]);
  const [produtividade, setProdutividade] = useState<any[]>([]);
  const [showWmsFallback, setShowWmsFallback] = useState(false);
  const [wmsSubTab, setWmsSubTab] = useState<'racks' | 'mapa' | 'fefo'>('mapa');

  // Estado para Importação e Integração de ZIP
  const [zipFiles, setZipFiles] = useState<any[]>([]);
  const [isAnalyzingZip, setIsAnalyzingZip] = useState(false);
  const [zipMergeSuccess, setZipMergeSuccess] = useState(false);
  const [zipMergeMessage, setZipMergeMessage] = useState("");
  const [zipMergeError, setZipMergeError] = useState("");
  const [zipCountdown, setZipCountdown] = useState<number | null>(null);
  const [zipDragActive, setZipDragActive] = useState(false);

  const processZipFile = async (file: File) => {
    setIsAnalyzingZip(true);
    setZipMergeError("");
    setZipMergeSuccess(false);
    setZipFiles([]);
    
    try {
      const zip = await JSZip.loadAsync(file);
      const extractedFiles: any[] = [];
      const filePromises: Promise<void>[] = [];

      zip.forEach((relativePath, zipEntry) => {
        // Ignora pastas vazias, arquivos de sistema como __MACOSX, arquivos git ou node_modules
        if (zipEntry.dir || relativePath.includes("__MACOSX") || relativePath.includes("node_modules") || relativePath.includes(".git")) {
          return;
        }

        // Localiza "src/" no caminho para normalizar e remover diretórios aninhados extras
        const srcIndex = relativePath.indexOf("src/");
        if (srcIndex === -1) {
          return; // Focar apenas nos arquivos da pasta src/ para modificação segura
        }

        const normPath = relativePath.substring(srcIndex);

        // Queremos apenas arquivos de código relevantes
        const allowedExtensions = [".tsx", ".ts", ".json", ".css", ".js", ".jsx"];
        const isAllowed = allowedExtensions.some(ext => normPath.endsWith(ext));

        if (!isAllowed) return;

        const promise = zipEntry.async("string").then((content) => {
          extractedFiles.push({
            name: zipEntry.name.split("/").pop() || zipEntry.name,
            path: normPath,
            content: content,
            size: content.length,
            selected: true, // selecionado por padrão
            status: "Pronto para integrar"
          });
        });

        filePromises.push(promise);
      });

      await Promise.all(filePromises);

      if (extractedFiles.length === 0) {
        setZipMergeError("Nenhum arquivo de código ('src/') válido foi encontrado no ZIP fornecido.");
      } else {
        // Ordena para que os arquivos do tipo components fiquem no topo
        extractedFiles.sort((a, b) => b.path.includes("components") ? 1 : -1);
        setZipFiles(extractedFiles);
      }
    } catch (err: any) {
      console.error("Erro ao analisar arquivo ZIP:", err);
      setZipMergeError("Erro ao processar o arquivo ZIP: " + err.message);
    } finally {
      setIsAnalyzingZip(false);
    }
  };

  const handleMergeZipFiles = async () => {
    const selectedFiles = zipFiles.filter(f => f.selected);
    if (selectedFiles.length === 0) {
      setZipMergeError("Por favor, selecione ao menos um arquivo para mesclar!");
      return;
    }

    setIsAnalyzingZip(true);
    setZipMergeError("");
    
    try {
      const payloadFiles = selectedFiles.map(f => ({
        path: f.path,
        content: f.content
      }));

      const res = await fetch("/api/state/merge-uploaded-zip-files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ files: payloadFiles })
      });

      const data = await res.json();
      
      if (data.success) {
        setZipMergeSuccess(true);
        setZipMergeMessage(data.message);
        
        // Inicia contagem regressiva para recarregar o app
        let counter = 5;
        setZipCountdown(counter);
        const timer = setInterval(() => {
          counter -= 1;
          setZipCountdown(counter);
          if (counter <= 0) {
            clearInterval(timer);
            window.location.reload();
          }
        }, 1000);
      } else {
        setZipMergeError(data.error || "Ocorreu um erro ao integrar os arquivos no servidor.");
      }
    } catch (err: any) {
      console.error("Erro ao mesclar arquivos:", err);
      setZipMergeError("Falha na requisição com o servidor: " + err.message);
    } finally {
      setIsAnalyzingZip(false);
    }
  };

  // Dispatchers de Produtividade (Firebase)
  const handleAddProductivity = async (item: any) => {
    try {
      const res = await fetch("/api/state/productivity/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item)
      });
      const resJson = await res.json();
      if (resJson.success) {
        // Envia também para o Firebase Firestore
        const novoItem = resJson.novoItem;
        if (novoItem) {
          try {
            await setDoc(doc(db, "productivity", novoItem.id), {
              id: novoItem.id,
              operador: novoItem.operador,
              tipo: novoItem.tipo,
              quantidadeCaixas: Number(novoItem.quantidadeCaixas),
              tempoMinutagem: Number(novoItem.tempoMinutagem),
              dataHora: novoItem.dataHora
            });
            console.log("Firebase: Atividade de produtividade persistida com sucesso.");
          } catch (fsErr: any) {
            console.error("Erro ao sincronizar com Firestore:", fsErr);
            handleFirestoreError(fsErr, OperationType.WRITE, `productivity/${novoItem.id}`);
          }
        }
        setProdutividade(resJson.produtividade);
        triggerToast("Atividade operacional adicionada e sincronizada com o Firebase!", "success");
      } else {
        throw new Error(resJson.error);
      }
    } catch (e: any) {
      triggerToast(e.message || "Erro ao registrar atividade no Firebase.", "warn");
    }
  };

  const handleResetProductivity = async () => {
    try {
      const res = await fetch("/api/state/productivity/reset", {
        method: "POST"
      });
      const resJson = await res.json();
      if (resJson.success) {
        // Sincroniza o restabelecimento com Firestore
        try {
          const listToSync = resJson.produtividade || [];
          for (const pItem of listToSync) {
            await setDoc(doc(db, "productivity", pItem.id), pItem);
          }
          console.log("Firebase: Base de produtividade restabelecida com sucesso no Firestore.");
        } catch (fsErr: any) {
          console.error("Erro ao sincronizar reset com Firestore:", fsErr);
          handleFirestoreError(fsErr, OperationType.WRITE, "productivity");
        }
        setProdutividade(resJson.produtividade);
        triggerToast("Base de produtividade restabelecida com sucesso.", "info");
      } else {
        throw new Error(resJson.error);
      }
    } catch (e: any) {
      triggerToast(e.message || "Erro ao limpar registros de produtividade.", "warn");
    }
  };

  // Estados de Carregamento e Notificações Rápidas
  const [stateLoading, setStateLoading] = useState(true);
  const [stateError, setStateError] = useState<string | null>(null);
  const [recentNotification, setRecentNotification] = useState<{ text: string; type: 'success' | 'warn' | 'info' } | null>(null);

  // Estado do Assistente IA Flutuante (chat integrado)
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [panelChatInput, setPanelChatInput] = useState("");
  const [panelChatLog, setPanelChatLog] = useState<any[]>([
    { 
      sender: 'assistant', 
      text: "Olá! Sou o assistente inteligente do CD Guarabira. Analiso em tempo real divergências, conciliações, endereços de picking e a melhor disposição/organização do estoque por Curva ABC (Regra de Pareto). Pergunte-me qualquer dúvida sobre os dados ou posições!", 
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) 
    }
  ]);
  const [panelChatLoading, setPanelChatLoading] = useState(false);
  const panelBottomRef = React.useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isAiDrawerOpen) {
      setTimeout(() => {
        panelBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [panelChatLog, isAiDrawerOpen]);

  const handlePanelChatSubmit = async (customText?: string) => {
    const textToSend = customText || panelChatInput;
    if (!textToSend.trim() || panelChatLoading) return;

    if (!customText) {
      setPanelChatInput("");
    }

    setPanelChatLog(prev => [...prev, {
      sender: 'user',
      text: textToSend,
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    }]);

    setPanelChatLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textToSend,
          contextoEstoque: produtos.map(p => ({
            sku: p.sku,
            descricao: p.descricao,
            categoria: p.categoria,
            curva: p.curvaABC,
            fisico: p.estoqueFisicoCaixas,
            sistemico: p.estoqueSistemaCaixas,
            diferenca: p.diferencaCaixas,
            valorDivergencia: p.divergenciaValor,
            pallets: p.quantidadePallets
          }))
        })
      });

      const resData = await res.json();
      if (resData.success) {
        setPanelChatLog(prev => [...prev, {
          sender: 'assistant',
          text: resData.answer,
          time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        }]);
      } else {
        throw new Error(resData.error || "Erro de rede");
      }
    } catch (err: any) {
      setPanelChatLog(prev => [...prev, {
        sender: 'assistant',
        text: "Desculpe conferente, houve um erro no contato remoto com o painel Gemini. Verifique se a GEMINI_API_KEY está configurada no painel de segredos do ambiente.",
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setPanelChatLoading(false);
    }
  };

  // Carrega e sincroniza o estado global na montagem e pós-transações com backup no localStorage do navegador contra reinicializações do servidor
  const sincronizarBaseCompleta = async () => {
    setStateLoading(true);
    setStateError(null);
    try {
      const res = await fetch("/api/state");
      const resJson = await res.json();
      if (resJson.success) {
        const { serverResetToken, data } = resJson;
        
        // Verifica se houve reinicialização da máquina/container para reidratar do navegador anterior
        const localResetToken = localStorage.getItem('paubrasil_server_reset_token');
        const backupDataStr = localStorage.getItem('paubrasil_state_backup_v2');
        
        let shouldRestoreOnServer = false;
        if (backupDataStr) {
          try {
            const backup = JSON.parse(backupDataStr);
            const serverIsEmpty = !data.historicoConciliacoes || data.historicoConciliacoes.length === 0;
            const backupHasData = (backup.historicoConciliacoes && backup.historicoConciliacoes.length > 0) ||
                                  (backup.divergenciasCongeladas && backup.divergenciasCongeladas.length > 0) ||
                                  (backup.estoqueAtual && backup.estoqueAtual.length > 0);
            
            if (serverIsEmpty && backupHasData) {
              shouldRestoreOnServer = true;
            } else if (serverResetToken && localResetToken && serverResetToken !== localResetToken && backupHasData) {
              shouldRestoreOnServer = true;
            }
          } catch (e) {
            console.error("Erro ao analisar backup do localStorage:", e);
          }
        }

        if (shouldRestoreOnServer && backupDataStr) {
          try {
            const parsedBackup = JSON.parse(backupDataStr);
            const restoreRes = await fetch("/api/state/restore-state", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(parsedBackup)
            });
            const restoreJson = await restoreRes.json();
            if (restoreJson.success) {
              localStorage.setItem('paubrasil_server_reset_token', serverResetToken);
              triggerToast("Base de dados operacionais e histórico restaurados com sucesso!", "info");
              // Sincroniza novamente com a base atualizada
              setTimeout(() => { sincronizarBaseCompleta(); }, 100);
              return;
            }
          } catch (restoreErr) {
            console.error("Falha ao reidratar base de dados do WMS:", restoreErr);
          }
        }

        const { produtosConsolidados, lotesValidade, pickingMapeamento, entradasFuturas, layoutWms, logsAuditoria, divergenciasCongeladas, historicoConciliacoes, produtividade: prodInServer } = data;
        setProdutos(produtosConsolidados || []);
        setLotesValidade(lotesValidade || []);
        setPickingMapeamento(pickingMapeamento || []);
        setEntradasFuturas(entradasFuturas || []);
        setLayoutWms(layoutWms || []);
        setLogsAuditoria(logsAuditoria || []);
        setDivergenciasCongeladas(divergenciasCongeladas || []);
        setHistoricoConciliacoes(historicoConciliacoes || []);
        setProdutividade(prodInServer || []);

        if (serverResetToken) {
          localStorage.setItem('paubrasil_server_reset_token', serverResetToken);
        }

        // Atualiza a imagem do backup local em localStorage para segurança persistente
        const backupPayload = {
          estoqueAtual: data.estoqueAtual || [],
          inventario: data.inventario || [],
          caixasPallet: data.caixasPallet || [],
          vendasMedias: data.vendasMedias || [],
          entradasFuturas: data.entradasFuturas || [],
          lotesValidade: data.lotesValidade || [],
          pickingMapeamento: data.pickingMapeamento || [],
          layoutOverrides: data.layoutOverrides || {},
          divergenciasCongeladas: divergenciasCongeladas || [],
          historicoConciliacoes: historicoConciliacoes || [],
          logsAuditoria: logsAuditoria || [],
          produtividade: prodInServer || []
        };
        localStorage.setItem('paubrasil_state_backup_v2', JSON.stringify(backupPayload));
      } else {
        throw new Error(resJson.error || "Erro desconhecido ao carregar estado do faturamento.");
      }
    } catch (e: any) {
      console.error(e);
      setStateError("Incapaz de conectar ao WMS Server na porta 3000. Por favor, verifique se a inicialização concluiu.");
    } finally {
      setStateLoading(false);
    }
  };

  // Escuta dinâmica do Firebase Firestore em tempo real para Atividades de Produtividade
  useEffect(() => {
    // 1. Testa a conexão com o Firestore no boot da plataforma
    const testLiveConnection = async () => {
      try {
        const { getDocFromServer } = await import('firebase/firestore');
        await getDocFromServer(doc(db, 'test', 'connection'));
        console.log("Conexão ao Firebase Firestore estabelecida com absoluto sucesso!");
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("ConsiliWMS: Firebase client offline. Verifique a configuração.");
        }
      }
    };
    testLiveConnection();

    // 2. Registra o monitoramento em tempo real das Atividades de Produtividade
    const qProductivity = query(collection(db, "productivity"));
    const unsubscribeProductivity = onSnapshot(qProductivity, (snapshot) => {
      if (!snapshot.empty) {
        const items: any[] = [];
        snapshot.forEach((docSnap) => {
          items.push(docSnap.data());
        });
        // Ordena por ID do log
        items.sort((a, b) => a.id.localeCompare(b.id));
        setProdutividade(items);
        console.log("Firebase Realtime: Sincronizados " + items.length + " registros de colaboradores do CD.");
      }
    }, (error) => {
      console.warn("Firestore Sync: Conectado/Agurdando login operacional ou permissões em firestore.rules:", error);
    });

    sincronizarBaseCompleta();

    return () => {
      unsubscribeProductivity();
    };
  }, []);

  const triggerToast = (text: string, type: 'success' | 'warn' | 'info' = 'success') => {
    setRecentNotification({ text, type });
    setTimeout(() => {
      setRecentNotification(null);
    }, 5000);
  };

  const handleLogout = () => {
    setOperatorUser(null);
    localStorage.removeItem('paubrasil_current_logged_user');
    triggerToast("Operador desconectado do CD com sucesso.", "info");
  };

  // ==========================================
  // DISPATCHERS DE AÇÃO OPERACIONAIS (TRANSAÇÕES)
  // Cada transação recarrega o estado de imediato para painel em tempo real!
  // ==========================================

  const handleUpdatePhysical = async (sku: string, quant: number) => {
    try {
      const res = await fetch("/api/state/update-physical", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sku, quantidadeFisica: quant })
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast(`Estoque físico do SKU ${sku} redefinido para ${quant} caixas.`);
        await sincronizarBaseCompleta();
      }
    } catch (e) {
      triggerToast("Erro ao processar alteração física do inventário.", "warn");
    }
  };

  const handleTriggerReconciliation = async (usuario: string) => {
    try {
      const res = await fetch("/api/state/reconcile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ usuario })
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast("Ajuste geral efetuado no estoque. Diferenças zeradas, ERP regularizado!", "success");
        await sincronizarBaseCompleta();
      }
    } catch (e) {
      triggerToast("Erro ao efetivar conciliação contábil.", "warn");
    }
  };

  const handleFreezeDivergences = async (
    skusToFreeze: string[], 
    observacoes: Record<string, string>,
    isManual?: boolean,
    manualSku?: string,
    manualQuantidade?: number,
    manualObservacao?: string,
    manualItems?: any[],
    documentos?: Record<string, { nome: string; tamanho: string }>
  ) => {
    try {
      const res = await fetch("/api/state/freeze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          skusToFreeze, 
          observacoes, 
          usuario: userEmail,
          isManual,
          manualSku,
          manualQuantidade,
          manualObservacao,
          manualItems,
          documentos
        })
      });
      const resJson = await res.json();
      if (resJson.success) {
        setDivergenciasCongeladas(resJson.divergenciasCongeladas || []);
        if (isManual) {
          triggerToast(`SKU ${manualSku ? manualSku.replace(/^0+/, '') : ''} congelado manualmente com sucesso!`);
        } else {
          triggerToast(`${skusToFreeze.length} divergência(s) congelada(s).`);
        }
        await sincronizarBaseCompleta();
        return true;
      } else {
        throw new Error(resJson.error || "Erro ao congelar quebras.");
      }
    } catch (e: any) {
      triggerToast(e.message || "Erro de conexão ao congelar.", "warn");
      return false;
    }
  };

  const handleUnfreezeDivergences = async (skusToUnfreeze: string[]) => {
    try {
      const res = await fetch("/api/state/unfreeze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skusToUnfreeze })
      });
      const resJson = await res.json();
      if (resJson.success) {
        setDivergenciasCongeladas(resJson.divergenciasCongeladas || []);
        triggerToast("Registro removido do congelamento.");
        await sincronizarBaseCompleta();
      } else {
        throw new Error(resJson.error || "Erro ao tirar do congelamento.");
      }
    } catch (e: any) {
      triggerToast(e.message || "Erro de conexão ao descongelar.", "warn");
    }
  };

  const handleImportState = async (payload: any) => {
    try {
      const res = await fetch("/api/state/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast("Planilha externa sincronizada com sucesso no banco de dados.", "success");
        await sincronizarBaseCompleta();
      }
    } catch (e) {
      triggerToast("Erro ao importar base externa.", "warn");
    }
  };

  const handleUpdatePrices = async (rawPricesCsv: string) => {
    try {
      const res = await fetch("/api/state/update-prices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawPricesCsv })
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast(`Tabela de preços atualizada com sucesso. ${resJson.count} SKUs revalorizados no ERP.`, "success");
        await sincronizarBaseCompleta();
      } else {
        throw new Error(resJson.error || "Erro ao processar tabela de preços");
      }
    } catch (e: any) {
      triggerToast(e.message || "Erro ao atualizar tabela de preços.", "warn");
    }
  };

  const handleAddProduct = async (payload: any) => {
    try {
      const res = await fetch("/api/state/add-product", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast(`Produto ${payload.sku} cadastrado e integrado com sucesso no ERP/WMS.`, "success");
        await sincronizarBaseCompleta();
      }
    } catch (e) {
      triggerToast("Erro ao cadastrar novo lote fiscal.", "warn");
    }
  };

  const handleReplenishPicking = async (sku: string, qtd: number) => {
    try {
      const res = await fetch("/api/state/replenish-picking", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sku, quantidadeCaixas: qtd })
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast(`Sucesso: ${qtd} caixas de ${sku} remanejadas para o Picking térreo.`);
        await sincronizarBaseCompleta();
      } else {
        throw new Error(resJson.error);
      }
    } catch (e: any) {
      triggerToast(e.message || "Erro no abastecimento de picking.", "warn");
      throw e;
    }
  };

  const handleQuarantineBatch = async (loteId: string) => {
    try {
      const res = await fetch("/api/state/quarantine-batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: loteId })
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast(`Lote colocado em quarentena imediatamente para recall.`, "info");
        await sincronizarBaseCompleta();
      }
    } catch (e) {
      triggerToast("Erro ao travar lote.", "warn");
    }
  };

  const handleReceiveFutureEntry = async (entryId: string) => {
    try {
      const res = await fetch("/api/state/receive-entry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: entryId })
      });
      const resJson = await res.json();
      if (resJson.success) {
        triggerToast(`Sucesso: Carga da Nota Fiscal integrada. Novo lote FEFO gerado.`);
        await sincronizarBaseCompleta();
      }
    } catch (e) {
      triggerToast("Erro ao receber nota fiscal na doca.", "warn");
    }
  };

  // Contagem de SKUs com divergência para badge vermelho no menu
  const totalDivergentes = produtos.filter(p => p.temDivergencia).length;

  // Contagem de alertas críticos (Vencidos ou abaixo do picking)
  const totalAlertasCriticosCount = lotesValidade.filter(l => l.diasParaVencer <= 30).length + 
    pickingMapeamento.filter(p => p.saldoAtualCaixas <= p.pontoRessuprimentoCaixas).length;

  if (!operatorUser) {
    return (
      <LoginScreen 
        onSuccess={(user) => { 
          setOperatorUser(user); 
          localStorage.setItem('paubrasil_current_logged_user', user);
          triggerToast(`Autenticado com sucesso! Bem-vindo de volta, ${user}.`, "success");
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-sleek-bg flex flex-col lg:flex-row font-sans selection:bg-sleek-accent-mkt selection:text-white" id="applet-main-container">
      
      {/* SIDEBAR - ESQUERDA (FIXA EM DESKTOP, CABEÇALHO EM MOBILE) */}
      <aside className="w-full lg:w-72 bg-sleek-sidebar text-white flex flex-col shrink-0 border-r border-slate-800 lg:sticky lg:top-0 lg:h-screen lg:max-h-screen select-none z-40" id="sleek-sidebar">
        
        {/* Logo Brand / Cabeçalho da Sidebar */}
        <div className="p-6 border-b border-slate-800 flex flex-col gap-4">
          <PauBrasilLogo />
          
          <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-750 space-y-2 shadow-lux" id="unit-info-card">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-450 animate-pulse"></span>
              <span className="text-[9px] uppercase font-black text-emerald-400 tracking-wider font-sans">Unidade Logística Ativa</span>
            </div>
            <h2 className="text-sm font-black text-white uppercase font-display tracking-tight leading-tight">
              Pau Brasil Guarabira
            </h2>
            <div className="flex items-center justify-between text-[10.5px] text-slate-300 font-semibold pt-1 border-t border-slate-805/45">
              <span className="text-slate-400">Plataforma CD</span>
              <span className="font-black text-sky-400 font-mono tracking-wide">Armazém Fácil</span>
            </div>
          </div>
        </div>

        {/* Links de Navegação */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <div className="text-[9px] uppercase font-bold text-slate-500 px-3 py-2 tracking-widest font-mono">Painel de Estoque</div>
          
          <button
            onClick={() => setActiveTab("executivo")}
            className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center gap-3 cursor-pointer ${activeTab === 'executivo' ? 'bg-sleek-accent-mkt text-white shadow-lux' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'}`}
          >
            <TrendingUp className="w-4 h-4 shrink-0" />
            <span>Dashboard Executivo e KPIs</span>
          </button>

          <button
            onClick={() => setActiveTab("conciliacao")}
            className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center justify-between gap-3 relative cursor-pointer ${activeTab === 'conciliacao' ? 'bg-sleek-accent-mkt text-white shadow-lux' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'}`}
          >
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Conciliação Física x Fiscal</span>
            </div>
            {totalDivergentes > 0 && (
              <span className="bg-sleek-accent-c text-white font-bold h-4 px-1.5 rounded-full text-[9px] flex items-center justify-center animate-bounce shadow">
                {totalDivergentes}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("wmsIntegrado")}
            className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center justify-between gap-3 relative cursor-pointer ${activeTab === 'wmsIntegrado' ? 'bg-indigo-600 text-white shadow-lux font-bold border border-indigo-505' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'}`}
          >
            <div className="flex items-center gap-3">
              <Layers className="w-4 h-4 shrink-0 animate-pulse text-indigo-400" />
              <span>Estrutura, Layout & FEFO</span>
            </div>
            <span className="text-[8px] uppercase tracking-wider font-extrabold bg-[#2D489A]/30 text-sky-400 border border-sky-500/20 px-1.5 py-0.5 rounded">
              WMS
            </span>
          </button>

          <button
            onClick={() => setActiveTab("produtividade")}
            className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center justify-between gap-3 relative cursor-pointer ${activeTab === 'produtividade' ? 'bg-sleek-accent-mkt text-white shadow-lux' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'}`}
          >
            <div className="flex items-center gap-3">
              <Activity className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Produtividade e Reabastecimentos</span>
            </div>
            <span className="text-[8px] uppercase tracking-wider font-extrabold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">
              Firebase
            </span>
          </button>

          <div className="pt-4 space-y-2">
            <div className="text-[9px] uppercase font-bold text-slate-500 px-3 py-1 tracking-widest font-mono">Inteligência Artificial</div>
            <button
               onClick={() => setActiveTab("aiInsights")}
               className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center gap-3 cursor-pointer ${activeTab === 'aiInsights' ? 'bg-violet-600 text-white shadow-lux font-bold' : 'text-slate-400 hover:bg-slate-800/10 hover:text-white'}`}
            >
              <Sparkles className="w-4 h-4 text-violet-400 animate-pulse shrink-0" />
              <span>Auditor e Assistente AI</span>
            </button>
            <button
               onClick={() => setActiveTab("inversaoEstoque")}
               className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center justify-between gap-3 cursor-pointer ${activeTab === 'inversaoEstoque' ? 'bg-indigo-600 text-white shadow-lux font-bold border border-indigo-505' : 'text-slate-400 hover:bg-slate-800/15 hover:text-white'}`}
            >
              <div className="flex items-center gap-3">
                <RefreshCw className="w-4 h-4 text-sky-400 shrink-0" />
                <span>Inversão Inteligente</span>
              </div>
              <span className="text-[8px] uppercase tracking-wider font-extrabold bg-sky-500/10 border border-sky-500/20 text-sky-400 px-1.5 py-0.5 rounded leading-none shrink-0 inline-block font-mono">
                IA
              </span>
            </button>
          </div>

          {isAdmin && (
            <div className="pt-4" id="admin-operators-menu-section">
              <div className="text-[9px] uppercase font-bold text-slate-500 px-3 py-1 tracking-widest font-mono">Controle Gerencial</div>
              <button
                onClick={() => setActiveTab("admin-operadores")}
                className={`w-full p-2.5 px-4 rounded-xl text-left text-xs font-semibold tracking-wide transition flex items-center gap-3 cursor-pointer ${activeTab === 'admin-operadores' ? 'bg-indigo-600 text-white shadow-lux font-bold border border-indigo-500' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'}`}
              >
                <Users className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Gestão de Operadores</span>
              </button>
            </div>
          )}

        </nav>

        {/* Detalhes do Conferente no rodapé */}
        <div className="p-5 border-t border-slate-800 bg-slate-950 text-slate-400 text-xs space-y-3.5" id="user-footer-sidebar">
          <div className="space-y-1">
            <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider">Operador Ativo</span>
            <div className="flex items-center justify-between gap-2 bg-slate-900/60 p-2 rounded-lg border border-slate-800/80">
              <div className="flex items-center gap-2 min-w-0">
                <Users className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="truncate text-[10.5px] font-sans font-extrabold text-slate-200" title={userEmail}>{userEmail}</span>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                title="Desconectar do Armazém"
                className="p-1 text-slate-400 hover:text-rose-450 bg-slate-800/50 hover:bg-rose-500/10 rounded border border-slate-800 hover:border-rose-500/20 cursor-pointer transition-all shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="text-[9px] text-slate-500 font-mono flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-sleek-accent-a rounded-full animate-pulse"></span>
            <span>INTEGRAÇÃO ERP ATIVA</span>
          </div>
        </div>

      </aside>

      {/* ÁREA DE CONTEÚDO PRINCIPAL (DIREITA) */}
      <div className="flex-1 flex flex-col min-w-0" id="main-content-layout">
        
        {/* TOPBAR SECUNDÁRIA (Ações globais de CD) */}
        <header className="bg-sleek-panel border-b border-sleek-border h-16 flex items-center justify-between px-6 sticky top-0 z-30 select-none shadow-sm">
          
          <div className="flex items-center gap-2 text-xs">
            <span className="text-sleek-text-muted font-medium font-sans">CD Logístico Hub</span>
            <span className="text-slate-300">/</span>
            <span className="font-mono bg-slate-100 text-[#0f172a] px-2 py-0.5 rounded text-[10px] font-bold">
              {activeTab === "executivo" && "Dashboard de KPIs"}
              {activeTab === "conciliacao" && "Foco das Divergências"}
              {activeTab === "wmsIntegrado" && "Estrutura, Layout & FEFO Integrado"}
              {activeTab === "produtividade" && "Produtividade de Equipe (Firebase)"}
              {activeTab === "aiInsights" && "Auditor Inteligente Central"}
              {activeTab === "inversaoEstoque" && "Inversão Inteligente de Estoque"}
              {activeTab === "admin-operadores" && "Controle de Logins Operacionais"}
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Acurácia do CD */}
            <div className="hidden sm:flex items-center gap-2 text-xs font-mono border-r border-sleek-border pr-4">
              <span className="text-sleek-text-muted">Acurácia:</span>
              <span className={`font-extrabold ${totalDivergentes === 0 ? 'text-sleek-accent-a' : 'text-sleek-accent-b'}`}>
                {totalDivergentes === 0 ? 'CD Sincronizado' : 'Ações Requeridas'}
              </span>
            </div>

            {/* Sincronizar ERP - Botão de Alta Visibilidade Branded Ambev */}
            <button 
              type="button"
              onClick={sincronizarBaseCompleta}
              disabled={stateLoading}
              className="flex items-center gap-2 bg-[#2D489A] hover:bg-[#1D327A] active:scale-95 text-white text-xs font-black py-2.5 px-4.5 rounded-xl shadow-lux border border-[#3B5BBF]/30 hover:border-[#3B5BBF]/60 transition-all duration-200 disabled:opacity-50 cursor-pointer"
              title="Sincronizar dados com o ERP Central"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-white ${stateLoading ? 'animate-spin' : ''}`} />
              <span className="tracking-wide">Sincronizar ERP</span>
            </button>
          </div>

        </header>

        {/* WORKSPACE DINÂMICO */}
        <main className="flex-1 p-6 space-y-6 overflow-y-auto">
          
          {/* Banner de erro ou desconexão */}
          {stateError && (
            <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl text-rose-800 text-sm font-semibold flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
              <div>
                <p>{stateError}</p>
                <button 
                  type="button" 
                  onClick={sincronizarBaseCompleta}
                  className="text-xs text-rose-900 underline mt-1 block hover:text-indigo-950 cursor-pointer"
                >
                  Tentar reconectar servidor ao banco do WMS
                </button>
              </div>
            </div>
          )}

          {/* Notificação Toast Flutuante Recente */}
          {recentNotification && (
            <div className={`p-4 rounded-xl border flex items-center gap-3 shadow-lux max-w-md ml-auto animate-bounce sticky top-2 z-50 transition-all ${recentNotification.type === 'warn' ? 'bg-rose-50 border-rose-200 text-rose-800' : recentNotification.type === 'info' ? 'bg-indigo-50 border-indigo-200 text-indigo-800' : 'bg-emerald-50 border-emerald-200 text-emerald-800'}`}>
              {recentNotification.type === 'warn' ? (
                <AlertTriangle className="w-5 h-5 text-sleek-accent-c shrink-0" />
              ) : recentNotification.type === 'info' ? (
                <Cpu className="w-5 h-5 text-sleek-accent-mkt shrink-0" />
              ) : (
                <CheckCircle2 className="w-5 h-5 text-sleek-accent-a shrink-0" />
              )}
              <span className="text-xs font-semibold">{recentNotification.text}</span>
            </div>
          )}

          {/* Abas */}
          {stateLoading && produtos.length === 0 ? (
            <div className="p-16 border border-dashed border-slate-200 bg-white rounded-2xl text-center space-y-4 shadow-lux">
              <div className="w-10 h-10 rounded-full border-4 border-sleek-accent-mkt border-t-transparent animate-spin mx-auto"></div>
              <p className="text-xs text-slate-500 font-mono font-bold">Carregando bases operacionais consolidando faturamentos no WMS...</p>
            </div>
          ) : (
            <div className="animate-fade-in">
              {activeTab === "executivo" && (
                <DashboardExecutive 
                  produtos={produtos} 
                  logsAuditoria={logsAuditoria}
                  onTabChange={setActiveTab}
                  onRefresh={sincronizarBaseCompleta}
                />
              )}

              {activeTab === "conciliacao" && (
                <InventoryReconciliation
                  produtos={produtos}
                  divergenciasCongeladas={divergenciasCongeladas}
                  historicoConciliacoes={historicoConciliacoes}
                  onUpdatePhysical={handleUpdatePhysical}
                  onTriggerReconciliation={handleTriggerReconciliation}
                  onImportState={handleImportState}
                  onUpdatePrices={handleUpdatePrices}
                  onAddProduct={handleAddProduct}
                  onFreezeDivergences={handleFreezeDivergences}
                  onUnfreezeDivergences={handleUnfreezeDivergences}
                  operatorEmail={userEmail}
                  onRefresh={sincronizarBaseCompleta}
                />
              )}

              {activeTab === "wmsIntegrado" && (
                <div className="bg-white rounded-3xl border border-slate-250 p-6 space-y-6 shadow-2xl animate-fadeIn col-span-full">
                  
                  {/* Cabeçalho do Módulo WMS */}
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                    <div className="flex items-start gap-3">
                      <div className="p-3 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-lg shadow-indigo-150 shrink-0">
                        <Layers className="w-6 h-6 animate-pulse" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="p-1 px-2 rounded bg-indigo-50 border border-indigo-100 text-[10px] font-black text-indigo-700 uppercase tracking-widest">
                            Módulo Integrado WMS
                          </span>
                        </div>
                        <h3 className="text-lg font-black text-slate-800 tracking-tight mt-1">
                          Estrutura Física, Layout Interativo & Controle FEFO
                        </h3>
                        <p className="text-xs text-slate-500 font-medium">
                          Plataforma de mapeamento tridimensional, arranjo espacial inteligente e abastecimento dinâmico de gôndolas e racks.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <a
                        href="https://aistudio.google.com/apps/2d1e154a-4234-44b9-859a-6b67d5560e2f?showPreview=true&showAssistant=true"
                        target="_blank"
                        rel="noreferrer"
                        className="bg-white hover:bg-indigo-50 border border-slate-200 text-indigo-600 font-bold p-3 px-5 rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:shadow"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Abrir em Nova Aba
                      </a>
                    </div>
                  </div>

                  {/* Frame Módulo WMS Integrado */}
                  <div className="space-y-6">
                    {/* Painel de Pontes de Segurança & Integração Externa */}
                    <div className="bg-gradient-to-r from-slate-50 via-indigo-50/10 to-slate-50 p-6 rounded-2xl border border-indigo-100 flex flex-col md:flex-row items-center justify-between gap-5 shadow-sm">
                      <div className="space-y-2 max-w-xl font-sans">
                        <div className="flex items-center gap-2">
                          <span className="p-0.5 px-2 rounded bg-amber-50 border border-amber-200 text-[9px] font-bold text-amber-700 uppercase tracking-widest flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-amber-600 animate-pulse" />
                            Ambiente Protegido pelo Google Cloud
                          </span>
                          <span className="p-0.5 px-2 rounded bg-indigo-50 border border-indigo-100 text-[9px] font-bold text-indigo-700 uppercase tracking-widest">
                            Conexão de Ponte Segura ACT
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-800">
                          Acesso Direto ao Painel de Endereçamento & FEFO
                        </h4>
                        <p className="text-[11.5px] text-slate-500 leading-relaxed">
                          Por políticas rígidas de segurança do sandbox (proteção de cabeçalhos <code className="bg-slate-100 px-1 py-0.5 rounded text-rose-600 font-mono text-[10px]">X-Frame-Options</code>), a incorporação direta em iframe foi rejeitada para prevenir riscos de sequestro de sessão. Por favor, acesse o módulo unificado seguro em tela cheia usando o botão abaixo.
                        </p>
                      </div>

                      <div className="shrink-0 w-full md:w-auto">
                        <a
                          href="https://aistudio.google.com/apps/2d1e154a-4234-44b9-859a-6b67d5560e2f?showPreview=true&showAssistant=true"
                          target="_blank"
                          rel="noreferrer"
                          className="w-full md:w-auto bg-gradient-to-r from-[#2D489A] to-[#1e3475] hover:from-[#1e3475] hover:to-[#2D489A] text-white p-4 px-6 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2.5 transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5"
                        >
                          <ExternalLink className="w-4 h-4 text-white" />
                          CONECTAR MÓDULO WMS (TELA CHEIA)
                        </a>
                      </div>
                    </div>

                    {/* NOVO: Painel de Integração de Códigos ZIP Consolidados */}
                    <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl p-6 border border-slate-800 space-y-5 shadow-xl shadow-slate-900/40 font-sans">
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center shrink-0">
                          <UploadCloud className="w-5 h-5" />
                        </div>
                        <div className="space-y-1">
                          <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                            Integrador ConsiliWMS (Fusão Direta de ZIP)
                            <span className="p-0.5 px-2 rounded bg-indigo-500/20 text-indigo-400 text-[9px] font-bold border border-indigo-500/30 uppercase tracking-widest leading-none">
                              Método 1 - Arquivo Fonte
                            </span>
                          </h4>
                          <p className="text-[11.5px] text-slate-400 leading-relaxed max-w-2xl">
                            Arraste e solte o arquivo <strong>.zip</strong> exportado do seu outro app ConsiliWMS. Nosso motor de fusão lerá os arquivos e reescreverá a estrutura do seu CD (Componentes de Gôndolas, Layout e FEFO) instantaneamente de forma permanente.
                          </p>
                        </div>
                      </div>

                      {/* Drop Zone */}
                      {!zipMergeSuccess ? (
                        <div className="space-y-4">
                          <div
                            onDragEnter={(e) => { e.preventDefault(); setZipDragActive(true); }}
                            onDragOver={(e) => { e.preventDefault(); setZipDragActive(true); }}
                            onDragLeave={(e) => { e.preventDefault(); setZipDragActive(false); }}
                            onDrop={(e) => {
                              e.preventDefault();
                              setZipDragActive(false);
                              if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                                processZipFile(e.dataTransfer.files[0]);
                              }
                            }}
                            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer relative ${
                              zipDragActive 
                                ? "border-indigo-500 bg-indigo-500/10 scale-[1.01]" 
                                : "border-slate-800 bg-slate-900/40 hover:bg-slate-900/60 hover:border-slate-700"
                            }`}
                          >
                            <input
                              type="file"
                              accept=".zip"
                              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                              onChange={(e) => {
                                if (e.target.files && e.target.files[0]) {
                                  processZipFile(e.target.files[0]);
                                }
                              }}
                            />
                            
                            {isAnalyzingZip ? (
                              <div className="space-y-3 py-2 flex flex-col items-center justify-center">
                                <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
                                <span className="text-xs font-semibold text-slate-300">Lendo e mapeando a estrutura física do arquivo ZIP...</span>
                              </div>
                            ) : zipFiles.length > 0 ? (
                              <div className="space-y-3 py-2">
                                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto animate-bounce" />
                                <span className="text-xs font-bold text-emerald-400 block">Arquivos do ZIP processados!</span>
                                <p className="text-[11px] text-slate-400">
                                  <strong>{zipFiles.length} arquivos fonte</strong> prontos para serem fundidos com esta plataforma.
                                </p>
                              </div>
                            ) : (
                              <div className="space-y-3">
                                <UploadCloud className="w-9 h-9 text-slate-500 mx-auto" />
                                <div>
                                  <span className="text-xs font-bold text-slate-200 block">
                                    Arraste o arquivo ZIP exportado aqui ou clique para selecionar
                                  </span>
                                  <span className="text-[10px] text-slate-600 mt-1 block">
                                    Garante o acoplamento do Código Fonte do CD (Estruturas Físicas e FEFO)
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Mensagem de Erros de Análise */}
                          {zipMergeError && (
                            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 px-4 rounded-xl text-[11.5px] flex items-center gap-2">
                              <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                              <span>{zipMergeError}</span>
                            </div>
                          )}

                          {/* Listagem Dinâmica de Arquivos */}
                          {zipFiles.length > 0 && !isAnalyzingZip && (
                            <div className="border border-slate-800 bg-slate-900/30 rounded-xl overflow-hidden animate-fadeIn">
                              <div className="bg-slate-900/60 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between text-[11px]">
                                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                                  <FileText className="w-3.5 h-3.5 text-indigo-400" />
                                  Modificar seguintes arquivos no workspace:
                                </span>
                                <span className="text-slate-500 font-mono">
                                  {zipFiles.filter(f => f.selected).length} de {zipFiles.length} selecionados
                                </span>
                              </div>

                              <div className="max-h-[160px] overflow-y-auto divide-y divide-slate-900/60 text-[10px] font-mono scrollbar-thin">
                                {zipFiles.map((f, idx) => (
                                  <div key={idx} className="p-2 px-4 flex items-center justify-between hover:bg-slate-800/20 transition-all">
                                    <div className="flex items-center gap-3">
                                      <input
                                        type="checkbox"
                                        checked={f.selected}
                                        onChange={() => {
                                          const updated = [...zipFiles];
                                          updated[idx].selected = !updated[idx].selected;
                                          setZipFiles(updated);
                                        }}
                                        className="rounded border-slate-800 bg-slate-950 text-indigo-600 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer"
                                      />
                                      <span className="text-slate-300 truncate max-w-sm md:max-w-md lg:max-w-lg" title={f.path}>
                                        {f.path}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-slate-500">{(f.size / 1024).toFixed(1)} KB</span>
                                      <span className="p-0.5 px-1.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/10 font-sans text-[8px] font-bold">
                                        VÁLIDO
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>

                              <div className="p-3 bg-slate-900/80 flex items-center justify-end border-t border-slate-805">
                                <button
                                  type="button"
                                  onClick={handleMergeZipFiles}
                                  disabled={zipFiles.filter(f => f.selected).length === 0}
                                  className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white p-2 px-5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-md"
                                >
                                  <Check className="w-4 h-4 text-white" />
                                  <span>Compilar e Integrar Layout no WMS</span>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        /* Mensagem de Sucesso */
                        <div className="bg-emerald-500/10 border border-emerald-500/25 rounded-xl p-5 text-center space-y-4 font-sans animate-scaleUp">
                          <div className="w-12 h-12 bg-emerald-500/15 rounded-full flex items-center justify-center mx-auto text-emerald-400 border border-emerald-500/30">
                            <Check className="w-6 h-6 animate-pulse" />
                          </div>
                          <div className="space-y-1">
                            <h5 className="font-extrabold text-sm text-emerald-400">Arquivos do Outro App Mesclados perfeitamente!</h5>
                            <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                              {zipMergeMessage || "O servidor integrou com precisão os componentes no workspace de forma definitiva."}
                            </p>
                          </div>
                          {zipCountdown !== null && (
                            <div className="p-2 px-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl font-mono text-[10.5px] inline-flex items-center gap-2 uppercase tracking-wide">
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>Hot reload da plataforma em {zipCountdown} segundos...</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Divisor Visual com Switcher para Fallback Local */}
                    <div className="flex items-center justify-between border-t border-slate-150 pt-4 font-sans">
                      <div className="space-y-0.5">
                        <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                          Estação Local Fallback (Modo Offline)
                        </h4>
                        <p className="text-[10px] text-slate-400">
                          Você também pode gerenciar gôndolas e faturamentos diretamente através do motor estático local abaixo.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => setShowWmsFallback(!showWmsFallback)}
                        className={`text-xs font-bold py-1.5 px-4 rounded-lg transition-all border ${
                          showWmsFallback 
                            ? 'bg-slate-800 hover:bg-slate-900 text-white border-slate-900 shadow-sm' 
                            : 'bg-white hover:bg-slate-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        {showWmsFallback ? '✕ Ocultar Fallback Local' : '⚙️ Ativar Fallback Local'}
                      </button>
                    </div>

                    {/* Renderização do Fallback Local (Estrutura, Layout, FEFO) */}
                    {showWmsFallback ? (
                      <div className="space-y-4 border border-indigo-100 rounded-2xl p-5 bg-slate-50/50 animate-scaleUp">
                        {/* Seletor de Sub-Abas do Fallback */}
                        <div className="flex flex-wrap items-center gap-2 border-b border-indigo-50/50 pb-3" id="fallback-tabs">
                          <button
                            type="button"
                            onClick={() => setWmsSubTab('racks')}
                            className={`p-2 px-4 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
                              wmsSubTab === 'racks' 
                                ? 'bg-indigo-600 text-white shadow-md' 
                                : 'bg-white text-slate-500 hover:text-slate-800 border border-slate-200'
                            }`}
                          >
                            <Map className="w-4 h-4 shrink-0" />
                            Estrutura Física e Racks WMS
                          </button>

                          <button
                            type="button"
                            onClick={() => setWmsSubTab('mapa')}
                            className={`p-2 px-4 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
                              wmsSubTab === 'mapa' 
                                ? 'bg-indigo-600 text-white shadow-md' 
                                : 'bg-white text-slate-500 hover:text-slate-800 border border-slate-200'
                            }`}
                          >
                            <Layers className="w-4 h-4 shrink-0" />
                            Layout Interativo (Mapa d'Áreas)
                          </button>

                          <button
                            type="button"
                            onClick={() => setWmsSubTab('fefo')}
                            className={`p-2 px-4 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
                              wmsSubTab === 'fefo' 
                                ? 'bg-indigo-600 text-white shadow-md' 
                                : 'bg-white text-slate-500 hover:text-slate-800 border border-slate-200'
                            }`}
                          >
                            <FolderLock className="w-4 h-4 shrink-0" />
                            Garantia FEFO e Abastecimentos
                          </button>
                        </div>

                        {/* Telas dinâmicas do Fallback */}
                        <div className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm min-h-[400px]">
                          {wmsSubTab === 'racks' && (
                            <WmsLayout 
                              layout={layoutWms} 
                              produtos={produtos} 
                            />
                          )}

                          {wmsSubTab === 'mapa' && (
                            <InteractiveLayout
                              layout={layoutWms}
                              produtos={produtos}
                              onRefresh={sincronizarBaseCompleta}
                            />
                          )}

                          {wmsSubTab === 'fefo' && (
                            <FutureControl
                              produtos={produtos}
                              lotes={lotesValidade || []}
                              picking={pickingMapeamento || []}
                              entradasFuturas={entradasFuturas || []}
                              layout={layoutWms}
                              onReplenishPicking={handleReplenishPicking}
                              onQuarantineBatch={handleQuarantineBatch}
                              onReceiveFutureEntry={handleReceiveFutureEntry}
                              onImportState={handleImportState}
                            />
                          )}
                        </div>
                      </div>
                    ) : (
                      /* Banner Decorativo Ilustrando o Dashboard do WMS */
                      <div className="border border-dashed border-slate-250 rounded-2xl p-10 bg-slate-50 text-center space-y-3 font-sans opacity-85">
                        <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center mx-auto text-indigo-500">
                          <Layers className="w-6 h-6 animate-pulse" />
                        </div>
                        <h5 className="text-xs font-bold text-slate-600">Módulo Unificado Pronto para Conexão</h5>
                        <p className="text-[10px] text-slate-450 max-w-sm mx-auto">
                          Clique no botão de conexão acima para inicializar a modelagem tridimensional no portal integrado e monitorar o endereçamento físico do CD.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Rodapé Informativo */}
                  <div className="flex items-center gap-2 text-[11px] text-slate-450 bg-slate-50 p-3.5 px-4 rounded-xl border border-slate-100 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse shrink-0"></span>
                    <span>
                      Dica: Para usufruir de melhor espaço de tela para o endereçamento de gôndolas, utilize o botão "Abrir em Nova Aba" acima. O faturamento e divergências continuam mapeadas e integradas em tempo real.
                    </span>
                  </div>

                </div>
              )}

              {activeTab === "aiInsights" && (
                <AiInsights 
                  produtos={produtos} 
                />
              )}

              {activeTab === "inversaoEstoque" && (
                <StockInversionAI
                  produtos={produtos}
                  operatorEmail={userEmail}
                  onRefresh={sincronizarBaseCompleta}
                />
              )}

              {activeTab === "produtividade" && (
                <ProductivityHub
                  produtividade={produtividade}
                  onAddProductivity={handleAddProductivity}
                  onResetProductivity={handleResetProductivity}
                />
              )}

              {activeTab === "admin-operadores" && isAdmin && (
                <AdminOperators />
              )}
            </div>
          )}

        </main>

        {/* FOOTER TÉCNICO COMPACTO */}
        <footer className="border-t border-sleek-border bg-white text-slate-400 py-4 shrink-0 select-none">
          <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-3 text-[10px] font-mono">
            <div>
              <span className="text-sleek-accent-mkt font-bold">&#8226; Armazém Fácil Central Control</span> | CD Hub Centralizado de Cubagem
            </div>
            <div className="flex gap-4">
              <span className="text-slate-500">Database: <strong className="text-sleek-accent-a font-bold">Cloud Fire / PostgreSQL</strong></span>
              <span className="text-slate-500">Acesso: <strong className="text-slate-700">Port 3000 Ingress</strong></span>
            </div>
            <div className="flex items-center gap-2.5">
              <span>Operador CD: <strong className="text-slate-700">{userEmail}</strong></span>
              <button 
                type="button" 
                onClick={handleLogout}
                className="bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white border border-rose-200 hover:border-rose-650 text-[9.5px] font-mono font-bold px-2 py-0.5 rounded transition-all cursor-pointer flex items-center gap-1 shadow-sm"
              >
                <LogOut className="w-2.5 h-2.5" />
                <span>Sair</span>
              </button>
            </div>
          </div>
        </footer>

      </div>

      {/* BOTÃO FLUTUANTE DO ASSISTENTE DE IA GERAL */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          type="button"
          onClick={() => setIsAiDrawerOpen(!isAiDrawerOpen)}
          className="flex items-center gap-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold p-3 px-5 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer duration-200 border border-violet-500/20"
          title="Abrir Assistente Inteligente WMS"
          id="global-ai-assistant-button"
        >
          <Sparkles className="w-5 h-5 animate-pulse text-white shrink-0" />
          <span className="text-xs font-semibold tracking-wide">Assistente IA CD</span>
        </button>
      </div>

      {/* SIDEBAR DRAWER DO ASSISTENTE DE IA */}
      <div 
        className={`fixed top-0 right-0 h-full w-96 max-w-full bg-[#0b0f19] text-slate-100 shadow-2xl z-50 flex flex-col border-l border-slate-800 transition-transform duration-350 ease-in-out transform ${isAiDrawerOpen ? 'translate-x-0' : 'translate-x-full'}`}
        id="global-ai-assistant-drawer"
      >
        {/* Header do Drawer */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-violet-600 rounded-lg text-white">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-display font-bold text-xs">Assistente do CD Guarabira</h4>
              <p className="text-[9px] text-[#2D489A] font-mono font-bold">CONCÍLIO_WMS_V3.5</p>
            </div>
          </div>
          <button 
            type="button"
            onClick={() => setIsAiDrawerOpen(false)}
            className="text-slate-400 hover:text-white p-1 hover:bg-slate-800 rounded transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Zona Dinâmica de Mensagens */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3.5 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
          {panelChatLog.map((msg, idx) => {
            const isAss = msg.sender === 'assistant';
            return (
              <div 
                key={idx} 
                className={`flex flex-col max-w-[85%] space-y-1 ${isAss ? 'mr-auto items-start' : 'ml-auto items-end'}`}
              >
                <span className="text-[8px] text-slate-500 font-mono font-bold uppercase">
                  {isAss ? 'SISTEMA_AUDITOR_IA' : 'CONFERENTE'} &#8226; {msg.time}
                </span>
                <div className={`p-3 rounded-2xl text-xs leading-relaxed ${isAss ? 'bg-[#151d30] text-slate-200 border border-slate-800 rounded-tl-none font-sans' : 'bg-violet-600 text-white rounded-tr-none font-sans font-medium'}`}>
                  {msg.text}
                </div>
              </div>
            );
          })}
          
          {panelChatLoading && (
            <div className="flex flex-col items-start space-y-1 mr-auto max-w-[85%]">
              <span className="text-[8px] text-slate-500 font-mono font-bold">IA PROCESSANDO...</span>
              <div className="bg-[#151d30] p-3 rounded-2xl rounded-tl-none text-slate-400 border border-slate-800 text-xs flex items-center gap-2 font-mono">
                <span className="w-1.5 h-1.5 bg-violet-500 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-violet-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-violet-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                <span>Analisando posições de faturamento...</span>
              </div>
            </div>
          )}
          <div ref={panelBottomRef} />
        </div>

        {/* Sugestões de Perguntas Rápidas */}
        <div className="p-3 bg-slate-900/60 border-t border-slate-800/80 space-y-1.5 shrink-0">
          <span className="text-[8.5px] uppercase font-bold text-slate-400 block font-mono">Perguntas pré-configuradas:</span>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => handlePanelChatSubmit("Qual é o SKU mais crítico em divergência de estoque físico hoje no CD?")}
              className="text-[10px] bg-slate-850 hover:bg-slate-800 border border-slate-800 hover:border-slate-750 text-slate-300 py-1 px-2.5 rounded-lg text-left transition cursor-pointer max-w-full truncate"
            >
              🔍 Qual o SKU mais crítico em divergência?
            </button>
            <button
              type="button"
              onClick={() => handlePanelChatSubmit("Qual a melhor colocação física (layout) do SKU CER001 pelas regras de Pareto em giro de carga?")}
              className="text-[10px] bg-slate-850 hover:bg-slate-800 border border-slate-800 hover:border-slate-750 text-slate-300 py-1 px-2.5 rounded-lg text-left transition cursor-pointer max-w-full truncate"
            >
              📐 Melhor layout para o SKU CER001 (Curva A)?
            </button>
            <button
              type="button"
              onClick={() => handlePanelChatSubmit("Gere um sumário executivo rápido de toda a conferência do estoque e status de acurácia pós-ajuste")}
              className="text-[10px] bg-slate-850 hover:bg-slate-800 border border-slate-800 hover:border-slate-750 text-slate-300 py-1 px-2.5 rounded-lg text-left transition cursor-pointer max-w-full truncate"
            >
              📊 Diagnosticar acurácia de estoque total
            </button>
          </div>
        </div>

        {/* Campo de Escrita final */}
        <div className="p-3 bg-slate-950 border-t border-slate-800">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handlePanelChatSubmit();
            }} 
            className="flex gap-2"
          >
            <input 
              type="text" 
              placeholder="Pergunte ao CD: 'Como melhorar o layout?'"
              value={panelChatInput}
              onChange={(e) => setPanelChatInput(e.target.value)}
              disabled={panelChatLoading}
              className="flex-1 bg-slate-900 border border-slate-800 text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-violet-500 text-slate-100 font-sans"
            />
            <button 
              type="submit"
              disabled={!panelChatInput.trim() || panelChatLoading}
              className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white p-2.5 rounded-xl transition cursor-pointer disabled:opacity-40"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

    </div>
  );
}
