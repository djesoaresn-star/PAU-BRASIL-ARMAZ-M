/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Carrega variáveis ambientais do arquivo .env
dotenv.config();

import { initializeApp } from "firebase/app";
import { getFirestore, doc, setDoc, onSnapshot, collection } from "firebase/firestore";

// Inicialização do Firebase do Armazém no Servidor Express
let db: any = null;
try {
  const configPath = path.join(process.cwd(), "src/firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    const firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    const fbApp = initializeApp(firebaseConfig);
    db = getFirestore(fbApp);
    console.log("Firebase initialized successfully on Express Server backend.");
  } else {
    console.warn("Could not find firebase-applet-config.json for Server side database syncing.");
  }
} catch (fbErr) {
  console.error("Failed to initialize Firebase on server boot:", fbErr);
}

import { 
  relatorioEstoqueInicial, 
  relatorioInventarioInicial, 
  relatorioCaixasPallet, 
  relatorioVendasMedias, 
  relatorioEntradasFuturasInicial,
  lotesValidadeInicial,
  pickingMapeamentoInicial,
  processarBasesDados,
  gerarLayoutWms,
  erpCatalogMap
} from "./src/data/mockDatabase.js";

// Configuração do express
const app = express();
const PORT = 3000;

// Token de sessão único do servidor para detectar reinicializações/quedas do Cloud Run
const serverResetToken = Math.random().toString(36).substring(7) + "-" + Date.now();

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// ==========================================
// ESTADO EM MEMÓRIA DO LOGÍSTICA HUB (Para sincronização em tempo real)
// ==========================================
let estoqueAtualState = [...relatorioEstoqueInicial];
let inventarioState = [...relatorioInventarioInicial];
let caixasPalletState = [...relatorioCaixasPallet];
let vendasMediasState = [...relatorioVendasMedias];
let entradasFuturasState = [...relatorioEntradasFuturasInicial];
let lotesValidadeState = [...lotesValidadeInicial];
let pickingMapeamentoState = [...pickingMapeamentoInicial];
let layoutOverridesState: Record<string, any> = {};

// Estado de divergências e quebras congeladas (com espaço para observações e valoração)
let divergenciasCongeladasState: any[] = [
  {
    id: "FZ001",
    sku: "00013061",
    descricao: "H2OH LIMONETO PET 500ML SHRINK C/12",
    estoqueFisicoCaixas: 145,
    estoqueSistemaCaixas: 150,
    diferencaCaixas: -5,
    custoPorSku: 37.20,
    valorTotalDivergencia: -186.00,
    fatorHectolitro: 0.06,
    divergenciaHectolitro: -0.30,
    observacao: "Quebra de fardo na movimentação do corredor B.",
    dataCongelamento: "2026-05-28T14:30:00.000Z",
    usuario: "djesoaresn@gmail.com",
    documentoNome: null as string | null,
    documentoTamanho: null as string | null
  },
  {
    id: "FZ002",
    sku: "00000371",
    descricao: "SKOL LATA 350ML C/12",
    estoqueFisicoCaixas: 840,
    estoqueSistemaCaixas: 820,
    diferencaCaixas: 20,
    custoPorSku: 31.80,
    valorTotalDivergencia: 636.00,
    fatorHectolitro: 0.042,
    divergenciaHectolitro: 0.84,
    observacao: "Sobra física identificada após desobstrução do bloco 4.",
    dataCongelamento: "2026-05-29T11:15:00.000Z",
    usuario: "djesoaresn@gmail.com",
    documentoNome: null as string | null,
    documentoTamanho: null as string | null
  }
];

// Histórico de Conciliações dos últimos 30 dias
let historicoConciliacoesState = [
  {
    id: "CONC-01",
    data: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(), // ~15 dias atrás
    usuario: "gestor@consiliwms.com",
    skusAjustados: 3,
    totalValorAjustado: -699.00,
    totalHectolitrosAjustado: -1.55,
    itensDivergentes: [
      {
        sku: "00013061",
        descricao: "H2OH LIMONETO PET 500ML SHRINK C/12",
        estoqueFisicoCaixas: 145,
        estoqueSistemaCaixas: 150,
        diferencaCaixas: -5,
        diferencaReais: -186.00,
        diferencaHectolitros: -0.30,
        custoMedio: 37.20
      },
      {
        sku: "00000371",
        descricao: "SKOL LATA 350ML C/12",
        estoqueFisicoCaixas: 840,
        estoqueSistemaCaixas: 820,
        diferencaCaixas: 20,
        diferencaReais: 636.00,
        diferencaHectolitros: 0.84,
        custoMedio: 31.80
      },
      {
        sku: "00013070",
        descricao: "GUARANA ANTARCTICA 350ML CORONA C/12",
        estoqueFisicoCaixas: 320,
        estoqueSistemaCaixas: 345,
        diferencaCaixas: -25,
        diferencaReais: -1149.00,
        diferencaHectolitros: -2.09,
        custoMedio: 45.96
      }
    ]
  },
  {
    id: "CONC-02",
    data: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString(), // ~7 dias atrás
    usuario: "operador@consiliwms.com",
    skusAjustados: 2,
    totalValorAjustado: 450.00,
    totalHectolitrosAjustado: 0.684,
    itensDivergentes: [
      {
        sku: "00013061",
        descricao: "H2OH LIMONETO PET 500ML SHRINK C/12",
        estoqueFisicoCaixas: 160,
        estoqueSistemaCaixas: 150,
        diferencaCaixas: 10,
        diferencaReais: 372.00,
        diferencaHectolitros: 0.60,
        custoMedio: 37.20
      },
      {
        sku: "00013070",
        descricao: "GUARANA ANTARCTICA 350ML CORONA C/12",
        estoqueFisicoCaixas: 325,
        estoqueSistemaCaixas: 323,
        diferencaCaixas: 2,
        diferencaReais: 78.00,
        diferencaHectolitros: 0.084,
        custoMedio: 39.00
      }
    ]
  }
];

// Tabela de preços padrão fornecida pelo cliente para revalorização imediata
const tabelaPrecosIniciais: Record<string, number> = {
  "0000347": 30.4766,
  "0000371": 115.8000,
  "0000503": 19.4514,
  "0000504": 26.9727,
  "0000838": 13.4000,
  "0000982": 53.3450,
  "0000988": 52.2269,
  "0001114": 27.5460,
  "0001116": 28.0955,
  "0001164": 25.0000,
  "0001166": 20.0878,
  "0001232": 27.7751,
  "0001388": 51.4415,
  "0001695": 59.8917,
  "0001699": 21.9457,
  "0001743": 40.7643,
  "0001745": 30.9065,
  "0001898": 30.9215,
  "0002006": 60.0000,
  "0002008": 27.0076,
  "0002104": 35.4490,
  "0002319": 34.2232,
  "0002320": 31.8196,
  "0002349": 28.3923,
  "0002350": 27.0199,
  "0002353": 28.0860,
  "0002538": 48.2180,
  "0002546": 61.0246,
  "0002548": 53.6461,
  "0002585": 27.6858,
  "0007325": 34.0946,
  "0007945": 31.3374,
  "0007947": 32.3482,
  "0007977": 23.1437,
  "0007979": 28.6800,
  "0007980": 23.4085,
  "0007981": 23.2491,
  "0007982": 23.4008,
  "0007983": 23.3211,
  "0007985": 23.8184,
  "0008411": 25.0000,
  "0008791": 30.0750,
  "0008793": 28.1522,
  "0008919": 29.3324,
  "0009067": 28.9540,
  "0009068": 28.5200,
  "0009069": 28.5103,
  "0009071": 51.1000,
  "0009072": 33.2600,
  "0009081": 37.9000,
  "0009083": 37.8384,
  "0009084": 22.1225,
  "0009085": 22.3333,
  "0009087": 19.4123,
  "0009089": 20.6438,
  "0009091": 24.9208,
  "0009092": 23.5749,
  "0009093": 28.9200,
  "0009096": 20.0276,
  "0009274": 21.8884,
  "0009276": 26.1304,
  "0009320": 35.4597,
  "0009795": 33.4451,
  "0010175": 44.8500,
  "0010530": 78.4000,
  "0010537": 51.6363,
  "0010949": 19.0000,
  "0011593": 33.9049,
  "0012948": 30.8914,
  "0012951": 77.3027,
  "0013061": 32.7897,
  "0013065": 27.2310,
  "0013194": 61.7200,
  "0013196": 61.7200,
  "0013201": 39.0754,
  "0013203": 53.9000,
  "0013205": 39.1376,
  "0013307": 56.9571,
  "0013486": 38.5800,
  "0013566": 29.4038,
  "0013839": 18.2275,
  "0014099": 60.3036,
  "0014135": 38.7823,
  "0014283": 188.2309,
  "0014293": 166.5859,
  "0014550": 133.4597,
  "0016503": 38.2818,
  "0017266": 73.0000,
  "0017268": 51.5748,
  "0017276": 51.8890,
  "0017278": 54.1466,
  "0017757": 98.8239,
  "0017808": 90.6682,
  "0018142": 81.7620,
  "0018152": 13.2126,
  "0018266": 12.0834,
  "0018267": 12.2419,
  "0018268": 12.4744,
  "0018676": 24.7100,
  "0018677": 75.0000,
  "0018752": 71.9600,
  "0018772": 71.9600,
  "0018780": 83.6345,
  "0018807": 101.7217,
  "0018833": 79.8401,
  "0018836": 118.0086,
  "0019164": 3.8986,
  "0019166": 112.8752,
  "0019225": 138.1473,
  "0019227": 29.0762,
  "0019229": 37.2286,
  "0019231": 24.8190,
  "0019305": 26.0018,
  "0019321": 12.8400,
  "0019644": 28.5112,
  "0019668": 37.5759,
  "0019729": 28.8529,
  "0019849": 28.9035,
  "0020164": 37.4000,
  "0020217": 45.9387,
  "0020329": 54.6895,
  "0020498": 32.4843,
  "0020530": 64.7133,
  "0020533": 55.8600,
  "0020535": 76.8898,
  "0020549": 44.1900,
  "0020647": 25.8081,
  "0020651": 29.9470,
  "0020853": 34.5800,
  "0021020": 31.7842,
  "0021025": 62.2016,
  "0021119": 31.2654,
  "0021422": 71.0809,
  "0021441": 19.0200,
  "0021526": 74.0001,
  "0021527": 79.9000,
  "0021529": 77.8500,
  "0021530": 30.2801,
  "0021632": 94.5838,
  "0021658": 40.1550,
  "0021666": 24.8190,
  "0021668": 70.3093,
  "0021778": 59.0000,
  "0021781": 154.8900,
  "0021786": 22.0000,
  "0021787": 18.5100,
  "0021788": 83.3900,
  "0021791": 9.3000,
  "0021792": 62.1289,
  "0021955": 144.8100,
  "0021968": 34.0499,
  "0021970": 34.0499,
  "0021973": 34.0400,
  "0021974": 34.0499,
  "0022003": 21.8499,
  "0022005": 21.8499,
  "0022007": 21.8498,
  "0022009": 18.6500,
  "0022027": 35.0000,
  "0022106": 18.0700,
  "0022177": 23.1016,
  "0022180": 86.5156,
  "0022200": 27.3100,
  "0022202": 25.6700,
  "0022326": 37.6700,
  "0022330": 26.5300,
  "0022382": 31.7900,
  "0022508": 19.9300,
  "0022514": 50.3900,
  "0022543": 24.3200,
  "0022562": 42.1900,
  "0022783": 98.6328,
  "0022859": 140.0000,
  "0022860": 70.0000,
  "0022871": 120.8000,
  "0022876": 50.0000,
  "0023028": 180.8600,
  "0023029": 122.3400,
  "0023184": 48.0300,
  "0023186": 60.5702,
  "0023246": 120.9600,
  "0023256": 72.6300,
  "0023269": 115.9491,
  "0023271": 107.1100,
  "0023441": 29.4600,
  "0023443": 9.5000,
  "0023449": 40.0000,
  "0023546": 16.3399,
  "0023552": 14.2098,
  "0023594": 31.0700,
  "0023600": 50.4000,
  "0023602": 50.4000,
  "0023671": 51.7700,
  "0023672": 51.7700,
  "0023673": 51.7700,
  "0023674": 51.7700,
  "0023731": 28.0000,
  "0024161": 19.3000,
  "0024168": 130.8600,
  "0024184": 120.8000,
  "0024256": 9.4999,
  "0024304": 55.5600,
  "0024306": 23.8590,
  "0024408": 13.7700,
  "0024409": 14.2400,
  "0024410": 16.0000,
  "0024411": 13.7700,
  "0024479": 78.4163,
  "0024486": 29.9700,
  "0024488": 17.2100,
  "0025151": 108.9172,
  "0025160": 44.5137,
  "0025174": 116.0000,
  "0025176": 116.0000,
  "0025178": 100.4799,
  "0025194": 29.8161,
  "0025220": 12.3000,
  "0025329": 40.1800,
  "0025335": 40.1800,
  "0025347": 40.1800,
  "0025429": 21.9200,
  "0025430": 25.2800,
  "0025434": 42.8000,
  "0025546": 25.0000,
  "0025700": 31.0243,
  "0025837": 85.9000,
  "0026037": 22.9700,
  "0026099": 37.9000,
  "0026462": 41.6734,
  "0026607": 25.0100,
  "0027001": 54.9000,
  "0027177": 21.8499,
  "0027179": 21.8499,
  "0027522": 64.2820,
  "0027559": 89.6368,
  "0027560": 51.5705,
  "0027562": 51.5705,
  "0027566": 28.8100,
  "0027613": 51.5705,
  "0027624": 28.8100,
  "0027686": 126.4600,
  "0027704": 126.7649,
  "0027866": 119.8000,
  "0028137": 32.5776,
  "0028203": 11.3100,
  "0028204": 10.9900,
  "0029197": 13.3799,
  "0029199": 13.3700,
  "0029201": 13.3799,
  "0029207": 13.3700,
  "0029209": 13.3700,
  "0029215": 13.3700,
  "0029253": 62.8533,
  "0029416": 51.7700,
  "0029418": 51.7700,
  "0029485": 122.6500,
  "0029580": 106.9459,
  "0029733": 19.9700,
  "0029845": 34.4395,
  "0029891": 24.3200,
  "0029926": 177.4200,
  "0030045": 96.1800,
  "0030132": 70.0000,
  "0030134": 70.0000,
  "0030136": 89.7500,
  "0030148": 53.2800,
  "0030151": 53.2800,
  "0030152": 53.2800,
  "0030220": 50.6000,
  "0030440": 70.0000,
  "0030852": 14.0000,
  "0030854": 14.0000,
  "0030878": 58.4300,
  "0031064": 33.6800,
  "0031272": 45.0000,
  "0031582": 46.1000,
  "0031589": 46.1000,
  "0031667": 46.1000,
  "0031669": 46.1000,
  "0031674": 47.6800,
  "0031678": 166.0000,
  "0031708": 83.8000,
  "0031766": 250.3500,
  "0031789": 47.6800,
  "0031805": 120.6000,
  "0032036": 94.0800,
  "0032067": 22.7200,
  "0032126": 26.5300,
  "0032128": 10.0100,
  "0032131": 18.3500,
  "0032155": 21.2500,
  "0032175": 127.3800,
  "0032349": 32.1225,
  "0032361": 123.3400,
  "0032425": 51.4800,
  "0032427": 45.0000,
  "0032500": 30.3000,
  "0032526": 10.5799,
  "0032528": 12.1699,
  "0032538": 21.5000,
  "0032644": 12.4399,
  "0032646": 12.4399,
  "0032648": 12.4399,
  "0032754": 159.0000,
  "0032969": 31.9600,
  "0033042": 46.9300,
  "0033046": 168.4000,
  "0033048": 168.4000,
  "0033061": 90.0600,
  "0033066": 90.0600,
  "0033109": 50.0171,
  "0033239": 76.4000,
  "0033250": 76.4000,
  "0033251": 76.4000,
  "0033252": 76.4000,
  "0033318": 70.0000,
  "0033734": 35.2900,
  "0033738": 67.2300,
  "0033818": 37.5800,
  "0033820": 34.9000,
  "0033854": 120.6000,
  "0034027": 30.4800,
  "0034263": 28.2100,
  "0034296": 31.2300,
  "0034298": 31.2300,
  "0034320": 35.8800,
  "0034325": 17.9000,
  "0034410": 30.9000,
  "0034420": 29.1600,
  "0034429": 31.9600,
  "0034432": 140.4400,
  "0034475": 10.0400,
  "0034479": 13.4200,
  "0034527": 62.5100,
  "0034529": 120.6000,
  "0034530": 62.5100,
  "0034608": 39.0000,
  "0034681": 65.0000,
  "0034683": 90.0000,
  "0034685": 90.0000,
  "0034687": 65.0000,
  "0034770": 31.9600,
  "0034890": 25.0000,
  "0034918": 19.5400,
  "0034920": 20.1200,
  "0034923": 19.5900,
  "0035003": 34.0400,
  "0035012": 13.9500,
  "0035061": 83.8040,
  "0035108": 51.7700,
  "0035134": 8.9500,
  "0035136": 8.9500,
  "0035331": 65.6100,
  "0035617": 38.7100,
  "0035620": 135.0000,
  "0035980": 53.4900,
  "0035992": 51.0000,
  "0036034": 64.8800,
  "0037576": 40.9100,
  "0037820": 26.5300
};

// Executa o bootstrap imediato aplicando a tabela original Ambev do cliente
Object.entries(tabelaPrecosIniciais).forEach(([sku, preco]) => {
  if (preco > 0) {
    const idx = estoqueAtualState.findIndex(e => e.sku === sku);
    if (idx !== -1) {
      estoqueAtualState[idx].custoMedio = preco;
    }
  }
});

// Log de atividades reconciliadas
interface AuditoriaLog {
  id: string;
  data: string;
  usuario: string;
  skusAjustados: number;
  totalValorAjustado: number;
  descricao: string;
}
let logsAuditoria: AuditoriaLog[] = [
  { id: 'LOG001', data: '2026-05-28T14:30:00Z', usuario: 'djesoaresn@gmail.com', skusAjustados: 4, totalValorAjustado: -12500.00, descricao: 'Conciliação Semanal Rotativa de Alcoólicos' }
];

// Dados de Produtividade (Ressuprimento, repack, despejo, carregamento, descarregamento e montagem)
export interface ProdutividadeItem {
  id: string;
  operador: string;
  tipo: 'Ressuprimento e Reabastecimento' | 'Repack' | 'Despejo' | 'Carregamento' | 'Descarregamento' | 'Montagem';
  quantidadeCaixas: number;
  dataHora: string;
  tempoMinutagem: number; // minutos gastos
}

let produtividadeState: ProdutividadeItem[] = [
  { id: 'PROD001', operador: 'Carlos Silva', tipo: 'Ressuprimento e Reabastecimento', quantidadeCaixas: 140, dataHora: '2026-06-04T08:30:00Z', tempoMinutagem: 45 },
  { id: 'PROD002', operador: 'Alex Souza', tipo: 'Repack', quantidadeCaixas: 85, dataHora: '2026-06-04T09:15:00Z', tempoMinutagem: 30 },
  { id: 'PROD003', operador: 'Mariana Lima', tipo: 'Despejo', quantidadeCaixas: 60, dataHora: '2026-06-04T10:00:00Z', tempoMinutagem: 20 },
  { id: 'PROD004', operador: 'Carlos Silva', tipo: 'Carregamento', quantidadeCaixas: 350, dataHora: '2026-06-04T10:45:00Z', tempoMinutagem: 90 },
  { id: 'PROD005', operador: 'Alex Souza', tipo: 'Descarregamento', quantidadeCaixas: 450, dataHora: '2026-06-04T11:30:00Z', tempoMinutagem: 110 },
  { id: 'PROD006', operador: 'Mariana Lima', tipo: 'Montagem', quantidadeCaixas: 95, dataHora: '2026-06-04T13:00:00Z', tempoMinutagem: 40 },
  { id: 'PROD007', operador: 'Juliana Costa', tipo: 'Ressuprimento e Reabastecimento', quantidadeCaixas: 180, dataHora: '2026-06-04T13:30:00Z', tempoMinutagem: 50 },
  { id: 'PROD008', operador: 'Marcos Dias', tipo: 'Repack', quantidadeCaixas: 110, dataHora: '2026-06-04T14:15:00Z', tempoMinutagem: 35 },
  { id: 'PROD009', operador: 'Juliana Costa', tipo: 'Montagem', quantidadeCaixas: 140, dataHora: '2026-06-04T15:00:00Z', tempoMinutagem: 45 }
];

// File-based state persistence configuration to survive server restarts/hot reloads
const STATE_FILE_PATH = path.join(process.cwd(), "persisted_state.json");

let lastOperationalDateState = "";
const lastSavedHashes: Record<string, string> = {};
let isFirestoreSynced = false;

// Função automática de virada de dia que salva o snapshot fiscal no histórico de conciliações
// e zera o estoque físico na base para o operador reiniciar a contagem do zero.
export async function checkAndTriggerDayTurn(customUser?: string) {
  const user = customUser || "sistema@consiliwms.com";
  try {
    const dateObj = new Date();
    // Obtém data operacional padrão no fuso de Brasília/Recife (CD Guarabira)
    const options = { timeZone: "America/Recife", year: "numeric" as const, month: "2-digit" as const, day: "2-digit" as const };
    const formatter = new Intl.DateTimeFormat("pt-BR", options);
    const parts = formatter.formatToParts(dateObj);
    const day = parts.find(p => p.type === "day")?.value;
    const month = parts.find(p => p.type === "month")?.value;
    const year = parts.find(p => p.type === "year")?.value;
    const currentDateStr = `${year}-${month}-${day}`;

    // Inicializa na primeira execução com a data de hoje, sem realizar o reset imediato
    if (!lastOperationalDateState) {
      lastOperationalDateState = currentDateStr;
      await savePersistedState();
      return false;
    }

    // Se a data atual é diferente da última registrada, significa que o dia mudou!
    if (currentDateStr !== lastOperationalDateState) {
      console.log(`[VIRADA DE DIA] Alteração de data detectada: ${lastOperationalDateState} -> ${currentDateStr}. Fechando dia operacional e arquivando dados.`);

      // 1. Consolida o fechamento do dia anterior para salvar no histórico
      const consolidadoPre = processarBasesDados(
        estoqueAtualState,
        inventarioState,
        caixasPalletState,
        vendasMediasState,
        divergenciasCongeladasState
      );

      let skusAjustadosCount = 0;
      let totalValorAjuste = 0;
      let totalHectolitrosAjuste = 0;
      const itensDivergentes: any[] = [];
      const todosItensInventario: any[] = [];

      consolidadoPre.forEach((item) => {
        const diffBoxes = item.diferencaCaixas;
        const diffReais = item.divergenciaValor;
        const diffHecto = item.divergenciaHectolitro;

        const itemSnapshot = {
          sku: item.sku,
          descricao: item.descricao,
          estoqueFisicoCaixas: Math.floor(item.saldoAjustadoCaixas),
          estoqueSistemaCaixas: Math.floor(item.estoqueSistemaCaixas),
          diferencaCaixas: diffBoxes,
          diferencaReais: Number(diffReais.toFixed(2)),
          diferencaHectolitros: Number(diffHecto.toFixed(4)),
          custoMedio: item.custoMedio
        };

        todosItensInventario.push(itemSnapshot);

        if (diffBoxes !== 0) {
          itensDivergentes.push(itemSnapshot);
          totalValorAjuste += diffReais;
          totalHectolitrosAjuste += diffHecto;
          skusAjustadosCount++;
        }
      });

      // 2. Salva o snapshot fiscal consolidado do lote no histórico para fins fiscais e rastreamento permanente
      const [prevYear, prevMonth, prevDay] = lastOperationalDateState.split("-");
      const referenceLabel = `${prevDay}/${prevMonth}/${prevYear}`;

      const novaConciliacao = {
        id: `AUTO-${lastOperationalDateState}-${Date.now().toString(36).toUpperCase()}`,
        data: new Date().toISOString(),
        usuario: user,
        skusAjustados: skusAjustadosCount,
        totalValorAjustado: totalValorAjuste,
        totalHectolitrosAjustado: totalHectolitrosAjuste,
        itensDivergentes: itensDivergentes,
        todosItensInventario: todosItensInventario,
        isConsolidadorRotina: false,
        isAutoFechamentoDiario: true,
        dataReferenciaDia: referenceLabel
      };

      historicoConciliacoesState.unshift(novaConciliacao);

      // 3. Registra na auditoria a virada automática
      logsAuditoria.unshift({
        id: `LOG-AUTO-${Date.now().toString(36).toUpperCase()}`,
        data: new Date().toISOString(),
        usuario: user,
        skusAjustados: skusAjustadosCount,
        totalValorAjustado: totalValorAjuste,
        descricao: `Fechamento fiscal e virada de lote diário automático (${referenceLabel}). Todo o estoque físico foi resetado para zero para reiniciar a contagem diária contábil.`
      });

      // 4. Retorna todo o estoque físico de contagem rápida para ZERO em todo o CD
      inventarioState = inventarioState.map((inv) => {
        return {
          ...inv,
          estoqueFisicoCaixas: 0, // Reinicia em zero conforme solicitação absoluta do conferente!
          estoqueSistemaCaixas: inv.estoqueSistemaCaixas // Saldo sistêmico fiscal permanece idêntico
        };
      });

      // Reter limite histórico de conciliações de 30 dias
      const mLimite = Date.now() - (30 * 24 * 3600 * 1000);
      historicoConciliacoesState = historicoConciliacoesState.filter((c) => {
        return new Date(c.data).getTime() >= mLimite;
      });

      lastOperationalDateState = currentDateStr;
      await savePersistedState();
      return true;
    }
  } catch (err) {
    console.error("Erro ao computar virada de dia automática:", err);
  }
  return false;
}

export async function savePersistedState() {
  try {
    const dataToSave: Record<string, any> = {
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      entradasFuturasState,
      lotesValidadeState,
      pickingMapeamentoState,
      divergenciasCongeladasState,
      historicoConciliacoesState,
      logsAuditoria,
      layoutOverridesState,
      produtividadeState,
      lastOperationalDateState,
      erpCatalogMapList: Array.from(erpCatalogMap.entries())
    };

    // 1. Salvar no arquivo de cache local no disco para sobrevivência ao boot
    fs.writeFileSync(STATE_FILE_PATH, JSON.stringify(dataToSave, null, 2), "utf-8");

    // 2. Se Firebase inicializado, sincronizar as tabelas alteradas de forma incremental (economiza writes)
    if (db) {
      for (const key of Object.keys(dataToSave)) {
        const dataStr = JSON.stringify(dataToSave[key]);
        if (lastSavedHashes[key] !== dataStr) {
          lastSavedHashes[key] = dataStr;
          await setDoc(doc(db, "global_state", key), { data: dataToSave[key] });
        }
      }
    }
  } catch (err) {
    console.error("Error writing persisted state recursively:", err);
  }
}

export function loadPersistedState() {
  try {
    // 1. Carrega do cache local em disco de forma síncrona/imediata no boot
    if (fs.existsSync(STATE_FILE_PATH)) {
      const fileData = fs.readFileSync(STATE_FILE_PATH, "utf-8");
      const saved = JSON.parse(fileData);
      
      if (saved.estoqueAtualState) {
        estoqueAtualState = saved.estoqueAtualState;
      }
      if (saved.inventarioState) {
        inventarioState = saved.inventarioState;
      }
      if (saved.caixasPalletState) {
        caixasPalletState = saved.caixasPalletState;
      }
      if (saved.vendasMediasState) {
        vendasMediasState = saved.vendasMediasState;
      }
      if (saved.entradasFuturasState) {
        entradasFuturasState = saved.entradasFuturasState;
      }
      if (saved.lotesValidadeState) {
        lotesValidadeState = saved.lotesValidadeState;
      }
      if (saved.pickingMapeamentoState) {
        pickingMapeamentoState = saved.pickingMapeamentoState;
      }
      if (saved.divergenciasCongeladasState) {
        divergenciasCongeladasState = saved.divergenciasCongeladasState;
      }
      if (saved.historicoConciliacoesState) {
        historicoConciliacoesState = saved.historicoConciliacoesState;
      }
      if (saved.logsAuditoria) {
        logsAuditoria = saved.logsAuditoria;
      }
      if (saved.layoutOverridesState) {
        layoutOverridesState = saved.layoutOverridesState;
      }
      if (saved.produtividadeState) {
        produtividadeState = saved.produtividadeState;
      }
      if (saved.lastOperationalDateState) {
        lastOperationalDateState = saved.lastOperationalDateState;
      }
      if (saved.erpCatalogMapList) {
        erpCatalogMap.clear();
        saved.erpCatalogMapList.forEach(([key, val]: [string, any]) => {
          erpCatalogMap.set(key, val);
        });
      }
      console.log("Successfully loaded local filesystem cache.");
    }

    // 2. Registra o listener em tempo real no Firestore se ativado
    if (db && !isFirestoreSynced) {
      isFirestoreSynced = true;
      const collectionRef = collection(db, "global_state");
      onSnapshot(collectionRef, (snapshot) => {
        snapshot.forEach((docSnap) => {
          const key = docSnap.id;
          const value = docSnap.data().data;
          if (value === undefined) return;

          const valueStr = JSON.stringify(value);
          if (lastSavedHashes[key] === valueStr) return;

          lastSavedHashes[key] = valueStr;

          if (key === "estoqueAtualState") estoqueAtualState = value;
          else if (key === "inventarioState") inventarioState = value;
          else if (key === "caixasPalletState") caixasPalletState = value;
          else if (key === "vendasMediasState") vendasMediasState = value;
          else if (key === "entradasFuturasState") entradasFuturasState = value;
          else if (key === "lotesValidadeState") lotesValidadeState = value;
          else if (key === "pickingMapeamentoState") pickingMapeamentoState = value;
          else if (key === "divergenciasCongeladasState") divergenciasCongeladasState = value;
          else if (key === "historicoConciliacoesState") historicoConciliacoesState = value;
          else if (key === "logsAuditoria") logsAuditoria = value;
          else if (key === "layoutOverridesState") layoutOverridesState = value;
          else if (key === "produtividadeState") produtividadeState = value;
          else if (key === "lastOperationalDateState") lastOperationalDateState = value;
          else if (key === "erpCatalogMapList") {
            erpCatalogMap.clear();
            value.forEach(([k, v]: [string, any]) => {
              erpCatalogMap.set(k, v);
            });
          }
        });
        console.log("Firestore sync: Server in-memory schemas refreshed from central Firestore.");
      });
    }
  } catch (err) {
    console.error("Error loading persisted state on server:", err);
  }
}

// Initial hydration from local file-system state
loadPersistedState();

// Instanciação inteligente da API do Gemini
let aiCliente: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    aiCliente = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini API Client initialized successfully.");
  } else {
    console.warn("GEMINI_API_KEY is not defined. AI components will run in fallback offline recommendation mode.");
  }
} catch (e) {
  console.error("Error initializing Gemini API:", e);
}

// ==========================================
// ENDPOINTS DO BACKEND (API)
// ==========================================

// Middleware para salvar automaticamente as alterações de estado no arquivo persisted_state.json após qualquer API de mutação bem-sucedida
app.use((req, res, next) => {
  if (req.method !== "GET" && req.path.startsWith("/api/state")) {
    res.on("finish", () => {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        savePersistedState();
      }
    });
  }
  next();
});

// Retorna todo o estado do sistema consolidado e processado
app.get("/api/state", async (req, res) => {
  try {
    // Executa e aguarda de forma inteligente a virada de dia automática caso mude o dia operacional
    await checkAndTriggerDayTurn("sistema@consiliwms.com");

    const produtosConsolidados = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );
    const layoutWms = gerarLayoutWms(produtosConsolidados).map(p => {
      if (layoutOverridesState[p.id]) {
        return { ...p, ...layoutOverridesState[p.id] };
      }
      return p;
    });

    res.json({
      success: true,
      serverResetToken,
      data: {
        estoqueAtual: estoqueAtualState,
        inventario: inventarioState,
        caixasPallet: caixasPalletState,
        vendasMedias: vendasMediasState,
        entradasFuturas: entradasFuturasState,
        lotesValidade: lotesValidadeState,
        pickingMapeamento: pickingMapeamentoState,
        produtosConsolidados,
        layoutWms,
        logsAuditoria,
        divergenciasCongeladas: divergenciasCongeladasState,
        historicoConciliacoes: historicoConciliacoesState,
        produtividade: produtividadeState
      }
    });
  } catch (error: any) {
    console.error("Erro ao obter estado das bases de dados:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para simular ou forçar a virada diária de lote de estoque de forma manual
app.post("/api/state/day-turn", async (req, res) => {
  const { usuario } = req.body;
  const user = usuario || "operador@consiliwms.com";

  try {
    console.log(`[VIRADA DE DIA MANUAL] Iniciado fechamento operacional por ${user}.`);

    // 1. Processa e consolida o saldo atual antes do reset
    const consolidadoPre = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );

    let skusAjustadosCount = 0;
    let totalValorAjuste = 0;
    let totalHectolitrosAjuste = 0;
    const itensDivergentes: any[] = [];
    const todosItensInventario: any[] = [];

    consolidadoPre.forEach((item) => {
      const diffBoxes = item.diferencaCaixas;
      const diffReais = item.divergenciaValor;
      const diffHecto = item.divergenciaHectolitro;

      const itemSnapshot = {
        sku: item.sku,
        descricao: item.descricao,
        estoqueFisicoCaixas: Math.floor(item.saldoAjustadoCaixas),
        estoqueSistemaCaixas: Math.floor(item.estoqueSistemaCaixas),
        diferencaCaixas: diffBoxes,
        diferencaReais: Number(diffReais.toFixed(2)),
        diferencaHectolitros: Number(diffHecto.toFixed(4)),
        custoMedio: item.custoMedio
      };

      todosItensInventario.push(itemSnapshot);

      if (diffBoxes !== 0) {
        itensDivergentes.push(itemSnapshot);
        totalValorAjuste += diffReais;
        totalHectolitrosAjuste += diffHecto;
        skusAjustadosCount++;
      }
    });

    // 2. Cria identificador formatado de data
    const dateObj = new Date();
    const options = { timeZone: "America/Recife", year: "numeric" as const, month: "2-digit" as const, day: "2-digit" as const };
    const formatter = new Intl.DateTimeFormat("pt-BR", options);
    const parts = formatter.formatToParts(dateObj);
    const day = parts.find(p => p.type === "day")?.value;
    const month = parts.find(p => p.type === "month")?.value;
    const year = parts.find(p => p.type === "year")?.value;
    const currentDateStr = `${year}-${month}-${day}`;
    const dateLabel = `${day}/${month}/${year}`;

    // 3. Cadastra o novo ponto consolidado no histórico de conciliações para persistência
    const novaConciliacao = {
      id: `MANUAL-${Date.now().toString(36).toUpperCase()}`,
      data: new Date().toISOString(),
      usuario: user,
      skusAjustados: skusAjustadosCount,
      totalValorAjustado: totalValorAjuste,
      totalHectolitrosAjustado: totalHectolitrosAjuste,
      itensDivergentes: itensDivergentes,
      todosItensInventario: todosItensInventario,
      isConsolidadorRotina: false,
      isManualFechamentoDiario: true,
      dataReferenciaDia: dateLabel
    };

    historicoConciliacoesState.unshift(novaConciliacao);

    // 4. Cria registro específico na auditoria
    logsAuditoria.unshift({
      id: `LOG-MAN-${Date.now().toString(36).toUpperCase()}`,
      data: new Date().toISOString(),
      usuario: user,
      skusAjustados: skusAjustadosCount,
      totalValorAjustado: totalValorAjuste,
      descricao: `Fechamento de faturamento diário operado MANUALMENTE por ${user} (${dateLabel}). Todo o estoque físico atual foi zerado e salvo no histórico consolidado.`
    });

    // 5. Zera completamente todas as contagens físicas do CD
    inventarioState = inventarioState.map((inv) => {
      return {
        ...inv,
        estoqueFisicoCaixas: 0, // Zera para o recomeço diário!
        estoqueSistemaCaixas: inv.estoqueSistemaCaixas
      };
    });

    // Aplica controle de limite de histórico
    const mLimite = Date.now() - (30 * 24 * 3600 * 1000);
    historicoConciliacoesState = historicoConciliacoesState.filter((c) => {
      return new Date(c.data).getTime() >= mLimite;
    });

    lastOperationalDateState = currentDateStr;
    await savePersistedState();

    res.json({
      success: true,
      message: `Virada de dia concluída com sucesso! Histórico de conciliações alimentado com as contagens calculadas e estoque físico resetado para zero.`,
      fechamento: novaConciliacao
    });
  } catch (error: any) {
    console.error("Erro na virada de dia manual em /api/state/day-turn:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para reidratação do estado do WMS a partir do backup do localStorage do cliente
app.post("/api/state/restore-state", (req, res) => {
  const { 
    estoqueAtual, 
    inventario, 
    caixasPallet, 
    vendasMedias, 
    entradasFuturas, 
    lotesValidade, 
    pickingMapeamento, 
    divergenciasCongeladas, 
    historicoConciliacoes, 
    logsAuditoria: logsAuditoriaInput,
    layoutOverrides,
    produtividade
  } = req.body;

  try {
    if (Array.isArray(estoqueAtual)) estoqueAtualState = estoqueAtual;
    if (Array.isArray(inventario)) inventarioState = inventario;
    if (Array.isArray(caixasPallet)) caixasPalletState = caixasPallet;
    if (Array.isArray(vendasMedias)) vendasMediasState = vendasMedias;
    if (Array.isArray(entradasFuturas)) entradasFuturasState = entradasFuturas;
    if (Array.isArray(lotesValidade)) lotesValidadeState = lotesValidade;
    if (Array.isArray(pickingMapeamento)) pickingMapeamentoState = pickingMapeamento;
    if (Array.isArray(divergenciasCongeladas)) divergenciasCongeladasState = divergenciasCongeladas;
    if (Array.isArray(historicoConciliacoes)) historicoConciliacoesState = historicoConciliacoes;
    if (Array.isArray(logsAuditoriaInput)) logsAuditoria = logsAuditoriaInput;
    if (Array.isArray(produtividade)) produtividadeState = produtividade;
    if (layoutOverrides && typeof layoutOverrides === 'object') {
      layoutOverridesState = layoutOverrides;
    }

    savePersistedState();
    res.json({ 
      success: true, 
      message: "Base de dados reidratada com total acurácia a partir do backup permanente do navegador!" 
    });
  } catch (error: any) {
    console.error("Erro durante restauração de estado:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/state/update-layout-position", (req, res) => {
  const { id, skuAlocado, palletsAlocados, idadePallet, stockAgeIndex } = req.body;
  
  if (!id) {
    return res.status(400).json({ success: false, error: "ID da posição é obrigatório." });
  }

  try {
    layoutOverridesState[id] = {
      skuAlocado: skuAlocado || null,
      palletsAlocados: typeof palletsAlocados === 'number' ? palletsAlocados : 0,
      idadePallet: typeof idadePallet === 'number' ? idadePallet : 0,
      stockAgeIndex: typeof stockAgeIndex === 'number' ? stockAgeIndex : 0,
    };
    
    savePersistedState();
    res.json({ success: true, message: `Posição ${id} atualizada com sucesso.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Atualiza o estoque físico de um determinado SKU (simula contagem de inventário de campo)
app.post("/api/state/update-physical", (req, res) => {
  const { sku, quantidadeFisica } = req.body;
  
  if (!sku || typeof quantidadeFisica !== 'number') {
    return res.status(400).json({ success: false, error: "SKU e quantidade física válida são obrigatórios." });
  }

  try {
    const flooredQtd = Math.floor(quantidadeFisica);
    // Atualiza na base de inventário
    const itemIndex = inventarioState.findIndex(i => i.sku === sku);
    if (itemIndex !== -1) {
      inventarioState[itemIndex].estoqueFisicoCaixas = flooredQtd;
    } else {
      // Se não houver registro anterior, criamos
      const estItem = estoqueAtualState.find(e => e.sku === sku);
      const sist = estItem ? Math.floor(estItem.quantidadeAtualCaixas) : 0;
      inventarioState.push({
        sku,
        estoqueFisicoCaixas: flooredQtd,
        estoqueSistemaCaixas: sist
      });
    }

    savePersistedState();

    res.json({ success: true, message: `SKU ${sku} atualizado para ${flooredQtd} caixas físicas.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Efetua a conciliação automática: zera divergências alinhando sistema ao físico real
app.post("/api/state/reconcile", (req, res) => {
  const { usuario } = req.body;
  const userString = usuario || "operador@consiliwms.com";

  try {
    // Consolidamos o estado atual pré-conciliação para calcular as perdas/ganhos
    const consolidadoPre = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );

    let skusAjustadosCount = 0;
    let totalValorAjuste = 0;
    let totalHectolitrosAjuste = 0;
    const itensDivergentes: any[] = [];
    const todosItensInventario: any[] = [];

    consolidadoPre.forEach((item) => {
      const diffBoxes = item.diferencaCaixas;
      const diffReais = item.divergenciaValor;
      const diffHecto = item.divergenciaHectolitro;

      const itemSnapshot = {
        sku: item.sku,
        descricao: item.descricao,
        estoqueFisicoCaixas: Math.floor(item.saldoAjustadoCaixas),
        estoqueSistemaCaixas: Math.floor(item.estoqueSistemaCaixas),
        diferencaCaixas: diffBoxes,
        diferencaReais: Number(diffReais.toFixed(2)),
        diferencaHectolitros: Number(diffHecto.toFixed(4)),
        custoMedio: item.custoMedio
      };

      todosItensInventario.push(itemSnapshot);

      if (diffBoxes !== 0) {
        itensDivergentes.push(itemSnapshot);
        totalValorAjuste += diffReais;
        totalHectolitrosAjuste += diffHecto;
        skusAjustadosCount++;
      }
    });

    // NÃO alinhamos mais o estoqueAtualState ao estoqueFisico observado (conforme solicitação do usuário: o saldo fiscal deve permanecer o mesmo)
    // Portanto, o cadastro de faturamento fiscal / estoque atual NÃO é modificado pela conciliação automática.

    // Apenas o estoque físico de contagem na base de inventários é retornado para zero para preparar o próximo dia, mantendo o saldo fiscal intacto.
    inventarioState = inventarioState.map((inv) => {
      return {
        ...inv,
        estoqueFisicoCaixas: 0, // Retorna para zero conforme solicitado!
        estoqueSistemaCaixas: inv.estoqueSistemaCaixas // O saldo fiscal permanece exatamente o mesmo
      };
    });

    // Mantém o memorial de itens congelados salvo e persistente (só sai via exclusão explícita)
    // divergenciasCongeladasState = [];

    // Registra SEMPRE na auditoria e no histórico acumulado dos últimos 30 dias para salvar o saldo consolidado
    const novaConciliacao = {
      id: `CONC-${String(historicoConciliacoesState.length + 1).padStart(2, '0')}`,
      data: new Date().toISOString(),
      usuario: userString,
      skusAjustados: skusAjustadosCount,
      totalValorAjustado: totalValorAjuste,
      totalHectolitrosAjustado: totalHectolitrosAjuste,
      itensDivergentes: itensDivergentes,
      todosItensInventario: todosItensInventario, // Snapshot consolidado de todos os itens do CD!
      isConsolidadorRotina: skusAjustadosCount === 0
    };

    historicoConciliacoesState.unshift(novaConciliacao);

    logsAuditoria.unshift({
      id: `LOG${String(logsAuditoria.length + 1).padStart(3, '0')}`,
      data: new Date().toISOString(),
      usuario: userString,
      skusAjustados: skusAjustadosCount,
      totalValorAjustado: totalValorAjuste,
      descricao: skusAjustadosCount > 0 
        ? `Conciliação de estoque realizada. ${skusAjustadosCount} itens ajustados no total de R$ ${totalValorAjuste.toFixed(2)} (${totalHectolitrosAjuste.toFixed(3)} HL).`
        : `Conciliação de rotina executada. CD Sincronizado: Saldo físico de ${todosItensInventario.length} itens salvo no histórico.`
    });

    // Filtra para manter somente os últimos 30 dias
    const limiteTrintaDias = Date.now() - (30 * 24 * 3600 * 1000);
    historicoConciliacoesState = historicoConciliacoesState.filter((conc) => {
      return new Date(conc.data).getTime() >= limiteTrintaDias;
    });

    savePersistedState();

    res.json({
      success: true,
      message: "Conciliação realizada com sucesso! Sistema sincronizado com a contagem física.",
      skusAjustados: skusAjustadosCount,
      totalValorAjustado: totalValorAjuste
    });
  } catch (error: any) {
    console.error("Erro na conciliação:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Importação flexível de dados (Simulação de sincronismo ERP diário)
app.post("/api/state/import", (req, res) => {
  const { estoqueAtual, inventario, entradasFuturas, lotesValidade, pickingMapeamento, erpCatalog, divergenciasCongeladas } = req.body;

  try {
    if (estoqueAtual && Array.isArray(estoqueAtual)) {
      estoqueAtualState = estoqueAtual;
    }
    
    let totalItemsImported = 0;
    let auditDesc = "";

    // Sincronização do catálogo fiscal mestre do ERP (Atualização de Produto)
    if (erpCatalog && Array.isArray(erpCatalog)) {
      totalItemsImported = erpCatalog.length;
      auditDesc = `Importação Catálogo Fiscal ERP: Sincronizados ${erpCatalog.length} produtos do ERP com custos, hectolitros e fatores pallet/SKU originais.`;

      // CLEAR THE MAP TO OVERWRITE/RESET THE PREVIOUS CATALOG - DOES NOT ACCUMULATE OR PRESERVE DELETED SKUS
      erpCatalogMap.clear();

      erpCatalog.forEach((item: any) => {
        const skuNorm = String(item.sku || "").toUpperCase().trim().padStart(8, '0');
        if (!skuNorm) return;

        // Adiciona ao catálogo mestre compartilhado em memória
        erpCatalogMap.set(skuNorm, {
          sku: skuNorm,
          descricao: item.descricao,
          unidadeMedida: item.unidadeMedida || "UN",
          fatorPallet: Number(item.fatorPallet || 80),
          fatorSku: Number(item.fatorSku || 12),
          fatorHecto: Number(item.fatorHecto || 0.05),
          custoPorSku: Number(item.custoPorSku || 45.00),
          categoria: item.categoria || "MARKETPLACE"
        });

        // 1. Atualiza ou adiciona ao estoque mestre (Cadastro de Produto)
        const idxEst = estoqueAtualState.findIndex(e => e.sku.toUpperCase() === skuNorm);
        if (idxEst !== -1) {
          estoqueAtualState[idxEst].descricao = item.descricao;
          estoqueAtualState[idxEst].custoMedio = Number(item.custoPorSku);
          estoqueAtualState[idxEst].fatorEmbalagem = Number(item.fatorSku);
          estoqueAtualState[idxEst].fatorHectolitro = Number(item.fatorHecto);
        } else {
          estoqueAtualState.push({
            sku: skuNorm,
            descricao: item.descricao,
            custoMedio: Number(item.custoPorSku),
            fatorEmbalagem: Number(item.fatorSku),
            fatorHectolitro: Number(item.fatorHecto),
            quantidadeAtualCaixas: 0
          });
        }

        // 2. Sincroniza o fator pallet
        const idxPal = caixasPalletState.findIndex(p => p.sku.toUpperCase() === skuNorm);
        if (idxPal !== -1) {
          caixasPalletState[idxPal].caixasPorPallet = Number(item.fatorPallet);
        } else {
          caixasPalletState.push({
            sku: skuNorm,
            caixasPorPallet: Number(item.fatorPallet)
          });
        }

        // 3. Inicializa inventário com 0/0 se ainda não existir
        const idxInv = inventarioState.findIndex(i => i.sku.toUpperCase() === skuNorm);
        if (idxInv === -1) {
          inventarioState.push({
            sku: skuNorm,
            estoqueSistemaCaixas: 0,
            estoqueFisicoCaixas: 0
          });
        }
      });
    }

    // Sincronização do estoque e inventário do CD (Atualização de Estoque / Conciliação do Dia)
    if (inventario && Array.isArray(inventario)) {
      totalItemsImported = inventario.length;
      auditDesc = `Sincronizador ERP Relatório 02.05.02: ${inventario.length} itens integrados (Colunas AB, AC e AD processadas).`;

      // ENFORCE OVERWRITE - Clear old inventory counts to fully replace them and prevent summation / accumulation with prior files
      inventarioState = [];

      // Sincroniza cada contagem externa e actualiza custos médios na listagem de faturamento de estoque para valoração em Real
      inventario.forEach((invItem: any) => {
        const skuNorm = String(invItem.sku || "").toUpperCase().trim().padStart(8, '0');
        if (!skuNorm || skuNorm === '00000000') return;
        
        const fcaixas = Math.floor(Number(invItem.estoqueFisicoCaixas ?? 0));
        const scaixas = Math.floor(Number(invItem.estoqueSistemaCaixas ?? 0));
        const cMedio = Number(invItem.custoMedio);

        // Adiciona à base de inventário ativa (onde calculamos diferenças físicas x fiscais)
        inventarioState.push({
          sku: skuNorm,
          estoqueFisicoCaixas: fcaixas,
          estoqueSistemaCaixas: scaixas,
          vendaOntemCaixas: Number(invItem.vendaOntemCaixas ?? 0)
        });

        // Atualiza a listagem de estoque fiscal ativa
        const idxEst = estoqueAtualState.findIndex(e => e.sku.toUpperCase() === skuNorm);
        if (idxEst !== -1) {
          if (cMedio > 0) {
            estoqueAtualState[idxEst].custoMedio = cMedio;
          }
          // ERP atualizou os estoques no banco de dados ativo
          estoqueAtualState[idxEst].quantidadeAtualCaixas = scaixas;

          // Se o item existe com descrição genérica, atualiza para o catálogo mestre se disponível
          const currentDesc = estoqueAtualState[idxEst].descricao;
          if (!currentDesc || currentDesc === "Novo Produto (Criado após conciliação)" || currentDesc.startsWith("Item Sincronizado") || currentDesc === `PROD-${skuNorm}`) {
            const erpItem = erpCatalogMap.get(skuNorm);
            if (erpItem) {
              estoqueAtualState[idxEst].descricao = erpItem.descricao;
              estoqueAtualState[idxEst].fatorEmbalagem = erpItem.fatorSku;
              estoqueAtualState[idxEst].fatorHectolitro = erpItem.fatorHecto;
            }
          }
        } else {
          // Se for uma contagem de um item não cadastrado previamente no CD, nós o criamos
          const erpItem = erpCatalogMap.get(skuNorm);
          estoqueAtualState.push({
            sku: skuNorm,
            descricao: erpItem?.descricao || invItem.descricao || `Item Sincronizado ${skuNorm}`,
            custoMedio: erpItem?.custoPorSku || (cMedio > 0 ? cMedio : 45.00),
            fatorEmbalagem: erpItem?.fatorSku || 12,
            fatorHectolitro: erpItem?.fatorHecto || 0.05,
            quantidadeAtualCaixas: scaixas
          });
        }
      });
    }

    // Sincronização direta de desvios e congelamentos (Atualização de Congelamento)
    if (divergenciasCongeladas && Array.isArray(divergenciasCongeladas)) {
      totalItemsImported = divergenciasCongeladas.length;
      auditDesc = `Sincronização Acumulativa de Perdas: Importados e adicionados ${divergenciasCongeladas.length} desvios ao memorial de congelados.`;

      const novosItens = divergenciasCongeladas.map((item: any, index: number) => {
        const skuNorm = String(item.sku || "").toUpperCase().trim().padStart(8, '0');
        const erpItem = erpCatalogMap.get(skuNorm);
        const estItem = estoqueAtualState.find(e => e.sku === skuNorm);
        const invItem = inventarioState.find(i => i.sku === skuNorm);

        const resolvedDesc = erpItem?.descricao || estItem?.descricao || item.descricao || item.desc || `Item Congelado ${skuNorm}`;
        const custo = Number(item.custoPorSku ?? erpItem?.custoPorSku ?? estItem?.custoMedio ?? item.custoMedio ?? item.custo ?? 45.00);
        const fcaixas = Number(item.diferencaCaixas ?? item.caixas ?? item.quantidade ?? 0);
        const fHecto = Number(item.fatorHectolitro ?? erpItem?.fatorHecto ?? estItem?.fatorHectolitro ?? 0.05);

        const resolvedFisico = Number(item.estoqueFisicoCaixas ?? invItem?.estoqueFisicoCaixas ?? estItem?.quantidadeAtualCaixas ?? 0);
        const resolvedSistema = Number(item.estoqueSistemaCaixas ?? invItem?.estoqueSistemaCaixas ?? estItem?.quantidadeAtualCaixas ?? 0);

        return {
          id: item.id || `FZ${String(divergenciasCongeladasState.length + index + 1).padStart(3, '0')}_${Date.now()}`,
          sku: skuNorm,
          descricao: resolvedDesc,
          estoqueFisicoCaixas: resolvedFisico,
          estoqueSistemaCaixas: resolvedSistema,
          diferencaCaixas: fcaixas,
          custoPorSku: custo,
          valorTotalDivergencia: Number((Math.abs(fcaixas) * custo).toFixed(2)),
          fatorHectolitro: fHecto,
          divergenciaHectolitro: Number((fcaixas * fHecto).toFixed(4)),
          observacao: item.observacao || "Bloqueio/congelamento via planilha Excel importada.",
          dataCongelamento: item.dataCongelamento || new Date().toISOString(),
          usuario: item.usuario || "sistema@consiliwms.com"
        };
      });

      divergenciasCongeladasState = [...divergenciasCongeladasState, ...novosItens];
    }

    if (entradasFuturas && Array.isArray(entradasFuturas)) entradasFuturasState = entradasFuturas;
    if (lotesValidade && Array.isArray(lotesValidade)) lotesValidadeState = lotesValidade;
    if (pickingMapeamento && Array.isArray(pickingMapeamento)) pickingMapeamentoState = pickingMapeamento;

    logsAuditoria.unshift({
      id: `LOG${String(logsAuditoria.length + 1).padStart(3, '0')}`,
      data: new Date().toISOString(),
      usuario: "erp-system@integration.com",
      skusAjustados: totalItemsImported,
      totalValorAjustado: 0,
      descricao: auditDesc || `Sincronizador ERP efetuado com absoluto sucesso para ${totalItemsImported} registros.`
    });

    res.json({ success: true, message: "Importação e integração efetuadas com absoluto sucesso no WMS.", divergenciasCongeladas: divergenciasCongeladasState });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para importação dedicada das vendas do dia anterior (Coluna J em SKU Fechado)
app.post("/api/state/import-sales", (req, res) => {
  const { vendasOntem } = req.body;
  if (!vendasOntem || !Array.isArray(vendasOntem)) {
    return res.status(400).json({ success: false, error: "Tabela de vendas inválida." });
  }

  try {
    let updatedCount = 0;
    vendasOntem.forEach((item: any) => {
      const skuNorm = String(item.sku || "").toUpperCase().trim().padStart(8, '0');
      if (!skuNorm || skuNorm === '00000000') return;

      const venda = Number(item.vendaOntemCaixas || 0);

      const idx = inventarioState.findIndex(i => i.sku === skuNorm);
      if (idx !== -1) {
        inventarioState[idx].vendaOntemCaixas = venda;
        updatedCount++;
      } else {
        inventarioState.push({
          sku: skuNorm,
          estoqueFisicoCaixas: 0,
          estoqueSistemaCaixas: 0,
          vendaOntemCaixas: venda
        });
        updatedCount++;
      }
    });

    savePersistedState();

    logsAuditoria.unshift({
      id: `LOG${String(logsAuditoria.length + 1).padStart(3, '0')}`,
      data: new Date().toISOString(),
      usuario: "vendas-ontem@fechado.com",
      skusAjustados: updatedCount,
      totalValorAjustado: 0,
      descricao: `Importação Vendas Dia Anterior (Coluna J / SKU Fechado): Sincronizados ${updatedCount} SKUs com saídas externas.`
    });

    res.json({ success: true, message: `Vendas do dia anterior importadas com sucesso para ${updatedCount} SKUs.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para atualização dinâmica de preços em lote (Variação de preço)
app.post("/api/state/update-prices", (req, res) => {
  const { rawPricesCsv } = req.body;
  if (!rawPricesCsv || typeof rawPricesCsv !== 'string') {
    return res.status(400).json({ success: false, error: "Tabela de preços CSV em formato de texto é necessária." });
  }

  try {
    const lines = rawPricesCsv.split(/\r?\n/);
    let updatedCount = 0;
    
    // Função auxiliar para normatizar SKU
    const formatSku = (val: string): string => {
      return val.trim().padStart(8, '0');
    };

    lines.forEach((line) => {
      const trimmedLine = line.trim();
      if (!trimmedLine || trimmedLine.startsWith("Número") || trimmedLine.startsWith("Nmero")) return; // ignora cabeçalho

      const cols = trimmedLine.split(';');
      // Requisito rígido: Código do Produto na coluna F (index 5), Valor de Mercadoria na coluna I (index 8)
      if (cols.length >= 9) {
        const rawSku = cols[5]?.trim() || "";
        const rawPreco = cols[8]?.trim() || "";
        
        if (rawSku && rawPreco) {
          const sku = formatSku(rawSku);
          const preco = parseFloat(rawPreco.replace(/\./g, '').replace(',', '.')) || 0;
          
          if (preco > 0) {
            // Atualiza nas bases em memória do CD
            const idx = estoqueAtualState.findIndex(e => e.sku === sku || e.sku.replace(/^0+/, '') === sku.replace(/^0+/, ''));
            if (idx !== -1) {
              estoqueAtualState[idx].custoMedio = preco;
              updatedCount++;
            }
          }
        }
      }
    });

    logsAuditoria.unshift({
      id: `LOG${String(logsAuditoria.length + 1).padStart(3, '0')}`,
      data: new Date().toISOString(),
      usuario: "djesoaresn@gmail.com",
      skusAjustados: updatedCount,
      totalValorAjustado: 0,
      descricao: `Atualização de Preço ERP: ${updatedCount} SKUs valorizados dinamicamente via upload de arquivo de variação de preços.`
    });

    res.json({ success: true, count: updatedCount, message: `${updatedCount} SKUs atualizados e revalorizados com sucesso.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Criação rápida de um novo item para provar dinâmica fiscal
app.post("/api/state/add-product", (req, res) => {
  const { 
    sku, 
    descricao, 
    categoria, 
    custoMedio, 
    caixasPorPallet, 
    vendaMedia, 
    unidadeMedida, 
    fatorSku, 
    fatorHecto 
  } = req.body;

  if (!sku || !descricao) {
    return res.status(400).json({ success: false, error: "SKU e Descrição são requeridos." });
  }

  try {
    const skuNorm = String(sku).toUpperCase().trim().padStart(8, '0');
    const finalCusto = Number(custoMedio) || 45.00;
    const finalPallet = Number(caixasPorPallet) || 80;
    const finalSku = Number(fatorSku) || Number(req.body.fatorEmbalagem) || 12;
    const finalHecto = Number(fatorHecto) || Number(req.body.fatorHectolitro) || 0.05;
    const finalUm = String(unidadeMedida || "CX").toUpperCase();
    const finalCategoria = String(categoria || "MARKETPLACE").trim();

    // Adiciona ao catálogo mestre compartilhado em memória
    erpCatalogMap.set(skuNorm, {
      sku: skuNorm,
      descricao: descricao.toUpperCase().trim(),
      unidadeMedida: finalUm,
      fatorPallet: finalPallet,
      fatorSku: finalSku,
      fatorHecto: finalHecto,
      custoPorSku: finalCusto,
      categoria: finalCategoria
    });

    // 1. Adiciona ou atualiza no estoque atual
    const idxEst = estoqueAtualState.findIndex(e => e.sku === skuNorm);
    if (idxEst !== -1) {
      estoqueAtualState[idxEst].descricao = descricao.toUpperCase().trim();
      estoqueAtualState[idxEst].custoMedio = finalCusto;
      estoqueAtualState[idxEst].fatorEmbalagem = finalSku;
      estoqueAtualState[idxEst].fatorHectolitro = finalHecto;
    } else {
      estoqueAtualState.push({
        sku: skuNorm,
        descricao: descricao.toUpperCase().trim(),
        custoMedio: finalCusto,
        fatorEmbalagem: finalSku,
        fatorHectolitro: finalHecto,
        quantidadeAtualCaixas: 100
      });
    }

    // 2. Adiciona ou atualiza no inventário inicial (com divergência inicial nula)
    const idxInv = inventarioState.findIndex(i => i.sku === skuNorm);
    if (idxInv !== -1) {
      inventarioState[idxInv].estoqueFisicoCaixas = 100;
      inventarioState[idxInv].estoqueSistemaCaixas = 100;
    } else {
      inventarioState.push({
        sku: skuNorm,
        estoqueFisicoCaixas: 100,
        estoqueSistemaCaixas: 100
      });
    }

    // 3. Adiciona ao mapeamento de caixas por pallet
    const idxPal = caixasPalletState.findIndex(p => p.sku === skuNorm);
    if (idxPal !== -1) {
      caixasPalletState[idxPal].caixasPorPallet = finalPallet;
    } else {
      caixasPalletState.push({
        sku: skuNorm,
        caixasPorPallet: finalPallet
      });
    }

    // 4. Adiciona ao volume de vendas
    const idxVendas = vendasMediasState.findIndex(v => v.sku === skuNorm);
    if (idxVendas !== -1) {
      vendasMediasState[idxVendas].vendaMensalMediaCaixas = Number(vendaMedia) || 200;
    } else {
      vendasMediasState.push({
        sku: skuNorm,
        vendaMensalMediaCaixas: Number(vendaMedia) || 200
      });
    }

    res.json({ success: true, message: `Novo produto ${skuNorm} integrado nativamente com sucesso.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para congelar divergências e quebras de inventário selecionadas com observações
app.post("/api/state/freeze", (req, res) => {
  const { skusToFreeze, observacoes, usuario, isManual, manualSku, manualQuantidade, manualObservacao, manualItems, documentos } = req.body;
  const user = usuario || "djesoaresn@gmail.com";

  try {
    const produtosConsolidados = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );

    if (isManual) {
      const itemsToProcess: { sku: string; quantidade: number; observacao?: string; tipo?: string }[] = [];
      
      if (manualItems && Array.isArray(manualItems)) {
        itemsToProcess.push(...manualItems);
      } else {
        if (!manualSku || typeof manualQuantidade !== 'number') {
          return res.status(400).json({ success: false, error: "SKU e quantidade de congelamento válida são obrigatórios." });
        }
        itemsToProcess.push({ sku: manualSku, quantidade: manualQuantidade, observacao: manualObservacao });
      }

      itemsToProcess.forEach(mItem => {
        const normalizedSku = mItem.sku.trim().toUpperCase().padStart(8, '0');
        const p = produtosConsolidados.find(item => item.sku === normalizedSku);

        let pDesc = p?.descricao || `Produto ${normalizedSku.replace(/^0+/, '')}`;
        let pCusto = p?.custoMedio || 45.00;
        let pHectolitro = p?.fatorHectolitro || 0.055;

        const erpItem = erpCatalogMap.get(normalizedSku);
        if (erpItem) {
          pDesc = erpItem.descricao;
          pCusto = erpItem.custoPorSku;
          pHectolitro = erpItem.fatorHecto;
        }

        const physicalVal = p ? Math.floor(p.estoqueFisicoCaixas) : 0;
        const systemVal = p ? Math.floor(p.estoqueSistemaCaixas) : 0;
        const originalDiff = physicalVal - systemVal;

        let finalQty = mItem.quantidade;
        if (mItem.tipo === 'falta') {
          finalQty = -Math.abs(mItem.quantidade);
        } else if (mItem.tipo === 'sobra') {
          finalQty = Math.abs(mItem.quantidade);
        } else if (originalDiff < 0) {
          finalQty = -Math.abs(mItem.quantidade);
        } else if (originalDiff > 0) {
          finalQty = Math.abs(mItem.quantidade);
        } else {
          // Se originalDiff for 0, perdas representam quebras (falha física), que são negativas
          finalQty = -Math.abs(mItem.quantidade);
        }

        finalQty = Number(finalQty.toFixed(2));

        // Remove duplicados se já existir
        divergenciasCongeladasState = divergenciasCongeladasState.filter(item => item.sku !== normalizedSku);

        divergenciasCongeladasState.unshift({
          id: `FZ${String(divergenciasCongeladasState.length + 1).padStart(3, '0')}`,
          sku: normalizedSku,
          descricao: pDesc,
          estoqueFisicoCaixas: physicalVal,
          estoqueSistemaCaixas: systemVal,
          diferencaCaixas: finalQty,
          custoPorSku: pCusto,
          valorTotalDivergencia: Number((finalQty * pCusto).toFixed(2)),
          fatorHectolitro: pHectolitro,
          divergenciaHectolitro: Number((finalQty * pHectolitro).toFixed(4)),
          observacao: mItem.observacao || "Congelamento realizado via painel manual.",
          dataCongelamento: new Date().toISOString(),
          usuario: user
        });
      });

      return res.json({
        success: true,
        message: `${itemsToProcess.length} itens correspondentes congelados com sucesso!`,
        divergenciasCongeladas: divergenciasCongeladasState
      });
    }

    if (!skusToFreeze || !Array.isArray(skusToFreeze)) {
      return res.status(400).json({ success: false, error: "skusToFreeze deve ser um array." });
    }

    let countFrozen = 0;
    skusToFreeze.forEach((sku: string) => {
      const p = produtosConsolidados.find(item => item.sku === sku);
      if (p) {
        const obs = (observacoes && observacoes[sku]) ? observacoes[sku] : "Divergência mapeada e congelada.";
        const docInfo = documentos && documentos[sku];
        const docName = docInfo ? docInfo.nome : null;
        const docSize = docInfo ? docInfo.tamanho : null;
        
        // Remove duplicados se existirem para este SKU
        divergenciasCongeladasState = divergenciasCongeladasState.filter(item => item.sku !== sku);

        divergenciasCongeladasState.unshift({
          id: `FZ${String(divergenciasCongeladasState.length + 1).padStart(3, '0')}`,
          sku: p.sku,
          descricao: p.descricao,
          estoqueFisicoCaixas: Math.floor(p.estoqueFisicoCaixas),
          estoqueSistemaCaixas: Math.floor(p.estoqueSistemaCaixas),
          diferencaCaixas: Math.round(p.diferencaCaixas),
          custoPorSku: p.custoMedio,
          valorTotalDivergencia: Number((p.diferencaCaixas * p.custoMedio).toFixed(2)),
          fatorHectolitro: p.fatorHectolitro,
          divergenciaHectolitro: Number((p.diferencaCaixas * p.fatorHectolitro).toFixed(4)),
          observacao: obs,
          dataCongelamento: new Date().toISOString(),
          usuario: user,
          documentoNome: docName,
          documentoTamanho: docSize
        });
        countFrozen++;
      }
    });

    savePersistedState();

    res.json({ 
      success: true, 
      message: `${countFrozen} divergências congeladas com sucesso!`,
      divergenciasCongeladas: divergenciasCongeladasState
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para descongelar / liberar quebras da lista de verificação
app.post("/api/state/unfreeze", (req, res) => {
  const { skusToUnfreeze } = req.body;
  if (!skusToUnfreeze || !Array.isArray(skusToUnfreeze)) {
    return res.status(400).json({ success: false, error: "skusToUnfreeze deve ser um array de SKUs." });
  }

  try {
    divergenciasCongeladasState = divergenciasCongeladasState.filter(item => !skusToUnfreeze.includes(item.sku));
    
    savePersistedState();

    res.json({ 
      success: true, 
      message: "Itens liberados do congelamento com sucesso.",
      divergenciasCongeladas: divergenciasCongeladasState
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para listar os dados de produtividade
app.get("/api/state/productivity", (req, res) => {
  res.json({
    success: true,
    produtividade: produtividadeState
  });
});

// Endpoint para registrar nova atividade de produtividade (Manual ou Firebase-Sincronizado)
app.post("/api/state/productivity/add", (req, res) => {
  const { operador, tipo, quantidadeCaixas, tempoMinutagem } = req.body;
  
  if (!operador || !tipo || !quantidadeCaixas || !tempoMinutagem) {
    return res.status(400).json({ success: false, error: "Parâmetros incompletos. Requer operador, tipo, quantidadeCaixas, tempoMinutagem." });
  }

  try {
    const novoId = `PROD${String(produtividadeState.length + 1).padStart(3, '0')}`;
    const novoItem: ProdutividadeItem = {
      id: novoId,
      operador: String(operador).trim(),
      tipo: tipo,
      quantidadeCaixas: Number(quantidadeCaixas),
      dataHora: new Date().toISOString(),
      tempoMinutagem: Number(tempoMinutagem)
    };

    produtividadeState.push(novoItem);
    savePersistedState();

    res.json({
      success: true,
      message: "Atividade de produtividade registrada com sucesso!",
      novoItem,
      produtividade: produtividadeState
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para resetar ou restabelecer a base de dados de produtividade
app.post("/api/state/productivity/reset", (req, res) => {
  try {
    produtividadeState = [
      { id: 'PROD001', operador: 'Carlos Silva', tipo: 'Ressuprimento e Reabastecimento', quantidadeCaixas: 140, dataHora: new Date().toISOString(), tempoMinutagem: 45 },
      { id: 'PROD002', operador: 'Alex Souza', tipo: 'Repack', quantidadeCaixas: 85, dataHora: new Date().toISOString(), tempoMinutagem: 30 },
      { id: 'PROD003', operador: 'Mariana Lima', tipo: 'Despejo', quantidadeCaixas: 60, dataHora: new Date().toISOString(), tempoMinutagem: 20 },
      { id: 'PROD004', operador: 'Carlos Silva', tipo: 'Carregamento', quantidadeCaixas: 350, dataHora: new Date().toISOString(), tempoMinutagem: 90 },
      { id: 'PROD005', operador: 'Alex Souza', tipo: 'Descarregamento', quantidadeCaixas: 450, dataHora: new Date().toISOString(), tempoMinutagem: 110 },
      { id: 'PROD006', operador: 'Mariana Lima', tipo: 'Montagem', quantidadeCaixas: 95, dataHora: new Date().toISOString(), tempoMinutagem: 40 }
    ];
    savePersistedState();
    res.json({
      success: true,
      message: "Base de dados de produtividade redefinida com sucesso.",
      produtividade: produtividadeState
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint para gerar a análise de evolução individual mensal com variação de sistema e físico
app.get("/api/state/history/:sku", (req, res) => {
  let { sku } = req.params;
  
  if (!sku) {
    return res.status(400).json({ success: false, error: "Código do SKU é obrigatório." });
  }

  // Normaliza o SKU para 8 dígitos
  const skuNorm = sku.trim().toUpperCase().padStart(8, '0');

  try {
    const produtosConsolidados = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );

    const p = produtosConsolidados.find(item => item.sku === skuNorm);
    if (!p) {
      return res.status(404).json({ success: false, error: `SKU ${skuNorm} não localizado no cadastro operacional.` });
    }

    // Gerador determinístico baseado no SKU para gráficos estáticos e lindamente fluidos
    const getHash = (text: string, sub: string) => {
      let h = 0;
      const combined = text + sub;
      for (let i = 0; i < combined.length; i++) {
        h = (h * 31 + combined.charCodeAt(i)) & 0xffffffff;
      }
      return Math.abs(h);
    };

    const hashVal = getHash(skuNorm, "base");
    const stockBase = (hashVal % 140) + 40; // 40 a 180 caixas de estoque inicial
    const avgSale = (getHash(skuNorm, "sales") % 8) + 2; // 2 a 10 caixas por dia
    const refillSize = (getHash(skuNorm, "refill") % 60) + 50; // 50 a 110 caixas
    
    // Gerar os dados dos 30 dias de Maio de 2026
    const dataPoints = [];
    let currentSist = stockBase;
    
    // O desvio se inicia de forma determinística
    let currentFis = stockBase + (getHash(skuNorm, "driftInit") % 8) - 4; // Desvio inicial de +/- 4 caixas

    for (let day = 1; day <= 30; day++) {
      const dStr = String(day).padStart(2, '0');
      const label = `${dStr}/05`;
      
      // Recebimento a cada 7 dias (Dias 7, 14, 21, 28)
      const hasRefill = day % 7 === 0;
      const entries = hasRefill ? refillSize : 0;
      
      // Vendas diárias oscilam determinísticamente
      const daySales = Math.max(0, Math.round(avgSale + (getHash(skuNorm, `saleD-${day}`) % 4) - 2));

      currentSist = Math.max(0, currentSist - daySales + entries);

      // O estoque físico real oscila com pequenas quebras, desvios ou perdas operacionais
      const lossDrift = (getHash(skuNorm, `driftD-${day}`) % 3) - 1.4; // Drift flutuante de -1.4 a +1.6
      currentFis = Math.max(0, Math.floor(currentFis - daySales + entries + lossDrift));

      // No dia 15 ocorre uma reconciliação no CD equilibrando o estoque físico e sistêmico!
      if (day === 15) {
        currentFis = currentSist;
      }

      dataPoints.push({
        dia: label,
        data: `2026-05-${dStr}`,
        sistema: Math.round(currentSist * 100) / 100,
        fisico: Math.round(currentFis * 100) / 100,
        entradas: entries,
        saidas: daySales,
        divergencia: Math.round((currentFis - currentSist) * 100) / 100
      });
    }

    // Injeta reconciliações REAIS que ocorreram e foram salvas na pilha de historico de conciliações
    const realHistoryPoints = [...historicoConciliacoesState]
      .reverse() // Do mais antigo ao mais recente para o final do gráfico
      .map((conc) => {
        // Acha dados deste SKU na conciliação real
        const snap = ((conc as any).todosItensInventario || [])
          .find((item: any) => item.sku === skuNorm);
        
        const dataRecon = new Date(conc.data);
        const lDay = dataRecon.getDate().toString().padStart(2, '0');
        const lMonth = (dataRecon.getMonth() + 1).toString().padStart(2, '0');
        const lHour = dataRecon.getHours().toString().padStart(2, '0');
        const lMin = dataRecon.getMinutes().toString().padStart(2, '0');
        const labelStr = `${lDay}/${lMonth} ${lHour}:${lMin}`;

        const sist = snap ? snap.estoqueSistemaCaixas : p.estoqueSistemaCaixas;
        const fis = snap ? snap.estoqueFisicoCaixas : p.estoqueFisicoCaixas;

        return {
          dia: labelStr,
          data: conc.data,
          sistema: Math.round(sist * 100) / 100,
          fisico: Math.round(fis * 100) / 100,
          entradas: 0,
          saidas: 0,
          divergencia: Math.round((fis - sist) * 100) / 100,
          isReal: true,
          concId: conc.id
        };
      });

    dataPoints.push(...realHistoryPoints);

    res.json({
      success: true,
      data: {
        sku: p.sku,
        descricao: p.descricao,
        categoria: p.categoria,
        curvaABC: p.curvaABC,
        lastSist: p.estoqueSistemaCaixas,
        lastPhys: p.estoqueFisicoCaixas,
        custoMedio: p.custoMedio,
        fatorHectolitro: p.fatorHectolitro,
        dataPoints
      }
    });

  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Receber Entrada Fiscal Futura (Soma ao estoque atual)
app.post("/api/state/receive-entry", (req, res) => {
  const { id } = req.body;
  
  if (!id) {
    return res.status(400).json({ success: false, error: "ID da Entrada Fiscal Futura é requerido." });
  }

  try {
    const entryIdx = entradasFuturasState.findIndex(e => e.id === id);
    if (entryIdx === -1) {
      return res.status(404).json({ success: false, error: "Entrada fiscal não localizada." });
    }

    const entrada = entradasFuturasState[entryIdx];
    if (entrada.status === 'Recebido') {
      return res.status(400).json({ success: false, error: "Entrada fiscal já foi recebida anteriormente." });
    }

    // Altera o status para Recebido
    entrada.status = 'Recebido';

    // Procura o SKU no estoque atual
    const estItem = estoqueAtualState.find(e => e.sku === entrada.sku);
    if (estItem) {
      estItem.quantidadeAtualCaixas += entrada.quantidadeCaixas;
    }

    // Iguala no inventário também para evitar falsa divergência física imediata
    const invItem = inventarioState.find(i => i.sku === entrada.sku);
    if (invItem) {
      invItem.estoqueSistemaCaixas += entrada.quantidadeCaixas;
      invItem.estoqueFisicoCaixas += entrada.quantidadeCaixas;
    }

    // Lança novo lote de validade gerado a partir do recebimento da nota fiscal
    const dataValidade = new Date();
    dataValidade.setDate(dataValidade.getDate() + 120); // 4 meses de validade padrão
    
    lotesValidadeState.push({
      id: `L0${String(lotesValidadeState.length + 1).padStart(2, '0')}`,
      sku: entrada.sku,
      numeroLote: `LOTE-REC-${entrada.id}`,
      dataFabricacao: new Date().toISOString().split('T')[0],
      dataValidade: dataValidade.toISOString().split('T')[0],
      quantidadeCaixas: entrada.quantidadeCaixas,
      diasParaVencer: 120,
      alertaStatus: 'Normal'
    });

    // Registra auditoria
    logsAuditoria.unshift({
      id: `LOG${String(logsAuditoria.length + 1).padStart(3, '0')}`,
      data: new Date().toISOString(),
      usuario: "fiscal-agent@consiliwms.com",
      skusAjustados: 1,
      totalValorAjustado: entrada.valorTotal,
      descricao: `Recebimento da Nota Fiscal ${entrada.chaveNotaFiscal}. SKU ${entrada.sku} abastecido com ${entrada.quantidadeCaixas} cx.`
    });

    res.json({ success: true, message: `NF ${entrada.chaveNotaFiscal} recebida e integrada ao WMS com sucesso!`, entrada });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// MUDAR STATUS DE UM LOTE INTEIRO (Simulação de FEFO e descarte preventivo)
app.post("/api/state/quarantine-batch", (req, res) => {
  const { id } = req.body;
  if (!id) return res.status(400).json({ success: false, error: "ID do lote é requerido" });

  try {
    const lote = lotesValidadeState.find(l => l.id === id);
    if (!lote) return res.status(404).json({ success: false, error: "Lote não localizado" });

    lote.alertaStatus = 'Crítico';
    lote.diasParaVencer = 0; // foca a atenção

    res.json({ success: true, message: `Lote ${lote.numeroLote} colocado sob regime de quarentena.`, lote });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Reabastecer o Picking a partir do Armazém Central por SKU
app.post("/api/state/replenish-picking", (req, res) => {
  const { sku, quantidadeCaixas } = req.body;
  if (!sku || !quantidadeCaixas) {
    return res.status(400).json({ success: false, error: "SKU e quantidade de caixas são obrigatórios." });
  }

  try {
    const pickItem = pickingMapeamentoState.find(p => p.sku === sku);
    if (!pickItem) {
      return res.status(404).json({ success: false, error: "Mapeamento de picking não cadastrado para este SKU." });
    }

    const estItem = estoqueAtualState.find(e => e.sku === sku);
    const estoqueTotalDisponivel = estItem ? estItem.quantidadeAtualCaixas : 0;

    if (quantidadeCaixas > estoqueTotalDisponivel) {
      return res.status(400).json({ 
        success: false, 
        error: `Ressuprimento negado: Quantidade solicitada (${quantidadeCaixas} cx) é maior do que o estoque master total no WMS (${estoqueTotalDisponivel} cx).` 
      });
    }

    // Incrementa saldo no picking
    pickItem.saldoAtualCaixas = Math.min(pickItem.capacidadeCaixas, pickItem.saldoAtualCaixas + quantidadeCaixas);

    res.json({ 
      success: true, 
      message: `Ressuprimento de picking concluído para o SKU ${sku}. Saldo atualizado no picking: ${pickItem.saldoAtualCaixas} cx.`,
      picking: pickItem
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==========================================
// INTEGRATOR PROXY: SERVER-SIDE GEMINI DEEP ANALYSIS (AI INSIGHTS)
// ==========================================
app.post("/api/ai/insights", async (req, res) => {
  try {
    // Consolidamos as bases
    const produtosConsolidados = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );

    // Formata o resumo de dados para repassar como prompt contextualizado ao Gemini
    const divergentes = produtosConsolidados.filter(p => p.temDivergencia);
    const curvaA = produtosConsolidados.filter(p => p.curvaABC === 'A');
    const totalFinanceiro = produtosConsolidados.reduce((sum, p) => sum + p.valorTotalEstoque, 0);
    const volumeHL = produtosConsolidados.reduce((sum, p) => sum + p.volumeHectolitro, 0);

    const checklistDivergencias = divergentes.map(p => 
      `- SKU: ${p.sku} | ${p.descricao} | Cat: ${p.categoria} | Diferença: ${p.diferencaCaixas} cx | Impacto Financeiro: R$ ${p.divergenciaValor.toFixed(2)} | HL: ${p.divergenciaHectolitro.toFixed(2)}`
    ).join("\n");

    const lotesCriticos = lotesValidadeState
      .filter(l => l.alertaStatus === 'Crítico' || l.diasParaVencer <= 30)
      .map(l => `- Lote ${l.numeroLote} (SKU ${l.sku}): vence em ${l.dataValidade} (${l.diasParaVencer} dias restantes) | Volume: ${l.quantidadeCaixas} cx`).join("\n");

    const prompt = `
Você é um Engenheiro de Logística Sênior e Especialista em WMS da plataforma ConsiliWMS.
Analise a fotografia de estoque do armazém e formate uma análise operacional e executiva extremamente detalhada em formato JSON estruturado.

### RESUMO CONSOLIDADO DO ARMAZÉM:
- Valor Total do Estoque: R$ ${totalFinanceiro.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
- Volume Total em Hectolitros: ${volumeHL.toFixed(2)} HL
- Itens de Curva A (80% Giro): ${curvaA.map(p => `${p.sku} (${p.vendaMensalMediaCaixas} cx/mês)`).join(", ")}

### RELATÓRIO DE DIVERGÊNCIAS DETECTADAS (ESTOQUE FÍSICO x SISTEMA):
${checklistDivergencias || "Nenhuma divergência detectada no inventário atual!"}

### ALERTAS DE VALIDADE / RISCOS DE QUEBRA DE FEFO:
${lotesCriticos || "Nenhum lote com vencimento crítico pendente."}

### REGRAS DO NEGÓCIO PARA INSIGHTS:
1. Curva A (Verde) precisa ficar o mais perto possível da expedição. Identifique se SKUs de Alto Giro estão de fato alocados adequadamente (Cerveja Premium CER001, Guaraná NAB001, Mineral NAB003).
2. Proponha planos operacionais para auditoria das divergências físicas x fiscais de maior materialidade financeira (especialmente os divergentes de alto custo).
3. Avalie quebra de FEFO em lotes curtos e proponha ações imediatas de recall interno ou descontos de cross-docking rápidos.
4. Identifique gargalos e de rupturas se houver estoque físico menor que a média de giro semanal ou se o picking estiver abaixo do ponto de ressuprimento.

Gere uma resposta na linguagem PORTUGUÊS (BR) EM ESTREITO FORMATO JSON.
Não envolva com blocos de código markdown nem outros textos adicionais fora do JSON.
O JSON deve obedecer à risca esta estrutura:
{
  "resumoExecutivo": "Texto curto resumindo a integridade do estoque físico x sistema.",
  "principaisAlertas": [
    { "titulo": "Título Curto", "nivel": "Critico|Atencao|Normal", "analise": "Descrição do problema e os SKUs afetados." }
  ],
  "auditoriaEstoqueSugerida": "Texto com o passo a passo tático para o encarregado descobrir o motivo das divergências financeiras no inventário.",
  "otimizacaoLayoutWMS": {
    "diagnostico": "Análise se as regras de armazenagem inteligente estão sendo violadas pelos layouts.",
    "sugestoesMapeamento": "Propostas práticas de remanejamento para Curva A, B, C e Marketplace segregado (Azul)."
  },
  "conclusoesFefo": "Análise da gestão de estoque FEFO e plano de ação preventivo contra perdas por vencimento."
}
`;

    if (aiCliente) {
      console.log("Requesting Gemini insights layout analyze...");
      const response = await aiCliente.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });

      const responseText = response.text || "{}";
      const cleanedJson = responseText.trim();
      
      try {
        const parsedInsights = JSON.parse(cleanedJson);
        return res.json({ success: true, insights: parsedInsights });
      } catch (parseError) {
        console.error("Erro ao fazer parse do JSON do Gemini. Resposta crua:", responseText);
        // Fallback se o JSON vier mal formatado
        return res.json({ 
          success: true, 
          insights: fallbackGeneration(produtosConsolidados, lotesValidadeState)
        });
      }
    } else {
      console.log("API Key não definida. Gerando insights via algoritmo embutido (offline-mode)...");
      return res.json({
        success: true,
        insights: fallbackGeneration(produtosConsolidados, lotesValidadeState)
      });
    }

  } catch (error: any) {
    console.error("Erro durante o processamento de insights por IA:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Endpoint de Chat com IA com injeção de contexto em tempo real do WMS
app.post("/api/ai/chat", async (req, res) => {
  const { prompt, contextoEstoque } = req.body;
  
  if (!prompt) {
    return res.status(400).json({ success: false, error: "O prompt é obrigatório para interagir com a IA." });
  }

  try {
    if (aiCliente) {
      console.log("Recebendo mensagem do conferente no chat...");
      const systemInstruction = `Você é o Coordenador Sênior e Auditor de Estoque de IA da plataforma ConsiliWMS.
Você tem acesso completo à base de dados consolidados do armazém em tempo real:
${JSON.stringify(contextoEstoque || [])}

Sua missão é responder à dúvida, reclamação ou instrução do conferente de forma direta, tática e extremamente profissional, focada na otimização WMS do CD.
Seja breve (máximo de 3 parágrafos ou marcadores objetivos).
Responda sempre em PORTUGUÊS (BR).
Priorize: acurácia física, mitigação de divergências financeiras, organização de fluxo de pallets por Pareto 80/20, gestão FEFO de expiração rápida de lotes e abastecimento ágil de picking térreo.`;

      const response = await aiCliente.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.6
        }
      });

      return res.json({ 
        success: true, 
        answer: response.text || "Sem resposta gerada pelo modelo." 
      });
    } else {
      // Fallback offline se a API key não estiver setada
      console.log("Chat AI offline fallback...");
      const formattedValue = prompt.toLowerCase();
      let answer = "Estou rodando em modo diagnóstico offline WMS. Sugiro auditar os últimos lançamentos do ERP e realizar uma recontagem na posição do SKU em questão para sanizar divergências.";
      
      if (formattedValue.includes("mais crítico") || formattedValue.includes("crítico")) {
        const maisCritico = (contextoEstoque && contextoEstoque.length > 0) 
          ? [...contextoEstoque].sort((a: any, b: any) => Math.abs(b.diferenca) - Math.abs(a.diferenca))[0]
          : null;
        
        if (maisCritico) {
          answer = `Analisando a base em tempo real: O SKU mais crítico em divergência de estoque físico no armazém hoje é o <strong>${maisCritico.sku} (${maisCritico.descricao})</strong>, registrando uma diferença de <strong>${maisCritico.diferenca} caixas</strong> (impacto de R$ ${Math.abs(maisCritico.valorDivergencia).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}). Recomenda-se o bloqueio da posição de movimentação para auditoria.`;
        } else {
          answer = "Identificamos o SKU CER001 (Cerveja Lager Premium Gold 350ml) como o item com maior discrepância volumétrica ativa, apresentando divergência de -30 caixas entre o físico e o fiscal.";
        }
      } else if (formattedValue.includes("cer001") || formattedValue.includes("colocação") || (formattedValue.includes("layout") && formattedValue.includes("cer001"))) {
        answer = "Para o SKU CER001, classificado na <strong>Curva A (Giro Altíssimo)</strong>, o Zoneamento Inteligente WMS aconselha posicioná-lo exclusivamente no Bloco de Picking Central (Corredor A, módulo 1 ao 3, nível térat), reduzindo o tempo de empilhamento de doca e ciclo de transbordo (cross-docking).";
      } else if (formattedValue.includes("fefo") || formattedValue.includes("validade")) {
        answer = "A matriz de gestão FEFO indica que temos lotes de validade vencida ou com menos de 30 dias de vida útil no Bloco B. Lote semente L088 do SKU MTP001 está retido temporariamente para auditoria de devolução ou refugo.";
      } else if (formattedValue.includes("layout") || formattedValue.includes("pareto")) {
        answer = "De acordo com as leis do gráfico acumulado de Pareto (80/20), itens de Curva A (giro dinâmico acelerado) devem ser locados preferencialmente nas colunas 1 a 4 dos racks térreos das ruas de picking, enquanto SKUs de Curva C (baixo fluxo) devem subir para os níveis 3 e 4 das posições de corredor profundo.";
      } else if (formattedValue.includes("sumário") || formattedValue.includes("acurácia") || formattedValue.includes("estoque total")) {
        const totalDivergentesCount = contextoEstoque ? contextoEstoque.filter((p: any) => Math.abs(p.diferenca) > 0.001).length : 2;
        const totalSKUs = contextoEstoque ? contextoEstoque.length : 10;
        answer = `Sumário de Acurácia Geral WMS:<br/>&#8226; Total de SKUs monitorados: <strong>${totalSKUs}</strong><br/>&#8226; SKUs com discrepância pendente: <strong>${totalDivergentesCount}</strong><br/>&#8226; Taxa de Acurácia Operacional de inventário: <strong>${((totalSKUs - totalDivergentesCount)/totalSKUs * 100).toFixed(1)}%</strong>.<br/>A divergência líquida acumulada é monitorada pelo painel executivo com atualização retroativa de 10 dias.`;
      }

      return res.json({ success: true, answer });
    }
  } catch (error: any) {
    console.error("Erro no proxy de chat da IA:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Algoritmo determinístico offline se o Gemini estiver sem credenciais válidas
function fallbackGeneration(consolidado: any[], lotes: any[]) {
  const divergentesVal = consolidado.reduce((sum, p) => sum + Math.abs(p.divergenciaValor), 0);
  const criticosCount = lotes.filter(l => l.alertaStatus === 'Crítico').length;

  return {
    resumoExecutivo: "O estoque apresenta uma acurácia física média aceitável, mas com discrepâncias rotativas em alguns SKUs de alto giro que comprometem a valoração de fechamento.",
    principaisAlertas: [
      {
        titulo: "Diferença Física x Fiscal Detectada",
        nivel: "Atencao",
        analise: `Total de R$ ${divergentesVal.toLocaleString("pt-BR", { maximumFractionDigits: 2 })} em variâncias materiais de inventário, afetando principalmente canais refrigerados.`
      },
      {
        titulo: "Risco Ativo de Expiração Lotes (FEFO)",
        nivel: "Critico",
        analise: `Identificados ${criticosCount} lotes em status crítico ou vencidos necessitando descarte emergencial na segregação sanitária.`
      }
    ],
    auditoriaEstoqueSugerida: "1. Realizar recontagem cegamento (Double-Check) nos SKUs do grupo Cervejas com divergência.\n2. Cruzar as planilhas fiscais com os registros de notas fiscais de devolução recentes no ERP.\n3. Iniciar auditoria de inventário rotativo diário nas zonas de picking à noite.",
    otimizacaoLayoutWMS: {
      diagnostico: "Itens de Curva A (Cerveja Premium CER001, Guaraná NAB001) estão com alta dispersão, aumentando tempo médio de viagem do operador (Travel Time).",
      sugestoesMapeamento: "Concentrar pallets de CER001 nas primeiras posições da Rua 1 e Rua 2. Isolar itens de Marketplace na Rua 5 segregada com demarcação azul."
    },
    conclusoesFefo: "Habilitar alertas de validade no WMS em 60 dias para Curva A e 90 dias para parceiros de baixo giro da curva C."
  };
}

// Endpoint para receber arquivos descompactados do ZIP e gravá-los diretamente no workspace
app.post("/api/state/merge-uploaded-zip-files", (req, res) => {
  const { files } = req.body;
  
  if (!files || !Array.isArray(files)) {
    return res.status(400).json({ success: false, error: "Formato de arquivos inválido. Requer uma lista de arquivos." });
  }

  try {
    const writtenFiles = [];
    for (const file of files) {
      const { path: relativePath, content } = file;
      
      if (!relativePath || typeof content !== "string") continue;

      // Sanitiza o path para evitar directory traversal
      let sanitizedPath = relativePath.replace(/\\/g, "/").trim();
      // Remove barras iniciais ou caminhos relativos perigosos
      sanitizedPath = sanitizedPath.replace(/^(\.\.\/)+/, "").replace(/^\/+/, "");

      // Requisito de segurança: os arquivos integrados devem ficar apenas dentro de 'src/'
      if (!sanitizedPath.startsWith("src/")) {
        console.warn(`[ZIP MERGER] Ignorando arquivo fora de 'src/': ${sanitizedPath}`);
        continue;
      }

      const absoluteFilePath = path.join(process.cwd(), sanitizedPath);

      // Garante que o diretório pai existe
      const parentDir = path.dirname(absoluteFilePath);
      if (!fs.existsSync(parentDir)) {
        fs.mkdirSync(parentDir, { recursive: true });
      }

      // Grava o arquivo de forma limpa
      fs.writeFileSync(absoluteFilePath, content, "utf-8");
      writtenFiles.push(sanitizedPath);
      console.log(`[ZIP MERGER] Arquivo integrado com sucesso no workspace: ${sanitizedPath}`);
    }

    res.json({
      success: true,
      message: `Integração concluída! Os seguintes arquivos foram gravados com sucesso: ${writtenFiles.join(", ")}`,
      writtenFiles
    });
  } catch (error: any) {
    console.error("Erro ao integrar arquivos do ZIP:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Helper functions for stock inversion
function nameNormalize(str: string): string {
  return (str || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function getEmbalagem(descricao: string): string {
  const desc = nameNormalize(descricao);
  if (desc.includes("lata") || desc.includes("lt") || desc.includes("can")) return "LATA";
  if (desc.includes("pet") || desc.includes("garrafa pet")) return "PET";
  if (desc.includes("garrafa") || desc.includes("ln") || desc.includes("lnv") || desc.includes("long neck") || desc.includes("lf") || desc.includes("ow") || desc.includes("ret")) return "GARRAFA";
  return "OUTRO";
}

// 1. Endpoint for AI Inversion Recommendations
app.post("/api/ai/inversion-recommendations", async (req, res) => {
  try {
    const produtosConsolidados = processarBasesDados(
      estoqueAtualState,
      inventarioState,
      caixasPalletState,
      vendasMediasState,
      divergenciasCongeladasState
    );

    const sobras = produtosConsolidados.filter(p => p.diferencaCaixas > 0.001);
    const faltas = produtosConsolidados.filter(p => p.diferencaCaixas < -0.001);

    const candidates: any[] = [];

    sobras.forEach(sob => {
      const embalagemSobVal = getEmbalagem(sob.descricao);
      
      faltas.forEach(fal => {
        const embalagemFalVal = getEmbalagem(fal.descricao);
        
        if (sob.categoria === fal.categoria && embalagemSobVal === embalagemFalVal) {
          const limitQty = Math.min(sob.diferencaCaixas, Math.abs(fal.diferencaCaixas));
          
          candidates.push({
            sopSku: sob.sku,
            sopDesc: sob.descricao,
            sopSobra: sob.diferencaCaixas,
            sobCusto: sob.custoMedio,
            falSku: fal.sku,
            falDesc: fal.descricao,
            falFalta: fal.diferencaCaixas,
            falCusto: fal.custoMedio,
            categoria: sob.categoria,
            embalagem: embalagemSobVal,
            caixasSugeridas: limitQty,
            hlSugeridos: limitQty * sob.fatorHectolitro,
            valorBalanciado: limitQty * sob.custoMedio
          });
        }
      });
    });

    const hasAI = !!aiCliente;
    let finalRecommendations: any[] = [];

    if (hasAI && candidates.length > 0) {
      console.log("Analyzing stock inversion candidates with Gemini for CD...");
      
      const briefCandidates = candidates.map((c, idx) => 
        `Candidato #${idx}:
- Sobra: SKU ${c.sopSku} (${c.sopDesc}) | Qtd Sobra: +${c.sopSobra} cx
- Falta: SKU ${c.falSku} (${c.falDesc}) | Qtd Falta: ${c.falFalta} cx
- Limite de Inversão Sugerida: ${c.caixasSugeridas} cx`
      ).join("\n\n");

      const prompt = `
Você é uma inteligência artificial especialista em Auditoria Contábil de Estoque e Otimização Logística Ambev.
Sua tarefa é analisar os candidatos à Inversão Física de Estoque (onde um produto similar está sobrando e outro similar está faltando) e gerar relatórios executivos com viabilidade técnica.

### CANDIDATOS DETECTADOS NO INVENTÁRIO DO CD:
${briefCandidates}

### INSTRUÇÕES:
Para cada Candidato, você deve gerar uma análise concisa e fundamentada em português:
- **justificativa**: Explique por que esses produtos são intercambiáveis (por exemplo: "Ambos pertencem ao grupo de cervejas lata de mesmo volume. Realizar a inversão compensa fisicamente o saldo e regulariza a conta de pendências do armazém sem impacto na cubagem por tipo de vasilhame.").
- **grauViabilidade**: Atribua um nível de viabilidade ("ALTA" | "MÉDIA" | "BAIXA").
- **impacto**: Qual é o impacto financeiro ou desvio estimado.

Gere uma resposta na linguagem PORTUGUÊS (BR) EM ESTREITO FORMATO JSON.
Não inclua blocos markdown nem comentários fora do JSON.
A estrutura de retorno desejada deve ser uma lista de recomendações com a mesma ordem dos candidatos:
{
  "recommendations": [
    {
      "index": 0,
      "grauViabilidade": "ALTA",
      "justificativa": "Texto explicativo...",
      "impacto": "Mínimo / Compensado"
    }
  ]
}
`;

      const response = await aiCliente!.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const responseText = response.text || "{}";
      try {
        const parsed = JSON.parse(responseText.trim());
        const list = parsed.recommendations || [];
        
        finalRecommendations = candidates.map((c, idx) => {
          const matchedAi = list.find((item: any) => item.index === idx);
          return {
            ...c,
            viabilidade: matchedAi ? matchedAi.grauViabilidade : "ALTA",
            justificativa: matchedAi ? matchedAi.justificativa : `Inversão equilibrada de ${c.embalagem} no grupo ${c.categoria}. Compensação direta de diferenças contábeis.`,
            detalheImpacto: matchedAi ? matchedAi.impacto : "Saldo regulado de imediato no WMS."
          };
        });
      } catch (err) {
        console.warn("Error parsing Gemini swap recommendations JSON, falling back...", err);
        finalRecommendations = candidates.map(c => ({
          ...c,
          viabilidade: "ALTA",
          justificativa: `Inversão balanceada nativa. Ambos são ${c.embalagem} pertencentes à categoria ${c.categoria}. A compensação mútua reduz as diferenças de estoque sem desequilibrar a volumetria por grupo.`,
          detalheImpacto: "Ajuste direto contábil e físico."
        }));
      }
    } else {
      finalRecommendations = candidates.map(c => ({
        ...c,
        viabilidade: "ALTA",
        justificativa: `Inversão recomendada pelo algoritmo de afinidades de embalagem do CD Pau Brasil. Ambos são itens similares do tipo ${c.embalagem} sob a categoria ${c.categoria}. A inversão permite compensar a sobra de um com a falta de outro.`,
        detalheImpacto: "Acurácia do CD aproximada a 100% de forma flat."
      }));
    }

    res.json({ success: true, candidates: finalRecommendations });

  } catch (error: any) {
    console.error("Erro nas recomendações de inversão:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 2. Endpoint to Execute Stock Inversion
app.post("/api/state/invert-stock", (req, res) => {
  const { skuSobra, skuFalta, caixasInvertidas, usuario } = req.body;

  if (!skuSobra || !skuFalta || !caixasInvertidas || caixasInvertidas <= 0) {
    return res.status(400).json({ success: false, error: "SKUs de sobra, falta e quantidade válida de caixas são obrigatórios." });
  }

  try {
    const userEmail = usuario || "djesoaresn@gmail.com";
    const qtd = Number(caixasInvertidas);

    const estSobra = estoqueAtualState.find(e => e.sku === skuSobra);
    const estFalta = estoqueAtualState.find(e => e.sku === skuFalta);

    const descSobra = estSobra ? estSobra.descricao : skuSobra;
    const descFalta = estFalta ? estFalta.descricao : skuFalta;
    const custo = estSobra ? estSobra.custoMedio : 30.00;

    let idxSobra = inventarioState.findIndex(i => i.sku === skuSobra);
    if (idxSobra === -1) {
      const invSist = estSobra ? Math.floor(estSobra.quantidadeAtualCaixas) : 0;
      inventarioState.push({
        sku: skuSobra,
        estoqueFisicoCaixas: invSist - qtd,
        estoqueSistemaCaixas: invSist
      });
    } else {
      inventarioState[idxSobra].estoqueFisicoCaixas = Math.max(0, inventarioState[idxSobra].estoqueFisicoCaixas - qtd);
    }

    let idxFalta = inventarioState.findIndex(i => i.sku === skuFalta);
    if (idxFalta === -1) {
      const invSist = estFalta ? Math.floor(estFalta.quantidadeAtualCaixas) : 0;
      inventarioState.push({
        sku: skuFalta,
        estoqueFisicoCaixas: invSist + qtd,
        estoqueSistemaCaixas: invSist
      });
    } else {
      inventarioState[idxFalta].estoqueFisicoCaixas = inventarioState[idxFalta].estoqueFisicoCaixas + qtd;
    }

    const logId = `INV${Date.now().toString().slice(-6)}`;
    const totalFinanceiroInversao = qtd * custo;
    const descricaoAudit = `Inversão Inteligente realizada via IA pelo Conferente: SKU ${skuSobra} (-${qtd} cx) para equilibrar SKU ${skuFalta} (+${qtd} cx).`;
    
    logsAuditoria.unshift({
      id: logId,
      data: new Date().toISOString(),
      usuario: userEmail,
      skusAjustados: 2,
      totalValorAjustado: totalFinanceiroInversao,
      descricao: descricaoAudit
    });

    savePersistedState();

    res.json({ 
      success: true, 
      message: `Inversão aplicada com sucesso: SKU ${skuSobra} reduzido e SKU ${skuFalta} incrementado em ${qtd} caixas.`,
      logId,
      descricaoAudit
    });

  } catch (error: any) {
    console.error("Erro ao aplicar inversão inteligente de estoque:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 3. Endpoint for Intelligent AI Multi-SKU Group Inversion Suggestions
app.post("/api/ai/inversion-recommendations-multi", async (req, res) => {
  try {
    const { sobras, faltas, categoria, embalagem } = req.body;

    if (!sobras || !faltas || !Array.isArray(sobras) || !Array.isArray(faltas)) {
      return res.status(400).json({ success: false, error: "As listas de sobras e faltas são obrigatórias." });
    }

    const hasAI = !!aiCliente;
    let suggestions: { saidas: any[]; entradas: any[] } = { saidas: [], entradas: [] };

    if (hasAI && (sobras.length > 0 && faltas.length > 0)) {
      console.log(`Analyzing Multi-SKU balance with Gemini for Group: ${categoria} | Embalagem: ${embalagem}...`);

      const listSobras = sobras.map(s => `- SKU: ${s.sku} | Descrição: ${s.descricao} | Sobra de Estoque (Físico > Fiscal): +${s.sobra} cx | Custo: R$ ${s.custoMedio} cx`).join("\n");
      const listFaltas = faltas.map(f => `- SKU: ${f.sku} | Descrição: ${f.descricao} | Falta de Estoque (Físico < Fiscal): -${f.falta} cx | Custo: R$ ${f.custoMedio} cx`).join("\n");

      const prompt = `
Você é uma inteligência artificial especialista em Auditoria Contábil de Estoque e Otimização Logística Ambev do CD Pau Brasil.
Seu objetivo é analisar as Sobras (produtos com estoque físico maior que fiscal) e Faltas (produtos com estoque físico menor que fiscal) pertencentes ao grupo "${categoria}" com embalagem "${embalagem}".
Sua tarefa é criar uma compensação/inversão de estoque com quantidade em números inteiros ("SKU fechado") que busque zerar ou minimizar ao máximo as divergências sem ferir a cubagem física.
Você deve planejar a permuta de caixas de forma que o TOTAL DE CAIXAS SAINDO (das sobras) seja exatamente igual ao TOTAL DE CAIXAS ENTRANDO (para as faltas). 

### ITENS COM SOBRA CONTÁBIL (FÍSICO > SISTEMA):
${listSobras}

### ITENS COM FALTA CONTÁBIL (FÍSICO < SISTEMA):
${listFaltas}

### EXEMPLO DE COMPENSAÇÃO:
Se temos SKU A com sobra de +5 cx, SKU B com falta de -4 cx, e SKU C com falta de -1 cx:
- Saídas planejadas: SKU A (5 cx)
- Entradas planejadas: SKU B (4 cx), SKU C (1 cx)
Total Saídas = 5 cx; Total Entradas = 5 cx. (Balanço Perfeito).

### REGRAS CRÍTICAS:
1. Trabalhe apenas com quantidades INTEIRAS (caixas fechadas). Não use casas decimais.
2. A quantidade planejada para saída de cada SKU Sobra não deve ultrapassar o seu limite positivo de sobra.
3. A quantidade planejada para entrada de cada SKU Falta não deve ultrapassar o limite absoluto da sua falta.
4. O total de caixas sob "saidas" deve ser RIGOROSAMENTE IGUAL ao total de caixas sob "entradas". Se houver mais sobra do que falta ou vice-versa, reduza proporcionalmente até que as somas de caixas batam perfeitamente.
5. Justifique a permuta com autoridade técnica de conferente e auditor operacional.

Gere uma resposta na linguagem PORTUGUÊS (BR) EM ESTREITO FORMATO JSON.
Não inclua blocos markdown nem comentários fora do JSON.
Estrutura desejada de retorno:
{
  "sucesso": true,
  "justificativa": "Texto justificando a permuta técnica...",
  "saidas": [
    { "sku": "9068", "caixas": 5 }
  ],
  "entradas": [
    { "sku": "9067", "caixas": 4 },
    { "sku": "9069", "caixas": 1 }
  ]
}
`;

      const response = await aiCliente!.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const responseText = response.text || "{}";
      try {
        const parsed = JSON.parse(responseText.trim());
        suggestions.saidas = parsed.saidas || [];
        suggestions.entradas = parsed.entradas || [];
        res.json({ 
          success: true, 
          justificativa: parsed.justificativa || "Equilíbrio sugerido para equalizar o físico e o fiscal de embalagens similares.",
          saidas: suggestions.saidas,
          entradas: suggestions.entradas
        });
        return;
      } catch (err) {
        console.warn("Error parsing Gemini multi-swap output, falling back to heuristic...", err);
      }
    }

    // Heuristic Fallback / If AI is off
    const sortedSobras = [...sobras].sort((a,b) => b.sobra - a.sobra);
    const sortedFaltas = [...faltas].sort((a,b) => b.falta - a.falta);
    
    let totalSobraCaixas = sortedSobras.reduce((sum, s) => sum + Math.floor(s.sobra), 0);
    let totalFaltaCaixas = sortedFaltas.reduce((sum, f) => sum + Math.floor(f.falta), 0);
    let targetCaixas = Math.min(totalSobraCaixas, totalFaltaCaixas);

    const outSaidas: any[] = [];
    const outEntradas: any[] = [];

    // Aloca saídas até o target
    let allocatedSobra = 0;
    for (const sob of sortedSobras) {
      const limit = Math.floor(sob.sobra);
      if (limit <= 0) continue;
      const toTake = Math.min(limit, targetCaixas - allocatedSobra);
      if (toTake > 0) {
        outSaidas.push({ sku: sob.sku, caixas: toTake });
        allocatedSobra += toTake;
      }
      if (allocatedSobra >= targetCaixas) break;
    }

    // Aloca entradas até o target
    let allocatedFalta = 0;
    for (const fal of sortedFaltas) {
      const limit = Math.floor(fal.falta);
      if (limit <= 0) continue;
      const toTake = Math.min(limit, targetCaixas - allocatedFalta);
      if (toTake > 0) {
        outEntradas.push({ sku: fal.sku, caixas: toTake });
        allocatedFalta += toTake;
      }
      if (allocatedFalta >= targetCaixas) break;
    }

    res.json({
      success: true,
      justificativa: "Equilíbrio estático sugerido pela inteligência de contingência do CD Pau Brasil para compensação direta.",
      saidas: outSaidas,
      entradas: outEntradas
    });

  } catch (err: any) {
    console.error("Erro no recomendador multi-SKU:", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Endpoint to Execute Multi-SKU Group Stock Inversion
app.post("/api/state/invert-stock-multi", (req, res) => {
  const { saidas, entradas, grupo, usuario } = req.body;

  if (!saidas || !entradas || !Array.isArray(saidas) || !Array.isArray(entradas)) {
    return res.status(400).json({ success: false, error: "As listas de saídas (sobras) e entradas (faltas) são obrigatórias." });
  }

  const totalSaidas = saidas.reduce((acc, s) => acc + Number(s.caixas), 0);
  const totalEntradas = entradas.reduce((acc, e) => acc + Number(e.caixas), 0);

  if (totalSaidas !== totalEntradas || totalSaidas <= 0) {
    return res.status(400).json({
      success: false,
      error: `Divergência de compensação: o total de saídas (${totalSaidas} cx) precisa ser exatamente igual ao total de entradas (${totalEntradas} cx) e maior que zero.`
    });
  }

  try {
    const userEmail = usuario || "djesoaresn@gmail.com";
    let skusAjustados = 0;
    let totalValorAjustado = 0;

    // Processar Saídas (Saindo do estoque - reduz física, aproxima do fiscal que é menor)
    for (const s of saidas) {
      const sku = s.sku;
      const qtd = Number(s.caixas);
      if (qtd <= 0) continue;

      const est = estoqueAtualState.find(e => e.sku === sku);
      const custo = est ? est.custoMedio : 30.00;
      totalValorAjustado += qtd * custo;
      skusAjustados++;

      let idx = inventarioState.findIndex(i => i.sku === sku);
      if (idx === -1) {
        const invSist = est ? Math.floor(est.quantidadeAtualCaixas) : 0;
        inventarioState.push({
          sku,
          estoqueFisicoCaixas: invSist - qtd,
          estoqueSistemaCaixas: invSist
        });
      } else {
        inventarioState[idx].estoqueFisicoCaixas = Math.max(0, inventarioState[idx].estoqueFisicoCaixas - qtd);
      }
    }

    // Processar Entradas (Entrando no estoque - aumenta física, aproxima do fiscal que é maior)
    for (const e of entradas) {
      const sku = e.sku;
      const qtd = Number(e.caixas);
      if (qtd <= 0) continue;

      const est = estoqueAtualState.find(ee => ee.sku === sku);
      const custo = est ? est.custoMedio : 30.00;
      skusAjustados++;

      let idx = inventarioState.findIndex(i => i.sku === sku);
      if (idx === -1) {
        const invSist = est ? Math.floor(est.quantidadeAtualCaixas) : 0;
        inventarioState.push({
          sku,
          estoqueFisicoCaixas: invSist + qtd,
          estoqueSistemaCaixas: invSist
        });
      } else {
        inventarioState[idx].estoqueFisicoCaixas = inventarioState[idx].estoqueFisicoCaixas + qtd;
      }
    }

    const logId = `INV${Date.now().toString().slice(-6)}`;
    const labelSaidas = saidas.map(s => `SKU ${s.sku.replace(/^0+/, '')} (-${s.caixas} cx)`).join(", ");
    const labelEntradas = entradas.map(e => `SKU ${e.sku.replace(/^0+/, '')} (+${e.caixas} cx)`).join(", ");
    
    const descricaoAudit = `Inversão Inteligente de Grupo [${grupo}] realizada pelo Conferente: Saídas: [${labelSaidas}] | Entradas: [${labelEntradas}]. Compensado em lote.`;

    logsAuditoria.unshift({
      id: logId,
      data: new Date().toISOString(),
      usuario: userEmail,
      skusAjustados,
      totalValorAjustado,
      descricao: descricaoAudit
    });

    savePersistedState();

    res.json({
      success: true,
      message: `Inversão de Grupo aplicada com sucesso: ${skusAjustados} SKUs compensados no lote para equilibrar físico e fiscal.`,
      logId,
      descricaoAudit
    });

  } catch (error: any) {
    console.error("Erro ao aplicar inversão inteligente multi-SKU de estoque:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});


// ==========================================
// VITE CONTROLLER / STATIC PRODUCTION DELIVERY
// ==========================================
if (process.env.NODE_ENV !== "production") {
  createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  }).then(vite => {
    app.use(vite.middlewares);
    
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Development Server running on Port http://localhost:${PORT}`);
    });
  });
} else {
  const distPath = path.join(process.cwd(), 'dist');
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Production WMS Server serving static bundle on http://localhost:${PORT}`);
  });
}
