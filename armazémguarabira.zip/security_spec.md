# Security Specification: ConsiliWMS CD Guarabira Firebase

This specification outlines the data invariants, threat vectors, and hardened constraints protecting our real-time warehouse data.

## 1. Data Invariants

- **Productivity & Audit Logs Immutability**: Once written, productivity metrics and audit logs (`/productivity/*` and `/audit_logs/*`) represent legal warehouse and labor logs. They must NEVER be updated or deleted by client SDKs.
- **Strict Size/Type Constraining**: Any text field (e.g., `operador`, `observacao`) must have strict upper bounds to prevent Denial of Wallet payload bloat.
- **Identity Integrity**: Warehouse employees can only log productivity entries attributing the action safely to their authenticated session (`request.auth.uid` or matches authenticated email/matrícula).
- **Authorized Actions**: Only authenticated users with verified details can execute writes.

## 2. The "Dirty Dozen" Payloads

We design these twelve rogue payloads to attack our three exposed collections, testing and proving that our ruleset blocks them with a `PERMISSION_DENIED`:

### Collection: `productivity`
1. **Ghost Field Injection (Shadow Update / Value Poisoning)**: Create/update payload with a rogue administrative field (`isAdmin: true`).
2. **Identity Spoofing**: Operator Carlos tries to insert a productivity entry setting the `operador` identifier to a different UID or name.
3. **Malicious ID (ID Poisoning)**: Attempt to create a document with a bloated string (e.g., 2000-character gibberish) as the ID.
4. **Denial of Wallet (String Bloating)**: Operator sends a massive 1MB string inside the `operador` field.
5. **Unauthorized Mutation (Labor History Tampering)**: An regular operator attempts to `update` or `delete` an existing productivity log item to erase mistakes or cover slow work.
6. **Type Safety Violation**: Send `quantidadeCaixas: "one hundred"` (string) instead of a float/integer number.

### Collection: `congealed_discrepancies`
7. **Phantom Discrepancy Creation**: An unauthenticated or unverified client attempts to push a frozen discrepancy document.
8. **Negative Impact Price Injection**: Pushing a discrepancy with a negative price factor `custoPorSku: -502.20` to disrupt financial indices.
9. **Divergent State Overwrite**: Attempting to execute `allow write` on a completed or terminal status discrepancy without manager clearance.

### Collection: `audit_logs`
10. **System Log Hijacking**: Client attempts to delete historical audit trails (`/audit_logs/*`) to erase evidence of manual adjustments.
11. **Rogue Audit Entry**: Operator Carlos tries to create an audit entry with a simulated timestamp `data: "2010-01-01T00:00:00Z"` instead of using the mandatory server timestamp `request.time`.
12. **Blanket Query Scraping**: Running a broad, unfiltered client-side request for other users' logs before first restricting by auth state.

---

## 3. Test Runner Specification (`firestore.rules.test.ts`)

A automated testing suite would execute each payload against the emulator.
Because our platform uses our live production rules compilation, we translate these threat vectors directly into our firewall specifications in `firestore.rules`.
